import {
    a as e
} from "./chunk-BEqpzyXh.js";
import {
    n as t
} from "./jsx-runtime-B4RpOl0S.js";
import {
    t as n
} from "./preload-helper-rov5CBGT.js";
var r = e(t(), 1),
    i = `popstate`;

function a(e) {
    return typeof e == `object` && !!e && `pathname` in e && `search` in e && `hash` in e && `state` in e && `key` in e
}

function o(e = {}) {
    function t(e, t) {
        let n = t.state ? .masked,
            {
                pathname: r,
                search: i,
                hash: a
            } = n || e.location;
        return d(``, {
            pathname: r,
            search: i,
            hash: a
        }, t.state && t.state.usr || null, t.state && t.state.key || `default`, n ? {
            pathname: e.location.pathname,
            search: e.location.search,
            hash: e.location.hash
        } : void 0)
    }

    function n(e, t) {
        return typeof t == `string` ? t : f(t)
    }
    return m(t, n, null, e)
}

function s(e, t) {
    if (e === !1 || e == null) throw Error(t)
}

function c(e, t) {
    if (!e) try {
        throw Error(t)
    } catch {}
}

function l() {
    return Math.random().toString(36).substring(2, 10)
}

function u(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t,
        masked: e.unstable_mask ? {
            pathname: e.pathname,
            search: e.search,
            hash: e.hash
        } : void 0
    }
}

function d(e, t, n = null, r, i) {
    return {
        pathname: typeof e == `string` ? e : e.pathname,
        search: ``,
        hash: ``,
        ...typeof t == `string` ? p(t) : t,
        state: n,
        key: t && t.key || r || l(),
        unstable_mask: i
    }
}

function f({
    pathname: e = `/`,
    search: t = ``,
    hash: n = ``
}) {
    return t && t !== `?` && (e += t.charAt(0) === `?` ? t : `?` + t), n && n !== `#` && (e += n.charAt(0) === `#` ? n : `#` + n), e
}

function p(e) {
    let t = {};
    if (e) {
        let n = e.indexOf(`#`);
        n >= 0 && (t.hash = e.substring(n), e = e.substring(0, n));
        let r = e.indexOf(`?`);
        r >= 0 && (t.search = e.substring(r), e = e.substring(0, r)), e && (t.pathname = e)
    }
    return t
}

function m(e, t, n, r = {}) {
    let {
        window: o = document.defaultView,
        v5Compat: s = !1
    } = r, c = o.history, l = `POP`, f = null, p = m();
    p ? ? (p = 0, c.replaceState({ ...c.state,
        idx: p
    }, ``));

    function m() {
        return (c.state || {
            idx: null
        }).idx
    }

    function g() {
        l = `POP`;
        let e = m(),
            t = e == null ? null : e - p;
        p = e, f && f({
            action: l,
            location: b.location,
            delta: t
        })
    }

    function _(e, t) {
        l = `PUSH`;
        let r = a(e) ? e : d(b.location, e, t);
        n && n(r, e), p = m() + 1;
        let i = u(r, p),
            h = b.createHref(r.unstable_mask || r);
        try {
            c.pushState(i, ``, h)
        } catch (e) {
            if (e instanceof DOMException && e.name === `DataCloneError`) throw e;
            o.location.assign(h)
        }
        s && f && f({
            action: l,
            location: b.location,
            delta: 1
        })
    }

    function v(e, t) {
        l = `REPLACE`;
        let r = a(e) ? e : d(b.location, e, t);
        n && n(r, e), p = m();
        let i = u(r, p),
            o = b.createHref(r.unstable_mask || r);
        c.replaceState(i, ``, o), s && f && f({
            action: l,
            location: b.location,
            delta: 0
        })
    }

    function y(e) {
        return h(e)
    }
    let b = {
        get action() {
            return l
        },
        get location() {
            return e(o, c)
        },
        listen(e) {
            if (f) throw Error(`A history only accepts one active listener`);
            return o.addEventListener(i, g), f = e, () => {
                o.removeEventListener(i, g), f = null
            }
        },
        createHref(e) {
            return t(o, e)
        },
        createURL: y,
        encodeLocation(e) {
            let t = y(e);
            return {
                pathname: t.pathname,
                search: t.search,
                hash: t.hash
            }
        },
        push: _,
        replace: v,
        go(e) {
            return c.go(e)
        }
    };
    return b
}

function h(e, t = !1) {
    let n = `http://localhost`;
    typeof window < `u` && (n = window.location.origin === `null` ? window.location.href : window.location.origin), s(n, `No window.location.(origin|href) available to create URL`);
    let r = typeof e == `string` ? e : f(e);
    return r = r.replace(/ $/, `%20`), !t && r.startsWith(`//`) && (r = n + r), new URL(r, n)
}

function g(e, t, n = `/`) {
    return _(e, t, n, !1)
}

function _(e, t, n, r) {
    let i = O((typeof t == `string` ? p(t) : t).pathname || `/`, n);
    if (i == null) return null;
    let a = y(e);
    x(a);
    let o = null;
    for (let e = 0; o == null && e < a.length; ++e) {
        let t = oe(i);
        o = ie(a[e], t, r)
    }
    return o
}

function v(e, t) {
    let {
        route: n,
        pathname: r,
        params: i
    } = e;
    return {
        id: n.id,
        pathname: r,
        params: i,
        data: t[n.id],
        loaderData: t[n.id],
        handle: n.handle
    }
}

function y(e, t = [], n = [], r = ``, i = !1) {
    let a = (e, a, o = i, c) => {
        let l = {
            relativePath: c === void 0 ? e.path || `` : c,
            caseSensitive: e.caseSensitive === !0,
            childrenIndex: a,
            route: e
        };
        if (l.relativePath.startsWith(`/`)) {
            if (!l.relativePath.startsWith(r) && o) return;
            s(l.relativePath.startsWith(r), `Absolute route path "${l.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`), l.relativePath = l.relativePath.slice(r.length)
        }
        let u = A([r, l.relativePath]),
            d = n.concat(l);
        e.children && e.children.length > 0 && (s(e.index !== !0, `Index routes must not have child routes. Please remove all child routes from route path "${u}".`), y(e.children, t, d, u, o)), !(e.path == null && !e.index) && t.push({
            path: u,
            score: ne(u, e.index),
            routesMeta: d
        })
    };
    return e.forEach((e, t) => {
        if (e.path === `` || !e.path ? .includes(`?`)) a(e, t);
        else
            for (let n of b(e.path)) a(e, t, !0, n)
    }), t
}

function b(e) {
    let t = e.split(`/`);
    if (t.length === 0) return [];
    let [n, ...r] = t, i = n.endsWith(`?`), a = n.replace(/\?$/, ``);
    if (r.length === 0) return i ? [a, ``] : [a];
    let o = b(r.join(`/`)),
        s = [];
    return s.push(...o.map(e => e === `` ? a : [a, e].join(`/`))), i && s.push(...o), s.map(t => e.startsWith(`/`) && t === `` ? `/` : t)
}

function x(e) {
    e.sort((e, t) => e.score === t.score ? re(e.routesMeta.map(e => e.childrenIndex), t.routesMeta.map(e => e.childrenIndex)) : t.score - e.score)
}
var S = /^:[\w-]+$/,
    C = 3,
    w = 2,
    T = 1,
    E = 10,
    ee = -2,
    te = e => e === `*`;

function ne(e, t) {
    let n = e.split(`/`),
        r = n.length;
    return n.some(te) && (r += ee), t && (r += w), n.filter(e => !te(e)).reduce((e, t) => e + (S.test(t) ? C : t === `` ? T : E), r)
}

function re(e, t) {
    return e.length === t.length && e.slice(0, -1).every((e, n) => e === t[n]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function ie(e, t, n = !1) {
    let {
        routesMeta: r
    } = e, i = {}, a = `/`, o = [];
    for (let e = 0; e < r.length; ++e) {
        let s = r[e],
            c = e === r.length - 1,
            l = a === `/` ? t : t.slice(a.length) || `/`,
            u = D({
                path: s.relativePath,
                caseSensitive: s.caseSensitive,
                end: c
            }, l),
            d = s.route;
        if (!u && c && n && !r[r.length - 1].route.index && (u = D({
                path: s.relativePath,
                caseSensitive: s.caseSensitive,
                end: !1
            }, l)), !u) return null;
        Object.assign(i, u.params), o.push({
            params: i,
            pathname: A([a, u.pathname]),
            pathnameBase: pe(A([a, u.pathnameBase])),
            route: d
        }), u.pathnameBase !== `/` && (a = A([a, u.pathnameBase]))
    }
    return o
}

function D(e, t) {
    typeof e == `string` && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = ae(e.path, e.caseSensitive, e.end), i = t.match(n);
    if (!i) return null;
    let a = i[0],
        o = a.replace(/(.)\/+$/, `$1`),
        s = i.slice(1);
    return {
        params: r.reduce((e, {
            paramName: t,
            isOptional: n
        }, r) => {
            if (t === `*`) {
                let e = s[r] || ``;
                o = a.slice(0, a.length - e.length).replace(/(.)\/+$/, `$1`)
            }
            let i = s[r];
            return n && !i ? e[t] = void 0 : e[t] = (i || ``).replace(/%2F/g, `/`), e
        }, {}),
        pathname: a,
        pathnameBase: o,
        pattern: e
    }
}

function ae(e, t = !1, n = !0) {
    c(e === `*` || !e.endsWith(`*`) || e.endsWith(`/*`), `Route path "${e}" will be treated as if it were "${e.replace(/\*$/,`/*`)}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/,`/*`)}".`);
    let r = [],
        i = `^` + e.replace(/\/*\*?$/, ``).replace(/^\/*/, `/`).replace(/[\\.*+^${}|()[\]]/g, `\\$&`).replace(/\/:([\w-]+)(\?)?/g, (e, t, n, i, a) => {
            if (r.push({
                    paramName: t,
                    isOptional: n != null
                }), n) {
                let t = a.charAt(i + e.length);
                return t && t !== `/` ? `/([^\\/]*)` : `(?:/([^\\/]*))?`
            }
            return `/([^\\/]+)`
        }).replace(/\/([\w-]+)\?(\/|$)/g, `(/$1)?$2`);
    return e.endsWith(`*`) ? (r.push({
        paramName: `*`
    }), i += e === `*` || e === `/*` ? `(.*)$` : `(?:\\/(.+)|\\/*)$`) : n ? i += `\\/*$` : e !== `` && e !== `/` && (i += `(?:(?=\\/|$))`), [new RegExp(i, t ? void 0 : `i`), r]
}

function oe(e) {
    try {
        return e.split(`/`).map(e => decodeURIComponent(e).replace(/\//g, `%2F`)).join(`/`)
    } catch (t) {
        return c(!1, `The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${t}).`), e
    }
}

function O(e, t) {
    if (t === `/`) return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith(`/`) ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== `/` ? null : e.slice(n) || `/`
}
var se = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;

function ce(e, t = `/`) {
    let {
        pathname: n,
        search: r = ``,
        hash: i = ``
    } = typeof e == `string` ? p(e) : e, a;
    return n ? (n = n.replace(/\/\/+/g, `/`), a = n.startsWith(`/`) ? le(n.substring(1), `/`) : le(n, t)) : a = t, {
        pathname: a,
        search: me(r),
        hash: he(i)
    }
}

function le(e, t) {
    let n = t.replace(/\/+$/, ``).split(`/`);
    return e.split(`/`).forEach(e => {
        e === `..` ? n.length > 1 && n.pop() : e !== `.` && n.push(e)
    }), n.length > 1 ? n.join(`/`) : `/`
}

function k(e, t, n, r) {
    return `Cannot include a '${e}' character in a manually specified \`to.${t}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`
}

function ue(e) {
    return e.filter((e, t) => t === 0 || e.route.path && e.route.path.length > 0)
}

function de(e) {
    let t = ue(e);
    return t.map((e, n) => n === t.length - 1 ? e.pathname : e.pathnameBase)
}

function fe(e, t, n, r = !1) {
    let i;
    typeof e == `string` ? i = p(e) : (i = { ...e
    }, s(!i.pathname || !i.pathname.includes(`?`), k(`?`, `pathname`, `search`, i)), s(!i.pathname || !i.pathname.includes(`#`), k(`#`, `pathname`, `hash`, i)), s(!i.search || !i.search.includes(`#`), k(`#`, `search`, `hash`, i)));
    let a = e === `` || i.pathname === ``,
        o = a ? `/` : i.pathname,
        c;
    if (o == null) c = n;
    else {
        let e = t.length - 1;
        if (!r && o.startsWith(`..`)) {
            let t = o.split(`/`);
            for (; t[0] === `..`;) t.shift(), --e;
            i.pathname = t.join(`/`)
        }
        c = e >= 0 ? t[e] : `/`
    }
    let l = ce(i, c),
        u = o && o !== `/` && o.endsWith(`/`),
        d = (a || o === `.`) && n.endsWith(`/`);
    return !l.pathname.endsWith(`/`) && (u || d) && (l.pathname += `/`), l
}
var A = e => e.join(`/`).replace(/\/\/+/g, `/`),
    pe = e => e.replace(/\/+$/, ``).replace(/^\/*/, `/`),
    me = e => !e || e === `?` ? `` : e.startsWith(`?`) ? e : `?` + e,
    he = e => !e || e === `#` ? `` : e.startsWith(`#`) ? e : `#` + e,
    ge = class {
        constructor(e, t, n, r = !1) {
            this.status = e, this.statusText = t || ``, this.internal = r, n instanceof Error ? (this.data = n.toString(), this.error = n) : this.data = n
        }
    };

function _e(e) {
    return e != null && typeof e.status == `number` && typeof e.statusText == `string` && typeof e.internal == `boolean` && `data` in e
}

function ve(e) {
    return e.map(e => e.route.path).filter(Boolean).join(`/`).replace(/\/\/*/g, `/`) || `/`
}
var ye = typeof window < `u` && window.document !== void 0 && window.document.createElement !== void 0;

function be(e, t) {
    let n = e;
    if (typeof n != `string` || !se.test(n)) return {
        absoluteURL: void 0,
        isExternal: !1,
        to: n
    };
    let r = n,
        i = !1;
    if (ye) try {
        let e = new URL(window.location.href),
            r = n.startsWith(`//`) ? new URL(e.protocol + n) : new URL(n),
            a = O(r.pathname, t);
        r.origin === e.origin && a != null ? n = a + r.search + r.hash : i = !0
    } catch {
        c(!1, `<Link to="${n}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)
    }
    return {
        absoluteURL: r,
        isExternal: i,
        to: n
    }
}
Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);
var xe = [`POST`, `PUT`, `PATCH`, `DELETE`];
new Set(xe);
var Se = [`GET`, ...xe];
new Set(Se);
var j = r.createContext(null);
j.displayName = `DataRouter`;
var M = r.createContext(null);
M.displayName = `DataRouterState`;
var Ce = r.createContext(!1);

function we() {
    return r.useContext(Ce)
}
var Te = r.createContext({
    isTransitioning: !1
});
Te.displayName = `ViewTransition`;
var Ee = r.createContext(new Map);
Ee.displayName = `Fetchers`;
var De = r.createContext(null);
De.displayName = `Await`;
var N = r.createContext(null);
N.displayName = `Navigation`;
var P = r.createContext(null);
P.displayName = `Location`;
var F = r.createContext({
    outlet: null,
    matches: [],
    isDataRoute: !1
});
F.displayName = `Route`;
var I = r.createContext(null);
I.displayName = `RouteError`;
var Oe = `REACT_ROUTER_ERROR`,
    ke = `REDIRECT`,
    Ae = `ROUTE_ERROR_RESPONSE`;

function je(e) {
    if (e.startsWith(`${Oe}:${ke}:{`)) try {
        let t = JSON.parse(e.slice(28));
        if (typeof t == `object` && t && typeof t.status == `number` && typeof t.statusText == `string` && typeof t.location == `string` && typeof t.reloadDocument == `boolean` && typeof t.replace == `boolean`) return t
    } catch {}
}

function Me(e) {
    if (e.startsWith(`${Oe}:${Ae}:{`)) try {
        let t = JSON.parse(e.slice(40));
        if (typeof t == `object` && t && typeof t.status == `number` && typeof t.statusText == `string`) return new ge(t.status, t.statusText, t.data)
    } catch {}
}

function Ne(e, {
    relative: t
} = {}) {
    s(L(), `useHref() may be used only in the context of a <Router> component.`);
    let {
        basename: n,
        navigator: i
    } = r.useContext(N), {
        hash: a,
        pathname: o,
        search: c
    } = z(e, {
        relative: t
    }), l = o;
    return n !== `/` && (l = o === `/` ? n : A([n, o])), i.createHref({
        pathname: l,
        search: c,
        hash: a
    })
}

function L() {
    return r.useContext(P) != null
}

function R() {
    return s(L(), `useLocation() may be used only in the context of a <Router> component.`), r.useContext(P).location
}
var Pe = `You should call navigate() in a React.useEffect(), not when your component is first rendered.`;

function Fe(e) {
    r.useContext(N).static || r.useLayoutEffect(e)
}

function Ie() {
    let {
        isDataRoute: e
    } = r.useContext(F);
    return e ? $e() : Le()
}

function Le() {
    s(L(), `useNavigate() may be used only in the context of a <Router> component.`);
    let e = r.useContext(j),
        {
            basename: t,
            navigator: n
        } = r.useContext(N),
        {
            matches: i
        } = r.useContext(F),
        {
            pathname: a
        } = R(),
        o = JSON.stringify(de(i)),
        l = r.useRef(!1);
    return Fe(() => {
        l.current = !0
    }), r.useCallback((r, i = {}) => {
        if (c(l.current, Pe), !l.current) return;
        if (typeof r == `number`) {
            n.go(r);
            return
        }
        let s = fe(r, JSON.parse(o), a, i.relative === `path`);
        e == null && t !== `/` && (s.pathname = s.pathname === `/` ? t : A([t, s.pathname])), (i.replace ? n.replace : n.push)(s, i.state, i)
    }, [t, n, o, a, e])
}
r.createContext(null);

function Re() {
    let {
        matches: e
    } = r.useContext(F), t = e[e.length - 1];
    return t ? t.params : {}
}

function z(e, {
    relative: t
} = {}) {
    let {
        matches: n
    } = r.useContext(F), {
        pathname: i
    } = R(), a = JSON.stringify(de(n));
    return r.useMemo(() => fe(e, JSON.parse(a), i, t === `path`), [e, a, i, t])
}

function ze(e, t) {
    return Be(e, t)
}

function Be(e, t, n) {
    s(L(), `useRoutes() may be used only in the context of a <Router> component.`);
    let {
        navigator: i
    } = r.useContext(N), {
        matches: a
    } = r.useContext(F), o = a[a.length - 1], l = o ? o.params : {}, u = o ? o.pathname : `/`, d = o ? o.pathnameBase : `/`, f = o && o.route; {
        let e = f && f.path || ``;
        tt(u, !f || e.endsWith(`*`) || e.endsWith(`*?`), `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${u}" (under <Route path="${e}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${e}"> to <Route path="${e===`/`?`*`:`${e}/*`}">.`)
    }
    let m = R(),
        h;
    if (t) {
        let e = typeof t == `string` ? p(t) : t;
        s(d === `/` || e.pathname ? .startsWith(d), `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${d}" but pathname "${e.pathname}" was given in the \`location\` prop.`), h = e
    } else h = m;
    let _ = h.pathname || `/`,
        v = _;
    if (d !== `/`) {
        let e = d.replace(/^\//, ``).split(`/`);
        v = `/` + _.replace(/^\//, ``).split(`/`).slice(e.length).join(`/`)
    }
    let y = g(e, {
        pathname: v
    });
    c(f || y != null, `No routes matched location "${h.pathname}${h.search}${h.hash}" `), c(y == null || y[y.length - 1].route.element !== void 0 || y[y.length - 1].route.Component !== void 0 || y[y.length - 1].route.lazy !== void 0, `Matched leaf route at location "${h.pathname}${h.search}${h.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);
    let b = Ke(y && y.map(e => Object.assign({}, e, {
        params: Object.assign({}, l, e.params),
        pathname: A([d, i.encodeLocation ? i.encodeLocation(e.pathname.replace(/%/g, `%25`).replace(/\?/g, `%3F`).replace(/#/g, `%23`)).pathname : e.pathname]),
        pathnameBase: e.pathnameBase === `/` ? d : A([d, i.encodeLocation ? i.encodeLocation(e.pathnameBase.replace(/%/g, `%25`).replace(/\?/g, `%3F`).replace(/#/g, `%23`)).pathname : e.pathnameBase])
    })), a, n);
    return t && b ? r.createElement(P.Provider, {
        value: {
            location: {
                pathname: `/`,
                search: ``,
                hash: ``,
                state: null,
                key: `default`,
                unstable_mask: void 0,
                ...h
            },
            navigationType: `POP`
        }
    }, b) : b
}

function Ve() {
    let e = Qe(),
        t = _e(e) ? `${e.status} ${e.statusText}` : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        i = `rgba(200,200,200, 0.5)`,
        a = {
            padding: `0.5rem`,
            backgroundColor: i
        },
        o = {
            padding: `2px 4px`,
            backgroundColor: i
        },
        s = null;
    return s = r.createElement(r.Fragment, null, r.createElement(`p`, null, `💿 Hey developer 👋`), r.createElement(`p`, null, `You can provide a way better UX than this when your app throws errors by providing your own `, r.createElement(`code`, {
        style: o
    }, `ErrorBoundary`), ` or`, ` `, r.createElement(`code`, {
        style: o
    }, `errorElement`), ` prop on your route.`)), r.createElement(r.Fragment, null, r.createElement(`h2`, null, `Unexpected Application Error!`), r.createElement(`h3`, {
        style: {
            fontStyle: `italic`
        }
    }, t), n ? r.createElement(`pre`, {
        style: a
    }, n) : null, s)
}
var He = r.createElement(Ve, null),
    Ue = class extends r.Component {
        constructor(e) {
            super(e), this.state = {
                location: e.location,
                revalidation: e.revalidation,
                error: e.error
            }
        }
        static getDerivedStateFromError(e) {
            return {
                error: e
            }
        }
        static getDerivedStateFromProps(e, t) {
            return t.location !== e.location || t.revalidation !== `idle` && e.revalidation === `idle` ? {
                error: e.error,
                location: e.location,
                revalidation: e.revalidation
            } : {
                error: e.error === void 0 ? t.error : e.error,
                location: t.location,
                revalidation: e.revalidation || t.revalidation
            }
        }
        componentDidCatch(e, t) {
            this.props.onError && this.props.onError(e, t)
        }
        render() {
            let e = this.state.error;
            if (this.context && typeof e == `object` && e && `digest` in e && typeof e.digest == `string`) {
                let t = Me(e.digest);
                t && (e = t)
            }
            let t = e === void 0 ? this.props.children : r.createElement(F.Provider, {
                value: this.props.routeContext
            }, r.createElement(I.Provider, {
                value: e,
                children: this.props.component
            }));
            return this.context ? r.createElement(We, {
                error: e
            }, t) : t
        }
    };
Ue.contextType = Ce;
var B = new WeakMap;

function We({
    children: e,
    error: t
}) {
    let {
        basename: n
    } = r.useContext(N);
    if (typeof t == `object` && t && `digest` in t && typeof t.digest == `string`) {
        let e = je(t.digest);
        if (e) {
            let i = B.get(t);
            if (i) throw i;
            let a = be(e.location, n);
            if (ye && !B.get(t))
                if (a.isExternal || e.reloadDocument) window.location.href = a.absoluteURL || a.to;
                else {
                    let n = Promise.resolve().then(() => window.__reactRouterDataRouter.navigate(a.to, {
                        replace: e.replace
                    }));
                    throw B.set(t, n), n
                }
            return r.createElement(`meta`, {
                httpEquiv: `refresh`,
                content: `0;url=${a.absoluteURL||a.to}`
            })
        }
    }
    return e
}

function Ge({
    routeContext: e,
    match: t,
    children: n
}) {
    let i = r.useContext(j);
    return i && i.static && i.staticContext && (t.route.errorElement || t.route.ErrorBoundary) && (i.staticContext._deepestRenderedBoundaryId = t.route.id), r.createElement(F.Provider, {
        value: e
    }, n)
}

function Ke(e, t = [], n) {
    let i = n ? .state;
    if (e == null) {
        if (!i) return null;
        if (i.errors) e = i.matches;
        else if (t.length === 0 && !i.initialized && i.matches.length > 0) e = i.matches;
        else return null
    }
    let a = e,
        o = i ? .errors;
    if (o != null) {
        let e = a.findIndex(e => e.route.id && o ? .[e.route.id] !== void 0);
        s(e >= 0, `Could not find a matching route for errors on route IDs: ${Object.keys(o).join(`,`)}`), a = a.slice(0, Math.min(a.length, e + 1))
    }
    let c = !1,
        l = -1;
    if (n && i) {
        c = i.renderFallback;
        for (let e = 0; e < a.length; e++) {
            let t = a[e];
            if ((t.route.HydrateFallback || t.route.hydrateFallbackElement) && (l = e), t.route.id) {
                let {
                    loaderData: e,
                    errors: r
                } = i, o = t.route.loader && !e.hasOwnProperty(t.route.id) && (!r || r[t.route.id] === void 0);
                if (t.route.lazy || o) {
                    n.isStatic && (c = !0), a = l >= 0 ? a.slice(0, l + 1) : [a[0]];
                    break
                }
            }
        }
    }
    let u = n ? .onError,
        d = i && u ? (e, t) => {
            u(e, {
                location: i.location,
                params: i.matches ? .[0] ? .params ? ? {},
                unstable_pattern: ve(i.matches),
                errorInfo: t
            })
        } : void 0;
    return a.reduceRight((e, n, s) => {
        let u, f = !1,
            p = null,
            m = null;
        i && (u = o && n.route.id ? o[n.route.id] : void 0, p = n.route.errorElement || He, c && (l < 0 && s === 0 ? (tt(`route-fallback`, !1, "No `HydrateFallback` element provided to render during initial hydration"), f = !0, m = null) : l === s && (f = !0, m = n.route.hydrateFallbackElement || null)));
        let h = t.concat(a.slice(0, s + 1)),
            g = () => {
                let t;
                return t = u ? p : f ? m : n.route.Component ? r.createElement(n.route.Component, null) : n.route.element ? n.route.element : e, r.createElement(Ge, {
                    match: n,
                    routeContext: {
                        outlet: e,
                        matches: h,
                        isDataRoute: i != null
                    },
                    children: t
                })
            };
        return i && (n.route.ErrorBoundary || n.route.errorElement || s === 0) ? r.createElement(Ue, {
            location: i.location,
            revalidation: i.revalidation,
            component: p,
            error: u,
            children: g(),
            routeContext: {
                outlet: null,
                matches: h,
                isDataRoute: !0
            },
            onError: d
        }) : g()
    }, null)
}

function V(e) {
    return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`
}

function qe(e) {
    let t = r.useContext(j);
    return s(t, V(e)), t
}

function H(e) {
    let t = r.useContext(M);
    return s(t, V(e)), t
}

function Je(e) {
    let t = r.useContext(F);
    return s(t, V(e)), t
}

function U(e) {
    let t = Je(e),
        n = t.matches[t.matches.length - 1];
    return s(n.route.id, `${e} can only be used on routes that contain a unique "id"`), n.route.id
}

function Ye() {
    return U(`useRouteId`)
}

function Xe() {
    return H(`useNavigation`).navigation
}

function Ze() {
    let {
        matches: e,
        loaderData: t
    } = H(`useMatches`);
    return r.useMemo(() => e.map(e => v(e, t)), [e, t])
}

function Qe() {
    let e = r.useContext(I),
        t = H(`useRouteError`),
        n = U(`useRouteError`);
    return e === void 0 ? t.errors ? .[n] : e
}

function $e() {
    let {
        router: e
    } = qe(`useNavigate`), t = U(`useNavigate`), n = r.useRef(!1);
    return Fe(() => {
        n.current = !0
    }), r.useCallback(async (r, i = {}) => {
        c(n.current, Pe), n.current && (typeof r == `number` ? await e.navigate(r) : await e.navigate(r, {
            fromRouteId: t,
            ...i
        }))
    }, [e, t])
}
var et = {};

function tt(e, t, n) {
    !t && !et[e] && (et[e] = !0, c(!1, n))
}
r.useOptimistic, r.memo(nt);

function nt({
    routes: e,
    future: t,
    state: n,
    isStatic: r,
    onError: i
}) {
    return Be(e, void 0, {
        state: n,
        isStatic: r,
        onError: i,
        future: t
    })
}

function rt(e) {
    s(!1, `A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.`)
}

function it({
    basename: e = `/`,
    children: t = null,
    location: n,
    navigationType: i = `POP`,
    navigator: a,
    static: o = !1,
    unstable_useTransitions: l
}) {
    s(!L(), `You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`);
    let u = e.replace(/^\/*/, `/`),
        d = r.useMemo(() => ({
            basename: u,
            navigator: a,
            static: o,
            unstable_useTransitions: l,
            future: {}
        }), [u, a, o, l]);
    typeof n == `string` && (n = p(n));
    let {
        pathname: f = `/`,
        search: m = ``,
        hash: h = ``,
        state: g = null,
        key: _ = `default`,
        unstable_mask: v
    } = n, y = r.useMemo(() => {
        let e = O(f, u);
        return e == null ? null : {
            location: {
                pathname: e,
                search: m,
                hash: h,
                state: g,
                key: _,
                unstable_mask: v
            },
            navigationType: i
        }
    }, [u, f, m, h, g, _, i, v]);
    return c(y != null, `<Router basename="${u}"> is not able to match the URL "${f}${m}${h}" because it does not start with the basename, so the <Router> won't render anything.`), y == null ? null : r.createElement(N.Provider, {
        value: d
    }, r.createElement(P.Provider, {
        children: t,
        value: y
    }))
}

function at({
    children: e,
    location: t
}) {
    return ze(W(e), t)
}
r.Component;

function W(e, t = []) {
    let n = [];
    return r.Children.forEach(e, (e, i) => {
        if (!r.isValidElement(e)) return;
        let a = [...t, i];
        if (e.type === r.Fragment) {
            n.push.apply(n, W(e.props.children, a));
            return
        }
        s(e.type === rt, `[${typeof e.type==`string`?e.type:e.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`), s(!e.props.index || !e.props.children, `An index route cannot have child routes.`);
        let o = {
            id: e.props.id || a.join(`-`),
            caseSensitive: e.props.caseSensitive,
            element: e.props.element,
            Component: e.props.Component,
            index: e.props.index,
            path: e.props.path,
            middleware: e.props.middleware,
            loader: e.props.loader,
            action: e.props.action,
            hydrateFallbackElement: e.props.hydrateFallbackElement,
            HydrateFallback: e.props.HydrateFallback,
            errorElement: e.props.errorElement,
            ErrorBoundary: e.props.ErrorBoundary,
            hasErrorBoundary: e.props.hasErrorBoundary === !0 || e.props.ErrorBoundary != null || e.props.errorElement != null,
            shouldRevalidate: e.props.shouldRevalidate,
            handle: e.props.handle,
            lazy: e.props.lazy
        };
        e.props.children && (o.children = W(e.props.children, a)), n.push(o)
    }), n
}
var G = `get`,
    K = `application/x-www-form-urlencoded`;

function q(e) {
    return typeof HTMLElement < `u` && e instanceof HTMLElement
}

function ot(e) {
    return q(e) && e.tagName.toLowerCase() === `button`
}

function st(e) {
    return q(e) && e.tagName.toLowerCase() === `form`
}

function ct(e) {
    return q(e) && e.tagName.toLowerCase() === `input`
}

function lt(e) {
    return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
}

function ut(e, t) {
    return e.button === 0 && (!t || t === `_self`) && !lt(e)
}
var J = null;

function dt() {
    if (J === null) try {
        new FormData(document.createElement(`form`), 0), J = !1
    } catch {
        J = !0
    }
    return J
}
var ft = new Set([`application/x-www-form-urlencoded`, `multipart/form-data`, `text/plain`]);

function Y(e) {
    return e != null && !ft.has(e) ? (c(!1, `"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${K}"`), null) : e
}

function pt(e, t) {
    let n, r, i, a, o;
    if (st(e)) {
        let o = e.getAttribute(`action`);
        r = o ? O(o, t) : null, n = e.getAttribute(`method`) || G, i = Y(e.getAttribute(`enctype`)) || K, a = new FormData(e)
    } else if (ot(e) || ct(e) && (e.type === `submit` || e.type === `image`)) {
        let o = e.form;
        if (o == null) throw Error(`Cannot submit a <button> or <input type="submit"> without a <form>`);
        let s = e.getAttribute(`formaction`) || o.getAttribute(`action`);
        if (r = s ? O(s, t) : null, n = e.getAttribute(`formmethod`) || o.getAttribute(`method`) || G, i = Y(e.getAttribute(`formenctype`)) || Y(o.getAttribute(`enctype`)) || K, a = new FormData(o, e), !dt()) {
            let {
                name: t,
                type: n,
                value: r
            } = e;
            if (n === `image`) {
                let e = t ? `${t}.` : ``;
                a.append(`${e}x`, `0`), a.append(`${e}y`, `0`)
            } else t && a.append(t, r)
        }
    } else if (q(e)) throw Error(`Cannot submit element that is not <form>, <button>, or <input type="submit|image">`);
    else n = G, r = null, i = K, o = e;
    return a && i === `text/plain` && (o = a, a = void 0), {
        action: r,
        method: n.toLowerCase(),
        encType: i,
        formData: a,
        body: o
    }
}
Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);
var mt = {
        "&": `\\u0026`,
        ">": `\\u003e`,
        "<": `\\u003c`,
        "\u2028": `\\u2028`,
        "\u2029": `\\u2029`
    },
    ht = /[&><\u2028\u2029]/g;

function gt(e) {
    return e.replace(ht, e => mt[e])
}

function _t(e, t) {
    if (e === !1 || e == null) throw Error(t)
}

function vt(e, t, n, r) {
    let i = typeof e == `string` ? new URL(e, typeof window > `u` ? `server://singlefetch/` : window.location.origin) : e;
    return n ? i.pathname.endsWith(`/`) ? i.pathname = `${i.pathname}_.${r}` : i.pathname = `${i.pathname}.${r}` : i.pathname === `/` ? i.pathname = `_root.${r}` : t && O(i.pathname, t) === `/` ? i.pathname = `${t.replace(/\/$/,``)}/_root.${r}` : i.pathname = `${i.pathname.replace(/\/$/,``)}.${r}`, i
}
async function yt(e, t) {
    if (e.id in t) return t[e.id];
    try {
        let r = await n(() =>
            import (e.module), []);
        return t[e.id] = r, r
    } catch {
        return window.__reactRouterContext && window.__reactRouterContext.isSpaMode, window.location.reload(), new Promise(() => {})
    }
}

function bt(e) {
    return e != null && typeof e.page == `string`
}

function xt(e) {
    return e == null ? !1 : e.href == null ? e.rel === `preload` && typeof e.imageSrcSet == `string` && typeof e.imageSizes == `string` : typeof e.rel == `string` && typeof e.href == `string`
}
async function St(e, t, n) {
    return Dt((await Promise.all(e.map(async e => {
        let r = t.routes[e.route.id];
        if (r) {
            let e = await yt(r, n);
            return e.links ? e.links() : []
        }
        return []
    }))).flat(1).filter(xt).filter(e => e.rel === `stylesheet` || e.rel === `preload`).map(e => e.rel === `stylesheet` ? { ...e,
        rel: `prefetch`,
        as: `style`
    } : { ...e,
        rel: `prefetch`
    }))
}

function Ct(e, t, n, r, i, a) {
    let o = (e, t) => n[t] ? e.route.id !== n[t].route.id : !0,
        s = (e, t) => n[t].pathname !== e.pathname || n[t].route.path ? .endsWith(`*`) && n[t].params[`*`] !== e.params[`*`];
    return a === `assets` ? t.filter((e, t) => o(e, t) || s(e, t)) : a === `data` ? t.filter((t, a) => {
        let c = r.routes[t.route.id];
        if (!c || !c.hasLoader) return !1;
        if (o(t, a) || s(t, a)) return !0;
        if (t.route.shouldRevalidate) {
            let r = t.route.shouldRevalidate({
                currentUrl: new URL(i.pathname + i.search + i.hash, window.origin),
                currentParams: n[0] ? .params || {},
                nextUrl: new URL(e, window.origin),
                nextParams: t.params,
                defaultShouldRevalidate: !0
            });
            if (typeof r == `boolean`) return r
        }
        return !0
    }) : []
}

function wt(e, t, {
    includeHydrateFallback: n
} = {}) {
    return Tt(e.map(e => {
        let r = t.routes[e.route.id];
        if (!r) return [];
        let i = [r.module];
        return r.clientActionModule && (i = i.concat(r.clientActionModule)), r.clientLoaderModule && (i = i.concat(r.clientLoaderModule)), n && r.hydrateFallbackModule && (i = i.concat(r.hydrateFallbackModule)), r.imports && (i = i.concat(r.imports)), i
    }).flat(1))
}

function Tt(e) {
    return [...new Set(e)]
}

function Et(e) {
    let t = {},
        n = Object.keys(e).sort();
    for (let r of n) t[r] = e[r];
    return t
}

function Dt(e, t) {
    let n = new Set,
        r = new Set(t);
    return e.reduce((e, i) => {
        if (t && !bt(i) && i.as === `script` && i.href && r.has(i.href)) return e;
        let a = JSON.stringify(Et(i));
        return n.has(a) || (n.add(a), e.push({
            key: a,
            link: i
        })), e
    }, [])
}

function Ot() {
    let e = r.useContext(j);
    return _t(e, `You must render this element inside a <DataRouterContext.Provider> element`), e
}

function kt() {
    let e = r.useContext(M);
    return _t(e, `You must render this element inside a <DataRouterStateContext.Provider> element`), e
}
var X = r.createContext(void 0);
X.displayName = `FrameworkContext`;

function At() {
    let e = r.useContext(X);
    return _t(e, `You must render this element inside a <HydratedRouter> element`), e
}

function jt(e, t) {
    let n = r.useContext(X),
        [i, a] = r.useState(!1),
        [o, s] = r.useState(!1),
        {
            onFocus: c,
            onBlur: l,
            onMouseEnter: u,
            onMouseLeave: d,
            onTouchStart: f
        } = t,
        p = r.useRef(null);
    r.useEffect(() => {
        if (e === `render` && s(!0), e === `viewport`) {
            let e = new IntersectionObserver(e => {
                e.forEach(e => {
                    s(e.isIntersecting)
                })
            }, {
                threshold: .5
            });
            return p.current && e.observe(p.current), () => {
                e.disconnect()
            }
        }
    }, [e]), r.useEffect(() => {
        if (i) {
            let e = setTimeout(() => {
                s(!0)
            }, 100);
            return () => {
                clearTimeout(e)
            }
        }
    }, [i]);
    let m = () => {
            a(!0)
        },
        h = () => {
            a(!1), s(!1)
        };
    return n ? e === `intent` ? [o, p, {
        onFocus: Z(c, m),
        onBlur: Z(l, h),
        onMouseEnter: Z(u, m),
        onMouseLeave: Z(d, h),
        onTouchStart: Z(f, m)
    }] : [o, p, {}] : [!1, p, {}]
}

function Z(e, t) {
    return n => {
        e && e(n), n.defaultPrevented || t(n)
    }
}

function Mt({
    page: e,
    ...t
}) {
    let n = we(),
        {
            router: i
        } = Ot(),
        a = r.useMemo(() => g(i.routes, e, i.basename), [i.routes, e, i.basename]);
    return a ? n ? r.createElement(Pt, {
        page: e,
        matches: a,
        ...t
    }) : r.createElement(Ft, {
        page: e,
        matches: a,
        ...t
    }) : null
}

function Nt(e) {
    let {
        manifest: t,
        routeModules: n
    } = At(), [i, a] = r.useState([]);
    return r.useEffect(() => {
        let r = !1;
        return St(e, t, n).then(e => {
            r || a(e)
        }), () => {
            r = !0
        }
    }, [e, t, n]), i
}

function Pt({
    page: e,
    matches: t,
    ...n
}) {
    let i = R(),
        {
            future: a
        } = At(),
        {
            basename: o
        } = Ot(),
        s = r.useMemo(() => {
            if (e === i.pathname + i.search + i.hash) return [];
            let n = vt(e, o, a.unstable_trailingSlashAwareDataRequests, `rsc`),
                r = !1,
                s = [];
            for (let e of t) typeof e.route.shouldRevalidate == `function` ? r = !0 : s.push(e.route.id);
            return r && s.length > 0 && n.searchParams.set(`_routes`, s.join(`,`)), [n.pathname + n.search]
        }, [o, a.unstable_trailingSlashAwareDataRequests, e, i, t]);
    return r.createElement(r.Fragment, null, s.map(e => r.createElement(`link`, {
        key: e,
        rel: `prefetch`,
        as: `fetch`,
        href: e,
        ...n
    })))
}

function Ft({
    page: e,
    matches: t,
    ...n
}) {
    let i = R(),
        {
            future: a,
            manifest: o,
            routeModules: s
        } = At(),
        {
            basename: c
        } = Ot(),
        {
            loaderData: l,
            matches: u
        } = kt(),
        d = r.useMemo(() => Ct(e, t, u, o, i, `data`), [e, t, u, o, i]),
        f = r.useMemo(() => Ct(e, t, u, o, i, `assets`), [e, t, u, o, i]),
        p = r.useMemo(() => {
            if (e === i.pathname + i.search + i.hash) return [];
            let n = new Set,
                r = !1;
            if (t.forEach(e => {
                    let t = o.routes[e.route.id];
                    !t || !t.hasLoader || (!d.some(t => t.route.id === e.route.id) && e.route.id in l && s[e.route.id] ? .shouldRevalidate || t.hasClientLoader ? r = !0 : n.add(e.route.id))
                }), n.size === 0) return [];
            let u = vt(e, c, a.unstable_trailingSlashAwareDataRequests, `data`);
            return r && n.size > 0 && u.searchParams.set(`_routes`, t.filter(e => n.has(e.route.id)).map(e => e.route.id).join(`,`)), [u.pathname + u.search]
        }, [c, a.unstable_trailingSlashAwareDataRequests, l, i, o, d, t, e, s]),
        m = r.useMemo(() => wt(f, o), [f, o]),
        h = Nt(f);
    return r.createElement(r.Fragment, null, p.map(e => r.createElement(`link`, {
        key: e,
        rel: `prefetch`,
        as: `fetch`,
        href: e,
        ...n
    })), m.map(e => r.createElement(`link`, {
        key: e,
        rel: `modulepreload`,
        href: e,
        ...n
    })), h.map(({
        key: e,
        link: t
    }) => r.createElement(`link`, {
        key: e,
        nonce: n.nonce,
        ...t,
        crossOrigin: t.crossOrigin ? ? n.crossOrigin
    })))
}

function It(...e) {
    return t => {
        e.forEach(e => {
            typeof e == `function` ? e(t) : e != null && (e.current = t)
        })
    }
}
r.Component;
var Lt = typeof window < `u` && window.document !== void 0 && window.document.createElement !== void 0;
try {
    Lt && (window.__reactRouterVersion = `7.14.0`)
} catch {}

function Rt({
    basename: e,
    children: t,
    unstable_useTransitions: n,
    window: i
}) {
    let a = r.useRef();
    a.current ? ? = o({
        window: i,
        v5Compat: !0
    });
    let s = a.current,
        [c, l] = r.useState({
            action: s.action,
            location: s.location
        }),
        u = r.useCallback(e => {
            n === !1 ? l(e) : r.startTransition(() => l(e))
        }, [n]);
    return r.useLayoutEffect(() => s.listen(u), [s, u]), r.createElement(it, {
        basename: e,
        children: t,
        location: c.location,
        navigationType: c.action,
        navigator: s,
        unstable_useTransitions: n
    })
}

function zt({
    basename: e,
    children: t,
    history: n,
    unstable_useTransitions: i
}) {
    let [a, o] = r.useState({
        action: n.action,
        location: n.location
    }), s = r.useCallback(e => {
        i === !1 ? o(e) : r.startTransition(() => o(e))
    }, [i]);
    return r.useLayoutEffect(() => n.listen(s), [n, s]), r.createElement(it, {
        basename: e,
        children: t,
        location: a.location,
        navigationType: a.action,
        navigator: n,
        unstable_useTransitions: i
    })
}
zt.displayName = `unstable_HistoryRouter`;
var Bt = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
    Vt = r.forwardRef(function({
        onClick: e,
        discover: t = `render`,
        prefetch: n = `none`,
        relative: i,
        reloadDocument: a,
        replace: o,
        unstable_mask: s,
        state: c,
        target: l,
        to: u,
        preventScrollReset: d,
        viewTransition: f,
        unstable_defaultShouldRevalidate: p,
        ...m
    }, h) {
        let {
            basename: g,
            navigator: _,
            unstable_useTransitions: v
        } = r.useContext(N), y = typeof u == `string` && Bt.test(u), b = be(u, g);
        u = b.to;
        let x = Ne(u, {
                relative: i
            }),
            S = R(),
            C = null;
        if (s) {
            let e = fe(s, [], S.unstable_mask ? S.unstable_mask.pathname : `/`, !0);
            g !== `/` && (e.pathname = e.pathname === `/` ? g : A([g, e.pathname])), C = _.createHref(e)
        }
        let [w, T, E] = jt(n, m), ee = Jt(u, {
            replace: o,
            unstable_mask: s,
            state: c,
            target: l,
            preventScrollReset: d,
            relative: i,
            viewTransition: f,
            unstable_defaultShouldRevalidate: p,
            unstable_useTransitions: v
        });

        function te(t) {
            e && e(t), t.defaultPrevented || ee(t)
        }
        let ne = !(b.isExternal || a),
            re = r.createElement(`a`, { ...m,
                ...E,
                href: (ne ? C : void 0) || b.absoluteURL || x,
                onClick: ne ? te : e,
                ref: It(h, T),
                target: l,
                "data-discover": !y && t === `render` ? `true` : void 0
            });
        return w && !y ? r.createElement(r.Fragment, null, re, r.createElement(Mt, {
            page: x
        })) : re
    });
Vt.displayName = `Link`;
var Ht = r.forwardRef(function({
    "aria-current": e = `page`,
    caseSensitive: t = !1,
    className: n = ``,
    end: i = !1,
    style: a,
    to: o,
    viewTransition: s,
    children: c,
    ...l
}, u) {
    let d = z(o, {
            relative: l.relative
        }),
        f = R(),
        p = r.useContext(M),
        {
            navigator: m,
            basename: h
        } = r.useContext(N),
        g = p != null && nn(d) && s === !0,
        _ = m.encodeLocation ? m.encodeLocation(d).pathname : d.pathname,
        v = f.pathname,
        y = p && p.navigation && p.navigation.location ? p.navigation.location.pathname : null;
    t || (v = v.toLowerCase(), y = y ? y.toLowerCase() : null, _ = _.toLowerCase()), y && h && (y = O(y, h) || y);
    let b = _ !== `/` && _.endsWith(`/`) ? _.length - 1 : _.length,
        x = v === _ || !i && v.startsWith(_) && v.charAt(b) === `/`,
        S = y != null && (y === _ || !i && y.startsWith(_) && y.charAt(_.length) === `/`),
        C = {
            isActive: x,
            isPending: S,
            isTransitioning: g
        },
        w = x ? e : void 0,
        T;
    T = typeof n == `function` ? n(C) : [n, x ? `active` : null, S ? `pending` : null, g ? `transitioning` : null].filter(Boolean).join(` `);
    let E = typeof a == `function` ? a(C) : a;
    return r.createElement(Vt, { ...l,
        "aria-current": w,
        className: T,
        ref: u,
        style: E,
        to: o,
        viewTransition: s
    }, typeof c == `function` ? c(C) : c)
});
Ht.displayName = `NavLink`;
var Ut = r.forwardRef(({
    discover: e = `render`,
    fetcherKey: t,
    navigate: n,
    reloadDocument: i,
    replace: a,
    state: o,
    method: s = G,
    action: c,
    onSubmit: l,
    relative: u,
    preventScrollReset: d,
    viewTransition: f,
    unstable_defaultShouldRevalidate: p,
    ...m
}, h) => {
    let {
        unstable_useTransitions: g
    } = r.useContext(N), _ = Zt(), v = Qt(c, {
        relative: u
    }), y = s.toLowerCase() === `get` ? `get` : `post`, b = typeof c == `string` && Bt.test(c);
    return r.createElement(`form`, {
        ref: h,
        method: y,
        action: v,
        onSubmit: i ? l : e => {
            if (l && l(e), e.defaultPrevented) return;
            e.preventDefault();
            let i = e.nativeEvent.submitter,
                c = i ? .getAttribute(`formmethod`) || s,
                m = () => _(i || e.currentTarget, {
                    fetcherKey: t,
                    method: c,
                    navigate: n,
                    replace: a,
                    state: o,
                    relative: u,
                    preventScrollReset: d,
                    viewTransition: f,
                    unstable_defaultShouldRevalidate: p
                });
            g && n !== !1 ? r.startTransition(() => m()) : m()
        },
        ...m,
        "data-discover": !b && e === `render` ? `true` : void 0
    })
});
Ut.displayName = `Form`;

function Wt({
    getKey: e,
    storageKey: t,
    ...n
}) {
    let i = r.useContext(X),
        {
            basename: a
        } = r.useContext(N),
        o = R(),
        s = Ze();
    en({
        getKey: e,
        storageKey: t
    });
    let c = r.useMemo(() => {
        if (!i || !e) return null;
        let t = $(o, s, a, e);
        return t === o.key ? null : t
    }, []);
    if (!i || i.isSpaMode) return null;
    let l = ((e, t) => {
        if (!window.history.state || !window.history.state.key) {
            let e = Math.random().toString(32).slice(2);
            window.history.replaceState({
                key: e
            }, ``)
        }
        try {
            let n = JSON.parse(sessionStorage.getItem(e) || `{}`)[t || window.history.state.key];
            typeof n == `number` && window.scrollTo(0, n)
        } catch {
            sessionStorage.removeItem(e)
        }
    }).toString();
    return r.createElement(`script`, { ...n,
        suppressHydrationWarning: !0,
        dangerouslySetInnerHTML: {
            __html: `(${l})(${gt(JSON.stringify(t||$t))}, ${gt(JSON.stringify(c))})`
        }
    })
}
Wt.displayName = `ScrollRestoration`;

function Gt(e) {
    return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`
}

function Kt(e) {
    let t = r.useContext(j);
    return s(t, Gt(e)), t
}

function qt(e) {
    let t = r.useContext(M);
    return s(t, Gt(e)), t
}

function Jt(e, {
    target: t,
    replace: n,
    unstable_mask: i,
    state: a,
    preventScrollReset: o,
    relative: s,
    viewTransition: c,
    unstable_defaultShouldRevalidate: l,
    unstable_useTransitions: u
} = {}) {
    let d = Ie(),
        p = R(),
        m = z(e, {
            relative: s
        });
    return r.useCallback(h => {
        if (ut(h, t)) {
            h.preventDefault();
            let t = n === void 0 ? f(p) === f(m) : n,
                g = () => d(e, {
                    replace: t,
                    unstable_mask: i,
                    state: a,
                    preventScrollReset: o,
                    relative: s,
                    viewTransition: c,
                    unstable_defaultShouldRevalidate: l
                });
            u ? r.startTransition(() => g()) : g()
        }
    }, [p, d, m, n, i, a, t, e, o, s, c, l, u])
}
var Yt = 0,
    Xt = () => `__${String(++Yt)}__`;

function Zt() {
    let {
        router: e
    } = Kt(`useSubmit`), {
        basename: t
    } = r.useContext(N), n = Ye(), i = e.fetch, a = e.navigate;
    return r.useCallback(async (e, r = {}) => {
        let {
            action: o,
            method: s,
            encType: c,
            formData: l,
            body: u
        } = pt(e, t);
        r.navigate === !1 ? await i(r.fetcherKey || Xt(), n, r.action || o, {
            unstable_defaultShouldRevalidate: r.unstable_defaultShouldRevalidate,
            preventScrollReset: r.preventScrollReset,
            formData: l,
            body: u,
            formMethod: r.method || s,
            formEncType: r.encType || c,
            flushSync: r.flushSync
        }) : await a(r.action || o, {
            unstable_defaultShouldRevalidate: r.unstable_defaultShouldRevalidate,
            preventScrollReset: r.preventScrollReset,
            formData: l,
            body: u,
            formMethod: r.method || s,
            formEncType: r.encType || c,
            replace: r.replace,
            state: r.state,
            fromRouteId: n,
            flushSync: r.flushSync,
            viewTransition: r.viewTransition
        })
    }, [i, a, t, n])
}

function Qt(e, {
    relative: t
} = {}) {
    let {
        basename: n
    } = r.useContext(N), i = r.useContext(F);
    s(i, `useFormAction must be used inside a RouteContext`);
    let [a] = i.matches.slice(-1), o = { ...z(e || `.`, {
            relative: t
        })
    }, c = R();
    if (e == null) {
        o.search = c.search;
        let e = new URLSearchParams(o.search),
            t = e.getAll(`index`);
        if (t.some(e => e === ``)) {
            e.delete(`index`), t.filter(e => e).forEach(t => e.append(`index`, t));
            let n = e.toString();
            o.search = n ? `?${n}` : ``
        }
    }
    return (!e || e === `.`) && a.route.index && (o.search = o.search ? o.search.replace(/^\?/, `?index&`) : `?index`), n !== `/` && (o.pathname = o.pathname === `/` ? n : A([n, o.pathname])), f(o)
}
var $t = `react-router-scroll-positions`,
    Q = {};

function $(e, t, n, r) {
    let i = null;
    return r && (i = r(n === `/` ? e : { ...e,
        pathname: O(e.pathname, n) || e.pathname
    }, t)), i ? ? = e.key, i
}

function en({
    getKey: e,
    storageKey: t
} = {}) {
    let {
        router: n
    } = Kt(`useScrollRestoration`), {
        restoreScrollPosition: i,
        preventScrollReset: a
    } = qt(`useScrollRestoration`), {
        basename: o
    } = r.useContext(N), s = R(), l = Ze(), u = Xe();
    r.useEffect(() => (window.history.scrollRestoration = `manual`, () => {
        window.history.scrollRestoration = `auto`
    }), []), tn(r.useCallback(() => {
        if (u.state === `idle`) {
            let t = $(s, l, o, e);
            Q[t] = window.scrollY
        }
        try {
            sessionStorage.setItem(t || $t, JSON.stringify(Q))
        } catch (e) {
            c(!1, `Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${e}).`)
        }
        window.history.scrollRestoration = `auto`
    }, [u.state, e, o, s, l, t])), typeof document < `u` && (r.useLayoutEffect(() => {
        try {
            let e = sessionStorage.getItem(t || $t);
            e && (Q = JSON.parse(e))
        } catch {}
    }, [t]), r.useLayoutEffect(() => {
        let t = n ? .enableScrollRestoration(Q, () => window.scrollY, e ? (t, n) => $(t, n, o, e) : void 0);
        return () => t && t()
    }, [n, o, e]), r.useLayoutEffect(() => {
        if (i !== !1) {
            if (typeof i == `number`) {
                window.scrollTo(0, i);
                return
            }
            try {
                if (s.hash) {
                    let e = document.getElementById(decodeURIComponent(s.hash.slice(1)));
                    if (e) {
                        e.scrollIntoView();
                        return
                    }
                }
            } catch {
                c(!1, `"${s.hash.slice(1)}" is not a decodable element ID. The view will not scroll to it.`)
            }
            a !== !0 && window.scrollTo(0, 0)
        }
    }, [s, i, a]))
}

function tn(e, t) {
    let {
        capture: n
    } = t || {};
    r.useEffect(() => {
        let t = n == null ? void 0 : {
            capture: n
        };
        return window.addEventListener(`pagehide`, e, t), () => {
            window.removeEventListener(`pagehide`, e, t)
        }
    }, [e, n])
}

function nn(e, {
    relative: t
} = {}) {
    let n = r.useContext(Te);
    s(n != null, "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
    let {
        basename: i
    } = Kt(`useViewTransitionState`), a = z(e, {
        relative: t
    });
    if (!n.isTransitioning) return !1;
    let o = O(n.currentLocation.pathname, i) || n.currentLocation.pathname,
        c = O(n.nextLocation.pathname, i) || n.nextLocation.pathname;
    return D(a.pathname, c) != null || D(a.pathname, o) != null
}
export {
    Re as a, at as i, Vt as n, rt as r, Rt as t
};