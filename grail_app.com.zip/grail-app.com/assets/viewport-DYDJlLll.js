var e = null,
    t = 0,
    n = 0,
    r = 0,
    i = !0;

function a() {
    if (!e) {
        e = document.createElement(`div`), e.style.cssText = `position:fixed;top:0;left:0;width:0;visibility:hidden;pointer-events:none;` + (CSS.supports(`height`, `100lvh`) ? `height:100lvh;` : `height:100vh;`), e.setAttribute(`aria-hidden`, `true`), document.body.appendChild(e);
        let t = () => {
            i = !0
        };
        window.addEventListener(`resize`, t), window.addEventListener(`orientationchange`, t)
    }
    return e
}

function o() {
    return !i && r ? r : (r = a().offsetHeight || window.innerHeight, i = !1, r)
}
var s = new Set,
    c = new Set,
    l = 0,
    u = !1;

function d() {
    if (u) return;
    u = !0, t = o(), n = window.innerWidth;
    let e = () => {
        window.clearTimeout(l), l = window.setTimeout(() => {
            for (let e of c) e();
            let e = o(),
                r = window.innerWidth;
            if (e !== t || r !== n) {
                t = e, n = r;
                for (let e of s) e()
            }
        }, 150)
    };
    window.addEventListener(`resize`, e), window.addEventListener(`orientationchange`, e)
}

function f(e) {
    return d(), s.add(e), () => s.delete(e)
}

function p(e) {
    return d(), c.add(e), () => c.delete(e)
}
export {
    f as n, o as r, p as t
};