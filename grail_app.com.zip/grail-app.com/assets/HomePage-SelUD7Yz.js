const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/TotemStage-K55W8ci8.js", "assets/chunk-BEqpzyXh.js", "assets/jsx-runtime-B4RpOl0S.js", "assets/three.module-DHIuxIYb.js", "assets/meshopt_decoder.module-CjHzRMB6.js", "assets/device-DfrJF2Wj.js", "assets/viewport-DYDJlLll.js", "assets/matter-DegRgWhp.js", "assets/supabase-ne8yL6rH.js"]))) => i.map(i => d[i]);
import {
    a as e,
    t
} from "./chunk-BEqpzyXh.js";
import {
    n,
    t as r
} from "./jsx-runtime-B4RpOl0S.js";
import {
    t as i
} from "./preload-helper-rov5CBGT.js";
import {
    n as a,
    r as o,
    t as s
} from "./viewport-DYDJlLll.js";
import {
    a as c,
    i as l,
    n as u,
    o as d,
    r as f,
    t as p
} from "./device-DfrJF2Wj.js";
import {
    At as m,
    G as h,
    I as g,
    at as _,
    b as v,
    bt as y,
    n as b,
    rt as x,
    u as S,
    yt as C
} from "./three.module-DHIuxIYb.js";
import {
    t as w
} from "./quests-CQ2WangE.js";
import {
    r as T,
    t as E
} from "./warpFill-CfnOsA5y.js";
import {
    t as D
} from "./VoiceGarden-B9VM_bVK.js";
import {
    n as O,
    t as k
} from "./totems-6Ag_iF3F.js";
import {
    r as A,
    t as j
} from "./analytics-CTl5M4iv.js";
var ee = t((e => {
        var t = n();

        function r(e) {
            var t = `https://react.dev/errors/` + e;
            if (1 < arguments.length) {
                t += `?args[]=` + encodeURIComponent(arguments[1]);
                for (var n = 2; n < arguments.length; n++) t += `&args[]=` + encodeURIComponent(arguments[n])
            }
            return `Minified React error #` + e + `; visit ` + t + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
        }

        function i() {}
        var a = {
                d: {
                    f: i,
                    r: function() {
                        throw Error(r(522))
                    },
                    D: i,
                    C: i,
                    L: i,
                    m: i,
                    X: i,
                    S: i,
                    M: i
                },
                p: 0,
                findDOMNode: null
            },
            o = Symbol.for(`react.portal`);

        function s(e, t, n) {
            var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
            return {
                $$typeof: o,
                key: r == null ? null : `` + r,
                children: e,
                containerInfo: t,
                implementation: n
            }
        }
        var c = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

        function l(e, t) {
            if (e === `font`) return ``;
            if (typeof t == `string`) return t === `use-credentials` ? t : ``
        }
        e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = a, e.createPortal = function(e, t) {
            var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
            if (!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11) throw Error(r(299));
            return s(e, t, null, n)
        }, e.flushSync = function(e) {
            var t = c.T,
                n = a.p;
            try {
                if (c.T = null, a.p = 2, e) return e()
            } finally {
                c.T = t, a.p = n, a.d.f()
            }
        }, e.preconnect = function(e, t) {
            typeof e == `string` && (t ? (t = t.crossOrigin, t = typeof t == `string` ? t === `use-credentials` ? t : `` : void 0) : t = null, a.d.C(e, t))
        }, e.prefetchDNS = function(e) {
            typeof e == `string` && a.d.D(e)
        }, e.preinit = function(e, t) {
            if (typeof e == `string` && t && typeof t.as == `string`) {
                var n = t.as,
                    r = l(n, t.crossOrigin),
                    i = typeof t.integrity == `string` ? t.integrity : void 0,
                    o = typeof t.fetchPriority == `string` ? t.fetchPriority : void 0;
                n === `style` ? a.d.S(e, typeof t.precedence == `string` ? t.precedence : void 0, {
                    crossOrigin: r,
                    integrity: i,
                    fetchPriority: o
                }) : n === `script` && a.d.X(e, {
                    crossOrigin: r,
                    integrity: i,
                    fetchPriority: o,
                    nonce: typeof t.nonce == `string` ? t.nonce : void 0
                })
            }
        }, e.preinitModule = function(e, t) {
            if (typeof e == `string`)
                if (typeof t == `object` && t) {
                    if (t.as == null || t.as === `script`) {
                        var n = l(t.as, t.crossOrigin);
                        a.d.M(e, {
                            crossOrigin: n,
                            integrity: typeof t.integrity == `string` ? t.integrity : void 0,
                            nonce: typeof t.nonce == `string` ? t.nonce : void 0
                        })
                    }
                } else t ? ? a.d.M(e)
        }, e.preload = function(e, t) {
            if (typeof e == `string` && typeof t == `object` && t && typeof t.as == `string`) {
                var n = t.as,
                    r = l(n, t.crossOrigin);
                a.d.L(e, n, {
                    crossOrigin: r,
                    integrity: typeof t.integrity == `string` ? t.integrity : void 0,
                    nonce: typeof t.nonce == `string` ? t.nonce : void 0,
                    type: typeof t.type == `string` ? t.type : void 0,
                    fetchPriority: typeof t.fetchPriority == `string` ? t.fetchPriority : void 0,
                    referrerPolicy: typeof t.referrerPolicy == `string` ? t.referrerPolicy : void 0,
                    imageSrcSet: typeof t.imageSrcSet == `string` ? t.imageSrcSet : void 0,
                    imageSizes: typeof t.imageSizes == `string` ? t.imageSizes : void 0,
                    media: typeof t.media == `string` ? t.media : void 0
                })
            }
        }, e.preloadModule = function(e, t) {
            if (typeof e == `string`)
                if (t) {
                    var n = l(t.as, t.crossOrigin);
                    a.d.m(e, {
                        as: typeof t.as == `string` && t.as !== `script` ? t.as : void 0,
                        crossOrigin: n,
                        integrity: typeof t.integrity == `string` ? t.integrity : void 0
                    })
                } else a.d.m(e)
        }, e.requestFormReset = function(e) {
            a.d.r(e)
        }, e.unstable_batchedUpdates = function(e, t) {
            return e(t)
        }, e.useFormState = function(e, t, n) {
            return c.H.useFormState(e, t, n)
        }, e.useFormStatus = function() {
            return c.H.useHostTransitionStatus()
        }, e.version = `19.2.4`
    })),
    M = t(((e, t) => {
        function n() {
            if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`)) try {
                __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
            } catch {}
        }
        n(), t.exports = ee()
    })),
    N = e(n(), 1),
    P = `1.3.25`;

function F(e, t, n) {
    return Math.max(e, Math.min(t, n))
}

function te(e, t, n) {
    return (1 - n) * e + n * t
}

function I(e, t, n, r) {
    return te(e, t, 1 - Math.exp(-n * r))
}

function ne(e, t) {
    return (e % t + t) % t
}
var L = class {
    isRunning = !1;
    value = 0;
    from = 0;
    to = 0;
    currentTime = 0;
    lerp;
    duration;
    easing;
    onUpdate;
    advance(e) {
        if (!this.isRunning) return;
        let t = !1;
        if (this.duration && this.easing) {
            this.currentTime += e;
            let n = F(0, this.currentTime / this.duration, 1);
            t = n >= 1;
            let r = t ? 1 : this.easing(n);
            this.value = this.from + (this.to - this.from) * r
        } else this.lerp ? (this.value = I(this.value, this.to, this.lerp * 60, e), Math.round(this.value) === Math.round(this.to) && (this.value = this.to, t = !0)) : (this.value = this.to, t = !0);
        t && this.stop(), this.onUpdate ? .(this.value, t)
    }
    stop() {
        this.isRunning = !1
    }
    fromTo(e, t, {
        lerp: n,
        duration: r,
        easing: i,
        onStart: a,
        onUpdate: o
    }) {
        this.from = this.value = e, this.to = t, this.lerp = n, this.duration = r, this.easing = i, this.currentTime = 0, this.isRunning = !0, a ? .(), this.onUpdate = o
    }
};

function R(e, t) {
    let n;
    return function(...r) {
        clearTimeout(n), n = setTimeout(() => {
            n = void 0, e.apply(this, r)
        }, t)
    }
}
var re = class {
        width = 0;
        height = 0;
        scrollHeight = 0;
        scrollWidth = 0;
        debouncedResize;
        wrapperResizeObserver;
        contentResizeObserver;
        constructor(e, t, {
            autoResize: n = !0,
            debounce: r = 250
        } = {}) {
            this.wrapper = e, this.content = t, n && (this.debouncedResize = R(this.resize, r), this.wrapper instanceof Window ? window.addEventListener(`resize`, this.debouncedResize) : (this.wrapperResizeObserver = new ResizeObserver(this.debouncedResize), this.wrapperResizeObserver.observe(this.wrapper)), this.contentResizeObserver = new ResizeObserver(this.debouncedResize), this.contentResizeObserver.observe(this.content)), this.resize()
        }
        destroy() {
            this.wrapperResizeObserver ? .disconnect(), this.contentResizeObserver ? .disconnect(), this.wrapper === window && this.debouncedResize && window.removeEventListener(`resize`, this.debouncedResize)
        }
        resize = () => {
            this.onWrapperResize(), this.onContentResize()
        };
        onWrapperResize = () => {
            this.wrapper instanceof Window ? (this.width = window.innerWidth, this.height = window.innerHeight) : (this.width = this.wrapper.clientWidth, this.height = this.wrapper.clientHeight)
        };
        onContentResize = () => {
            this.wrapper instanceof Window ? (this.scrollHeight = this.content.scrollHeight, this.scrollWidth = this.content.scrollWidth) : (this.scrollHeight = this.wrapper.scrollHeight, this.scrollWidth = this.wrapper.scrollWidth)
        };
        get limit() {
            return {
                x: this.scrollWidth - this.width,
                y: this.scrollHeight - this.height
            }
        }
    },
    ie = class {
        events = {};
        emit(e, ...t) {
            let n = this.events[e] || [];
            for (let e = 0, r = n.length; e < r; e++) n[e] ? .(...t)
        }
        on(e, t) {
            return this.events[e] ? this.events[e].push(t) : this.events[e] = [t], () => {
                this.events[e] = this.events[e] ? .filter(e => t !== e)
            }
        }
        off(e, t) {
            this.events[e] = this.events[e] ? .filter(e => t !== e)
        }
        destroy() {
            this.events = {}
        }
    },
    z = 100 / 6,
    B = {
        passive: !1
    };

function V(e, t) {
    return e === 1 ? z : e === 2 ? t : 1
}
var ae = class {
        touchStart = {
            x: 0,
            y: 0
        };
        lastDelta = {
            x: 0,
            y: 0
        };
        window = {
            width: 0,
            height: 0
        };
        emitter = new ie;
        constructor(e, t = {
            wheelMultiplier: 1,
            touchMultiplier: 1
        }) {
            this.element = e, this.options = t, window.addEventListener(`resize`, this.onWindowResize), this.onWindowResize(), this.element.addEventListener(`wheel`, this.onWheel, B), this.element.addEventListener(`touchstart`, this.onTouchStart, B), this.element.addEventListener(`touchmove`, this.onTouchMove, B), this.element.addEventListener(`touchend`, this.onTouchEnd, B)
        }
        on(e, t) {
            return this.emitter.on(e, t)
        }
        destroy() {
            this.emitter.destroy(), window.removeEventListener(`resize`, this.onWindowResize), this.element.removeEventListener(`wheel`, this.onWheel, B), this.element.removeEventListener(`touchstart`, this.onTouchStart, B), this.element.removeEventListener(`touchmove`, this.onTouchMove, B), this.element.removeEventListener(`touchend`, this.onTouchEnd, B)
        }
        onTouchStart = e => {
            let {
                clientX: t,
                clientY: n
            } = e.targetTouches ? e.targetTouches[0] : e;
            this.touchStart.x = t, this.touchStart.y = n, this.lastDelta = {
                x: 0,
                y: 0
            }, this.emitter.emit(`scroll`, {
                deltaX: 0,
                deltaY: 0,
                event: e
            })
        };
        onTouchMove = e => {
            let {
                clientX: t,
                clientY: n
            } = e.targetTouches ? e.targetTouches[0] : e, r = -(t - this.touchStart.x) * this.options.touchMultiplier, i = -(n - this.touchStart.y) * this.options.touchMultiplier;
            this.touchStart.x = t, this.touchStart.y = n, this.lastDelta = {
                x: r,
                y: i
            }, this.emitter.emit(`scroll`, {
                deltaX: r,
                deltaY: i,
                event: e
            })
        };
        onTouchEnd = e => {
            this.emitter.emit(`scroll`, {
                deltaX: this.lastDelta.x,
                deltaY: this.lastDelta.y,
                event: e
            })
        };
        onWheel = e => {
            let {
                deltaX: t,
                deltaY: n,
                deltaMode: r
            } = e, i = V(r, this.window.width), a = V(r, this.window.height);
            t *= i, n *= a, t *= this.options.wheelMultiplier, n *= this.options.wheelMultiplier, this.emitter.emit(`scroll`, {
                deltaX: t,
                deltaY: n,
                event: e
            })
        };
        onWindowResize = () => {
            this.window = {
                width: window.innerWidth,
                height: window.innerHeight
            }
        }
    },
    oe = e => Math.min(1, 1.001 - 2 ** (-10 * e)),
    H = class {
        _isScrolling = !1;
        _isStopped = !1;
        _isLocked = !1;
        _preventNextNativeScrollEvent = !1;
        _resetVelocityTimeout = null;
        _rafId = null;
        _isDraggingSelection = !1;
        isTouching;
        isIos;
        time = 0;
        userData = {};
        lastVelocity = 0;
        velocity = 0;
        direction = 0;
        options;
        targetScroll;
        animatedScroll;
        animate = new L;
        emitter = new ie;
        dimensions;
        virtualScroll;
        constructor({
            wrapper: e = window,
            content: t = document.documentElement,
            eventsTarget: n = e,
            smoothWheel: r = !0,
            syncTouch: i = !1,
            syncTouchLerp: a = .075,
            touchInertiaExponent: o = 1.7,
            duration: s,
            easing: c,
            lerp: l = .1,
            infinite: u = !1,
            orientation: d = `vertical`,
            gestureOrientation: f = d === `horizontal` ? `both` : `vertical`,
            touchMultiplier: p = 1,
            wheelMultiplier: m = 1,
            autoResize: h = !0,
            prevent: g,
            virtualScroll: _,
            overscroll: v = !0,
            autoRaf: y = !1,
            anchors: b = !1,
            autoToggle: x = !1,
            allowNestedScroll: S = !1,
            __experimental__naiveDimensions: C = !1,
            naiveDimensions: w = C,
            stopInertiaOnNavigate: T = !1
        } = {}) {
            window.lenisVersion = P, window.lenis || (window.lenis = {}), window.lenis.version = P, d === `horizontal` && (window.lenis.horizontal = !0), i === !0 && (window.lenis.touch = !0), this.isIos = /(iPad|iPhone|iPod)/g.test(navigator.userAgent), (!e || e === document.documentElement) && (e = window), typeof s == `number` && typeof c != `function` ? c = oe : typeof c == `function` && typeof s != `number` && (s = 1), this.options = {
                wrapper: e,
                content: t,
                eventsTarget: n,
                smoothWheel: r,
                syncTouch: i,
                syncTouchLerp: a,
                touchInertiaExponent: o,
                duration: s,
                easing: c,
                lerp: l,
                infinite: u,
                gestureOrientation: f,
                orientation: d,
                touchMultiplier: p,
                wheelMultiplier: m,
                autoResize: h,
                prevent: g,
                virtualScroll: _,
                overscroll: v,
                autoRaf: y,
                anchors: b,
                autoToggle: x,
                allowNestedScroll: S,
                naiveDimensions: w,
                stopInertiaOnNavigate: T
            }, this.dimensions = new re(e, t, {
                autoResize: h
            }), this.updateClassName(), this.targetScroll = this.animatedScroll = this.actualScroll, this.options.wrapper.addEventListener(`scroll`, this.onNativeScroll), this.options.wrapper.addEventListener(`scrollend`, this.onScrollEnd, {
                capture: !0
            }), (this.options.anchors || this.options.stopInertiaOnNavigate) && this.options.wrapper.addEventListener(`click`, this.onClick), this.options.wrapper.addEventListener(`pointerdown`, this.onPointerDown), this.virtualScroll = new ae(n, {
                touchMultiplier: p,
                wheelMultiplier: m
            }), this.virtualScroll.on(`scroll`, this.onVirtualScroll), this.options.autoToggle && (this.checkOverflow(), this.rootElement.addEventListener(`transitionend`, this.onTransitionEnd)), this.options.autoRaf && (this._rafId = requestAnimationFrame(this.raf))
        }
        destroy() {
            this.emitter.destroy(), this.options.wrapper.removeEventListener(`scroll`, this.onNativeScroll), this.options.wrapper.removeEventListener(`scrollend`, this.onScrollEnd, {
                capture: !0
            }), this.options.wrapper.removeEventListener(`pointerdown`, this.onPointerDown), (this.options.anchors || this.options.stopInertiaOnNavigate) && this.options.wrapper.removeEventListener(`click`, this.onClick), this.virtualScroll.destroy(), this.dimensions.destroy(), this.cleanUpClassName(), this._rafId && cancelAnimationFrame(this._rafId)
        }
        on(e, t) {
            return this.emitter.on(e, t)
        }
        off(e, t) {
            return this.emitter.off(e, t)
        }
        onScrollEnd = e => {
            e instanceof CustomEvent || (this.isScrolling === `smooth` || this.isScrolling === !1) && e.stopPropagation()
        };
        dispatchScrollendEvent = () => {
            this.options.wrapper.dispatchEvent(new CustomEvent(`scrollend`, {
                bubbles: this.options.wrapper === window,
                detail: {
                    lenisScrollEnd: !0
                }
            }))
        };
        get overflow() {
            let e = this.isHorizontal ? `overflow-x` : `overflow-y`;
            return getComputedStyle(this.rootElement)[e]
        }
        checkOverflow() {
            [`hidden`, `clip`].includes(this.overflow) ? this.internalStop() : this.internalStart()
        }
        onTransitionEnd = e => {
            e.propertyName ? .includes(`overflow`) && e.target === this.rootElement && this.checkOverflow()
        };
        setScroll(e) {
            this.isHorizontal ? this.options.wrapper.scrollTo({
                left: e,
                behavior: `instant`
            }) : this.options.wrapper.scrollTo({
                top: e,
                behavior: `instant`
            })
        }
        onClick = e => {
            let t = e.composedPath().filter(e => e instanceof HTMLAnchorElement && e.href).map(e => new URL(e.href)),
                n = new URL(window.location.href);
            if (this.options.anchors) {
                let e = t.find(e => n.host === e.host && n.pathname === e.pathname && e.hash);
                if (e) {
                    let t = typeof this.options.anchors == `object` && this.options.anchors ? this.options.anchors : void 0,
                        n = decodeURIComponent(e.hash);
                    this.scrollTo(n, t);
                    return
                }
            }
            if (this.options.stopInertiaOnNavigate && t.some(e => n.host === e.host && n.pathname !== e.pathname)) {
                this.reset();
                return
            }
        };
        onPointerDown = e => {
            e.button === 1 && this.reset()
        };
        isTouchOnSelectionHandle(e) {
            let t = window.getSelection();
            if (!t || t.isCollapsed || t.rangeCount === 0) return !1;
            let n = e.targetTouches[0] ? ? e.changedTouches[0];
            if (!n) return !1;
            let r = t.getRangeAt(0).getClientRects();
            if (r.length === 0) return !1;
            let i = r[0],
                a = r[r.length - 1],
                o = Math.hypot(n.clientX - i.left, n.clientY - i.top) <= 40,
                s = Math.hypot(n.clientX - a.right, n.clientY - a.bottom) <= 40;
            return o || s
        }
        onVirtualScroll = e => {
            if (typeof this.options.virtualScroll == `function` && this.options.virtualScroll(e) === !1) return;
            let {
                deltaX: t,
                deltaY: n,
                event: r
            } = e;
            if (this.emitter.emit(`virtual-scroll`, {
                    deltaX: t,
                    deltaY: n,
                    event: r
                }), r.ctrlKey || r.lenisStopPropagation) return;
            let i = r.type.includes(`touch`),
                a = r.type.includes(`wheel`);
            if (i && this.isIos && (r.type === `touchstart` && (this._isDraggingSelection = this.isTouchOnSelectionHandle(r)), this._isDraggingSelection)) {
                r.type === `touchend` && (this._isDraggingSelection = !1);
                return
            }
            this.isTouching = r.type === `touchstart` || r.type === `touchmove`;
            let o = t === 0 && n === 0;
            if (this.options.syncTouch && i && r.type === `touchstart` && o && !this.isStopped && !this.isLocked) {
                this.reset();
                return
            }
            let s = this.options.gestureOrientation === `vertical` && n === 0 || this.options.gestureOrientation === `horizontal` && t === 0;
            if (o || s) return;
            let c = r.composedPath();
            c = c.slice(0, c.indexOf(this.rootElement));
            let l = this.options.prevent,
                u = Math.abs(t) >= Math.abs(n) ? `horizontal` : `vertical`;
            if (c.find(e => e instanceof HTMLElement && (typeof l == `function` && l ? .(e) || e.hasAttribute ? .(`data-lenis-prevent`) || u === `vertical` && e.hasAttribute ? .(`data-lenis-prevent-vertical`) || u === `horizontal` && e.hasAttribute ? .(`data-lenis-prevent-horizontal`) || i && e.hasAttribute ? .(`data-lenis-prevent-touch`) || a && e.hasAttribute ? .(`data-lenis-prevent-wheel`) || this.options.allowNestedScroll && this.hasNestedScroll(e, {
                    deltaX: t,
                    deltaY: n
                })))) return;
            if (this.isStopped || this.isLocked) {
                r.cancelable && r.preventDefault();
                return
            }
            if (!(this.options.syncTouch && i || this.options.smoothWheel && a)) {
                this.isScrolling = `native`, this.animate.stop(), r.lenisStopPropagation = !0;
                return
            }
            let d = n;
            this.options.gestureOrientation === `both` ? d = Math.abs(n) > Math.abs(t) ? n : t : this.options.gestureOrientation === `horizontal` && (d = t), (!this.options.overscroll || this.options.infinite || this.options.wrapper !== window && this.limit > 0 && (this.animatedScroll > 0 && this.animatedScroll < this.limit || this.animatedScroll === 0 && n > 0 || this.animatedScroll === this.limit && n < 0)) && (r.lenisStopPropagation = !0), r.cancelable && r.preventDefault();
            let f = i && this.options.syncTouch,
                p = i && r.type === `touchend`;
            p && (d = Math.sign(d) * Math.abs(this.velocity) ** this.options.touchInertiaExponent), this.scrollTo(this.targetScroll + d, {
                programmatic: !1,
                ...f ? {
                    lerp: p ? this.options.syncTouchLerp : 1
                } : {
                    lerp: this.options.lerp,
                    duration: this.options.duration,
                    easing: this.options.easing
                }
            })
        };
        resize() {
            this.dimensions.resize(), this.animatedScroll = this.targetScroll = this.actualScroll, this.emit()
        }
        emit() {
            this.emitter.emit(`scroll`, this)
        }
        onNativeScroll = () => {
            if (this._resetVelocityTimeout !== null && (clearTimeout(this._resetVelocityTimeout), this._resetVelocityTimeout = null), this._preventNextNativeScrollEvent) {
                this._preventNextNativeScrollEvent = !1;
                return
            }
            if (this.isScrolling === !1 || this.isScrolling === `native`) {
                let e = this.animatedScroll;
                this.animatedScroll = this.targetScroll = this.actualScroll, this.lastVelocity = this.velocity, this.velocity = this.animatedScroll - e, this.direction = Math.sign(this.animatedScroll - e), this.isStopped || (this.isScrolling = `native`), this.emit(), this.velocity !== 0 && (this._resetVelocityTimeout = setTimeout(() => {
                    this.lastVelocity = this.velocity, this.velocity = 0, this.isScrolling = !1, this.emit()
                }, 400))
            }
        };
        reset() {
            this.isLocked = !1, this.isScrolling = !1, this.animatedScroll = this.targetScroll = this.actualScroll, this.lastVelocity = this.velocity = 0, this.animate.stop()
        }
        start() {
            if (this.isStopped) {
                if (this.options.autoToggle) {
                    this.rootElement.style.removeProperty(`overflow`);
                    return
                }
                this.internalStart()
            }
        }
        internalStart() {
            this.isStopped && (this.reset(), this.isStopped = !1, this.emit())
        }
        stop() {
            if (!this.isStopped) {
                if (this.options.autoToggle) {
                    this.rootElement.style.setProperty(`overflow`, `clip`);
                    return
                }
                this.internalStop()
            }
        }
        internalStop() {
            this.isStopped || (this.reset(), this.isStopped = !0, this.emit())
        }
        raf = e => {
            let t = e - (this.time || e);
            this.time = e, this.animate.advance(t * .001), this.options.autoRaf && (this._rafId = requestAnimationFrame(this.raf))
        };
        scrollTo(e, {
            offset: t = 0,
            immediate: n = !1,
            lock: r = !1,
            programmatic: i = !0,
            lerp: a = i ? this.options.lerp : void 0,
            duration: o = i ? this.options.duration : void 0,
            easing: s = i ? this.options.easing : void 0,
            onStart: c,
            onComplete: l,
            force: u = !1,
            userData: d
        } = {}) {
            if ((this.isStopped || this.isLocked) && !u) return;
            let f = e,
                p = t;
            if (typeof f == `string` && [`top`, `left`, `start`, `#`].includes(f)) f = 0;
            else if (typeof f == `string` && [`bottom`, `right`, `end`].includes(f)) f = this.limit;
            else {
                let e = null;
                if (typeof f == `string` ? (e = f.startsWith(`#`) ? document.getElementById(f.slice(1)) : document.querySelector(f), e || f === `#top` && (f = 0)) : f instanceof HTMLElement && f ? .nodeType && (e = f), e) {
                    if (this.options.wrapper !== window) {
                        let e = this.rootElement.getBoundingClientRect();
                        p -= this.isHorizontal ? e.left : e.top
                    }
                    let t = e.getBoundingClientRect(),
                        n = getComputedStyle(e),
                        r = this.isHorizontal ? Number.parseFloat(n.scrollMarginLeft) : Number.parseFloat(n.scrollMarginTop),
                        i = getComputedStyle(this.rootElement),
                        a = this.isHorizontal ? Number.parseFloat(i.scrollPaddingLeft) : Number.parseFloat(i.scrollPaddingTop);
                    f = (this.isHorizontal ? t.left : t.top) + this.animatedScroll - (Number.isNaN(r) ? 0 : r) - (Number.isNaN(a) ? 0 : a)
                }
            }
            if (typeof f == `number`) {
                if (f += p, this.options.infinite) {
                    if (i) {
                        this.targetScroll = this.animatedScroll = this.scroll;
                        let e = f - this.animatedScroll;
                        e > this.limit / 2 ? f -= this.limit : e < -this.limit / 2 && (f += this.limit)
                    }
                } else f = F(0, f, this.limit);
                if (f === this.targetScroll) {
                    c ? .(this), l ? .(this);
                    return
                }
                if (this.userData = d ? ? {}, n) {
                    this.animatedScroll = this.targetScroll = f, this.setScroll(this.scroll), this.reset(), this.preventNextNativeScrollEvent(), this.emit(), l ? .(this), this.userData = {}, requestAnimationFrame(() => {
                        this.dispatchScrollendEvent()
                    });
                    return
                }
                i || (this.targetScroll = f), typeof o == `number` && typeof s != `function` ? s = oe : typeof s == `function` && typeof o != `number` && (o = 1), this.animate.fromTo(this.animatedScroll, f, {
                    duration: o,
                    easing: s,
                    lerp: a,
                    onStart: () => {
                        r && (this.isLocked = !0), this.isScrolling = `smooth`, c ? .(this)
                    },
                    onUpdate: (e, t) => {
                        this.isScrolling = `smooth`, this.lastVelocity = this.velocity, this.velocity = e - this.animatedScroll, this.direction = Math.sign(this.velocity), this.animatedScroll = e, this.setScroll(this.scroll), i && (this.targetScroll = e), t || this.emit(), t && (this.reset(), this.emit(), l ? .(this), this.userData = {}, requestAnimationFrame(() => {
                            this.dispatchScrollendEvent()
                        }), this.preventNextNativeScrollEvent())
                    }
                })
            }
        }
        preventNextNativeScrollEvent() {
            this._preventNextNativeScrollEvent = !0, requestAnimationFrame(() => {
                this._preventNextNativeScrollEvent = !1
            })
        }
        hasNestedScroll(e, {
            deltaX: t,
            deltaY: n
        }) {
            let r = Date.now();
            e._lenis || = {};
            let i = e._lenis,
                a, o, s, c, l, u, d, f, p, m;
            if (r - (i.time ? ? 0) > 2e3) {
                i.time = Date.now();
                let t = window.getComputedStyle(e);
                if (i.computedStyle = t, a = [`auto`, `overlay`, `scroll`].includes(t.overflowX), o = [`auto`, `overlay`, `scroll`].includes(t.overflowY), l = [`auto`].includes(t.overscrollBehaviorX), u = [`auto`].includes(t.overscrollBehaviorY), i.hasOverflowX = a, i.hasOverflowY = o, !(a || o)) return !1;
                d = e.scrollWidth, f = e.scrollHeight, p = e.clientWidth, m = e.clientHeight, s = d > p, c = f > m, i.isScrollableX = s, i.isScrollableY = c, i.scrollWidth = d, i.scrollHeight = f, i.clientWidth = p, i.clientHeight = m, i.hasOverscrollBehaviorX = l, i.hasOverscrollBehaviorY = u
            } else s = i.isScrollableX, c = i.isScrollableY, a = i.hasOverflowX, o = i.hasOverflowY, d = i.scrollWidth, f = i.scrollHeight, p = i.clientWidth, m = i.clientHeight, l = i.hasOverscrollBehaviorX, u = i.hasOverscrollBehaviorY;
            if (!(a && s || o && c)) return !1;
            let h = Math.abs(t) >= Math.abs(n) ? `horizontal` : `vertical`,
                g, _, v, y, b, x;
            if (h === `horizontal`) g = Math.round(e.scrollLeft), _ = d - p, v = t, y = a, b = s, x = l;
            else if (h === `vertical`) g = Math.round(e.scrollTop), _ = f - m, v = n, y = o, b = c, x = u;
            else return !1;
            return !x && (g >= _ || g <= 0) ? !0 : (v > 0 ? g < _ : g > 0) && y && b
        }
        get rootElement() {
            return this.options.wrapper === window ? document.documentElement : this.options.wrapper
        }
        get limit() {
            return this.options.naiveDimensions ? this.isHorizontal ? this.rootElement.scrollWidth - this.rootElement.clientWidth : this.rootElement.scrollHeight - this.rootElement.clientHeight : this.dimensions.limit[this.isHorizontal ? `x` : `y`]
        }
        get isHorizontal() {
            return this.options.orientation === `horizontal`
        }
        get actualScroll() {
            let e = this.options.wrapper;
            return this.isHorizontal ? e.scrollX ? ? e.scrollLeft : e.scrollY ? ? e.scrollTop
        }
        get scroll() {
            return this.options.infinite ? ne(this.animatedScroll, this.limit) : this.animatedScroll
        }
        get progress() {
            return this.limit === 0 ? 1 : this.scroll / this.limit
        }
        get isScrolling() {
            return this._isScrolling
        }
        set isScrolling(e) {
            this._isScrolling !== e && (this._isScrolling = e, this.updateClassName())
        }
        get isStopped() {
            return this._isStopped
        }
        set isStopped(e) {
            this._isStopped !== e && (this._isStopped = e, this.updateClassName())
        }
        get isLocked() {
            return this._isLocked
        }
        set isLocked(e) {
            this._isLocked !== e && (this._isLocked = e, this.updateClassName())
        }
        get isSmooth() {
            return this.isScrolling === `smooth`
        }
        get className() {
            let e = `lenis`;
            return this.options.autoToggle && (e += ` lenis-autoToggle`), this.isStopped && (e += ` lenis-stopped`), this.isLocked && (e += ` lenis-locked`), this.isScrolling && (e += ` lenis-scrolling`), this.isScrolling === `smooth` && (e += ` lenis-smooth`), e
        }
        updateClassName() {
            this.cleanUpClassName(), this.className.split(` `).forEach(e => {
                this.rootElement.classList.add(e)
            })
        }
        cleanUpClassName() {
            for (let e of Array.from(this.rootElement.classList))(e === `lenis` || e.startsWith(`lenis-`)) && this.rootElement.classList.remove(e)
        }
    },
    se = new Map;

function ce(e, t) {
    let n = {
        done: 0,
        total: Math.max(1, t)
    };
    return se.set(e, n), {
        step(e = 1) {
            n.done = Math.min(n.total, n.done + e)
        },
        finish() {
            n.done = n.total
        }
    }
}

function le() {
    let e = 0,
        t = 0;
    for (let n of se.values()) e += n.done, t += n.total;
    return t === 0 ? 0 : e / t
}

function ue() {
    return se.size > 0
}
var U = {
        root: `_root_1bp3t_1`,
        embed: `_embed_1bp3t_12`,
        canvas: `_canvas_1bp3t_19`,
        title: `_title_1bp3t_40`,
        kicker: `_kicker_1bp3t_50`,
        panel: `_panel_1bp3t_74`,
        slider: `_slider_1bp3t_94`,
        sliderHead: `_sliderHead_1bp3t_95`,
        val: `_val_1bp3t_99`,
        check: `_check_1bp3t_116`,
        actions: `_actions_1bp3t_126`
    },
    W = r(),
    de = w.length,
    fe = 18,
    G = 2,
    pe = 9,
    me = {
        Uncomfortable: `#ff6b5e`,
        Exposure: `#5e9cff`,
        Social: `#46c98e`,
        Creative: `#c77dff`
    },
    he = e => me[e] ? ? `#c9a24a`,
    ge = e => (e % de + de) % de,
    K = (e, t, n) => e + (t - e) * n,
    _e = (e, t, n) => {
        let r = Math.min(1, Math.max(0, (n - e) / (t - e)));
        return r * r * (3 - 2 * r)
    },
    ve = 345,
    ye = 0,
    be = 490,
    xe = ye + be,
    Se = 2.4,
    Ce = xe / ve * Se,
    we = `In-person beats text for anything that matters.`,
    Te = `-apple-system, system-ui, 'SF Pro Display', 'Helvetica Neue', sans-serif`,
    Ee = [{
        slug: `tempers`,
        name: `The Temperers of Steel`
    }, {
        slug: `brotherhood-of-tale`,
        name: `The Brotherhood of Tale`
    }, {
        slug: `keepers-of-time`,
        name: `The Keepers of Time`
    }, {
        slug: `seeker-of-forsaken`,
        name: `The Seekers of Forsaken`
    }, {
        slug: `wind-shifters`,
        name: `The Wind Shifters`
    }],
    De = e => Ee[e % Ee.length],
    Oe = `A small nudge off autopilot. Do the thing, then come back and mark it done.`;

function ke(e) {
    return new Promise((t, n) => {
        let r = new Image;
        r.onload = () => t(r), r.onerror = n, r.src = e
    })
}

function Ae(e) {
    let t = document.createElement(`canvas`);
    t.width = t.height = 14;
    let n = t.getContext(`2d`, {
        willReadFrequently: !0
    });
    n.drawImage(e, 0, 0, 14, 14);
    let r = n.getImageData(0, 0, 14, 14).data,
        i = [150, 150, 150],
        a = -1;
    for (let e = 0; e < r.length; e += 4) {
        if (r[e + 3] < 128) continue;
        let t = r[e],
            n = r[e + 1],
            o = r[e + 2],
            s = Math.max(t, n, o) - Math.min(t, n, o);
        s > a && Math.max(t, n, o) > 70 && (a = s, i = [t, n, o])
    }
    let o = .3 * i[0] + .59 * i[1] + .11 * i[2],
        s = .5,
        c = e => Math.round(e * (1 - s) + o * s);
    return `rgba(${c(i[0])}, ${c(i[1])}, ${c(i[2])}, 0.28)`
}
async function je(e) {
    let t = {},
        n = {};
    return await Promise.all(Ee.map(async r => {
        let i = await ke(`/patterns/${r.slug}.webp`);
        e ? .(), t[r.slug] = i, n[r.slug] = Ae(i)
    })), {
        emblems: t,
        glow: n,
        avatars: await Promise.all([1, 2, 3].map(t => ke(`/avatars/a${t}.webp`).then(t => (e ? .(), t))))
    }
}
var Me = 6.5,
    Ne = {
        angleStep: .65,
        radius: 2.6,
        squish: .7,
        gapX: -.05,
        gapY: .4,
        edgeTwist: -.06,
        cardScale: .65,
        bend: .06,
        smear: 1,
        auto: !0,
        autoSpeed: .15,
        mouseTilt: .12,
        magnet: .1
    },
    Pe = .18,
    Fe = .72,
    Ie = 1.18,
    Le = 1.7,
    Re = 1.95,
    ze = 2.55,
    Be = 2.15,
    Ve = 2.6,
    He = .86,
    Ue = .55,
    We = `
uniform float uBend;
uniform float uFlip;   // 0..1 accept turn; rows stagger top -> bottom
uniform float uCardH;  // plane height, for the row stagger
varying vec2 vUv;
void main() {
  vUv = uv;
  vec3 p = position;
  // Curl the side edges back, plus a gentle vertical bow — the bent-plane look.
  p.z -= uBend * position.x * position.x;
  p.z -= uBend * 0.35 * position.y * position.y;
  // Accept flip: each row turns a full 360°, the top edge leading the bottom
  // (top starts and finishes ahead), so the back ripples down the card.
  if (uFlip > 0.0001) {
    float yN = position.y / uCardH + 0.5;          // 0 bottom .. 1 top
    float delay = 0.2;                             // subtle lead of top over bottom
    float rp = clamp((uFlip - (1.0 - yN) * delay) / (1.0 - delay), 0.0, 1.0);
    float a = rp * 6.2831853;
    float s = sin(a), c = cos(a);
    float nx = p.x * c - p.z * s;
    p.z = p.x * s + p.z * c;
    p.x = nx;
  }
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}
`,
    Ge = `
precision highp float;
uniform sampler2D uTex;
uniform sampler2D uBack;
uniform float uSmear;
uniform vec2 uDir;
uniform float uDim;
varying vec2 vUv;

void main() {
  // Back of the card — the guild emblem, full-bleed.
  if (!gl_FrontFacing) {
    vec4 b = texture2D(uBack, vUv);
    gl_FragColor = vec4(b.rgb * max(uDim, 0.7), b.a);
    return;
  }
  // Front — texture with velocity smear. When there's no motion (the common
  // case: slow spin, frozen deck, single card) skip the 7-tap loop entirely.
  if (uSmear < 0.0008) {
    vec4 c0 = texture2D(uTex, vUv);
    c0.rgb *= uDim;
    gl_FragColor = c0;
    return;
  }
  vec4 acc = vec4(0.0);
  float total = 0.0;
  for (int i = 0; i < 7; i++) {
    float t = float(i) / 6.0 - 0.5;     // -0.5 .. 0.5
    float w = 1.0 - abs(t) * 1.3;
    if (w <= 0.0) continue;
    acc += texture2D(uTex, vUv + uDir * t * uSmear) * w;
    total += w;
  }
  vec4 c = acc / total;
  c.rgb *= uDim;
  gl_FragColor = c;
}
`;

function Ke(e, t, n, r, i) {
    let a = r * .16;
    e.beginPath(), e.moveTo(t + a, n), e.lineTo(t + r - a, n), e.arcTo(t + r, n, t + r, n + a, a), e.lineTo(t + r, n + i * .5), e.quadraticCurveTo(t + r, n + i * .86, t + r / 2, n + i), e.quadraticCurveTo(t, n + i * .86, t, n + i * .5), e.lineTo(t, n + a), e.arcTo(t, n, t + a, n, a), e.closePath()
}

function qe(e, t, n, r, i, a) {
    let o = r * 1.12;
    e.save(), Ke(e, t, n, r, o), e.shadowColor = a, e.shadowBlur = 18, e.shadowOffsetY = 4, e.fillStyle = `#dcdcdc`, e.fill(), e.restore(), e.save(), Ke(e, t, n, r, o), e.clip(), e.drawImage(i, t, n, r, o), e.restore()
}

function Je(e, t, n, r, i) {
    e.font = `500 14px ${Te}`, e.textBaseline = `middle`;
    let a = t;
    for (let t = 0; t < 3; t++) {
        let o = `0:18`,
            s = 40 + e.measureText(o).width + 8;
        e.beginPath(), e.roundRect(a, n, s, 40, 40 / 2), e.fillStyle = `rgba(255,255,255,0.71)`, e.fill(), e.save(), e.beginPath(), e.arc(a + 20, n + 40 / 2, 16, 0, Math.PI * 2), e.clip(), e.drawImage(r[(i + t) % r.length], a + 4, n + 4, 32, 32), e.restore(), e.fillStyle = `#838383`, e.fillText(o, a + 40, n + 40 / 2 + 1), a += s + 4
    }
    let o = 8 + e.measureText(`+12`).width + 8;
    e.beginPath(), e.roundRect(a, n, o, 40, 40 / 2), e.fillStyle = `rgba(255,255,255,0.71)`, e.fill(), e.fillStyle = `#838383`, e.fillText(`+12`, a + 8, n + 40 / 2 + 1), e.textBaseline = `alphabetic`
}

function Ye(e, t, n, r, i, a, o = 99) {
    let s = ``,
        c = 0,
        l = t => {
            e.fillText(t, n, r), r += a, c++
        };
    for (let n of t.split(` `)) {
        let t = s ? s + ` ` + n : n;
        if (e.measureText(t).width <= i) {
            s = t;
            continue
        }
        if (s && (l(s), s = ``, c >= o)) return r;
        for (; e.measureText(n).width > i;) {
            let t = 1;
            for (; t < n.length && e.measureText(n.slice(0, t + 1)).width <= i;) t++;
            if (l(n.slice(0, t)), c >= o) return r;
            n = n.slice(t)
        }
        s = n
    }
    return s && c < o && l(s), r
}

function Xe(e, t) {
    let n = ve,
        r = xe,
        i = G;
    e.width = n * i, e.height = r * i;
    let a = e.getContext(`2d`);
    a.setTransform(i, 0, 0, i, 0, 0), a.clearRect(0, 0, n, r), a.save(), a.beginPath(), a.roundRect(0, ye, n, be, 20), a.clip();
    let o = Math.max(n / t.width, be / t.height),
        s = t.width * o,
        c = t.height * o;
    a.drawImage(t, (n - s) / 2, ye + (be - c) / 2, s, c), a.restore()
}

function Ze(e, t, n, r, i, a) {
    let o = ve,
        s = xe,
        c = G;
    e.width = o * c, e.height = s * c;
    let l = e.getContext(`2d`);
    l.setTransform(c, 0, 0, c, 0, 0), l.clearRect(0, 0, o, s), l.beginPath(), l.roundRect(0, 0, o, s, 20), l.fillStyle = `#efefef`, l.fill(), qe(l, 16, 24, 56, r, i), l.save(), l.beginPath(), l.roundRect(0, 0, o, s, 20), l.clip(), l.textAlign = `left`, l.textBaseline = `alphabetic`;
    let u = 106.72;
    l.font = `400 16px ${Te}`, l.fillStyle = `#838383`, l.fillText(n.name, 16, u), l.font = `700 33px ${Te}`, l.fillStyle = `#000`, u = Ye(l, t.text, 16, u + 36, o - 32, 33 * .97), l.font = `400 16px ${Te}`, l.fillStyle = `#464646`, Ye(l, t.body ? ? Oe, 16, u + 14, o - 32, 16 * 1.24), Je(l, 16, s - 47 - 40, a, t.id), l.fillStyle = `#f2f2f2`, l.fillRect(0, s - 38, o, 38), l.strokeStyle = `rgba(0,0,0,0.08)`, l.lineWidth = 1, l.beginPath(), l.moveTo(0, s - 38), l.lineTo(o, s - 38), l.stroke(), l.font = `400 12px ${Te}`, l.fillStyle = `#838383`, l.textAlign = `center`, Ye(l, we, o / 2, s - 22, o - 36, 14, 2), l.textAlign = `left`, l.restore()
}
var Qe = 2.2;

function $e({
    embedded: e = !1,
    reveal: t = !1,
    revealNonce: n = 0,
    cfg: r,
    scrollRef: i,
    active: a = !0,
    spMax: o = 1 / 0,
    revealProgress: c
} = {}) {
    let u = (0, N.useRef)(null),
        T = (0, N.useRef)(o);
    (0, N.useEffect)(() => {
        T.current = o
    }, [o]);
    let [E, D] = (0, N.useState)({ ...Ne,
        ...r
    }), [O, k] = (0, N.useState)(!1), [A, j] = (0, N.useState)(w[0].category), ee = (0, N.useRef)(E), M = (0, N.useRef)(0), P = (0, N.useRef)(0), F = (0, N.useRef)(0), te = (0, N.useRef)(null), I = (0, N.useRef)({
        x: 0,
        y: 0
    }), ne = (0, N.useRef)(t), L = (0, N.useRef)(0), R = (0, N.useRef)(i), re = (0, N.useRef)(typeof matchMedia == `function` && matchMedia(`(prefers-reduced-motion: reduce)`).matches);
    (0, N.useEffect)(() => {
        ee.current = E
    }, [E]), (0, N.useEffect)(() => {
        R.current = i
    }, [i]);
    let ie = (0, N.useRef)(a);
    (0, N.useEffect)(() => {
        ie.current = a
    }, [a]);
    let z = (0, N.useRef)(c);
    (0, N.useEffect)(() => {
        z.current = c
    }, [c]), (0, N.useEffect)(() => {
        !t || re.current || (ne.current = !0, L.current = performance.now() / 1e3)
    }, [t, n]), (0, N.useEffect)(() => {
        let t = u.current;
        if (!t || l()) {
            k(!0), ce(`spiral`, 1).finish();
            return
        }
        G = f() ? 1.5 : 2;
        let n = new b({
            canvas: t,
            antialias: d(),
            alpha: !0
        });
        n.setPixelRatio(p(2, 1.5)), n.setClearColor(0, 0);
        let r = new C,
            i = new x(38, 1, .1, 100);
        i.position.z = 9;
        let a = () => {
            let e = t.clientWidth,
                a = t.clientHeight;
            n.setSize(e, a, !1), i.aspect = e / a, i.updateProjectionMatrix(), n.render(r, i)
        };
        a();
        let o = s(a),
            c = t.clientWidth,
            E = t.clientHeight,
            D = performance.now(),
            O = requestAnimationFrame(function e() {
                let n = t.clientWidth,
                    r = t.clientHeight;
                (n !== c || r !== E) && (c = n, E = r, a()), performance.now() - D < 1200 && (O = requestAnimationFrame(e))
            }),
            A = (e, t) => {
                let n = document.createElement(`canvas`);
                return n.width = e, n.height = t, n
            },
            N = w.map(() => {
                let e = A(ve * G, xe * G),
                    t = e.getContext(`2d`);
                return t.setTransform(G, 0, 0, G, 0, 0), t.fillStyle = `#efefef`, t.beginPath(), t.roundRect(0, 0, ve, xe, 20), t.fill(), e
            }),
            B = w.map(() => A(ve * G, xe * G)),
            V = (e, t = !1) => {
                let r = new S(e);
                return r.colorSpace = ``, r.anisotropy = Math.min(f() ? 2 : 16, n.capabilities.getMaxAnisotropy()), t && (r.minFilter = g), f() && (r.onUpdate = () => {
                    e.dataset.painted && (e.width = 1, e.height = 1)
                }), r
            },
            ae = N.map(e => V(e, !0)),
            oe = B.map(e => V(e)),
            H = 0,
            se = 0,
            le = ce(`spiral`, Ee.length + 3 + 1);
        Promise.all([je(() => le.step()), document.fonts ? .ready]).then(([e]) => {
            let t = () => {
                let n = performance.now() + 6;
                for (; H < w.length && performance.now() < n;) {
                    let t = H++,
                        n = w[t],
                        r = De(n.id),
                        i = e.emblems[r.slug];
                    Ze(N[t], n, r, i, e.glow[r.slug], e.avatars), Xe(B[t], i), N[t].dataset.painted = B[t].dataset.painted = `1`, ae[t].needsUpdate = !0, oe[t].needsUpdate = !0
                }
                Ke = performance.now() / 1e3 + .45, H < w.length ? se = requestAnimationFrame(t) : le.step()
            };
            se = requestAnimationFrame(t)
        }).catch(e => {
            le.finish()
        });
        let ue = new v;
        r.add(ue);
        let U = new _(Se, Ce, 24, 16),
            W = [];
        for (let e = 0; e < fe; e++) {
            let e = new h(U, new y({
                uniforms: {
                    uTex: {
                        value: ae[0]
                    },
                    uBack: {
                        value: oe[0]
                    },
                    uBend: {
                        value: Ne.bend
                    },
                    uSmear: {
                        value: 0
                    },
                    uDir: {
                        value: new m(0, 1)
                    },
                    uDim: {
                        value: 1
                    },
                    uFlip: {
                        value: 0
                    },
                    uCardH: {
                        value: Ce
                    }
                },
                vertexShader: We,
                fragmentShader: Ge,
                transparent: !0,
                side: 2,
                depthTest: !1,
                depthWrite: !1
            }));
            ue.add(e), W.push(e)
        }
        let de = 0,
            me = !0,
            he = performance.now() / 1e3,
            ye = 0,
            be = 0,
            we = 0,
            Te = 0,
            Oe = -1,
            ke = 0,
            Ae = 0,
            Ke = 0,
            qe = performance.now() / 1e3,
            Je = 0,
            Ye = () => {
                if (!ie.current) {
                    de = requestAnimationFrame(Ye);
                    return
                }
                if (!me) return;
                let t = performance.now() / 1e3; {
                    let e = Math.min(T.current, R.current ? .current ? .p ? ? 0),
                        n = I.current;
                    if ((Math.abs(e - Oe) > 1e-5 || Math.abs(n.x - ke) > 1e-4 || Math.abs(n.y - Ae) > 1e-4 || ne.current) && (qe = t), t - qe > 2 && t - Je < 1 / 30) {
                        de = requestAnimationFrame(Ye);
                        return
                    }
                    Je = t
                }
                let a = Math.min(.05, t - he) || .016;
                he = t;
                let o = ee.current,
                    s = R.current ? .current ? .p ? ? 0,
                    c = Math.min(T.current, Number.isFinite(s) ? s : 0),
                    l = _e(Pe, Fe, c),
                    u = _e(Ie, Le, c),
                    d = _e(Re, ze, c),
                    f = _e(Be, Ve, c),
                    p = Math.max(l, u),
                    m = 1,
                    h = z.current;
                if (h) {
                    if (ne.current = !1, !re.current) {
                        let e = Math.min(1, Math.max(0, h.current));
                        m = 1 - (1 - e) ** 3, e < 1 && (Ke = t + .45)
                    }
                } else if (ne.current) {
                    let e = Math.min(1, (t - L.current) / Qe);
                    m = 1 - (1 - e) ** 3, e >= 1 && (ne.current = !1)
                }
                let g = 12 + (o.radius - 12) * m,
                    _ = 1 + (o.autoSpeed - 1) * m,
                    v = .4 + (o.cardScale - .4) * m;
                o.auto && !re.current && (M.current += _ * a * (1 - l));
                let y = M.current;
                P.current += (y - P.current) * Math.min(1, a * 8), Math.abs(y - P.current) < 3e-4 && (P.current = y);
                let b = P.current,
                    x = (b - ye) / a;
                ye = b, be += (x - be) * .25;
                let S = Math.min(.055, Math.abs(be) * .012 * o.smear);
                if (!e) {
                    let e = Math.round(b);
                    e !== F.current && (F.current = e, j(w[ge(e)].category))
                }
                let C = g * o.squish;
                i.position.z = C + Me;
                let E = I.current;
                we += (-E.y * o.mouseTilt - we) * Math.min(1, a * 4), Te += (E.x * o.mouseTilt - Te) * Math.min(1, a * 4);
                let D = 1 - p;
                ue.rotation.x = we * D, ue.rotation.z = -Te * D;
                let O = Math.tan(38 * Math.PI / 180 / 2) * i.position.z,
                    k = O * i.aspect,
                    A = E.x * k,
                    N = E.y * O;
                l > .001 && te.current === null && (te.current = Math.round(b)), l < .001 && (te.current = null);
                let B = (te.current ? ? Math.round(b)) - pe;
                for (let e = 0; e < fe; e++) {
                    let t = B + e,
                        n = t - b,
                        r = n * o.angleStep,
                        i = Math.cos(r),
                        a = Math.sin(r),
                        s = W[e],
                        c = e - pe,
                        m = g * a + n * o.gapX,
                        h = n * o.gapY,
                        _ = A - m,
                        y = N - h,
                        x = Math.exp(-(_ * _ + y * y) / 9),
                        w = o.magnet * x * (1 - l);
                    m += _ * w, h += y * w;
                    let T = C * i,
                        E = -a * o.edgeTwist,
                        D = Math.max(.32, .5 + .5 * i),
                        O = T * 100,
                        k = o.cardScale * 1.15,
                        j = e === pe ? o.cardScale * 1.35 : 0,
                        ee = K(m, c * .004, l),
                        M = K(h, c * .0035, l),
                        P = K(T, -Math.abs(c) * .012, l),
                        F = K(r, 0, l),
                        te = K(E, 0, l),
                        I = K(v, k, l),
                        ne = K(D, 1, l);
                    ee = K(ee, 0, u), M = K(M, 0, u), P = K(P, 0, u), F = K(F, 0, u), te = K(te, 0, u), I = K(I, j, u), ne = K(ne, 1, u), I *= 1 - (1 - He) * f, M += Ue * f, s.position.set(ee, M, P), s.rotation.set(0, F, te), s.scale.setScalar(I);
                    let L = (50 - Math.abs(c)) * 2;
                    s.renderOrder = Math.round(K(O, L, p));
                    let R = s.material.uniforms;
                    R.uTex.value = ae[ge(t)], R.uBack.value = oe[ge(t)], R.uBend.value = o.bend * (1 - u), R.uSmear.value = S, R.uDim.value = ne, R.uFlip.value = d
                }
                let V = o.auto && !re.current && l < .999,
                    H = Math.abs(c - Oe) > 1e-5 || Math.abs(E.x - ke) > 1e-4 || Math.abs(E.y - Ae) > 1e-4 || Math.abs(y - P.current) > 3e-4;
                Oe = c, ke = E.x, Ae = E.y, (ne.current || V || H) && (Ke = t + .45), t <= Ke && n.render(r, i), de = requestAnimationFrame(Ye)
            };
        de = requestAnimationFrame(Ye);
        let $e = t => {
            e || (t.preventDefault(), M.current += t.deltaY * .0016)
        };
        return t.addEventListener(`wheel`, $e, {
            passive: !1
        }), () => {
            me = !1, cancelAnimationFrame(de), cancelAnimationFrame(O), cancelAnimationFrame(se), o(), t.removeEventListener(`wheel`, $e), U.dispose(), W.forEach(e => e.material.dispose()), ae.forEach(e => e.dispose()), oe.forEach(e => e.dispose()), n.dispose()
        }
    }, []);
    let B = (0, N.useRef)(null),
        V = e => {
            e.pointerType !== `touch` && e.currentTarget.setPointerCapture ? .(e.pointerId), B.current = {
                x: e.clientX,
                y: e.clientY
            }
        },
        ae = e => {
            let t = e.currentTarget.getBoundingClientRect();
            if (I.current = {
                    x: (e.clientX - t.left) / t.width * 2 - 1,
                    y: -((e.clientY - t.top) / t.height * 2 - 1)
                }, !B.current) return;
            let n = e.pointerType === `touch` ? (e.clientX - B.current.x) * .008 : -(e.clientY - B.current.y) * .006;
            B.current.x = e.clientX, B.current.y = e.clientY, M.current += n
        },
        oe = () => {
            B.current = null
        },
        H = (e, t) => D(n => ({ ...n,
            [e]: t
        }));
    return (0, W.jsxs)(`div`, {
        className: e ? U.embed : U.root,
        style: {
            "--accent": he(A)
        },
        children: [O ? (0, W.jsx)(`img`, {
            className: U.canvas,
            src: `/mobile/deck-hero.webp`,
            alt: ``,
            "aria-hidden": !0,
            width: 1440,
            height: 770,
            decoding: `async`,
            style: {
                objectFit: `cover`
            }
        }) : (0, W.jsx)(`canvas`, {
            ref: u,
            className: U.canvas,
            "aria-hidden": !0,
            onPointerDown: V,
            onPointerMove: ae,
            onPointerUp: oe,
            onPointerLeave: oe
        }), !e && (0, W.jsxs)(`div`, {
            className: U.title,
            children: [(0, W.jsx)(`span`, {
                className: U.kicker,
                children: `Grail · lab`
            }), (0, W.jsxs)(`h1`, {
                children: [`Quest Spiral `, (0, W.jsx)(`em`, {
                    children: `gl`
                })]
            }), (0, W.jsx)(`p`, {
                children: `Bent WebGL planes on a spiral. Scroll or drag to flow the quests.`
            })]
        }), !e && (0, W.jsxs)(`div`, {
            className: U.panel,
            children: [(0, W.jsx)(et, {
                label: `Winding`,
                v: E.angleStep,
                min: .25,
                max: 1.1,
                step: .02,
                onChange: e => H(`angleStep`, e)
            }), (0, W.jsx)(et, {
                label: `Radius`,
                v: E.radius,
                min: 1.8,
                max: 7,
                step: .1,
                onChange: e => H(`radius`, e)
            }), (0, W.jsx)(et, {
                label: `Squish`,
                v: E.squish,
                min: .2,
                max: 1.6,
                step: .05,
                onChange: e => H(`squish`, e)
            }), (0, W.jsx)(et, {
                label: `Gap X`,
                v: E.gapX,
                min: -1.5,
                max: 1.5,
                step: .05,
                onChange: e => H(`gapX`, e)
            }), (0, W.jsx)(et, {
                label: `Gap Y`,
                v: E.gapY,
                min: .4,
                max: 4,
                step: .1,
                onChange: e => H(`gapY`, e)
            }), (0, W.jsx)(et, {
                label: `Edge twist`,
                v: E.edgeTwist,
                min: -.8,
                max: .8,
                step: .02,
                onChange: e => H(`edgeTwist`, e)
            }), (0, W.jsx)(et, {
                label: `Card size`,
                v: E.cardScale,
                min: .4,
                max: 1.8,
                step: .05,
                onChange: e => H(`cardScale`, e)
            }), (0, W.jsx)(et, {
                label: `Bend`,
                v: E.bend,
                min: 0,
                max: .18,
                step: .01,
                onChange: e => H(`bend`, e)
            }), (0, W.jsx)(et, {
                label: `Smear`,
                v: E.smear,
                min: 0,
                max: 3,
                step: .1,
                onChange: e => H(`smear`, e)
            }), (0, W.jsx)(et, {
                label: `Mouse tilt`,
                v: E.mouseTilt,
                min: 0,
                max: .7,
                step: .02,
                onChange: e => H(`mouseTilt`, e)
            }), (0, W.jsx)(et, {
                label: `Magnet`,
                v: E.magnet,
                min: 0,
                max: 1,
                step: .05,
                onChange: e => H(`magnet`, e)
            }), (0, W.jsxs)(`label`, {
                className: U.check,
                children: [(0, W.jsx)(`input`, {
                    type: `checkbox`,
                    checked: E.auto,
                    onChange: e => H(`auto`, e.target.checked)
                }), `Auto-spin`]
            }), (0, W.jsx)(et, {
                label: `Speed`,
                v: E.autoSpeed,
                min: .05,
                max: 3,
                step: .05,
                onChange: e => H(`autoSpeed`, e)
            }), (0, W.jsxs)(`div`, {
                className: U.actions,
                children: [(0, W.jsx)(`button`, {
                    onClick: () => {
                        M.current = 0
                    },
                    children: `Recenter`
                }), (0, W.jsx)(`button`, {
                    onClick: () => D(Ne),
                    children: `Reset`
                })]
            })]
        })]
    })
}

function et(e) {
    let {
        label: t,
        v: n,
        min: r,
        max: i,
        step: a,
        onChange: o
    } = e;
    return (0, W.jsxs)(`label`, {
        className: U.slider,
        children: [(0, W.jsxs)(`span`, {
            className: U.sliderHead,
            children: [(0, W.jsx)(`span`, {
                children: t
            }), (0, W.jsx)(`span`, {
                className: U.val,
                children: n
            })]
        }), (0, W.jsx)(`input`, {
            type: `range`,
            min: r,
            max: i,
            step: a,
            value: n,
            onChange: e => o(parseFloat(e.target.value))
        })]
    })
}
var tt = (0, N.memo)($e),
    nt = 1.9,
    rt = 2.6,
    it = T(`#f7c6f7`),
    at = T(`#ffdcff`),
    ot = T(`#9a5ec2`),
    st = T(`#000000`),
    ct = (e, t, n) => [e[0] + (t[0] - e[0]) * n, e[1] + (t[1] - e[1]) * n, e[2] + (t[2] - e[2]) * n],
    lt = (e, t, n) => {
        let r = Math.min(1, Math.max(0, (n - e) / (t - e)));
        return r * r * (3 - 2 * r)
    };

function ut({
    scrollRef: e,
    className: t,
    active: n = !0,
    style: r,
    maxProgress: i = 1,
    noiseAmp: a = .82,
    sp0: o = nt,
    sp1: c = rt
}) {
    let l = (0, N.useRef)(null),
        u = (0, N.useRef)({
            sp0: o,
            sp1: c
        });
    (0, N.useEffect)(() => {
        u.current = {
            sp0: o,
            sp1: c
        }
    }, [o, c]);
    let d = (0, N.useRef)(i);
    (0, N.useEffect)(() => {
        d.current = i
    }, [i]);
    let f = (0, N.useRef)(a);
    (0, N.useEffect)(() => {
        f.current = a
    }, [a]);
    let m = (0, N.useRef)(n);
    return (0, N.useEffect)(() => {
        m.current = n
    }, [n]), (0, N.useEffect)(() => {
        let t = l.current,
            n;
        try {
            n = E(t, {
                transparent: !0
            })
        } catch {
            return
        }
        let r = 0,
            i = !0,
            a = 0,
            o = performance.now() / 1e3,
            c = -1,
            h = 0,
            g = e => {
                let t = lt(.5, .96, e);
                n.draw({
                    origin: [.5, .5],
                    progress: e,
                    noiseAmp: f.current,
                    noiseScale: 8.5,
                    edge: .01,
                    time: a,
                    bright: ct(at, it, t),
                    base: it,
                    deep: ct(ot, it, t),
                    backdrop: st
                })
            },
            _ = () => {
                let e = p(1.75, 1.25);
                t.width = Math.floor(t.clientWidth * e), t.height = Math.floor(t.clientHeight * e), g(Math.max(0, c))
            };
        _();
        let v = s(_),
            y = !1,
            b = () => {
                if (!i) return;
                let t = performance.now() / 1e3,
                    n = Math.min(.05, t - o);
                if (o = t, !m.current) {
                    y || = (g(0), c = 0, !0), r = requestAnimationFrame(b);
                    return
                }
                y = !1;
                let s = e.current ? .p ? ? 0,
                    l = e.current ? .collapse ? ? 0,
                    {
                        sp0: f,
                        sp1: p
                    } = u.current,
                    _ = Math.min(d.current, lt(f, p, s)) * (1 - l),
                    v = _ > .001 && _ < Math.min(.999, d.current) - .002;
                (v || Math.abs(_ - c) > 1e-4) && (h = t + .4), c = _, t <= h && (v && (a += n * 1.7), g(_)), r = requestAnimationFrame(b)
            };
        return r = requestAnimationFrame(b), () => {
            i = !1, cancelAnimationFrame(r), v(), n.dispose()
        }
    }, [e]), (0, W.jsx)(`canvas`, {
        ref: l,
        className: t,
        style: r,
        "aria-hidden": !0
    })
}
var dt = {
    colontitle: `_colontitle_1ghgf_1`,
    right: `_right_1ghgf_18`,
    dark: `_dark_1ghgf_21`,
    light: `_light_1ghgf_24`
};

function ft({
    label: e,
    chapter: t,
    tone: n = `dark`,
    className: r,
    style: i
}) {
    return (0, W.jsxs)(`div`, {
        className: `${dt.colontitle} ${n===`light`?dt.light:dt.dark} ${r??``}`,
        style: i,
        "aria-hidden": !0,
        children: [(0, W.jsx)(`span`, {
            children: e
        }), (0, W.jsx)(`span`, {
            className: dt.right,
            children: t
        })]
    })
}
var q = {
        voice: `_voice_bknov_3`,
        divider: `_divider_bknov_16`,
        colL: `_colL_bknov_27`,
        colR: `_colR_bknov_28`,
        bodyL: `_bodyL_bknov_69`,
        bodyR: `_bodyR_bknov_70`,
        sheetClip: `_sheetClip_bknov_89`,
        modal: `_modal_bknov_100`,
        handle: `_handle_bknov_119`,
        dots: `_dots_bknov_126`,
        dot: `_dot_bknov_126`,
        dotOn: `_dotOn_bknov_132`,
        mHead: `_mHead_bknov_140`,
        mSub: `_mSub_bknov_149`,
        stage: `_stage_bknov_155`,
        garden: `_garden_bknov_162`,
        mic: `_mic_bknov_168`,
        micGlyph: `_micGlyph_bknov_183`,
        mCaption: `_mCaption_bknov_188`,
        pills: `_pills_bknov_193`,
        pill: `_pill_bknov_193`,
        headRow: `_headRow_bknov_210`,
        phoneStage: `_phoneStage_bknov_211`,
        bodyRow: `_bodyRow_bknov_212`,
        phoneM: `_phoneM_bknov_213`
    },
    pt = [`Tell`, `future`, `self`],
    mt = [`And`, `seekers`, `after`],
    ht = `The quest fades by tomorrow. What you felt right after doing it doesn't. Say it out loud while it's fresh, thirty seconds or three minutes, and you've got it forever. It's how a thing you did becomes a thing you remember.`,
    gt = `Before you start, hear what other people said about this one. After you're done, leave yours for whoever gets it next. Same quest, a hundred different nights. Yours will be the best one.`;

function _t() {
    return (0, W.jsxs)(`section`, {
        className: q.voice,
        children: [(0, W.jsx)(ft, {
            label: `About Voice Feedback`,
            chapter: `Chapter 04`,
            tone: `light`,
            style: {
                opacity: `calc(clamp(0, (var(--vreveal, 0) - 0.75) / 0.2, 1) * (1 - var(--treveal, 0)))`
            }
        }), (0, W.jsxs)(`div`, {
            className: q.headRow,
            children: [(0, W.jsx)(`div`, {
                className: q.colL,
                "aria-hidden": !0,
                children: pt.map(e => (0, W.jsx)(`span`, {
                    children: e
                }, e))
            }), (0, W.jsx)(`div`, {
                className: q.colR,
                "aria-hidden": !0,
                children: mt.map(e => (0, W.jsx)(`span`, {
                    children: e
                }, e))
            })]
        }), (0, W.jsxs)(`div`, {
            className: q.phoneStage,
            children: [(0, W.jsx)(`img`, {
                className: q.phoneM,
                src: `/accept-phone.webp`,
                alt: ``,
                "aria-hidden": !0
            }), (0, W.jsx)(`div`, {
                className: q.sheetClip,
                children: (0, W.jsxs)(`div`, {
                    className: q.modal,
                    children: [(0, W.jsx)(`div`, {
                        className: q.handle,
                        "aria-hidden": !0
                    }), (0, W.jsxs)(`div`, {
                        className: q.dots,
                        "aria-hidden": !0,
                        children: [(0, W.jsx)(`span`, {
                            className: q.dotOn
                        }), (0, W.jsx)(`span`, {
                            className: q.dot
                        })]
                    }), (0, W.jsx)(`h2`, {
                        className: q.mHead,
                        children: `What was that like?`
                    }), (0, W.jsx)(`p`, {
                        className: q.mSub,
                        children: `Leave a voice for yourself and for others`
                    }), (0, W.jsxs)(`div`, {
                        className: q.stage,
                        children: [(0, W.jsx)(D, {
                            holeFracY: .5,
                            className: q.garden
                        }), (0, W.jsx)(`div`, {
                            className: q.mic,
                            "aria-hidden": !0,
                            children: (0, W.jsxs)(`svg`, {
                                className: q.micGlyph,
                                viewBox: `0 0 24 24`,
                                "aria-hidden": !0,
                                children: [(0, W.jsx)(`rect`, {
                                    x: `9`,
                                    y: `2.5`,
                                    width: `6`,
                                    height: `11`,
                                    rx: `3`,
                                    fill: `currentColor`
                                }), (0, W.jsx)(`path`, {
                                    d: `M5.5 11a6.5 6.5 0 0 0 13 0`,
                                    fill: `none`,
                                    stroke: `currentColor`,
                                    strokeWidth: `1.7`,
                                    strokeLinecap: `round`
                                }), (0, W.jsx)(`path`, {
                                    d: `M12 17.5V21M8.5 21h7`,
                                    fill: `none`,
                                    stroke: `currentColor`,
                                    strokeWidth: `1.7`,
                                    strokeLinecap: `round`
                                })]
                            })
                        })]
                    }), (0, W.jsx)(`p`, {
                        className: q.mCaption,
                        children: `You can make it longer, right?`
                    }), (0, W.jsxs)(`div`, {
                        className: q.pills,
                        children: [(0, W.jsx)(`span`, {
                            className: q.pill,
                            children: `Easy`
                        }), (0, W.jsx)(`span`, {
                            className: q.pill,
                            children: `Medium`
                        }), (0, W.jsx)(`span`, {
                            className: q.pill,
                            children: `Hard`
                        })]
                    })]
                })
            })]
        }), (0, W.jsxs)(`div`, {
            className: q.bodyRow,
            children: [(0, W.jsx)(`p`, {
                className: q.bodyL,
                children: ht
            }), (0, W.jsx)(`p`, {
                className: q.bodyR,
                children: gt
            })]
        })]
    })
}
var vt = (0, N.memo)(_t),
    yt = e(M(), 1),
    J = {
        totem: `_totem_1pamk_1`,
        nameFront: `_nameFront_1pamk_13`,
        nameBack: `_nameBack_1pamk_14`,
        hideCursor: `_hideCursor_1pamk_20`,
        cursor: `_cursor_1pamk_25`,
        embedded: `_embedded_1pamk_30`,
        cursorOn: `_cursorOn_1pamk_47`,
        cursorArrow: `_cursorArrow_1pamk_48`,
        backdrop: `_backdrop_1pamk_57`,
        stage: `_stage_1pamk_69`,
        nameInner: `_nameInner_1pamk_116`,
        wordMask: `_wordMask_1pamk_120`,
        word: `_word_1pamk_120`,
        wordRise: `_wordRise_1pamk_1`,
        scrim: `_scrim_1pamk_138`,
        colontitle: `_colontitle_1pamk_160`,
        topbar: `_topbar_1pamk_164`,
        oneLiner: `_oneLiner_1pamk_177`,
        swapIn: `_swapIn_1pamk_1`,
        number: `_number_1pamk_185`,
        paren: `_paren_1pamk_194`,
        digit: `_digit_1pamk_195`,
        digitIn: `_digitIn_1pamk_1`,
        divider: `_divider_1pamk_203`,
        bottom: `_bottom_1pamk_215`,
        title: `_title_1pamk_227`,
        titleLine: `_titleLine_1pamk_236`,
        selector: `_selector_1pamk_237`,
        pitch: `_pitch_1pamk_244`,
        pills: `_pills_1pamk_251`,
        pill: `_pill_1pamk_251`,
        pillOn: `_pillOn_1pamk_274`,
        stageImg: `_stageImg_1pamk_376`,
        stageInMobile: `_stageInMobile_1pamk_1`,
        stageIn: `_stageIn_1pamk_1`
    },
    bt = (0, N.lazy)(() => i(() =>
        import (`./TotemStage-K55W8ci8.js`).then(e => ({
            default: e.TotemStage
        })), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6]))),
    xt = 232;

function St({
    text: e,
    baseDelay: t = 0,
    className: n
}) {
    return (0, W.jsx)(`span`, {
        className: n,
        children: e.trim().split(/\s+/).map((e, n) => (0, W.jsx)(`span`, {
            className: J.wordMask,
            children: (0, W.jsx)(`span`, {
                className: J.word,
                style: {
                    animationDelay: `${t+n*.09}s`
                },
                children: e
            })
        }, n))
    })
}

function Ct({
    n: e
}) {
    let t = (0, N.useRef)(null),
        n = (0, N.useRef)(null),
        r = (0, N.useRef)(!1);
    return (0, N.useEffect)(() => {
        if (!r.current) {
            r.current = !0;
            return
        }
        let e = {
            duration: 520,
            easing: `cubic-bezier(0.22, 1, 0.36, 1)`
        };
        t.current ? .animate([{
            transform: `translateX(0)`
        }, {
            transform: `translateX(-0.42em)`
        }, {
            transform: `translateX(0)`
        }], e), n.current ? .animate([{
            transform: `translateX(0)`
        }, {
            transform: `translateX(0.42em)`
        }, {
            transform: `translateX(0)`
        }], e)
    }, [e]), (0, W.jsxs)(`span`, {
        className: J.number,
        children: [(0, W.jsx)(`span`, {
            ref: t,
            className: J.paren,
            children: `(`
        }), (0, W.jsx)(`span`, {
            className: J.digit,
            children: e
        }, e), (0, W.jsx)(`span`, {
            ref: n,
            className: J.paren,
            children: `)`
        })]
    })
}

function wt({
    embedded: e = !1
}) {
    let [t, n] = (0, N.useState)(0), [r, i] = (0, N.useState)(1), [a, o] = (0, N.useState)(`right`), [s, c] = (0, N.useState)(!1), [d, p] = (0, N.useState)(!1), [m, h] = (0, N.useState)(!1), [g, _] = (0, N.useState)(!1), [v, y] = (0, N.useState)(!1), [b] = (0, N.useState)(() => f()), x = b || g && l(), S = (0, N.useRef)(!1), C = (0, N.useRef)(null), w = (0, N.useRef)(null), T = (0, N.useRef)([]), E = k[t], D = k.length, j = e => {
        let n = t;
        if (e.key === `ArrowRight` || e.key === `ArrowDown`) n = (t + 1) % D;
        else if (e.key === `ArrowLeft` || e.key === `ArrowUp`) n = (t - 1 + D) % D;
        else if (e.key === `Home`) n = 0;
        else if (e.key === `End`) n = D - 1;
        else return;
        e.preventDefault(), M(n), T.current[n] ? .focus()
    };
    (0, N.useEffect)(() => {
        S.current = m
    }, [m]);
    let ee = (e, r, a) => {
            e !== t && (i(r), n(e), A(`totem_selected`, {
                slug: k[e].slug,
                via: a
            }))
        },
        M = e => ee(e, e > t ? 1 : -1, `pill`),
        P = e => ee((t + e + D) % D, e, `stage`);
    return (0, N.useEffect)(() => {
        if (u()) return;
        let e = e => {
                let t = e.clientY > window.innerHeight - xt,
                    n = C.current;
                n && (n.style.transform = `translate(${e.clientX-48}px, ${e.clientY-48}px)`), p(t), c(S.current && !t), o(e.clientX < window.innerWidth / 2 ? `left` : `right`)
            },
            t = () => c(!1);
        return window.addEventListener(`pointermove`, e), document.addEventListener(`pointerleave`, t), () => {
            window.removeEventListener(`pointermove`, e), document.removeEventListener(`pointerleave`, t)
        }
    }, []), (0, N.useEffect)(() => {
        let e = w.current;
        if (!e) return;
        let t = new IntersectionObserver(([e]) => h(e.isIntersecting), {
            threshold: .4
        });
        t.observe(e);
        let n = new IntersectionObserver(([e]) => {
            e.isIntersecting && (_(!0), n.disconnect())
        }, {
            rootMargin: `150% 0px`
        });
        return n.observe(e), () => {
            t.disconnect(), n.disconnect()
        }
    }, []), (0, N.useEffect)(() => {
        m || c(!1)
    }, [m]), (0, N.useEffect)(() => {
        m && y(!0)
    }, [m]), (0, W.jsxs)(`section`, {
        ref: w,
        className: `${J.totem} ${e?J.embedded:``} ${m&&!d?J.hideCursor:``}`,
        onClick: e => {
            e.clientY > window.innerHeight - xt || e.target.closest(`[data-controls]`) || window.getSelection ? .() ? .toString() || P(e.clientX < window.innerWidth / 2 ? -1 : 1)
        },
        children: [(0, W.jsx)(ft, {
            label: `About Totems`,
            chapter: `Chapter 05`,
            tone: `dark`,
            className: J.colontitle
        }), !e && (0, W.jsx)(O, {
            active: m,
            className: J.backdrop
        }), (0, W.jsx)(`div`, {
            className: J.nameBack,
            "aria-hidden": !0,
            children: (0, W.jsx)(St, {
                text: E.name,
                className: J.nameInner
            }, `${E.slug}-${v}`)
        }), g && (x ? (0, W.jsx)(`div`, {
            className: J.stage,
            "aria-hidden": !0,
            children: (0, W.jsx)(`img`, {
                className: J.stageImg,
                src: `/mobile/totem-${E.slug}.webp`,
                alt: ``,
                width: 736,
                height: 1082,
                decoding: `async`
            }, E.slug)
        }) : (0, W.jsx)(N.Suspense, {
            fallback: null,
            children: (0, W.jsx)(bt, {
                modelPath: E.model,
                baseRotY: E.rotY,
                mirror: E.mirror,
                dir: r,
                active: m,
                className: J.stage
            })
        })), (0, W.jsx)(`div`, {
            className: J.scrim,
            "aria-hidden": !0
        }), (0, W.jsx)(`h2`, {
            className: J.nameFront,
            children: (0, W.jsx)(St, {
                text: E.epithet,
                baseDelay: .14,
                className: J.nameInner
            }, `${E.slug}-${v}`)
        }), (0, W.jsxs)(`div`, {
            className: J.topbar,
            children: [(0, W.jsx)(`p`, {
                id: `totem-panel`,
                role: `tabpanel`,
                "aria-live": `polite`,
                "aria-labelledby": `totem-tab-${t}`,
                className: J.oneLiner,
                children: E.description
            }, E.slug), (0, W.jsx)(Ct, {
                n: t + 1
            })]
        }), (0, W.jsx)(`div`, {
            className: J.divider,
            "aria-hidden": !0
        }), (0, W.jsxs)(`div`, {
            className: J.bottom,
            "data-controls": !0,
            children: [(0, W.jsxs)(`h3`, {
                className: J.title,
                children: [(0, W.jsx)(St, {
                    text: `Six totems.`,
                    className: J.titleLine
                }, `ta-${v}`), (0, W.jsx)(St, {
                    text: `One's yours.`,
                    baseDelay: .18,
                    className: J.titleLine
                }, `tb-${v}`)]
            }), (0, W.jsxs)(`div`, {
                className: J.selector,
                children: [(0, W.jsx)(`p`, {
                    className: J.pitch,
                    children: `You pick one when you start. It levels up as you do, and it's the face you wear the whole way. Pick the one you're trying to become.`
                }), (0, W.jsx)(`div`, {
                    className: J.pills,
                    role: `tablist`,
                    "aria-label": `Totems`,
                    onKeyDown: j,
                    children: k.map((e, n) => (0, W.jsx)(`button`, {
                        ref: e => {
                            T.current[n] = e
                        },
                        id: `totem-tab-${n}`,
                        role: `tab`,
                        "aria-selected": n === t,
                        "aria-controls": `totem-panel`,
                        tabIndex: n === t ? 0 : -1,
                        className: `${J.pill} ${n===t?J.pillOn:``}`,
                        onClick: () => M(n),
                        children: e.name
                    }, e.slug))
                })]
            })]
        }), typeof document < `u` && (0, yt.createPortal)((0, W.jsx)(`div`, {
            ref: C,
            className: `${J.cursor} ${s?J.cursorOn:``}`,
            "data-side": a,
            "aria-hidden": !0,
            children: (0, W.jsx)(`img`, {
                src: `/arrow.svg`,
                alt: ``,
                className: J.cursorArrow
            })
        }), document.body)]
    })
}
var Tt = (0, N.memo)(wt),
    Y = {
        stats: `_stats_10nox_14`,
        embedded: `_embedded_10nox_26`,
        backdrop: `_backdrop_10nox_29`,
        goo: `_goo_10nox_40`,
        canvas: `_canvas_10nox_52`,
        head: `_head_10nox_66`,
        headMask: `_headMask_10nox_82`,
        headLine: `_headLine_10nox_88`,
        in: `_in_10nox_92`,
        statsRise: `_statsRise_10nox_1`,
        body: `_body_10nox_99`,
        statsFade: `_statsFade_10nox_1`,
        labels: `_labels_10nox_120`,
        label: `_label_10nox_120`,
        labelName: `_labelName_10nox_164`,
        labelCount: `_labelCount_10nox_169`,
        grid: `_grid_10nox_203`,
        tile: `_tile_10nox_213`,
        tileFill: `_tileFill_10nox_222`,
        tileLabel: `_tileLabel_10nox_233`,
        tileName: `_tileName_10nox_255`,
        tileCount: `_tileCount_10nox_262`
    },
    Et = {
        CHA: 88,
        STR: 52,
        WIS: 64,
        INT: 76
    },
    Dt = [{
        key: `CHA`,
        label: `Charisma`,
        guild: `The Wind Shifters`,
        color: `#f5b945`
    }, {
        key: `STR`,
        label: `Strength`,
        guild: `The Temperers of Steel`,
        color: `#ff6b4a`
    }, {
        key: `WIS`,
        label: `Wisdom`,
        guild: `The Keepers of Time`,
        color: `#4ecb8a`
    }, {
        key: `INT`,
        label: `Intellect`,
        guild: `The Brotherhood of Tale`,
        color: `#5b8def`
    }],
    Ot = `#ffffff`,
    kt = `Point at the part of yourself you want to build, and the quests you take pile up there. Strength, intellect, charisma, wisdom. Some land exactly where you aimed. Some surprise you. Either way, it adds up into someone you weren't last month.`,
    At = .5,
    jt = 25,
    Mt = 4,
    Nt = 100,
    Pt = 5,
    Ft = 8,
    It = 8,
    Lt = 143,
    Rt = .38,
    zt = .42,
    Bt = e => {
        let t = 1.70158;
        return 1 + (t + 1) * (e - 1) ** 3 + t * (e - 1) ** 2
    },
    Vt = {
        STR: `/patterns/stats-bg-str.webp`,
        INT: `/patterns/stats-bg-int.webp`,
        CHA: `/patterns/stats-bg-char.webp`,
        WIS: `/patterns/stats-bg-wis.webp`
    };

function Ht({
    embedded: t = !1
}) {
    let n = (0, N.useRef)(null),
        r = (0, N.useRef)(null),
        a = (0, N.useRef)(null),
        o = (0, N.useRef)([]),
        s = (0, N.useRef)([]),
        c = (0, N.useRef)(null),
        l = (0, N.useRef)(!1),
        u = (0, N.useRef)(!1),
        [d, m] = (0, N.useState)(!1),
        [h, g] = (0, N.useState)(!1),
        [_] = (0, N.useState)(() => f());
    return (0, N.useEffect)(() => {
        let e = n.current;
        if (!e) return;
        let t = new IntersectionObserver(([e]) => {
            l.current = e.isIntersecting, m(e.isIntersecting);
            let t = e.intersectionRatio >= .35;
            u.current = t, g(t)
        }, {
            threshold: [0, .04, .35, .4]
        });
        return t.observe(e), () => t.disconnect()
    }, []), (0, N.useEffect)(() => {
        if (!_) return;
        let e = c.current;
        if (!e) return;
        let t = Dt.map(e => Et[e.key] ? ? 60);
        s.current.forEach(e => {
            e && (e.textContent = `0`)
        });
        let n = !1,
            r = 0,
            i = new IntersectionObserver(([e]) => {
                if (!e.isIntersecting || n) return;
                n = !0;
                let i = performance.now(),
                    a = e => {
                        let n = Math.min(1, (e - i) / 1200),
                            o = 1 - (1 - n) ** 3;
                        for (let e = 0; e < t.length; e++) {
                            let n = s.current[e];
                            n && (n.textContent = String(Math.round(t[e] * o)))
                        }
                        n < 1 && (r = requestAnimationFrame(a))
                    };
                r = requestAnimationFrame(a)
            }, {
                threshold: .4
            });
        return i.observe(e), () => {
            i.disconnect(), cancelAnimationFrame(r)
        }
    }, [_]), (0, N.useEffect)(() => {
        if (_) return;
        let t, n = !1;
        return i(async () => {
            let {
                default: t
            } = await
            import (`./matter-DegRgWhp.js`).then(t => e(t.default, 1));
            return {
                default: t
            }
        }, __vite__mapDeps([7, 1])).then(({
            default: e
        }) => {
            n || (t = s(e))
        }), () => {
            n = !0, t ? .()
        };

        function s(e) {
            let t = r.current,
                n = t.getContext(`2d`),
                i = a.current,
                s = i.getContext(`2d`),
                {
                    Engine: c,
                    Composite: d,
                    Bodies: f,
                    Body: m,
                    Events: h
                } = e,
                g = c.create({
                    enableSleeping: !0
                });
            g.gravity.y = 1.4, g.positionIterations = 12, g.velocityIterations = 8;
            let _ = 0,
                v = 0,
                y = 0,
                b = 1,
                x = 24,
                S = null,
                C = null,
                w = null,
                T = [],
                E = () => [S, C, w, ...T].filter(Boolean),
                D = [],
                O = new WeakMap,
                k = [0, 0, 0, 0],
                A = [0, 0, 0, 0],
                j = e => Math.min(3, Math.max(0, Math.floor(e / (_ / 4)))),
                ee = {
                    restitution: .3,
                    friction: .04,
                    frictionStatic: .2,
                    frictionAir: .012,
                    density: .0016
                },
                M = .6,
                N = 1.45,
                P = () => x * (M + Math.random() * (N - M)),
                F = [],
                te = Dt.map(e => {
                    let t = new Image;
                    return t.src = Vt[e.key], t
                });

            function I(e, t, n, r, i, a) {
                let o = t.naturalWidth / t.naturalHeight,
                    s = i / a,
                    c, l, u, d;
                o > s ? (l = t.naturalHeight, c = l * s, u = (t.naturalWidth - c) / 2, d = 0) : (c = t.naturalWidth, l = c / s, u = 0, d = (t.naturalHeight - l) / 2), e.drawImage(t, u, d, c, l, n, r, i, a)
            }

            function ne(e) {
                d.remove(g.world, e);
                let t = D.indexOf(e);
                t >= 0 && D.splice(t, 1), O.delete(e)
            }

            function L() {
                for (let e of D) d.remove(g.world, e);
                D.length = 0
            }

            function R() {
                if (_ = t.clientWidth, v = t.clientHeight, !_ || !v) return;
                b = p(2, 1.5), t.width = Math.floor(_ * b), t.height = Math.floor(v * b), i.width = t.width, i.height = t.height, y = v * At;
                let e = _ / 4,
                    n = v - y;
                x = Math.max(15, Math.min(48, Math.sqrt(.68 * e * n / (jt * Math.PI)))), E().length && d.remove(g.world, E()), S = f.rectangle(_ / 2, v + 40, _ + 200, 80, {
                    isStatic: !0
                }), C = f.rectangle(-40, v / 2, 80, v * 3, {
                    isStatic: !0
                }), w = f.rectangle(_ + 40, v / 2, 80, v * 3, {
                    isStatic: !0
                }), T = [.25, .5, .75].map(e => f.rectangle(_ * e, v / 2, It, v * 2, {
                    isStatic: !0
                })), d.add(g.world, E())
            }
            R();

            function re(e) {
                let t = O.get(e);
                if (!t) return;
                t.dying = !0, t.dieT = 0, e.isSensor = !0;
                let n = Math.random() < .5 ? -1 : 1;
                m.setVelocity(e, {
                    x: n * (5 + Math.random() * 8),
                    y: -(2 + Math.random() * 7)
                }), m.setAngularVelocity(e, (Math.random() - .5) * .8)
            }

            function ie(e, t) {
                let n = O.get(e);
                if (!n || n.landed || n.dying || !(t === S || O.get(t) ? .landed)) return;
                if (e.position.y < y) {
                    re(e);
                    return
                }
                let r = j(e.position.x);
                n.landed = !0, n.color = Dt[r].color, n.idx = r, k[r] = Math.min(Nt, k[r] + Mt)
            }
            h.on(g, `collisionStart`, e => {
                for (let t of e.pairs) O.has(t.bodyA) && ie(t.bodyA, t.bodyB), O.has(t.bodyB) && ie(t.bodyB, t.bodyA)
            });
            let z = {
                    x: 0,
                    y: 0,
                    inside: !1,
                    holding: !1
                },
                B = 0,
                V = {
                    x: 0
                };

            function ae(e, t) {
                let n = P();
                t = Math.min(t, y - x * N * 2);
                let r = f.circle(e, t, n, ee);
                m.setVelocity(r, {
                    x: Math.max(-9, Math.min(9, V.x * .8)),
                    y: 1 + Math.random()
                }), O.set(r, {
                    landed: !1,
                    color: Ot,
                    scale: 1,
                    dying: !1,
                    dieT: 0,
                    idx: -1,
                    popT: zt,
                    popDelay: 0
                }), D.push(r), d.add(g.world, r), D.length > 260 && ne(D[0])
            }

            function oe() {
                for (let e = 0; e < 4; e++) {
                    let t = Pt + Math.floor(Math.random() * (Ft - Pt + 1)),
                        n = e * .25 * _ + 8,
                        r = (e + 1) * .25 * _ - 8,
                        i = n,
                        a = v - 8,
                        o = 0;
                    for (let s = 0; s < t; s++) {
                        let t = P();
                        i + t * 2 > r && i > n && (i = n, a -= o * 2 * .95, o = 0);
                        let c = f.circle(i + t, a - t, t, ee);
                        O.set(c, {
                            landed: !0,
                            color: Dt[e].color,
                            scale: 0,
                            dying: !1,
                            dieT: 0,
                            idx: e,
                            popT: 0,
                            popDelay: .85 + s * .07 + Math.random() * .12
                        }), D.push(c), d.add(g.world, c), i += t * 2 + 1, o = Math.max(o, t)
                    }
                    k[e] = t * Mt
                }
            }
            oe();
            let H = e => {
                    let n = t.getBoundingClientRect();
                    return {
                        x: e.clientX - n.left,
                        y: e.clientY - n.top
                    }
                },
                se = e => {
                    let t = H(e);
                    z.x = t.x, z.y = t.y, z.inside = !0
                },
                ce = e => {
                    let t = H(e);
                    z.x = t.x, z.y = t.y, z.inside = !0
                },
                le = () => {
                    z.inside = !1, z.holding = !1
                },
                ue = e => {
                    let t = H(e);
                    z.x = t.x, z.y = t.y, z.inside = !0, z.holding = !0, ae(t.x, t.y), G = performance.now() + Lt
                },
                U = () => {
                    z.holding = !1
                },
                W = 0,
                de = () => {
                    clearTimeout(W), W = window.setTimeout(() => {
                        t.clientWidth === _ && t.clientHeight === v || (R(), L(), oe())
                    }, 160)
                };
            t.addEventListener(`pointermove`, se), t.addEventListener(`pointerenter`, ce), t.addEventListener(`pointerleave`, le), t.addEventListener(`pointerdown`, ue), window.addEventListener(`pointerup`, U), window.addEventListener(`resize`, de);
            let fe = 0,
                G = 0,
                pe = performance.now(),
                me = 0,
                he = 0,
                ge = 1e3 / 60,
                K = () => {
                    let e = performance.now(),
                        t = Math.min(.05, (e - pe) / 1e3);
                    if (pe = e, !l.current) {
                        me = 0, fe = requestAnimationFrame(K);
                        return
                    }
                    V.x = V.x * .6 + (z.x - B) * .4, B = z.x, (z.holding || z.inside) && e >= G && (ae(z.x, z.y), G = e + (z.holding ? Lt : 500 + Math.random() * 300)), me += t * 1e3;
                    let r = 0;
                    for (; me >= ge && r < 5;) c.update(g, ge), me -= ge, r++;
                    me > ge && (me = 0), u.current ? he += t : he = 0;
                    for (let e of D) {
                        let n = O.get(e);
                        n.dying && (n.dieT += t, n.scale = Math.max(0, 1 - n.dieT / Rt), n.scale <= 0 && F.push(e))
                    }
                    if (F.length) {
                        for (let e of F) ne(e);
                        F.length = 0
                    }
                    if (u.current)
                        for (let e of D) {
                            let n = O.get(e);
                            if (!(n.dying || n.popT >= zt)) {
                                if (n.popDelay > 0) {
                                    n.popDelay -= t;
                                    continue
                                }
                                n.popT = Math.min(zt, n.popT + t), n.scale = Bt(n.popT / zt)
                            }
                        }
                    if (u.current && he >= .75) {
                        for (let e = 0; e < 4; e++)
                            if (A[e] !== k[e]) {
                                A[e] += (k[e] - A[e]) * Math.min(1, t * 9), Math.abs(k[e] - A[e]) < .5 && (A[e] = k[e]);
                                let n = o.current[e];
                                n && (n.textContent = String(Math.round(A[e])))
                            }
                    }
                    if (he > 1.6 && !z.inside && !z.holding && D.every(e => {
                            let t = O.get(e);
                            return !t.dying && t.popT >= zt && e.isSleeping
                        }) && A.every((e, t) => e === k[t])) {
                        fe = requestAnimationFrame(K);
                        return
                    }
                    n.setTransform(b, 0, 0, b, 0, 0), n.clearRect(0, 0, _, v), n.strokeStyle = `rgba(255,255,255,0.12)`, n.lineWidth = 1, [.25, .5, .75].forEach((e, t) => {
                        let r = Math.min(1, Math.max(0, (he - .6 - t * .14) / .6));
                        if (r <= 0) return;
                        let i = 1 - (1 - r) ** 3;
                        n.beginPath(), n.moveTo(_ * e, y), n.lineTo(_ * e, y + (v - y) * i), n.stroke()
                    });
                    for (let e of D) {
                        let t = O.get(e);
                        if (t.landed) continue;
                        let r = (e.circleRadius ? ? x) * t.scale;
                        r < .5 || (n.globalAlpha = t.dying ? .16 * t.scale : .16, n.beginPath(), n.arc(e.position.x, e.position.y, r, 0, Math.PI * 2), n.fillStyle = t.color, n.fill())
                    }
                    n.globalAlpha = 1, s.setTransform(b, 0, 0, b, 0, 0), s.clearRect(0, 0, _, v);
                    for (let e = 0; e < 4; e++) {
                        let t = _ / 4 * e;
                        s.save(), s.beginPath();
                        let n = !1;
                        for (let t of D) {
                            let r = O.get(t);
                            if (!r.landed || r.idx !== e) continue;
                            let i = (t.circleRadius ? ? x) * 1.09 * r.scale;
                            i < .5 || (s.moveTo(t.position.x + i, t.position.y), s.arc(t.position.x, t.position.y, i, 0, Math.PI * 2), n = !0)
                        }
                        if (n) {
                            s.clip();
                            let n = x * N * 3,
                                r = te[e];
                            r.complete && r.naturalWidth ? I(s, r, t, y - n, _ / 4, v - y + n) : (s.fillStyle = Dt[e].color, s.fillRect(t, y - n, _ / 4, v - y + n))
                        }
                        s.restore()
                    }
                    fe = requestAnimationFrame(K)
                };
            return fe = requestAnimationFrame(K), () => {
                cancelAnimationFrame(fe), t.removeEventListener(`pointermove`, se), t.removeEventListener(`pointerenter`, ce), t.removeEventListener(`pointerleave`, le), t.removeEventListener(`pointerdown`, ue), window.removeEventListener(`pointerup`, U), window.removeEventListener(`resize`, de), clearTimeout(W), d.clear(g.world, !1), c.clear(g)
            }
        }
    }, []), (0, W.jsxs)(`section`, {
        ref: n,
        className: `${Y.stats} ${t?Y.embedded:``} ${h?Y.in:``}`,
        children: [(0, W.jsx)(ft, {
            label: `About Stats`,
            chapter: `Chapter 06`,
            tone: `dark`
        }), !t && (0, W.jsx)(O, {
            active: d,
            className: Y.backdrop
        }), !_ && (0, W.jsx)(`canvas`, {
            ref: a,
            className: Y.goo,
            "aria-hidden": !0
        }), !_ && (0, W.jsx)(`canvas`, {
            ref: r,
            className: Y.canvas,
            "aria-hidden": !0
        }), (0, W.jsxs)(`h2`, {
            className: Y.head,
            children: [(0, W.jsx)(`span`, {
                className: Y.headMask,
                children: (0, W.jsx)(`span`, {
                    className: Y.headLine,
                    children: `Every quest`
                })
            }), (0, W.jsx)(`span`, {
                className: Y.headMask,
                children: (0, W.jsx)(`span`, {
                    className: Y.headLine,
                    children: `lands somewhere.`
                })
            })]
        }), (0, W.jsx)(`p`, {
            className: Y.body,
            children: kt
        }), (0, W.jsx)(`ul`, {
            className: `sr-only`,
            children: Dt.map(e => (0, W.jsxs)(`li`, {
                children: [e.label, `, from `, e.guild, `.`]
            }, e.key))
        }), !_ && (0, W.jsx)(`div`, {
            className: Y.labels,
            "aria-hidden": !0,
            children: Dt.map((e, t) => (0, W.jsxs)(`div`, {
                className: Y.label,
                style: {
                    left: `calc(${t*25}% + 32px)`
                },
                children: [(0, W.jsx)(`span`, {
                    className: Y.labelName,
                    children: e.label
                }), (0, W.jsx)(`span`, {
                    className: Y.labelCount,
                    ref: e => {
                        o.current[t] = e
                    },
                    children: `0`
                })]
            }, e.key))
        }), _ && (0, W.jsx)(`div`, {
            className: Y.grid,
            ref: c,
            children: Dt.map((e, t) => {
                let n = Et[e.key] ? ? 60;
                return (0, W.jsxs)(`div`, {
                    className: Y.tile,
                    children: [(0, W.jsx)(`div`, {
                        className: Y.tileFill,
                        style: {
                            backgroundImage: `url(${Vt[e.key]})`,
                            "--target": `${n}%`
                        }
                    }), (0, W.jsxs)(`div`, {
                        className: Y.tileLabel,
                        children: [(0, W.jsx)(`span`, {
                            className: Y.tileName,
                            children: e.label
                        }), (0, W.jsx)(`span`, {
                            className: Y.tileCount,
                            ref: e => {
                                s.current[t] = e
                            }
                        })]
                    })]
                }, e.key)
            })
        })]
    })
}
var Ut = (0, N.memo)(Ht),
    X = {
        guilds: `_guilds_194d4_3`,
        topbar: `_topbar_194d4_18`,
        wheel: `_wheel_194d4_34`,
        guildName: `_guildName_194d4_49`,
        spoke: `_spoke_194d4_62`,
        crest: `_crest_194d4_67`,
        shader: `_shader_194d4_99`,
        shaderBlur: `_shaderBlur_194d4_108`,
        sb1: `_sb1_194d4_117`,
        sb2: `_sb2_194d4_123`,
        shaderGrad: `_shaderGrad_194d4_129`,
        cover: `_cover_194d4_135`,
        kicker: `_kicker_194d4_145`,
        in: `_in_194d4_158`,
        guildsFade: `_guildsFade_194d4_1`,
        headWrap: `_headWrap_194d4_162`,
        head: `_head_194d4_162`,
        headRow: `_headRow_194d4_187`,
        letter: `_letter_194d4_188`,
        leadStack: `_leadStack_194d4_206`,
        lead: `_lead_194d4_206`,
        leadWord: `_leadWord_194d4_233`,
        leadLetter: `_leadLetter_194d4_236`,
        blurbBody: `_blurbBody_194d4_244`
    },
    Wt = [{
        pattern: `/patterns/tempers.webp`,
        name: `The Temperers of Steel`
    }, {
        pattern: `/patterns/brotherhood-of-tale.webp`,
        name: `The Brotherhood of Tale`
    }, {
        pattern: `/patterns/keepers-of-time.webp`,
        name: `The Keepers of Time`
    }, {
        pattern: `/patterns/seeker-of-forsaken.webp`,
        name: `The Seekers of Forsaken`
    }, {
        pattern: `/patterns/wind-shifters.webp`,
        name: `The Wind Shifters`
    }],
    Gt = 10,
    Kt = 4,
    qt = .05,
    Jt = 110,
    Yt = 26,
    Xt = 16,
    Zt = e => (e % 360 + 540) % 360 - 180,
    Qt = [`Pick your guilds.`, `They define`, `your quests`],
    $t = `A guild is a corner of Grail built around one thing.`,
    en = `Getting strong. Getting out more. Slowing down. Making stuff. Join the ones that fit the life you want, and that's where your daily quests start coming from. Or make your own, for your city, your crew, whatever you're into, and pull others in. Nobody's ranked. You just get to see you're not the only one out here.`;

function tn() {
    let [e] = (0, N.useState)(() => f()), t = (0, N.useRef)(null), n = (0, N.useRef)(null), r = (0, N.useRef)(null), i = (0, N.useRef)([]), a = (0, N.useRef)(!1), [o, s] = (0, N.useState)(!1);
    return (0, N.useEffect)(() => {
        let e = t.current;
        if (!e) return;
        let n = new IntersectionObserver(([e]) => {
            a.current = e.isIntersecting, s(e.isIntersecting)
        }, {
            threshold: .12
        });
        return n.observe(e), () => n.disconnect()
    }, []), (0, N.useEffect)(() => {
        let o = n.current,
            s = r.current,
            l = t.current;
        if (!o || !s || !l) return;
        let u = c(),
            d = 15,
            f = window.scrollY,
            p = 0,
            m = {
                x: 0,
                y: 0,
                on: !1
            },
            h = Array(Gt).fill(0),
            g = e => {
                m.x = e.clientX, m.y = e.clientY, m.on = !0
            },
            _ = () => {
                m.on = !1
            };
        window.addEventListener(`pointermove`, g), document.addEventListener(`pointerleave`, _);
        let v = 0,
            y = performance.now(),
            b = () => {
                let t = performance.now(),
                    n = Math.min(.05, (t - y) / 1e3);
                if (y = t, !a.current) {
                    f = window.scrollY, v = requestAnimationFrame(b);
                    return
                }
                let r = window.scrollY,
                    c = n > 0 ? (r - f) / n : 0;
                f = r, p += (c - p) * Math.min(1, n * 6);
                let g = Math.max(-Jt, Math.min(Jt, p * qt));
                u || (d += (Kt + g) * n);
                let _ = o.getBoundingClientRect(),
                    x = _.left + _.width / 2,
                    S = _.top + _.height / 2,
                    C = o.offsetWidth / 2,
                    w = l.getBoundingClientRect(),
                    T = w.width / l.offsetWidth || 1,
                    E = (i.current[0] ? .offsetHeight ? ? 0) / 2;
                o.style.transform = `rotate(${d}deg)`;
                let D = m.x - x,
                    O = m.y - S,
                    k = Math.hypot(D, O),
                    A = Math.atan2(D, -O) * 180 / Math.PI,
                    j = C * (e ? .78 : 1),
                    ee = C * (e ? 1.04 : 1),
                    M = e => {
                        let t = e * Math.PI / 180;
                        return j * ee / Math.hypot(ee * Math.sin(t), j * Math.cos(t))
                    },
                    N = 0,
                    P = 1e9,
                    F = 0;
                for (let t = 0; t < Gt; t++) {
                    let r = Zt(t * 360 / Gt + 15 + d);
                    Math.abs(r) < P && (P = Math.abs(r), N = t, F = r);
                    let a = 0;
                    if (m.on && !e) {
                        let e = Zt(A - r),
                            t = Math.exp(-((e / Yt) ** 2)),
                            n = k * Math.cos(e * Math.PI / 180);
                        a = Math.max(-.09 * C, Math.min(.13 * C, (n - C) * 1.8)) * t
                    }
                    h[t] += (a - h[t]) * Math.min(1, n * 7);
                    let o = i.current[t],
                        s = M(r) - C + h[t];
                    o && (o.style.transform = `translate(-50%, calc(-50% + ${(-s).toFixed(1)}px))`)
                }
                let te = Math.max(0, 1 - Math.abs(Kt + g) / 80),
                    I = Math.max(0, Math.min(1, 1 - (P - 6) / Xt)) * te,
                    ne = F * Math.PI / 180,
                    L = M(F) + h[N];
                s.style.left = `${((x+Math.sin(ne)*L-w.left)/T).toFixed(1)}px`, s.style.top = `${((S-Math.cos(ne)*L-w.top)/T+E+14).toFixed(1)}px`, s.textContent = Wt[N % Wt.length].name, s.style.opacity = I.toFixed(2), v = requestAnimationFrame(b)
            };
        return v = requestAnimationFrame(b), () => {
            cancelAnimationFrame(v), window.removeEventListener(`pointermove`, g), document.removeEventListener(`pointerleave`, _)
        }
    }, [e]), (0, W.jsxs)(`section`, {
        ref: t,
        className: `${X.guilds} ${o?X.in:``}`,
        children: [(0, W.jsxs)(`div`, {
            className: X.topbar,
            children: [(0, W.jsx)(`span`, {
                children: `About Guilds`
            }), (0, W.jsx)(`span`, {
                children: `Chapter 07`
            })]
        }), (0, W.jsx)(`div`, {
            ref: n,
            className: X.wheel,
            "aria-hidden": !0,
            children: Array.from({
                length: Gt
            }, (e, t) => (0, W.jsx)(`div`, {
                className: X.spoke,
                style: {
                    transform: `rotate(${t*360/Gt+15}deg)`
                },
                children: (0, W.jsx)(`span`, {
                    className: X.crest,
                    ref: e => {
                        i.current[t] = e
                    },
                    children: (0, W.jsx)(`img`, {
                        src: Wt[t % Wt.length].pattern,
                        srcSet: `${Wt[t%Wt.length].pattern.replace(`.webp`,`-160.webp`)} 160w, ${Wt[t%Wt.length].pattern} 845w`,
                        sizes: `(max-width: 768px) 16vw, 12.15vw`,
                        alt: ``,
                        width: 845,
                        height: 836,
                        loading: `lazy`,
                        decoding: `async`
                    })
                })
            }, t))
        }), (0, W.jsx)(`p`, {
            ref: r,
            className: X.guildName,
            "aria-hidden": !0
        }), (0, W.jsxs)(`div`, {
            className: X.shader,
            "aria-hidden": !0,
            children: [(0, W.jsx)(`div`, {
                className: `${X.shaderBlur} ${X.sb1}`
            }), (0, W.jsx)(`div`, {
                className: `${X.shaderBlur} ${X.sb2}`
            }), (0, W.jsx)(`div`, {
                className: X.shaderGrad
            })]
        }), (0, W.jsx)(`div`, {
            className: X.cover,
            "aria-hidden": !0
        }), (0, W.jsx)(`p`, {
            className: X.kicker,
            children: `Join a guild. Or start one.`
        }), (0, W.jsx)(`div`, {
            className: X.headWrap,
            "data-guild-title": !0,
            children: e ? (0, W.jsx)(`h2`, {
                className: X.head,
                children: (() => {
                    let e = 0;
                    return Qt.join(` `).split(` `).flatMap((t, n, r) => {
                        let i = (0, W.jsx)(`span`, {
                            className: X.leadWord,
                            children: [...t].map((t, n) => (0, W.jsx)(`span`, {
                                className: X.letter,
                                style: {
                                    "--i": e++
                                },
                                children: t
                            }, n))
                        }, `w${n}`);
                        return n < r.length - 1 ? [i, ` `] : [i]
                    })
                })()
            }) : (0, W.jsx)(`h2`, {
                className: X.head,
                children: (() => {
                    let e = 0;
                    return Qt.map((t, n) => (0, W.jsx)(`span`, {
                        className: X.headRow,
                        children: [...t].map((t, n) => t === ` ` ? (0, W.jsx)(`span`, {
                            children: `\xA0`
                        }, n) : (0, W.jsx)(`span`, {
                            className: X.letter,
                            style: {
                                "--i": e++
                            },
                            children: t
                        }, n))
                    }, n))
                })()
            })
        }), (0, W.jsxs)(`div`, {
            className: X.leadStack,
            children: [(0, W.jsx)(`p`, {
                className: X.lead,
                children: (() => {
                    let e = 0;
                    return $t.split(` `).flatMap((t, n, r) => {
                        let i = (0, W.jsx)(`span`, {
                            className: X.leadWord,
                            children: [...t].map((t, n) => (0, W.jsx)(`span`, {
                                className: X.leadLetter,
                                style: {
                                    "--i": e++
                                },
                                children: t
                            }, n))
                        }, `w${n}`);
                        return n < r.length - 1 ? [i, ` `] : [i]
                    })
                })()
            }), (0, W.jsx)(`p`, {
                className: X.blurbBody,
                children: en
            })]
        })]
    })
}
var nn = (0, N.memo)(tn),
    rn = {
        x: .454,
        y: .32
    },
    an = .28,
    on = .46,
    sn = 70,
    cn = 8.5,
    ln = 44,
    un = `
attribute vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }
`,
    dn = `
precision highp float;
uniform vec2 uRes;
uniform vec2 uLight;
uniform vec2 uTileC;
uniform vec2 uTileH;
uniform float uTileR;
uniform vec2 uMarkH;
uniform sampler2D uMark;
uniform float uSpread;
uniform float uIntensity;
uniform vec3 uTint;

float sdRoundBox(vec2 p, vec2 b, float r) {
  vec2 q = abs(p) - b + r;
  return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

// How much light leaves point q: 1 on the pink tile, 0 where the mark sits, 0 outside.
float emit(vec2 q) {
  float d = sdRoundBox(q - uTileC, uTileH, uTileR);
  float inside = 1.0 - smoothstep(-1.0, 1.0, d);
  vec2 uv = (q - uTileC) / (2.0 * uMarkH) + 0.5;
  float inBox = step(0.0, uv.x) * step(uv.x, 1.0) * step(0.0, uv.y) * step(uv.y, 1.0);
  float m = texture2D(uMark, uv).a * inBox;
  return inside * (1.0 - m);
}

void main() {
  vec2 p = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);
  vec2 toL = uLight - p;
  vec2 stepv = toL / float(${ln});
  // Per-pixel start jitter hides the banding a fixed step count would show.
  vec2 q = p + stepv * hash(p);
  float sum = 0.0;
  for (int i = 0; i < ${ln}; i++) { sum += emit(q); q += stepv; }
  // Fraction of the line of sight that was lit tile: ~1/distance like a real lamp.
  float ray = sum / float(${ln});
  float dEdge = max(0.0, sdRoundBox(p - uTileC, uTileH, uTileR));
  float fall = exp(-dEdge / uSpread);
  float I = ray * fall * uIntensity;
  vec3 col = min(uTint * I, vec3(1.0));
  float a = max(col.r, max(col.g, col.b));
  gl_FragColor = vec4(col, a); // premultiplied: pure light over whatever's behind
}
`;

function fn(e, t, n) {
    let r = e.createShader(t);
    if (e.shaderSource(r, n), e.compileShader(r), !e.getShaderParameter(r, e.COMPILE_STATUS)) {
        let t = e.getShaderInfoLog(r);
        throw e.deleteShader(r), Error(`rays shader: ${t}`)
    }
    return r
}
var pn = 26.604 / 25,
    mn = 256,
    hn = Math.round(256 / pn),
    gn = 20;

function _n() {
    return new Promise((e, t) => {
        let n = new Image;
        n.onload = () => {
            let t = document.createElement(`canvas`);
            t.width = mn + gn * 2, t.height = hn + gn * 2;
            let r = t.getContext(`2d`);
            r.filter = `blur(2.5px)`, r.drawImage(n, gn, gn, mn, hn), e(t)
        }, n.onerror = () => t(Error(`rays: mark failed to load`)), n.src = `/grail-mark.svg`
    })
}

function vn({
    tileRef: e,
    className: t
}) {
    let n = (0, N.useRef)(null);
    return (0, N.useEffect)(() => {
        if (f() || l()) return;
        let t = n.current,
            r = e.current;
        if (!t || !r) return;
        let i = t.getContext(`webgl`, {
            alpha: !0,
            premultipliedAlpha: !0,
            antialias: !1,
            depth: !1,
            stencil: !1,
            powerPreference: `low-power`
        });
        if (!i) return;
        let a;
        try {
            if (a = i.createProgram(), i.attachShader(a, fn(i, i.VERTEX_SHADER, un)), i.attachShader(a, fn(i, i.FRAGMENT_SHADER, dn)), i.linkProgram(a), !i.getProgramParameter(a, i.LINK_STATUS)) throw Error(i.getProgramInfoLog(a) ? ? `link`)
        } catch {
            return
        }
        i.useProgram(a);
        let o = i.createBuffer();
        i.bindBuffer(i.ARRAY_BUFFER, o), i.bufferData(i.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), i.STATIC_DRAW);
        let u = i.getAttribLocation(a, `aPos`);
        i.enableVertexAttribArray(u), i.vertexAttribPointer(u, 2, i.FLOAT, !1, 0, 0);
        let d = e => i.getUniformLocation(a, e),
            m = d(`uRes`),
            h = d(`uLight`),
            g = d(`uTileC`),
            _ = d(`uTileH`),
            v = d(`uTileR`),
            y = d(`uMarkH`),
            b = d(`uSpread`),
            x = d(`uIntensity`),
            S = d(`uTint`);
        i.uniform1i(d(`uMark`), 0), i.uniform3f(S, 1, .88, .98), i.clearColor(0, 0, 0, 0);
        let C = i.createTexture();
        i.bindTexture(i.TEXTURE_2D, C), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_S, i.CLAMP_TO_EDGE), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_WRAP_T, i.CLAMP_TO_EDGE), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MIN_FILTER, i.LINEAR), i.texParameteri(i.TEXTURE_2D, i.TEXTURE_MAG_FILTER, i.LINEAR), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, 1, 1, 0, i.RGBA, i.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 0]));
        let w = !1;
        _n().then(e => {
            w || (i.bindTexture(i.TEXTURE_2D, C), i.texImage2D(i.TEXTURE_2D, 0, i.RGBA, i.RGBA, i.UNSIGNED_BYTE, e), D = !0)
        }).catch(() => {});
        let T = c(),
            E = 1,
            D = !0,
            O = !1,
            k = {
                x: NaN,
                y: NaN
            },
            A = {
                x: 0,
                y: 0,
                vx: 0,
                vy: 0,
                init: !1
            },
            j = {
                cx: 0,
                cy: 0,
                w: 0
            },
            ee = () => {
                E = Math.min(1, p(1, .75) * .6), t.width = Math.max(1, Math.floor(t.clientWidth * E)), t.height = Math.max(1, Math.floor(t.clientHeight * E)), i.viewport(0, 0, t.width, t.height), D = !0
            };
        ee();
        let M = s(ee),
            N = new IntersectionObserver(([e]) => {
                O = e.isIntersecting, O && (D = !0)
            }, {
                threshold: 0
            });
        N.observe(t);
        let P = e => {
            k.x = e.clientX, k.y = e.clientY
        };
        T || window.addEventListener(`pointermove`, P, {
            passive: !0
        });
        let F = 0,
            te = performance.now(),
            I = () => {
                F = requestAnimationFrame(I);
                let e = performance.now(),
                    n = Math.min(.05, (e - te) / 1e3);
                if (te = e, !O || !t.closest(`.foot-live`)) return;
                let a = t.getBoundingClientRect(),
                    o = r.getBoundingClientRect();
                if (!o.width) return;
                let s = o.left - a.left + o.width / 2,
                    c = o.top - a.top + o.height / 2,
                    l = o.width / 2,
                    u = o.height / 2;
                (s !== j.cx || c !== j.cy || o.width !== j.w) && (D = !0, j = {
                    cx: s,
                    cy: c,
                    w: o.width
                });
                let d = s + (rn.x - .5) * o.width,
                    f = c + (rn.y - .5) * o.height;
                if (!T && !Number.isNaN(k.x) && (d += (k.x - a.left - s) * an, f += (k.y - a.top - c) * an), d = Math.max(s - l * on, Math.min(s + l * on, d)), f = Math.max(c - u * on, Math.min(c + u * on, f)), !A.init) A.x = d, A.y = f, A.init = !0, D = !0;
                else {
                    A.vx += (d - A.x) * sn * n, A.vy += (f - A.y) * sn * n;
                    let e = Math.exp(-cn * n);
                    A.vx *= e, A.vy *= e;
                    let t = A.x + A.vx * n,
                        r = A.y + A.vy * n;
                    (Math.abs(t - A.x) > .02 || Math.abs(r - A.y) > .02) && (D = !0), A.x = t, A.y = r
                }
                if (!D) return;
                D = !1, r.style.setProperty(`--lx`, `${((A.x-(s-l))/o.width*100).toFixed(1)}%`), r.style.setProperty(`--ly`, `${((A.y-(c-u))/o.height*100).toFixed(1)}%`);
                let p = o.width * .62,
                    S = p / pn;
                i.uniform2f(m, t.width, t.height), i.uniform2f(h, A.x * E, A.y * E), i.uniform2f(g, s * E, c * E), i.uniform2f(_, l * E, u * E), i.uniform1f(v, Math.min(32, l * .5) * E), i.uniform2f(y, p * ((mn + gn * 2) / mn) / 2 * E, S * ((hn + gn * 2) / hn) / 2 * E), i.uniform1f(b, o.width * 3.2 * E), i.uniform1f(x, .25), i.clear(i.COLOR_BUFFER_BIT), i.drawArrays(i.TRIANGLES, 0, 3)
            };
        return F = requestAnimationFrame(I), () => {
            w = !0, cancelAnimationFrame(F), N.disconnect(), M(), window.removeEventListener(`pointermove`, P)
        }
    }, [e]), (0, W.jsx)(`canvas`, {
        ref: n,
        className: t,
        "aria-hidden": !0
    })
}
var Z = {
        footer: `_footer_jyv7u_1`,
        topbar: `_topbar_jyv7u_20`,
        w: `_w_jyv7u_18`,
        phL: `_phL_jyv7u_19`,
        lead: `_lead_jyv7u_43`,
        pitch: `_pitch_jyv7u_44`,
        formZone: `_formZone_jyv7u_45`,
        bottom: `_bottom_jyv7u_47`,
        footRise: `_footRise_jyv7u_1`,
        rays: `_rays_jyv7u_69`,
        tile: `_tile_jyv7u_87`,
        tileMark: `_tileMark_jyv7u_129`,
        emailInput: `_emailInput_jyv7u_165`,
        line: `_line_jyv7u_170`,
        inputWrap: `_inputWrap_jyv7u_205`,
        ph: `_ph_jyv7u_19`,
        phOff: `_phOff_jyv7u_256`,
        measure: `_measure_jyv7u_265`,
        bubbleWrap: `_bubbleWrap_jyv7u_279`,
        bubbleFloat: `_bubbleFloat_jyv7u_1`,
        bubble: `_bubble_jyv7u_279`,
        bubblePop: `_bubblePop_jyv7u_1`,
        bubbleLeft: `_bubbleLeft_jyv7u_340`,
        bubbleCenter: `_bubbleCenter_jyv7u_345`,
        bubbleMeasure: `_bubbleMeasure_jyv7u_350`,
        dots: `_dots_jyv7u_361`,
        dotRun: `_dotRun_jyv7u_1`,
        bubbleEnter: `_bubbleEnter_jyv7u_383`,
        bubbleText: `_bubbleText_jyv7u_396`,
        bubbleLine: `_bubbleLine_jyv7u_1`,
        affirmBtn: `_affirmBtn_jyv7u_399`,
        enterBtn: `_enterBtn_jyv7u_411`,
        bigDone: `_bigDone_jyv7u_447`,
        caption: `_caption_jyv7u_458`,
        another: `_another_jyv7u_470`,
        bcol: `_bcol_jyv7u_505`,
        bcenter: `_bcenter_jyv7u_513`,
        bright: `_bright_jyv7u_518`,
        dim: `_dim_jyv7u_521`,
        wordmark: `_wordmark_jyv7u_525`,
        mail: `_mail_jyv7u_530`,
        legal: `_legal_jyv7u_535`,
        hl: `_hl_jyv7u_542`,
        wordmarkBtn: `_wordmarkBtn_jyv7u_555`
    },
    yn = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i,
    bn = new Set(`gmail.googlemail.icloud.me.mac.hotmail.outlook.live.msn.yahoo.ymail.proton.protonmail.pm.gmx.aol.mail.web.t-online.yandex.zoho.fastmail.hey.seznam.wp.o2.orange.free.ukr.bluewin.libero.freenet.posteo.tutanota.tuta.email.inbox`.split(`.`)),
    xn = {
        noat: [`that's not an email yet.`, `keep going.`],
        atonly: [`@ what, exactly?`, `and then?`],
        nodot: [`you forgot the .something.`, `almost. give it a dot.`],
        space: [`emails don't have spaces.`],
        multiat: [`one @ is plenty.`],
        mash: [`nice try.`, `that's just mashing.`],
        invalid: [`that's not quite an email.`, `close, but no.`]
    },
    Sn = [`we're listening.`, `take your time.`, `no rush.`],
    Cn = /[a-z0-9._%+-]/i,
    wn = /[a-z0-9.-]/i;

function Tn(e) {
    let t = e.indexOf(`@`),
        n = t === -1 ? e : e.slice(0, t),
        r = t === -1 ? `` : e.slice(t + 1),
        i = (e, t) => {
            for (let n of e)
                if (!t.test(n)) return n;
            return null
        },
        a = i(n, Cn) ? ? i(r, wn);
    return a ? a === `'` || a === `"` || a === "`" ? `no quotes in an email.` : a === `,` ? `commas are for lists.` : a === `/` || a === `\\` ? `this isn't a url.` : a === `!` ? `calm down.` : `emails don't do "${a}".` : null
}

function En(e) {
    if (e.length < 6) return !1;
    let t = e.toLowerCase();
    if (new Set(t).size / t.length <= .34) return !0;
    let n = Math.floor(t.length / 2);
    return t.length % 2 == 0 && t.slice(0, n) === t.slice(n) ? !0 : [`qwertyuiop`, `asdfghjkl`, `zxcvbnm`, `0123456789`].some(e => {
        for (let n = 0; n + 6 <= e.length; n++)
            if (t.includes(e.slice(n, n + 6))) return !0;
        return !1
    })
}

function Dn(e, t) {
    let n = e.trim();
    if (!n) return {
        kind: `hidden`
    };
    if (/^(https?:\/\/|www\.)/i.test(n)) return {
        kind: `line`,
        text: `that's a website, not an email.`
    };
    if (/\s/.test(n)) return {
        kind: `pool`,
        pool: `space`
    };
    if (/\p{Extended_Pictographic}/u.test(n)) return {
        kind: `line`,
        text: `an emoji. in an email. no.`
    };
    let r = (n.match(/@/g) ? ? []).length;
    if (r > 1) return {
        kind: `pool`,
        pool: `multiat`
    };
    let i = Tn(n);
    if (i) return {
        kind: `line`,
        text: i
    };
    if (r === 0) return {
        kind: `pool`,
        pool: En(n) ? `mash` : `noat`
    };
    let [a, o] = n.split(`@`);
    return a ? o ? n.includes(`..`) ? {
        kind: `line`,
        text: `one dot at a time.`
    } : a.startsWith(`.`) || a.endsWith(`.`) ? {
        kind: `line`,
        text: `dots go between things.`
    } : /\.[a-z]{2,}$/i.test(o) ? yn.test(n) ? /\.ru$/i.test(o) && !t ? {
        kind: `ru`
    } : n.toLowerCase().includes(`test`) ? {
        kind: `quip`,
        text: `did we hire QA?`
    } : bn.has(o.split(`.`)[0].toLowerCase()) ? {
        kind: `enter`
    } : {
        kind: `quip`,
        text: `ooh, a custom domain. fancy.`
    } : n.length > 60 ? {
        kind: `line`,
        text: `that's a novel, not an email.`
    } : {
        kind: `pool`,
        pool: `invalid`
    } : {
        kind: `pool`,
        pool: `nodot`
    } : {
        kind: `pool`,
        pool: `atonly`
    } : {
        kind: `line`,
        text: `nothing before the @?`
    }
}
var On = `Your Email`,
    kn = 9 / 2,
    An = .9,
    jn = .07;

function Mn({
    text: e,
    base: t,
    step: n = .04
}) {
    let r = e.split(` `);
    return (0, W.jsx)(W.Fragment, {
        children: r.map((e, i) => (0, W.jsxs)(`span`, {
            className: Z.w,
            style: {
                animationDelay: `${(t+i*n).toFixed(2)}s`
            },
            children: [e, i < r.length - 1 ? `\xA0` : ``]
        }, i))
    })
}

function Nn({
    text: e
}) {
    return (0, W.jsx)(W.Fragment, {
        children: [...e].map((e, t) => (0, W.jsx)(`span`, {
            className: Z.hl,
            style: {
                "--i": t
            },
            children: e === ` ` ? `\xA0` : e
        }, t))
    })
}

function Pn() {
    let [e, t] = (0, N.useState)(``), [n, r] = (0, N.useState)(`idle`), [a, o] = (0, N.useState)(null), [s, c] = (0, N.useState)(!1), [l, u] = (0, N.useState)({
        mode: `hidden`
    }), d = (0, N.useRef)(!1), f = (0, N.useRef)({}), p = (0, N.useRef)(0), m = (0, N.useRef)(-1), h = (0, N.useRef)(null), g = (0, N.useRef)(null), _ = (0, N.useRef)(null), v = (0, N.useRef)(null), y = e => e.includes(`@`) ? `right` : `left`;
    (0, N.useEffect)(() => {
        let t = g.current,
            n = h.current;
        if (!t || !n) return;
        t.textContent = e;
        let r = n.offsetWidth,
            i = t.offsetWidth / 2,
            a = Math.max(0, Math.min(r / 2 + i, r - 120)),
            o = Math.min(r, Math.max(r / 2 - i, 120));
        n.style.setProperty(`--endx`, `${a.toFixed(0)}px`), n.style.setProperty(`--startx`, `${o.toFixed(0)}px`);
        let s = 0;
        for (let t of e) s = s * 31 + t.charCodeAt(0) | 0;
        n.style.setProperty(`--tilt`, `${Math.abs(s)%13-6}deg`)
    }, [e]), (0, N.useEffect)(() => {
        if (window.clearTimeout(p.current), !e.trim()) {
            u({
                mode: `hidden`
            });
            return
        }
        let t = window.setTimeout(() => {
            let t = Dn(e, d.current);
            if (t.kind === `pool`) {
                let n = xn[t.pool],
                    r = (f.current[t.pool] ? ? -1) + 1;
                f.current[t.pool] = r, u({
                    mode: `text`,
                    text: n[r % n.length],
                    side: y(e)
                })
            } else t.kind === `line` ? u({
                mode: `text`,
                text: t.text,
                side: y(e)
            }) : t.kind === `quip` ? (u({
                mode: `text`,
                text: t.text,
                side: `right`
            }), p.current = window.setTimeout(() => u({
                mode: `enter`
            }), 800)) : t.kind === `ru` ? u({
                mode: `ru`
            }) : t.kind === `enter` ? u({
                mode: `enter`
            }) : u({
                mode: `hidden`
            })
        }, 500);
        return () => window.clearTimeout(t)
    }, [e]), (0, N.useEffect)(() => {
        if (l.mode !== `text` || Sn.includes(l.text)) return;
        let t = window.setTimeout(() => {
            let t = Dn(e, d.current);
            (t.kind === `pool` || t.kind === `line`) && (m.current = (m.current + 1) % Sn.length, u({
                mode: `text`,
                text: Sn[m.current],
                side: `center`,
                idle: !0
            }))
        }, 2200);
        return () => window.clearTimeout(t)
    }, [l, e]);
    let b = (0, N.useRef)(null);
    (0, N.useEffect)(() => {
        let e = b.current,
            t = h.current;
        if (!(!e || !t))
            if (l.mode === `text`) {
                e.textContent = l.text;
                let n = e.offsetWidth + 44 + (l.idle ? 26 : 0);
                t.style.setProperty(`--bw`, `${n}px`)
            } else t.style.removeProperty(`--bw`)
    }, [l]);
    let x = () => {
        d.current = !0, u({
            mode: `enter`
        })
    };
    return (0, W.jsxs)(`section`, {
        className: Z.footer,
        children: [(0, W.jsx)(`h2`, {
            className: `sr-only`,
            children: `Get in early`
        }), (0, W.jsx)(vn, {
            tileRef: v,
            className: Z.rays
        }), (0, W.jsxs)(`div`, {
            className: Z.topbar,
            children: [(0, W.jsx)(`span`, {
                children: (0, W.jsx)(Mn, {
                    text: `Get In Early`,
                    base: 1.4,
                    step: .05
                })
            }), (0, W.jsx)(`span`, {
                children: (0, W.jsx)(Mn, {
                    text: `Chapter 08`,
                    base: 1.5,
                    step: .05
                })
            })]
        }), (0, W.jsx)(`div`, {
            ref: v,
            className: Z.tile,
            "data-tile": !0,
            "aria-hidden": !0,
            children: (0, W.jsx)(`span`, {
                className: Z.tileMark
            })
        }), (0, W.jsx)(`p`, {
            className: Z.lead,
            children: (0, W.jsx)(Mn, {
                text: `Stop meaning to. Start doing.`,
                base: .5,
                step: .06
            })
        }), (0, W.jsx)(`p`, {
            className: Z.pitch,
            children: (0, W.jsx)(Mn, {
                text: `We're still building Grail, and we're letting the first group in when it's ready. Leave your email and you'll be near the front of the line.`,
                base: .65,
                step: .015
            })
        }), n === `done` || n === `dupe` ? (0, W.jsxs)(`div`, {
            className: Z.formZone,
            children: [(0, W.jsx)(`p`, {
                className: Z.bigDone,
                children: (0, W.jsx)(Mn, {
                    text: n === `done` ? `You're in.` : `Already in.`,
                    base: .1,
                    step: .08
                })
            }), (0, W.jsx)(`p`, {
                className: Z.caption,
                children: (0, W.jsx)(Mn, {
                    text: n === `done` ? `We'll email you when the gates open.` : `This email is on the list.`,
                    base: .4
                })
            }), n === `dupe` && (0, W.jsx)(`button`, {
                type: `button`,
                className: Z.another,
                onClick: () => {
                    A(`waitlist_retry_clicked`, {}), t(``), r(`idle`), o(null), u({
                        mode: `hidden`
                    })
                },
                children: `Join with another email`
            })]
        }) : (0, W.jsxs)(`form`, {
            className: Z.formZone,
            onSubmit: async t => {
                t.preventDefault();
                let a = e.trim().toLowerCase();
                if (!a || n === `sending`) return;
                if (_.current ? .value) {
                    r(`done`);
                    return
                }
                try {
                    let e = Number(localStorage.getItem(`grail_wl_ts`) || 0);
                    if (Date.now() - e < 2e4) {
                        r(`done`);
                        return
                    }
                } catch {}
                let s = Dn(a, d.current);
                if (s.kind === `ru`) {
                    u({
                        mode: `ru`
                    }), A(`waitlist_blocked`, {
                        reason: `ru_affirm`
                    });
                    return
                }
                if (s.kind !== `enter` && s.kind !== `quip`) {
                    A(`waitlist_blocked`, {
                        reason: `invalid`
                    }), s.kind === `pool` ? u({
                        mode: `text`,
                        text: xn[s.pool][0],
                        side: y(a)
                    }) : s.kind === `line` && u({
                        mode: `text`,
                        text: s.text,
                        side: y(a)
                    });
                    return
                }
                r(`sending`), o(null);
                let {
                    submitWaitlist: c
                } = await i(async () => {
                    let {
                        submitWaitlist: e
                    } = await
                    import (`./supabase-ne8yL6rH.js`).then(e => e.c);
                    return {
                        submitWaitlist: e
                    }
                }, __vite__mapDeps([8, 1])), {
                    error: l
                } = await c(a, !0);
                if (l === `already_exists`) r(`dupe`), A(`waitlist_duplicate`, {
                    source: `footer`
                });
                else if (l) r(`idle`), o(`That did not go through. Try again.`);
                else {
                    r(`done`), A(`waitlist_submitted`, {
                        source: `footer`,
                        session_id: null,
                        allow_contact: !0
                    }), j(a);
                    try {
                        localStorage.setItem(`grail_wl_ts`, String(Date.now()))
                    } catch {}
                }
            },
            children: [(0, W.jsx)(`input`, {
                ref: _,
                type: `text`,
                name: `company`,
                tabIndex: -1,
                autoComplete: `off`,
                "aria-hidden": !0,
                style: {
                    position: `absolute`,
                    left: `-9999px`,
                    width: 1,
                    height: 1,
                    opacity: 0
                }
            }), (0, W.jsxs)(`div`, {
                ref: h,
                className: Z.inputWrap,
                children: [(0, W.jsx)(`span`, {
                    ref: g,
                    className: Z.measure,
                    "aria-hidden": !0
                }), (0, W.jsx)(`input`, {
                    className: Z.emailInput,
                    type: `email`,
                    required: !0,
                    "aria-label": `Your email`,
                    value: e,
                    onChange: e => t(e.target.value),
                    onFocus: () => c(!0),
                    onBlur: e => c(e.target.value.length > 0),
                    disabled: n === `sending`
                }), (0, W.jsx)(`span`, {
                    className: `${Z.ph} ${s||e?Z.phOff:``}`,
                    "aria-hidden": !0,
                    children: [...On].map((e, t) => e === ` ` ? (0, W.jsx)(`span`, {
                        children: `\xA0`
                    }, t) : (0, W.jsx)(`span`, {
                        className: Z.phL,
                        style: {
                            animationDelay: `${(An+Math.abs(t-kn)*jn).toFixed(2)}s`
                        },
                        children: e
                    }, t))
                }), (0, W.jsx)(`span`, {
                    className: Z.line,
                    "aria-hidden": !0
                }), (0, W.jsx)(`div`, {
                    className: Z.bubbleWrap,
                    "aria-live": `polite`,
                    style: {
                        left: l.mode === `text` && l.side === `left` ? `var(--startx, 50%)` : l.mode === `text` && l.side === `center` ? `50%` : `var(--endx, 50%)`
                    },
                    children: l.mode !== `hidden` && (0, W.jsx)(`div`, {
                        className: `${Z.bubble} ${l.mode===`enter`?Z.bubbleEnter:``} ${l.mode===`text`&&l.side===`left`?Z.bubbleLeft:l.mode===`text`&&l.side===`center`?Z.bubbleCenter:``}`,
                        children: l.mode === `enter` ? (0, W.jsx)(`button`, {
                            type: `submit`,
                            className: Z.enterBtn,
                            "aria-label": `Join the waitlist`,
                            disabled: n === `sending`,
                            children: `↵`
                        }) : l.mode === `ru` ? (0, W.jsxs)(`span`, {
                            className: Z.bubbleText,
                            children: [`🇺🇦 We stand with Ukraine.`, (0, W.jsx)(`button`, {
                                type: `button`,
                                className: Z.affirmBtn,
                                onClick: x,
                                children: `I do →`
                            })]
                        }) : (0, W.jsxs)(`span`, {
                            className: Z.bubbleText,
                            children: [l.text, l.idle && (0, W.jsxs)(`span`, {
                                className: Z.dots,
                                "aria-hidden": !0,
                                children: [(0, W.jsx)(`i`, {}), (0, W.jsx)(`i`, {}), (0, W.jsx)(`i`, {})]
                            })]
                        }, l.text)
                    })
                }), (0, W.jsx)(`span`, {
                    ref: b,
                    className: Z.bubbleMeasure,
                    "aria-hidden": !0
                })]
            }), (0, W.jsx)(`p`, {
                className: Z.caption,
                children: (0, W.jsx)(Mn, {
                    text: a ? ? `Early access · No card, no spam`,
                    base: a ? 0 : 1.3,
                    step: .05
                })
            })]
        }), (0, W.jsxs)(`div`, {
            className: Z.bottom,
            children: [(0, W.jsxs)(`div`, {
                className: Z.bcol,
                children: [(0, W.jsx)(`a`, {
                    className: `${Z.legal} ${Z.dim}`,
                    href: `https://denormalized.co`,
                    target: `_blank`,
                    rel: `noopener`,
                    children: (0, W.jsx)(`span`, {
                        className: Z.w,
                        style: {
                            animationDelay: `1.4s`
                        },
                        children: (0, W.jsx)(Nn, {
                            text: `Made by Denormalized`
                        })
                    })
                }), (0, W.jsx)(`a`, {
                    className: Z.legal,
                    href: `/privacy`,
                    children: (0, W.jsx)(`span`, {
                        className: Z.w,
                        style: {
                            animationDelay: `1.52s`
                        },
                        children: (0, W.jsx)(Nn, {
                            text: `Privacy`
                        })
                    })
                })]
            }), (0, W.jsxs)(`div`, {
                className: `${Z.bcol} ${Z.bcenter}`,
                children: [(0, W.jsx)(`span`, {
                    className: Z.w,
                    style: {
                        animationDelay: `1.45s`
                    },
                    children: (0, W.jsx)(`button`, {
                        className: Z.wordmarkBtn,
                        onClick: () => window.scrollTo({
                            top: 0,
                            behavior: `smooth`
                        }),
                        "aria-label": `Grail — back to top`,
                        children: (0, W.jsx)(`img`, {
                            className: Z.wordmark,
                            src: `/Logo.svg`,
                            alt: `Grail`
                        })
                    })
                }), (0, W.jsx)(`span`, {
                    children: (0, W.jsx)(Mn, {
                        text: `Real Life Happens Offline`,
                        base: 1.5,
                        step: .03
                    })
                })]
            }), (0, W.jsxs)(`div`, {
                className: `${Z.bcol} ${Z.bright}`,
                children: [(0, W.jsx)(`a`, {
                    className: Z.mail,
                    href: `mailto:grail@denormalized.co`,
                    children: (0, W.jsx)(`span`, {
                        className: Z.w,
                        style: {
                            animationDelay: `1.45s`
                        },
                        children: (0, W.jsx)(Nn, {
                            text: `grail@denormalized.co`
                        })
                    })
                }), (0, W.jsx)(`a`, {
                    className: Z.legal,
                    href: `/terms`,
                    children: (0, W.jsx)(`span`, {
                        className: Z.w,
                        style: {
                            animationDelay: `1.55s`
                        },
                        children: (0, W.jsx)(Nn, {
                            text: `Terms`
                        })
                    })
                })]
            })]
        })]
    })
}
var Fn = (0, N.memo)(Pn),
    In = [`inOutCubic`, `outCubic`, `inOutQuint`, `inExpo`, `outExpo`, `inOutExpo`, `inOutSine`],
    Ln = {
        inOutCubic: e => e < .5 ? 4 * e * e * e : 1 - (-2 * e + 2) ** 3 / 2,
        outCubic: e => 1 - (1 - e) ** 3,
        inOutQuint: e => e < .5 ? 16 * e ** 5 : 1 - (-2 * e + 2) ** 5 / 2,
        inExpo: e => e <= 0 ? 0 : 2 ** (10 * e - 10),
        outExpo: e => e >= 1 ? 1 : 1 - 2 ** (-10 * e),
        inOutExpo: e => e <= 0 ? 0 : e >= 1 ? 1 : e < .5 ? 2 ** (20 * e - 10) / 2 : (2 - 2 ** (-20 * e + 10)) / 2,
        inOutSine: e => -(Math.cos(Math.PI * e) - 1) / 2
    },
    Rn = {
        surround: `#f2cdf8`,
        bookW: 120,
        bookWMobile: 84,
        perspective: 2110,
        floatAmp: 17.5,
        floatSpeed: 1.6,
        thickness: 30,
        pageInset: 0,
        pages: 2,
        pageFan: 10.5,
        minLoad: 1.2,
        holdAt100: .35,
        countLag: 5,
        countMin: .4,
        maxWait: 10,
        openDur: 1.1,
        openDeg: 165,
        openEase: `inOutCubic`,
        tiltX: 12,
        tiltY: 22,
        tiltZ: -8,
        shiftX: .32,
        shiftDelay: .35,
        shiftDur: .9,
        shiftEase: `inOutCubic`,
        revealDelay: .55,
        revealDur: .7,
        expandDelay: .7,
        expandDur: 1.5,
        expandEase: `inOutSine`,
        expandMargin: 1.06,
        spiralDelay: .9,
        spiralDur: 2.2,
        titleDelay: 1.5
    };

function zn(e) {
    return Math.max(e.expandDelay + e.expandDur, e.revealDelay + e.revealDur)
}
var Bn = {
        root: `_root_o5e3l_2`,
        mask: `_mask_o5e3l_10`,
        stage: `_stage_o5e3l_17`,
        group: `_group_o5e3l_23`,
        cover: `_cover_o5e3l_34`,
        art: `_art_o5e3l_44`,
        frame: `_frame_o5e3l_54`,
        corner: `_corner_o5e3l_59`,
        mark: `_mark_o5e3l_66`,
        txt: `_txt_o5e3l_74`,
        loading: `_loading_o5e3l_87`,
        pct: `_pct_o5e3l_88`
    },
    Vn = 309.182,
    Hn = 417,
    Un = Math.PI / 180,
    Wn = e => Math.min(1, Math.max(0, e)),
    Gn = (e, t) => {
        let n = Math.cos(t),
            r = Math.sin(t);
        return [e[0], e[1] * n - e[2] * r, e[1] * r + e[2] * n]
    },
    Kn = (e, t) => {
        let n = Math.cos(t),
            r = Math.sin(t);
        return [e[0] * n + e[2] * r, e[1], -e[0] * r + e[2] * n]
    },
    qn = (e, t) => {
        let n = Math.cos(t),
            r = Math.sin(t);
        return [e[0] * n - e[1] * r, e[0] * r + e[1] * n, e[2]]
    };

function Jn({
    params: e,
    fakeLoad: t = 0,
    scrub: n = null,
    onTick: r,
    onDone: i
}) {
    let a = (0, N.useRef)(null),
        o = (0, N.useRef)(null),
        s = (0, N.useRef)(null),
        l = (0, N.useRef)(null),
        u = (0, N.useRef)(null),
        d = (0, N.useRef)(null),
        p = (0, N.useRef)(null),
        m = (0, N.useRef)(e),
        h = (0, N.useRef)(t),
        g = (0, N.useRef)(n),
        _ = (0, N.useRef)({
            onTick: r,
            onDone: i
        });
    return (0, N.useEffect)(() => {
        m.current = e
    }, [e]), (0, N.useEffect)(() => {
        h.current = t
    }, [t]), (0, N.useEffect)(() => {
        g.current = n
    }, [n]), (0, N.useEffect)(() => {
        _.current = {
            onTick: r,
            onDone: i
        }
    }, [r, i]), (0, N.useEffect)(() => {
        let e = a.current,
            t = o.current,
            n = s.current,
            r = l.current,
            i = u.current,
            v = d.current,
            y = t.getContext(`2d`),
            b = c(),
            x = f(),
            S = 0,
            C = 0,
            w = 1,
            T = () => {
                let n = e.getBoundingClientRect();
                S = n.width, C = n.height, w = Math.min(2, window.devicePixelRatio || 1), t.width = Math.round(S * w), t.height = Math.round(C * w)
            };
        T(), window.addEventListener(`resize`, T);
        let E = performance.now(),
            D = 0,
            O = 0,
            k = null,
            A = null,
            j = -1,
            ee = !1,
            M = 0,
            N = (e, t) => {
                t && (y.fillStyle = t), y.beginPath();
                for (let t of e) {
                    let e = P(t) < 0 ? [...t].reverse() : t;
                    y.moveTo(e[0][0], e[0][1]);
                    for (let t = 1; t < e.length; t++) y.lineTo(e[t][0], e[t][1]);
                    y.closePath()
                }
                y.fill(`nonzero`)
            },
            P = e => {
                let t = 0;
                for (let n = 0; n < e.length; n++) {
                    let [r, i] = e[n], [a, o] = e[(n + 1) % e.length];
                    t += r * o - a * i
                }
                return t
            },
            F = t => {
                let a = m.current,
                    o = Math.min(.5, (t - E) / 1e3);
                E = t, D += o;
                let s = h.current > 0 ? Math.min(1, D / h.current) : ue() ? le() : 0;
                D > a.maxWait && (s = 1);
                let c = s - O;
                O += Math.min(c, Math.max(c * Math.min(1, o * a.countLag), o * a.countMin)), s >= 1 && O > .995 && (O = 1);
                let l;
                g.current == null ? (A == null && O >= 1 && D >= a.minLoad && (k ? ? = D, D - k >= a.holdAt100 && (A = D)), l = A == null ? -1 : D - A) : (l = g.current, l >= 0 && (O = 1));
                let u = Math.round(O * 100);
                u !== j && p.current && (j = u, p.current.textContent = `${u}%`);
                let d = l >= 0,
                    f = d ? Wn(l / a.openDur) : 0,
                    T = Ln[a.openEase](f),
                    te = d ? Ln[a.expandEase](Wn((l - a.expandDelay) / a.expandDur)) : 0,
                    I = d ? Ln.outCubic(Wn((l - a.revealDelay) / a.revealDur)) : 0,
                    ne = d ? Ln[a.shiftEase](Wn((l - a.shiftDelay) / a.shiftDur)) : 0,
                    L = Math.min(x ? a.bookWMobile : a.bookW, S * .5),
                    R = Hn / Vn * L,
                    re = S / 2,
                    ie = C / 2,
                    z, B, V, ae, oe, H;
                if (b) z = 0, B = V = ae = 0, oe = 1, H = 0, e.style.opacity = String(1 - (d ? Wn(l / .5) : 0));
                else {
                    z = (a.openDeg * T + (180 - a.openDeg) * te) * Un;
                    let e = T * (1 - te),
                        t = (1 - f) * a.floatAmp;
                    B = (a.tiltX * e + Math.sin(D * a.floatSpeed * .8) * t * .5) * Un, V = (a.tiltY * e + Math.sin(D * a.floatSpeed) * t) * Un, ae = a.tiltZ * e * Un;
                    let n = S / 2;
                    oe = 1 + (Math.max(n / ((1.5 - a.shiftX) * L), n / ((.5 + a.shiftX) * L), C / R) * a.expandMargin - 1) * te, H = a.shiftX * L * oe * ne
                }
                n.style.perspective = `${a.perspective}px`, r.style.transform = `translate3d(${H}px,0,0) rotateX(${B}rad) rotateY(${V}rad) rotateZ(${ae}rad) scale(${oe})`, i.style.width = `${L}px`, i.style.height = `${R}px`, i.style.left = `${-L/2}px`, i.style.top = `${-R/2}px`, i.style.transform = `rotateY(${-z}rad)`, v.style.transform = `scale(${L/Vn})`;
                let se = (e, t, n) => {
                        let r = [e * oe, t * oe, n * oe];
                        r = qn(r, ae), r = Kn(r, V), r = Gn(r, B), r[0] += H;
                        let i = 1 - r[2] / a.perspective;
                        return [re + r[0] / i, ie + r[1] / i]
                    },
                    ce = (e, t, n) => se(-L / 2 + e * Math.cos(n), t, e * Math.sin(n)),
                    U = (e, t, n, r) => [ce(e, -n, r), ce(t, -n, r), ce(t, n, r), ce(e, n, r)],
                    W = L * a.pageInset,
                    de = -a.thickness,
                    fe = [se(-L / 2, -R / 2, de), se(L / 2, -R / 2, de), se(L / 2, R / 2, de), se(-L / 2, R / 2, de)],
                    G = U(-1, L - W, R / 2 - W, 0),
                    pe = U(-1, L, R / 2, z),
                    me = P(pe) < 0,
                    he = [G];
                me && he.push(pe);
                for (let e = 0; e < a.pages; e++) {
                    let t = z - (e + 1) * a.pageFan * Un;
                    t > .5 * Un && he.push(U(-1, L - W, R / 2 - W, t))
                }
                if (y.setTransform(w, 0, 0, w, 0, 0), y.globalCompositeOperation = `source-over`, y.fillStyle = a.surround, y.fillRect(0, 0, S, C), N([fe], `#000`), y.globalCompositeOperation = `destination-out`, N(he), y.globalCompositeOperation = `source-over`, I < 1 && N(he, `rgba(0,0,0,${(1-I).toFixed(3)})`), _.current.onTick ? .(l), (b ? d && l >= .5 : d && l >= zn(a)) && g.current == null) {
                    ee || (ee = !0, _.current.onDone ? .());
                    return
                }
                M = requestAnimationFrame(F)
            };
        return M = requestAnimationFrame(F), () => {
            cancelAnimationFrame(M), window.removeEventListener(`resize`, T)
        }
    }, []), (0, W.jsxs)(`div`, {
        ref: a,
        className: Bn.root,
        role: `status`,
        "aria-live": `polite`,
        "aria-label": `Loading`,
        children: [(0, W.jsx)(`canvas`, {
            ref: o,
            className: Bn.mask,
            "aria-hidden": !0
        }), (0, W.jsx)(`div`, {
            ref: s,
            className: Bn.stage,
            "aria-hidden": !0,
            children: (0, W.jsx)(`div`, {
                ref: l,
                className: Bn.group,
                children: (0, W.jsx)(`div`, {
                    ref: u,
                    className: Bn.cover,
                    children: (0, W.jsxs)(`div`, {
                        ref: d,
                        className: Bn.art,
                        children: [(0, W.jsx)(`div`, {
                            className: Bn.frame
                        }), (0, W.jsx)(`div`, {
                            className: Bn.corner,
                            style: {
                                left: -61.84,
                                top: -61.84
                            }
                        }), (0, W.jsx)(`div`, {
                            className: Bn.corner,
                            style: {
                                left: 247.35,
                                top: -61.84
                            }
                        }), (0, W.jsx)(`div`, {
                            className: Bn.corner,
                            style: {
                                left: -61.84,
                                top: 355.16
                            }
                        }), (0, W.jsx)(`div`, {
                            className: Bn.corner,
                            style: {
                                left: 247.35,
                                top: 355.16
                            }
                        }), (0, W.jsx)(`img`, {
                            className: Bn.mark,
                            src: `/loader-mark.svg`,
                            alt: ``,
                            width: 112.424,
                            height: 108.404
                        }), (0, W.jsx)(`span`, {
                            className: `${Bn.txt} ${Bn.loading}`,
                            children: `Loading`
                        }), (0, W.jsx)(`span`, {
                            ref: p,
                            className: `${Bn.txt} ${Bn.pct}`,
                            children: `0%`
                        })]
                    })
                })
            })
        })]
    })
}
var Q = {
        page: `_page_bwga5_1`,
        scrollDbg: `_scrollDbg_bwga5_15`,
        acceptBg: `_acceptBg_bwga5_31`,
        inkStatic: `_inkStatic_bwga5_49`,
        clock: `_clock_bwga5_60`,
        inkReveal: `_inkReveal_bwga5_59`,
        acceptOverlay: `_acceptOverlay_bwga5_66`,
        clockNum: `_clockNum_bwga5_93`,
        clockGroup: `_clockGroup_bwga5_113`,
        clockDigit: `_clockDigit_bwga5_116`,
        clockColon: `_clockColon_bwga5_121`,
        phone: `_phone_bwga5_131`,
        scene: `_scene_bwga5_154`,
        hero: `_hero_bwga5_173`,
        section2: `_section2_bwga5_184`,
        s2inner: `_s2inner_bwga5_200`,
        s2head: `_s2head_bwga5_205`,
        s2line: `_s2line_bwga5_214`,
        s2body: `_s2body_bwga5_220`,
        in: `_in_bwga5_49`,
        s2rise: `_s2rise_bwga5_1`,
        sideLabel: `_sideLabel_bwga5_249`,
        section3: `_section3_bwga5_265`,
        s3labels: `_s3labels_bwga5_271`,
        section4: `_section4_bwga5_281`,
        s4colontitle: `_s4colontitle_bwga5_290`,
        s4head: `_s4head_bwga5_301`,
        s4divider: `_s4divider_bwga5_315`,
        s4body: `_s4body_bwga5_329`,
        s4lead: `_s4lead_bwga5_342`,
        s4para: `_s4para_bwga5_349`,
        s4line: `_s4line_bwga5_377`,
        s4word: `_s4word_bwga5_378`,
        scrim: `_scrim_bwga5_388`,
        blur: `_blur_bwga5_398`,
        b1: `_b1_bwga5_399`,
        b2: `_b2_bwga5_404`,
        grad: `_grad_bwga5_409`,
        nav: `_nav_bwga5_415`,
        logo: `_logo_bwga5_427`,
        logoBtn: `_logoBtn_bwga5_434`,
        tagline: `_tagline_bwga5_440`,
        cta: `_cta_bwga5_449`,
        headline: `_headline_bwga5_473`,
        word: `_word_bwga5_496`,
        letter: `_letter_bwga5_500`,
        space: `_space_bwga5_504`,
        rise: `_rise_bwga5_1`,
        waitPill: `_waitPill_bwga5_520`,
        waitPillOn: `_waitPillOn_bwga5_520`,
        waitPillLight: `_waitPillLight_bwga5_563`,
        waitPillPink: `_waitPillPink_bwga5_574`,
        footWrap: `_footWrap_bwga5_584`,
        footPin: `_footPin_bwga5_594`,
        footLive: `_footLive_bwga5_607`,
        footerOpen: `_footerOpen_bwga5_608`,
        pillMark: `_pillMark_bwga5_613`,
        pillBtn: `_pillBtn_bwga5_622`,
        restart: `_restart_bwga5_653`,
        section5: `_section5_bwga5_683`,
        s5inner: `_s5inner_bwga5_696`,
        s5head: `_s5head_bwga5_699`,
        s5headLine: `_s5headLine_bwga5_709`,
        s5in: `_s5in_bwga5_696`,
        s5headRise: `_s5headRise_bwga5_1`,
        s5questWrap: `_s5questWrap_bwga5_725`,
        s5crest: `_s5crest_bwga5_726`,
        s5sub: `_s5sub_bwga5_748`,
        s5list: `_s5list_bwga5_755`,
        s5row: `_s5row_bwga5_758`,
        s5left: `_s5left_bwga5_780`,
        s5chanceLabel: `_s5chanceLabel_bwga5_787`,
        s5chance: `_s5chance_bwga5_787`,
        s5num: `_s5num_bwga5_799`,
        s5photo: `_s5photo_bwga5_805`,
        s5desc: `_s5desc_bwga5_813`,
        peelWrap: `_peelWrap_bwga5_827`,
        peelInner: `_peelInner_bwga5_833`,
        forgeFixed: `_forgeFixed_bwga5_842`,
        totemWrap: `_totemWrap_bwga5_859`,
        totemHold: `_totemHold_bwga5_863`,
        totemPin: `_totemPin_bwga5_877`,
        statsWrap: `_statsWrap_bwga5_907`,
        statsPin: `_statsPin_bwga5_916`,
        guildsWrap: `_guildsWrap_bwga5_926`,
        desktopOnly: `_desktopOnly_bwga5_1087`,
        s4m: `_s4m_bwga5_1103`,
        s4mHead: `_s4mHead_bwga5_1104`,
        s4mPhone: `_s4mPhone_bwga5_1115`,
        s4mPhoneImg: `_s4mPhoneImg_bwga5_1124`,
        s4mCard: `_s4mCard_bwga5_1125`,
        s4mCrest: `_s4mCrest_bwga5_1137`,
        s4mGuild: `_s4mGuild_bwga5_1146`,
        s4mQuest: `_s4mQuest_bwga5_1151`,
        s4mCardDesc: `_s4mCardDesc_bwga5_1157`,
        s4mBody: `_s4mBody_bwga5_1165`,
        s4mLead: `_s4mLead_bwga5_1181`
    },
    Yn = 40,
    Xn = {
        radius: 3,
        cardScale: .5
    },
    Zn = `Reclaim your life`,
    $ = (e, t, n) => {
        let r = Math.min(1, Math.max(0, (n - e) / (t - e)));
        return r * r * (3 - 2 * r)
    },
    Qn = [
        [`Quest`, `accepted.`],
        [`Clock’s`, `running.`]
    ],
    $n = `Now there’s a clock on it. Forty-eight hours to go do the thing, because “later” is how every one of these dies.`,
    er = `Not 24, since a day is too easy to lose to work or weather or a bad mood. Two days gives you room to fit it into a real life, and keeps it tight enough that you can’t quietly let it slide. The clock is there to turn someday into this week.`,
    tr = [`/patterns/tempers.webp`, `/patterns/brotherhood-of-tale.webp`, `/patterns/keepers-of-time.webp`, `/patterns/seeker-of-forsaken.webp`, `/patterns/wind-shifters.webp`],
    nr = [{
        chance: `To end up at someone’s table.`,
        desc: `You went out to do one small thing. Six hours later you’re somewhere you didn’t plan, with people you didn’t know this morning.`
    }, {
        chance: `To be the only one out there.`,
        desc: `No one watching, no one to tell. Just you, somewhere you’d normally never be at this hour.`
    }, {
        chance: `To find the place you’d have walked past.`,
        desc: `A street you never turn down. A door you never tried. It was there the whole time.`
    }, {
        chance: `To find the scary thing was nothing.`,
        desc: `The thing you’d been putting off for weeks took four minutes. Then it was just done.`
    }, {
        chance: `To come home with something to tell.`,
        desc: `Not a screenshot. An actual thing that happened, that you were in the middle of.`
    }],
    rr = [{
        t: `Everyone's out`,
        ml: `42.4vw`
    }, {
        t: `living. You're`,
        ml: `25.1vw`
    }, {
        t: `watching them do it`,
        ml: `17vw`
    }, {
        t: `on a screen.`,
        ml: `42.4vw`
    }],
    ir = `Same week, over and over, until you can't tell them apart. You keep meaning to do the thing, go to the place, become the person, and somehow it’s always next week. The loop is comfortable, which is the problem, because comfortable is how a whole year slips by with nothing in it worth remembering.`;

function ar({
    lab: e
} = {}) {
    let t = (0, N.useRef)(null),
        n = (0, N.useRef)(null),
        r = (0, N.useRef)(null),
        i = (0, N.useRef)([]),
        s = (0, N.useRef)(null),
        d = (0, N.useRef)(null),
        p = (0, N.useRef)(null),
        m = (0, N.useRef)(null),
        h = (0, N.useRef)(null),
        g = (0, N.useRef)(null),
        _ = (0, N.useRef)(null),
        v = (0, N.useRef)(null),
        y = (0, N.useRef)(null),
        b = (0, N.useRef)(null),
        x = (0, N.useRef)(null),
        S = (0, N.useRef)(new Set),
        [C, w] = (0, N.useState)(!1),
        [T, E] = (0, N.useState)(`dark`),
        [D] = (0, N.useState)(() => f()),
        k = (0, N.useRef)(D),
        [j, ee] = (0, N.useState)(() => f()),
        M = (0, N.useRef)(j),
        P = (0, N.useRef)({
            p: 0,
            collapse: 0
        });
    (0, N.useRef)(null);
    let [F, te] = (0, N.useState)(0), [I, ne] = (0, N.useState)(!1), [L, R] = (0, N.useState)(!1), [re, ie] = (0, N.useState)(!1), [z, B] = (0, N.useState)(!0), [V, ae] = (0, N.useState)(!1), [oe, se] = (0, N.useState)(!1), [ce, le] = (0, N.useState)(!1), ue = (0, N.useRef)([]), [U, de] = (0, N.useState)(() => !/[?&]noloader=1/.test(location.search)), fe = (0, N.useRef)(U).current, G = (0, N.useRef)(+!U), [pe, me] = (0, N.useState)(+!U), he = (0, N.useRef)(pe), ge = e ? .params ? ? Rn, K = (0, N.useRef)(ge);
    (0, N.useEffect)(() => {
        K.current = ge
    }, [ge]);
    let _e = (0, N.useCallback)(e => {
            let t = K.current;
            G.current = Math.min(1, Math.max(0, (e - t.spiralDelay) / t.spiralDur));
            let n = +(e >= t.titleDelay);
            n !== he.current && (he.current = n, me(n))
        }, []),
        ve = (0, N.useCallback)(() => {
            G.current = Math.max(G.current, +!!c()), he.current || (he.current = 1, me(1)), de(!1)
        }, []);
    (0, N.useEffect)(() => {
        e && (de(!0), G.current = 0, he.current = 0, me(0), b.current ? .scrollTo(0, {
            immediate: !0
        }))
    }, [e ? .replayKey]), (0, N.useEffect)(() => {
        document.title = `Grail: Real-world quests, every day`
    }, []), (0, N.useEffect)(() => {
        A(`landing_viewed`, {
            path: window.location.pathname
        });
        let e = [
                [`journey`, d],
                [`totems`, m],
                [`stats`, h],
                [`guilds`, _],
                [`footer`, y]
            ],
            t = S.current,
            n = new IntersectionObserver(r => {
                for (let i of r) {
                    if (!i.isIntersecting) continue;
                    let r = e.find(([, e]) => e.current === i.target);
                    !r || t.has(r[0]) || (t.add(r[0]), A(`landing_chapter_viewed`, {
                        chapter: r[0],
                        index: e.findIndex(([e]) => e === r[0]) + 1
                    }), n.unobserve(i.target))
                }
            }, {
                threshold: .25
            });
        return e.forEach(([, e]) => {
            e.current && n.observe(e.current)
        }), () => n.disconnect()
    }, []);
    let ye = (0, N.useRef)(!1);
    (0, N.useEffect)(() => {
        let e = t.current;
        if (!e || k.current) return;
        let n = 0,
            r = () => {
                n = window.innerWidth;
                let t = n - Yn * 2;
                e.style.fontSize = `200px`;
                let r = e.scrollWidth;
                r > 0 && (e.style.fontSize = `${200*t/r}px`)
            },
            i = () => {
                window.innerWidth !== n && r()
            };
        return r(), window.addEventListener(`resize`, i), document.fonts ? .ready.then(r), () => window.removeEventListener(`resize`, i)
    }, [F, pe]), (0, N.useEffect)(() => {
        let e = `scrollRestoration` in history ? history.scrollRestoration : null;
        `scrollRestoration` in history && (history.scrollRestoration = `manual`), window.scrollTo(0, 0);
        let n = new H({
            syncTouch: !1
        });
        b.current = n;
        let i = 0,
            c = e => {
                n.raf(e), i = requestAnimationFrame(c)
            };
        i = requestAnimationFrame(c);
        let u = new Map,
            f = (e, t, n) => {
                u.get(e) !== t && (u.set(e, t), n(t))
            },
            p = () => {
                let e = n.scroll,
                    i = o(),
                    a = i > 0 && Number.isFinite(e) ? e / i : 0;
                P.current.p = a;
                let c = _.current;
                !v.current && c && (v.current = c.querySelector(`[data-guild-title]`));
                let u = s.current ? .children,
                    p = {
                        innerH: window.innerHeight,
                        g8Rect: c ? .getBoundingClientRect(),
                        g8Top: c ? .offsetTop ? ? 0,
                        g8H: c ? .offsetHeight ? ? 0,
                        titleTop: v.current ? .getBoundingClientRect().top ? ? 0,
                        footTop: y.current ? .offsetTop ? ? 0,
                        totemTop: m.current ? .offsetTop ? ? 0,
                        totemRect: m.current ? .getBoundingClientRect(),
                        s5Top: d.current ? .offsetTop ? ? 0,
                        s5H: d.current ? .offsetHeight ? ? 0,
                        s5Rect: d.current ? .getBoundingClientRect(),
                        rowTops: u ? Array.from(u, e => e.getBoundingClientRect().top) : []
                    },
                    h = y.current,
                    g = (p.g8Rect ? p.g8Rect.bottom : 1 / 0) < p.innerH * .6;
                if (k.current ? f(`pillOn`, !g, w) : f(`pillOn`, e > o() * .15 && !g, w), h) {
                    let t = Math.max(1, p.footTop - o());
                    r.current ? .style.setProperty(`--pillx`, String(Math.min(1, Math.max(0, e / t))))
                }
                let b = 0,
                    x = m.current,
                    S = d.current;
                if (x && S) {
                    let t = o();
                    b = k.current ? $(p.totemTop - t * .42, p.totemTop - t * .06, e) : $(p.s5Top + p.s5H + t * .25, p.totemTop - t * .1, e)
                }
                let C = $(0, .35, b),
                    T = $(.46, .74, b),
                    D = o(),
                    O = k.current && x ? $(p.totemTop - D * .86, p.totemTop - D * .15, e) : $(.52, .82, b);
                P.current.collapse = O, r.current ? .style.setProperty(`--vsheet`, String(C)), k.current && r.current ? .style.setProperty(`--vout`, String($(.15, .75, O)));
                let A = k.current && x ? $(p.totemTop - D * .95, p.totemTop - D * .32, e) : O;
                r.current ? .style.setProperty(`--forge`, String(A)), r.current ? .style.setProperty(`--vcard`, String(T)), k.current && r.current ? .style.setProperty(`--deckout`, String($(1.98, 2.12, a))), f(`sceneOn`, T < .999 && !(k.current && a > 2.15), B);
                let j = a > (k.current ? 2 : 1.55) && O < .999;
                if (f(`acceptOn`, j, ae), j && (!M.current && l() && (M.current = !0, ee(!0)), f(`acceptEver`, !0, R)), r.current ? .style.setProperty(`--treveal`, String($(.8, 1, b))), r.current ? .style.setProperty(`--dreveal`, String($(.9, 1, b))), r.current ? .style.setProperty(`--ink`, String($(k.current ? 2.05 : 1.9, k.current ? 2.65 : 2.6, a))), M.current) {
                    let e = k.current ? .82 : 1,
                        t = k.current ? $(2.05, 2.65, a) : $(1.9, 2.6, a);
                    r.current ? .style.setProperty(`--inkfill`, String(Math.min(e, t) * (1 - O) / e))
                }
                r.current ? .style.setProperty(`--dgrow`, String($(2.1, 2.45, a))), r.current ? .style.setProperty(`--hl`, String($(2.3, 2.72, a))), r.current ? .style.setProperty(`--phone`, String($(2.2, 2.65, a) * (1 - T)));
                let N = s.current;
                if (N) {
                    let e = o(),
                        t = p.rowTops;
                    for (let n = 0; n < N.children.length; n++) {
                        let r = Math.min(1, Math.max(0, (e * .9 - t[n]) / (e * .45)));
                        N.children[n].style.setProperty(`--rp`, String(r))
                    }
                }
                if (d.current) {
                    let t = o(),
                        n = p.s5Top - e,
                        i = p.s5Top + p.s5H - e,
                        a = Math.min(1, Math.max(0, (t - i) / t)),
                        s = Math.min(1, Math.max(0, (t - n) / t));
                    r.current ? .style.setProperty(`--vreveal`, String(a)), r.current ? .style.setProperty(`--afade`, String(Math.min(1, Math.max(0, n / (t * .7))))), r.current ? .style.setProperty(`--s5off`, String(Math.min(1, 1 - s + a))), r.current ? .style.setProperty(`--s5rot`, String(1 - s - a))
                }
                if (!k.current) {
                    let e = $(7.9, 9.1, a),
                        t = Number.isFinite(e) ? e : 0;
                    r.current ? .style.setProperty(`--totemscale`, String(1 - .5 * t)), r.current ? .style.setProperty(`--totemlag`, String(t))
                }
                let F = 0;
                if (c) {
                    let t = o(),
                        n = (t - (p.g8Top - e)) / t;
                    F = n;
                    let i = Math.min(1, Math.max(0, n));
                    i > .995 && !ye.current && (ye.current = !0, y.current ? .classList.add(Q.footerOpen, Q.footLive, `foot-live`)), r.current ? .style.setProperty(`--g8off`, String(1 - i)), r.current ? .style.setProperty(`--g8rot`, String(1 - i));
                    let a = p.titleTop / (p.innerH || t);
                    r.current ? .style.setProperty(`--g8hl`, String($(1.05, .6, a))), r.current ? .style.setProperty(`--g8morph`, String($(.52, .12, a)));
                    let s = Math.min(1, Math.max(0, (e + t - p.g8Top) / (t + p.g8H)));
                    r.current ? .style.setProperty(`--g8par`, String(s))
                }
                let te = A > .004 && F < 1.05;
                f(`forgeOn`, te, ie), te && (!M.current && l() && (M.current = !0, ee(!0)), f(`forgeEver`, !0, ne)); {
                    let e = p.innerH - 52,
                        t = t => !!t && t.top < e && t.bottom > e,
                        n = `dark`;
                    if (t(p.s5Rect) || t(p.g8Rect)) n = `light`;
                    else {
                        let t = p.s5Rect,
                            r = $(k.current ? 2.05 : 1.9, k.current ? 2.65 : 2.6, a),
                            i = !t || t.top > e,
                            o = !!t && t.bottom < e,
                            s = p.totemRect,
                            c = !s || s.top > e;
                        (r > .55 && i || o && c && O < .5) && (n = `pink`)
                    }
                    f(`pillTheme`, n, E)
                }
                let I = t.current;
                if (!I) return;
                let L = Math.min(1, e / (o() * .33)),
                    re = 1 - .62 * L,
                    z = -e * .18;
                I.style.transform = `translate3d(0, ${z}px, 0) scale(${re})`, I.style.opacity = String(1 - L)
            };
        n.on(`scroll`, p), p();
        let h = o(),
            g = a(() => {
                let e = n.scroll / h,
                    t = o();
                h = t, n.resize(), n.scrollTo(e * t, {
                    immediate: !0
                }), p()
            });
        return () => {
            e && (history.scrollRestoration = e), cancelAnimationFrame(i), g(), b.current = null, n.destroy()
        }
    }, []), (0, N.useEffect)(() => {
        let e = n.current;
        if (!e) return;
        let t = new IntersectionObserver(([e]) => se(e.isIntersecting), {
            threshold: .25
        });
        return t.observe(e), () => t.disconnect()
    }, []), (0, N.useEffect)(() => {
        let e = 172799,
            t = e => String(e).padStart(2, `0`),
            n = () => {
                let n = Math.floor(e / 3600),
                    r = Math.floor(e % 3600 / 60),
                    a = e % 60,
                    o = t(n) + t(r) + t(a);
                for (let e = 0; e < 6; e++) {
                    let t = i.current[e];
                    t && t.textContent !== o[e] && (t.textContent = o[e])
                }
                e = Math.max(0, e - 1)
            };
        if (n(), c()) return;
        let r = setInterval(n, 1e3);
        return () => clearInterval(r)
    }, []), (0, N.useEffect)(() => {
        if (c() || !ce) return;
        let e = 0,
            t = () => ue.current.forEach((t, n) => {
                t && (t.style.opacity = n === e ? `1` : `0`, t.style.transform = n === e ? `translateY(0)` : `translateY(45%)`)
            }),
            n = setInterval(() => {
                e = (e + 1) % tr.length, t()
            }, 1400);
        return () => clearInterval(n)
    }, [ce]), (0, N.useEffect)(() => {
        let e = p.current;
        if (!e) return;
        let t = new IntersectionObserver(([e]) => le(e.isIntersecting), {
            threshold: .55
        });
        return t.observe(e), () => t.disconnect()
    }, []), (0, N.useEffect)(() => {
        let e = s.current;
        if (!e || u() || c()) return;
        let t = -1,
            n = -1,
            r = e => {
                t = e.clientX, n = e.clientY
            };
        window.addEventListener(`mousemove`, r);
        let i = [],
            a = 0,
            o = () => {
                let r = e.getBoundingClientRect(),
                    s = window.innerHeight,
                    c = r.bottom > 0 && r.top < s;
                for (let r = 0; r < e.children.length; r++) {
                    let a = e.children[r].children[1];
                    if (!a) continue;
                    let o = 0;
                    if (c && t >= 0) {
                        let e = a.getBoundingClientRect(),
                            r = e.left + e.width / 2,
                            i = e.top + e.height / 2,
                            s = 1 / (1 + ((n - i) / 140) ** 2);
                        o = Math.max(-60, Math.min(60, (t - r) * .16)) * s
                    }
                    i[r] = (i[r] ? ? 0) + (o - (i[r] ? ? 0)) * .12, a.style.transform = `translateX(${i[r].toFixed(1)}px)`
                }
                a = requestAnimationFrame(o)
            };
        return a = requestAnimationFrame(o), () => {
            window.removeEventListener(`mousemove`, r), cancelAnimationFrame(a)
        }
    }, []), (0, N.useEffect)(() => {
        let e = b.current;
        return U ? (e ? .stop(), document.documentElement.style.overflow = `hidden`) : (e ? .start(), document.documentElement.style.overflow = ``), () => {
            document.documentElement.style.overflow = ``
        }
    }, [U]), (0, N.useEffect)(() => {
        if (!fe || F === 0) return;
        let e = performance.now(),
            t = 0,
            n = () => {
                let r = (performance.now() - e) / 1e3 / K.current.spiralDur;
                G.current = Math.min(1, r), r < 1 && (t = requestAnimationFrame(n))
            };
        return G.current = 0, t = requestAnimationFrame(n), () => cancelAnimationFrame(t)
    }, [F, fe]);
    let be = 0;
    return (0, W.jsxs)(`div`, {
        ref: r,
        className: `home-root ${Q.page}`,
        children: [!1, U && (0, W.jsx)(Jn, {
            params: ge,
            fakeLoad: e ? .fakeLoad ? ? 0,
            scrub: e ? .scrub ? ? null,
            onTick: _e,
            onDone: ve
        }), I && (j ? (0, W.jsx)(`img`, {
            className: Q.forgeFixed,
            src: `/mobile/forge.webp`,
            alt: ``,
            "aria-hidden": !0,
            width: 768,
            height: 1663,
            decoding: `async`,
            style: {
                visibility: re ? `visible` : `hidden`
            }
        }) : (0, W.jsx)(O, {
            active: re,
            className: Q.forgeFixed,
            style: {
                visibility: re ? `visible` : `hidden`
            }
        })), L && (j ? (0, W.jsx)(`div`, {
            className: `${Q.acceptBg} ${Q.inkStatic}`,
            "aria-hidden": !0,
            style: {
                visibility: V ? `visible` : `hidden`
            }
        }) : (0, W.jsx)(ut, {
            scrollRef: P,
            className: Q.acceptBg,
            active: V,
            style: {
                visibility: V ? `visible` : `hidden`
            },
            maxProgress: D ? .82 : 1,
            noiseAmp: D ? .45 : .82,
            sp0: D ? 2.05 : void 0,
            sp1: D ? 2.65 : void 0
        })), (0, W.jsx)(`div`, {
            className: Q.clock,
            "aria-hidden": !0,
            style: {
                visibility: V ? `visible` : `hidden`
            },
            children: (0, W.jsx)(`span`, {
                className: Q.clockNum,
                children: [`47`, `59`, `59`].map((e, t) => (0, W.jsxs)(N.Fragment, {
                    children: [t > 0 && (0, W.jsx)(`span`, {
                        className: Q.clockColon,
                        children: `:`
                    }), (0, W.jsx)(`span`, {
                        className: Q.clockGroup,
                        children: [0, 1].map(n => (0, W.jsx)(`span`, {
                            className: Q.clockDigit,
                            ref: e => {
                                i.current[t * 2 + n] = e
                            },
                            children: e[n]
                        }, n))
                    })]
                }, t))
            })
        }), (0, W.jsx)(`img`, {
            className: Q.phone,
            src: `/accept-phone.webp`,
            alt: ``,
            "aria-hidden": !0,
            width: 643,
            height: 1306,
            loading: `lazy`,
            decoding: `async`
        }), (0, W.jsx)(`div`, {
            className: Q.scene,
            style: {
                visibility: z ? `visible` : `hidden`
            },
            children: (0, W.jsx)(tt, {
                embedded: !0,
                reveal: !0,
                revealNonce: F,
                revealProgress: fe ? G : void 0,
                cfg: Xn,
                scrollRef: P,
                active: z,
                spMax: D ? 1.85 : 1 / 0
            })
        }), (0, W.jsxs)(`header`, {
            className: Q.hero,
            children: [(0, W.jsxs)(`div`, {
                className: Q.scrim,
                "aria-hidden": !0,
                children: [(0, W.jsx)(`div`, {
                    className: `${Q.blur} ${Q.b1}`
                }), (0, W.jsx)(`div`, {
                    className: `${Q.blur} ${Q.b2}`
                }), (0, W.jsx)(`div`, {
                    className: Q.grad
                })]
            }), (0, W.jsxs)(`nav`, {
                className: Q.nav,
                children: [(0, W.jsx)(`button`, {
                    className: Q.logoBtn,
                    onClick: () => b.current ? .scrollTo(0, {
                        duration: 1.4
                    }),
                    "aria-label": `Grail — back to top`,
                    children: (0, W.jsx)(`img`, {
                        className: Q.logo,
                        src: `/Logo.svg`,
                        alt: `Grail`
                    })
                }), (0, W.jsx)(`p`, {
                    className: Q.tagline,
                    children: `One real-world quest a day. Four stats that go up when you do things out in the world.`
                }), (0, W.jsx)(`button`, {
                    className: Q.cta,
                    onClick: () => {
                        A(`landing_cta_clicked`, {
                            cta: `join_waitlist_nav`,
                            target: `footer`
                        }), b.current ? .scrollTo(document.documentElement.scrollHeight, {
                            duration: 1.8
                        })
                    },
                    children: `Join Waitlist`
                })]
            }), (0, W.jsx)(`h1`, {
                ref: t,
                className: Q.headline,
                "aria-label": Zn,
                style: {
                    visibility: pe ? `visible` : `hidden`
                },
                children: Zn.split(` `).flatMap((e, t, n) => {
                    let r = (0, W.jsx)(`span`, {
                        className: Q.word,
                        children: [...e].map((e, t) => (0, W.jsx)(`span`, {
                            className: Q.letter,
                            style: {
                                animationDelay: `${be++*.045}s`
                            },
                            children: e
                        }, t))
                    }, `w${t}`);
                    return t < n.length - 1 ? [r, (0, W.jsx)(`span`, {
                        className: Q.space,
                        "aria-hidden": !0
                    }, `s${t}`)] : [r]
                })
            }, `${F}-${pe}`)]
        }), (0, W.jsxs)(`section`, {
            className: `${Q.section2} ${oe?Q.in:``}`,
            children: [(0, W.jsx)(ft, {
                label: `About Problem`,
                chapter: `Chapter 01`,
                tone: `dark`
            }), (0, W.jsx)(`h2`, {
                className: `sr-only`,
                children: rr.map(e => e.t).join(` `)
            }), (0, W.jsxs)(`div`, {
                className: Q.s2inner,
                ref: n,
                children: [(0, W.jsx)(`div`, {
                    className: Q.s2head,
                    "aria-hidden": !0,
                    children: rr.map((e, t) => (0, W.jsx)(`div`, {
                        className: Q.s2line,
                        style: {
                            marginLeft: e.ml
                        },
                        children: e.t
                    }, t))
                }), (0, W.jsx)(`p`, {
                    className: Q.s2body,
                    children: ir
                })]
            })]
        }), (0, W.jsx)(`section`, {
            className: Q.section3
        }), (0, W.jsxs)(`section`, {
            ref: g,
            className: Q.section4,
            "aria-hidden": !D,
            children: [D && (0, W.jsx)(ft, {
                label: `About Timer`,
                chapter: `Chapter 02`,
                tone: `light`,
                className: Q.s4colontitle
            }), D && (0, W.jsxs)(`div`, {
                className: Q.s4m,
                children: [(0, W.jsxs)(`h2`, {
                    className: Q.s4mHead,
                    children: [`Quest accepted.`, (0, W.jsx)(`br`, {}), `Clock’s running.`]
                }), (0, W.jsxs)(`div`, {
                    className: Q.s4mPhone,
                    children: [(0, W.jsx)(`img`, {
                        className: Q.s4mPhoneImg,
                        src: `/accept-phone.webp`,
                        alt: ``,
                        "aria-hidden": !0,
                        width: 643,
                        height: 1306,
                        loading: `lazy`,
                        decoding: `async`
                    }), (0, W.jsxs)(`div`, {
                        className: Q.s4mCard,
                        children: [(0, W.jsx)(`span`, {
                            className: Q.s4mCrest,
                            "aria-hidden": !0,
                            children: (0, W.jsx)(`img`, {
                                src: `/patterns/seeker-of-forsaken-160.webp`,
                                alt: ``,
                                width: 160,
                                height: 158,
                                loading: `lazy`,
                                decoding: `async`
                            })
                        }), (0, W.jsx)(`p`, {
                            className: Q.s4mGuild,
                            children: `The Seekers of Forsaken`
                        }), (0, W.jsx)(`h3`, {
                            className: Q.s4mQuest,
                            children: `Ask a stranger for a recommendation today. A place, a book, anything.`
                        }), (0, W.jsx)(`p`, {
                            className: Q.s4mCardDesc,
                            children: `People like being asked. Open your mouth to the barista, the neighbor, the person in line.`
                        })]
                    })]
                }), (0, W.jsxs)(`div`, {
                    className: Q.s4mBody,
                    children: [(0, W.jsx)(`p`, {
                        className: Q.s4mLead,
                        children: $n
                    }), (0, W.jsx)(`p`, {
                        children: er
                    })]
                })]
            })]
        }), !D && (0, W.jsxs)(`div`, {
            className: `sr-only`,
            children: [(0, W.jsx)(`h2`, {
                children: `Quest accepted. Clock's running.`
            }), (0, W.jsx)(`p`, {
                children: $n
            }), (0, W.jsx)(`p`, {
                children: er
            })]
        }), (0, W.jsxs)(`div`, {
            className: `${Q.acceptOverlay} ${Q.desktopOnly}`,
            "aria-hidden": !0,
            children: [V && (0, W.jsx)(ft, {
                label: `About Timer`,
                chapter: `Chapter 02`,
                tone: `light`
            }), (0, W.jsx)(`h2`, {
                className: Q.s4head,
                children: (() => {
                    let e = 0;
                    return Qn.map((t, n) => (0, W.jsx)(`span`, {
                        className: Q.s4line,
                        children: t.flatMap((n, r) => {
                            let i = e++,
                                a = (0, W.jsx)(`span`, {
                                    className: Q.s4word,
                                    style: {
                                        "--i": i
                                    },
                                    children: n
                                }, i);
                            return r < t.length - 1 ? [a, ` `] : [a]
                        })
                    }, n))
                })()
            }), (0, W.jsx)(`div`, {
                className: Q.inkReveal,
                children: (0, W.jsxs)(`div`, {
                    className: Q.s4body,
                    children: [(0, W.jsx)(`p`, {
                        className: Q.s4lead,
                        children: $n
                    }), (0, W.jsx)(`p`, {
                        className: Q.s4para,
                        children: er
                    })]
                })
            }), (0, W.jsx)(`div`, {
                className: Q.s4divider
            })]
        }), (0, W.jsxs)(`section`, {
            ref: d,
            className: Q.section5,
            children: [(0, W.jsx)(ft, {
                label: `About Journey`,
                chapter: `Chapter 03`,
                tone: `light`,
                style: {
                    opacity: `clamp(0, (0.8 - var(--vreveal, 0)) / 0.2, 1)`
                }
            }), (0, W.jsxs)(`div`, {
                className: Q.s5inner,
                children: [(0, W.jsxs)(`h2`, {
                    ref: p,
                    className: `${Q.s5head} ${ce?Q.s5in:``}`,
                    children: [(0, W.jsxs)(`span`, {
                        className: Q.s5headLine,
                        children: [`It starts as one`, ` `, (0, W.jsxs)(`span`, {
                            className: Q.s5questWrap,
                            children: [(0, W.jsx)(`span`, {
                                className: Q.s5crest,
                                "aria-hidden": !0,
                                children: tr.map((e, t) => (0, W.jsx)(`img`, {
                                    ref: e => {
                                        ue.current[t] = e
                                    },
                                    src: e.replace(`.webp`, `-160.webp`),
                                    alt: ``,
                                    width: 160,
                                    height: 158,
                                    loading: `lazy`,
                                    decoding: `async`,
                                    style: {
                                        opacity: +(t === 0),
                                        transform: t === 0 ? `translateY(0)` : `translateY(45%)`
                                    }
                                }, t))
                            }), `\xA0`, `quest.`]
                        })]
                    }), (0, W.jsx)(`span`, {
                        className: Q.s5headLine,
                        children: `It rarely stays that way.`
                    })]
                }), (0, W.jsx)(`p`, {
                    className: Q.s5sub,
                    children: `No promises. Just what tends to happen when you show up.`
                }), (0, W.jsx)(`div`, {
                    className: Q.s5list,
                    ref: s,
                    children: nr.map((e, t) => (0, W.jsxs)(`div`, {
                        className: Q.s5row,
                        children: [(0, W.jsxs)(`div`, {
                            className: Q.s5left,
                            children: [(0, W.jsxs)(`div`, {
                                children: [(0, W.jsx)(`p`, {
                                    className: Q.s5chanceLabel,
                                    children: `A chance`
                                }), (0, W.jsx)(`p`, {
                                    className: Q.s5chance,
                                    children: e.chance
                                })]
                            }), (0, W.jsx)(`p`, {
                                className: Q.s5num,
                                children: String(t + 1).padStart(2, `0`)
                            })]
                        }), (0, W.jsx)(`img`, {
                            className: Q.s5photo,
                            src: `/story/0${t+1}.jpg`,
                            srcSet: `/story/0${t+1}-320.webp 320w, /story/0${t+1}-640.webp 640w`,
                            sizes: `(max-width: 768px) 42vw, 201px`,
                            alt: ``,
                            "aria-hidden": !0,
                            width: 600,
                            height: 400,
                            loading: `lazy`,
                            decoding: `async`
                        }), (0, W.jsx)(`p`, {
                            className: Q.s5desc,
                            children: e.desc
                        })]
                    }, t))
                })]
            })]
        }), (0, W.jsx)(`div`, {
            className: Q.peelWrap,
            children: (0, W.jsx)(`div`, {
                className: Q.peelInner,
                children: (0, W.jsx)(vt, {})
            })
        }), (0, W.jsxs)(`div`, {
            ref: m,
            className: Q.totemWrap,
            children: [(0, W.jsx)(`div`, {
                className: Q.totemPin,
                children: (0, W.jsx)(Tt, {
                    embedded: !0
                })
            }), (0, W.jsx)(`div`, {
                className: Q.totemHold,
                "aria-hidden": !0
            })]
        }), (0, W.jsx)(`div`, {
            ref: h,
            className: Q.statsWrap,
            children: (0, W.jsx)(`div`, {
                className: Q.statsPin,
                children: (0, W.jsx)(Ut, {
                    embedded: !0
                })
            })
        }), (0, W.jsx)(`div`, {
            ref: _,
            className: Q.guildsWrap,
            children: (0, W.jsx)(nn, {})
        }), (0, W.jsx)(`div`, {
            ref: y,
            className: Q.footWrap,
            children: (0, W.jsx)(`div`, {
                className: Q.footPin,
                children: (0, W.jsx)(Fn, {})
            })
        }), (0, W.jsxs)(`button`, {
            ref: x,
            className: `${Q.waitPill} ${C?Q.waitPillOn:``} ${T===`light`?Q.waitPillLight:T===`pink`?Q.waitPillPink:``}`,
            onClick: () => {
                A(`landing_cta_clicked`, {
                    cta: `join_waitlist_pill`,
                    target: `footer`
                }), b.current ? .scrollTo(document.documentElement.scrollHeight, {
                    duration: 1.8
                })
            },
            "aria-label": `Join Waitlist`,
            children: [(0, W.jsx)(`span`, {
                className: Q.pillMark,
                "aria-hidden": !0
            }), (0, W.jsx)(`span`, {
                className: Q.pillBtn,
                children: `Join Waitlist`
            })]
        }), !1]
    })
}
export {
    nn as a, tt as c, zn as i, M as l, In as n, Ut as o, Rn as r, Tt as s, ar as t
};