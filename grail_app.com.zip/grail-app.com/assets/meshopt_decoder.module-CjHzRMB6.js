import {
    $ as e,
    A as t,
    At as n,
    B as r,
    C as i,
    Ct as a,
    D as o,
    E as s,
    Et as c,
    F as l,
    G as u,
    H as d,
    I as f,
    J as p,
    K as m,
    L as h,
    M as g,
    Mt as _,
    N as v,
    O as ee,
    Ot as y,
    P as te,
    Q as ne,
    R as b,
    St as re,
    T as ie,
    U as ae,
    W as x,
    X as oe,
    Y as S,
    Z as se,
    _ as ce,
    _t as le,
    a as ue,
    b as C,
    c as w,
    ct as de,
    d as fe,
    dt as T,
    et as pe,
    f as E,
    i as me,
    j as he,
    jt as D,
    k as ge,
    kt as _e,
    l as ve,
    lt as ye,
    nt as be,
    o as xe,
    ot as Se,
    p as Ce,
    rt as we,
    st as Te,
    tt as O,
    ut as k,
    v as A,
    vt as j,
    w as Ee,
    xt as De,
    z as Oe
} from "./three.module-DHIuxIYb.js";

function M(e, t) {
    if (t === 0) return e;
    if (t === 2 || t === 1) {
        let n = e.getIndex();
        if (n === null) {
            let t = [],
                r = e.getAttribute(`position`);
            if (r !== void 0) {
                for (let e = 0; e < r.count; e++) t.push(e);
                e.setIndex(t), n = e.getIndex()
            } else return e
        }
        let r = n.count - 2,
            i = [];
        if (t === 2)
            for (let e = 1; e <= r; e++) i.push(n.getX(0)), i.push(n.getX(e)), i.push(n.getX(e + 1));
        else
            for (let e = 0; e < r; e++) e % 2 == 0 ? (i.push(n.getX(e)), i.push(n.getX(e + 1)), i.push(n.getX(e + 2))) : (i.push(n.getX(e + 2)), i.push(n.getX(e + 1)), i.push(n.getX(e)));
        i.length / 3;
        let a = e.clone();
        return a.setIndex(i), a.clearGroups(), a
    } else return e
}

function ke(e) {
    let t = new Map,
        n = new Map,
        r = e.clone();
    return N(e, r, function(e, r) {
        t.set(r, e), n.set(e, r)
    }), r.traverse(function(e) {
        if (!e.isSkinnedMesh) return;
        let r = e,
            i = t.get(e),
            a = i.skeleton.bones;
        r.skeleton = i.skeleton.clone(), r.bindMatrix.copy(i.bindMatrix), r.skeleton.bones = a.map(function(e) {
            return n.get(e)
        }), r.bind(r.skeleton, r.bindMatrix)
    }), r
}

function N(e, t, n) {
    n(e, t);
    for (let r = 0; r < e.children.length; r++) N(e.children[r], t.children[r], n)
}
var Ae = class extends Oe {
    constructor(e) {
        super(e), this.dracoLoader = null, this.ktx2Loader = null, this.meshoptDecoder = null, this.pluginCallbacks = [], this.register(function(e) {
            return new Fe(e)
        }), this.register(function(e) {
            return new Ie(e)
        }), this.register(function(e) {
            return new Ge(e)
        }), this.register(function(e) {
            return new Ke(e)
        }), this.register(function(e) {
            return new qe(e)
        }), this.register(function(e) {
            return new Re(e)
        }), this.register(function(e) {
            return new ze(e)
        }), this.register(function(e) {
            return new Be(e)
        }), this.register(function(e) {
            return new Ve(e)
        }), this.register(function(e) {
            return new Pe(e)
        }), this.register(function(e) {
            return new He(e)
        }), this.register(function(e) {
            return new Le(e)
        }), this.register(function(e) {
            return new We(e)
        }), this.register(function(e) {
            return new Ue(e)
        }), this.register(function(e) {
            return new Me(e)
        }), this.register(function(e) {
            return new I(e, F.EXT_MESHOPT_COMPRESSION)
        }), this.register(function(e) {
            return new I(e, F.KHR_MESHOPT_COMPRESSION)
        }), this.register(function(e) {
            return new Je(e)
        })
    }
    load(e, t, n, i) {
        let a = this,
            o;
        if (this.resourcePath !== ``) o = this.resourcePath;
        else if (this.path !== ``) {
            let t = r.extractUrlBase(e);
            o = r.resolveURL(t, this.path)
        } else o = r.extractUrlBase(e);
        this.manager.itemStart(e);
        let s = function(t) {
                i && i(t), a.manager.itemError(e), a.manager.itemEnd(e)
            },
            c = new A(this.manager);
        c.setPath(this.path), c.setResponseType(`arraybuffer`), c.setRequestHeader(this.requestHeader), c.setWithCredentials(this.withCredentials), c.load(e, function(n) {
            try {
                a.parse(n, o, function(n) {
                    t(n), a.manager.itemEnd(e)
                }, s)
            } catch (e) {
                s(e)
            }
        }, n, s)
    }
    setDRACOLoader(e) {
        return this.dracoLoader = e, this
    }
    setKTX2Loader(e) {
        return this.ktx2Loader = e, this
    }
    setMeshoptDecoder(e) {
        return this.meshoptDecoder = e, this
    }
    register(e) {
        return this.pluginCallbacks.indexOf(e) === -1 && this.pluginCallbacks.push(e), this
    }
    unregister(e) {
        return this.pluginCallbacks.indexOf(e) !== -1 && this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e), 1), this
    }
    parse(e, t, n, r) {
        let i, a = {},
            o = {},
            s = new TextDecoder;
        if (typeof e == `string`) i = JSON.parse(e);
        else if (e instanceof ArrayBuffer)
            if (s.decode(new Uint8Array(e, 0, 4)) === L) {
                try {
                    a[F.KHR_BINARY_GLTF] = new Ye(e)
                } catch (e) {
                    r && r(e);
                    return
                }
                i = JSON.parse(a[F.KHR_BINARY_GLTF].content)
            } else i = JSON.parse(s.decode(e));
        else i = e;
        if (i.asset === void 0 || i.asset.version[0] < 2) {
            r && r(Error(`THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported.`));
            return
        }
        let c = new ct(i, {
            path: t || this.resourcePath || ``,
            crossOrigin: this.crossOrigin,
            requestHeader: this.requestHeader,
            manager: this.manager,
            ktx2Loader: this.ktx2Loader,
            meshoptDecoder: this.meshoptDecoder
        });
        c.fileLoader.setRequestHeader(this.requestHeader);
        for (let e = 0; e < this.pluginCallbacks.length; e++) {
            let t = this.pluginCallbacks[e](c);
            t.name, o[t.name] = t, a[t.name] = !0
        }
        if (i.extensionsUsed)
            for (let e = 0; e < i.extensionsUsed.length; ++e) {
                let t = i.extensionsUsed[e],
                    n = i.extensionsRequired || [];
                switch (t) {
                    case F.KHR_MATERIALS_UNLIT:
                        a[t] = new Ne;
                        break;
                    case F.KHR_DRACO_MESH_COMPRESSION:
                        a[t] = new Xe(i, this.dracoLoader);
                        break;
                    case F.KHR_TEXTURE_TRANSFORM:
                        a[t] = new Ze;
                        break;
                    case F.KHR_MESH_QUANTIZATION:
                        a[t] = new Qe;
                        break;
                    default:
                        n.indexOf(t) >= 0 && o[t]
                }
            }
        c.setExtensions(a), c.setPlugins(o), c.parse(n, r)
    }
    parseAsync(e, t) {
        let n = this;
        return new Promise(function(r, i) {
            n.parse(e, t, r, i)
        })
    }
};

function je() {
    let e = {};
    return {
        get: function(t) {
            return e[t]
        },
        add: function(t, n) {
            e[t] = n
        },
        remove: function(t) {
            delete e[t]
        },
        removeAll: function() {
            e = {}
        }
    }
}

function P(e, t, n) {
    let r = e.json.materials[t];
    return r.extensions && r.extensions[n] ? r.extensions[n] : null
}
var F = {
        KHR_BINARY_GLTF: `KHR_binary_glTF`,
        KHR_DRACO_MESH_COMPRESSION: `KHR_draco_mesh_compression`,
        KHR_LIGHTS_PUNCTUAL: `KHR_lights_punctual`,
        KHR_MATERIALS_CLEARCOAT: `KHR_materials_clearcoat`,
        KHR_MATERIALS_DISPERSION: `KHR_materials_dispersion`,
        KHR_MATERIALS_IOR: `KHR_materials_ior`,
        KHR_MATERIALS_SHEEN: `KHR_materials_sheen`,
        KHR_MATERIALS_SPECULAR: `KHR_materials_specular`,
        KHR_MATERIALS_TRANSMISSION: `KHR_materials_transmission`,
        KHR_MATERIALS_IRIDESCENCE: `KHR_materials_iridescence`,
        KHR_MATERIALS_ANISOTROPY: `KHR_materials_anisotropy`,
        KHR_MATERIALS_UNLIT: `KHR_materials_unlit`,
        KHR_MATERIALS_VOLUME: `KHR_materials_volume`,
        KHR_TEXTURE_BASISU: `KHR_texture_basisu`,
        KHR_TEXTURE_TRANSFORM: `KHR_texture_transform`,
        KHR_MESH_QUANTIZATION: `KHR_mesh_quantization`,
        KHR_MATERIALS_EMISSIVE_STRENGTH: `KHR_materials_emissive_strength`,
        EXT_MATERIALS_BUMP: `EXT_materials_bump`,
        EXT_TEXTURE_WEBP: `EXT_texture_webp`,
        EXT_TEXTURE_AVIF: `EXT_texture_avif`,
        EXT_MESHOPT_COMPRESSION: `EXT_meshopt_compression`,
        KHR_MESHOPT_COMPRESSION: `KHR_meshopt_compression`,
        EXT_MESH_GPU_INSTANCING: `EXT_mesh_gpu_instancing`
    },
    Me = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_LIGHTS_PUNCTUAL, this.cache = {
                refs: {},
                uses: {}
            }
        }
        _markDefs() {
            let e = this.parser,
                t = this.parser.json.nodes || [];
            for (let n = 0, r = t.length; n < r; n++) {
                let r = t[n];
                r.extensions && r.extensions[this.name] && r.extensions[this.name].light !== void 0 && e._addNodeRef(this.cache, r.extensions[this.name].light)
            }
        }
        _loadLight(e) {
            let t = this.parser,
                n = `light:` + e,
                r = t.cache.get(n);
            if (r) return r;
            let i = t.json,
                a = ((i.extensions && i.extensions[this.name] || {}).lights || [])[e],
                o, s = new E(16777215);
            a.color !== void 0 && s.setRGB(a.color[0], a.color[1], a.color[2], b);
            let l = a.range === void 0 ? 0 : a.range;
            switch (a.type) {
                case `directional`:
                    o = new ce(s), o.target.position.set(0, 0, -1), o.add(o.target);
                    break;
                case `point`:
                    o = new Se(s), o.distance = l;
                    break;
                case `spot`:
                    o = new c(s), o.distance = l, a.spot = a.spot || {}, a.spot.innerConeAngle = a.spot.innerConeAngle === void 0 ? 0 : a.spot.innerConeAngle, a.spot.outerConeAngle = a.spot.outerConeAngle === void 0 ? Math.PI / 4 : a.spot.outerConeAngle, o.angle = a.spot.outerConeAngle, o.penumbra = 1 - a.spot.innerConeAngle / a.spot.outerConeAngle, o.target.position.set(0, 0, -1), o.add(o.target);
                    break;
                default:
                    throw Error(`THREE.GLTFLoader: Unexpected light type: ` + a.type)
            }
            return o.position.set(0, 0, 0), X(o, a), a.intensity !== void 0 && (o.intensity = a.intensity), o.name = t.createUniqueName(a.name || `light_` + e), r = Promise.resolve(o), t.cache.add(n, r), r
        }
        getDependency(e, t) {
            if (e === `light`) return this._loadLight(t)
        }
        createNodeAttachment(e) {
            let t = this,
                n = this.parser,
                r = n.json.nodes[e],
                i = (r.extensions && r.extensions[this.name] || {}).light;
            return i === void 0 ? null : this._loadLight(i).then(function(e) {
                return n._getNodeRef(t.cache, i, e)
            })
        }
    },
    Ne = class {
        constructor() {
            this.name = F.KHR_MATERIALS_UNLIT
        }
        getMaterialType() {
            return m
        }
        extendParams(e, t, n) {
            let r = [];
            e.color = new E(1, 1, 1), e.opacity = 1;
            let i = t.pbrMetallicRoughness;
            if (i) {
                if (Array.isArray(i.baseColorFactor)) {
                    let t = i.baseColorFactor;
                    e.color.setRGB(t[0], t[1], t[2], b), e.opacity = t[3]
                }
                i.baseColorTexture !== void 0 && r.push(n.assignTexture(e, `map`, i.baseColorTexture, j))
            }
            return Promise.all(r)
        }
    },
    Pe = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_EMISSIVE_STRENGTH
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            return n === null || n.emissiveStrength !== void 0 && (t.emissiveIntensity = n.emissiveStrength), Promise.resolve()
        }
    },
    Fe = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_CLEARCOAT
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let r = P(this.parser, e, this.name);
            if (r === null) return Promise.resolve();
            let i = [];
            if (r.clearcoatFactor !== void 0 && (t.clearcoat = r.clearcoatFactor), r.clearcoatTexture !== void 0 && i.push(this.parser.assignTexture(t, `clearcoatMap`, r.clearcoatTexture)), r.clearcoatRoughnessFactor !== void 0 && (t.clearcoatRoughness = r.clearcoatRoughnessFactor), r.clearcoatRoughnessTexture !== void 0 && i.push(this.parser.assignTexture(t, `clearcoatRoughnessMap`, r.clearcoatRoughnessTexture)), r.clearcoatNormalTexture !== void 0 && (i.push(this.parser.assignTexture(t, `clearcoatNormalMap`, r.clearcoatNormalTexture)), r.clearcoatNormalTexture.scale !== void 0)) {
                let e = r.clearcoatNormalTexture.scale;
                t.clearcoatNormalScale = new n(e, e)
            }
            return Promise.all(i)
        }
    },
    Ie = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_DISPERSION
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            return n === null || (t.dispersion = n.dispersion === void 0 ? 0 : n.dispersion), Promise.resolve()
        }
    },
    Le = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_IRIDESCENCE
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            if (n === null) return Promise.resolve();
            let r = [];
            return n.iridescenceFactor !== void 0 && (t.iridescence = n.iridescenceFactor), n.iridescenceTexture !== void 0 && r.push(this.parser.assignTexture(t, `iridescenceMap`, n.iridescenceTexture)), n.iridescenceIor !== void 0 && (t.iridescenceIOR = n.iridescenceIor), t.iridescenceThicknessRange === void 0 && (t.iridescenceThicknessRange = [100, 400]), n.iridescenceThicknessMinimum !== void 0 && (t.iridescenceThicknessRange[0] = n.iridescenceThicknessMinimum), n.iridescenceThicknessMaximum !== void 0 && (t.iridescenceThicknessRange[1] = n.iridescenceThicknessMaximum), n.iridescenceThicknessTexture !== void 0 && r.push(this.parser.assignTexture(t, `iridescenceThicknessMap`, n.iridescenceThicknessTexture)), Promise.all(r)
        }
    },
    Re = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_SHEEN
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            if (n === null) return Promise.resolve();
            let r = [];
            if (t.sheenColor = new E(0, 0, 0), t.sheenRoughness = 0, t.sheen = 1, n.sheenColorFactor !== void 0) {
                let e = n.sheenColorFactor;
                t.sheenColor.setRGB(e[0], e[1], e[2], b)
            }
            return n.sheenRoughnessFactor !== void 0 && (t.sheenRoughness = n.sheenRoughnessFactor), n.sheenColorTexture !== void 0 && r.push(this.parser.assignTexture(t, `sheenColorMap`, n.sheenColorTexture, j)), n.sheenRoughnessTexture !== void 0 && r.push(this.parser.assignTexture(t, `sheenRoughnessMap`, n.sheenRoughnessTexture)), Promise.all(r)
        }
    },
    ze = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_TRANSMISSION
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            if (n === null) return Promise.resolve();
            let r = [];
            return n.transmissionFactor !== void 0 && (t.transmission = n.transmissionFactor), n.transmissionTexture !== void 0 && r.push(this.parser.assignTexture(t, `transmissionMap`, n.transmissionTexture)), Promise.all(r)
        }
    },
    Be = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_VOLUME
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            if (n === null) return Promise.resolve();
            let r = [];
            t.thickness = n.thicknessFactor === void 0 ? 0 : n.thicknessFactor, n.thicknessTexture !== void 0 && r.push(this.parser.assignTexture(t, `thicknessMap`, n.thicknessTexture)), t.attenuationDistance = n.attenuationDistance || 1 / 0;
            let i = n.attenuationColor || [1, 1, 1];
            return t.attenuationColor = new E().setRGB(i[0], i[1], i[2], b), Promise.all(r)
        }
    },
    Ve = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_IOR
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            return n === null ? Promise.resolve() : (t.ior = n.ior === void 0 ? 1.5 : n.ior, t.ior === 0 && (t.ior = 1e3), Promise.resolve())
        }
    },
    He = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_SPECULAR
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            if (n === null) return Promise.resolve();
            let r = [];
            t.specularIntensity = n.specularFactor === void 0 ? 1 : n.specularFactor, n.specularTexture !== void 0 && r.push(this.parser.assignTexture(t, `specularIntensityMap`, n.specularTexture));
            let i = n.specularColorFactor || [1, 1, 1];
            return t.specularColor = new E().setRGB(i[0], i[1], i[2], b), n.specularColorTexture !== void 0 && r.push(this.parser.assignTexture(t, `specularColorMap`, n.specularColorTexture, j)), Promise.all(r)
        }
    },
    Ue = class {
        constructor(e) {
            this.parser = e, this.name = F.EXT_MATERIALS_BUMP
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            if (n === null) return Promise.resolve();
            let r = [];
            return t.bumpScale = n.bumpFactor === void 0 ? 1 : n.bumpFactor, n.bumpTexture !== void 0 && r.push(this.parser.assignTexture(t, `bumpMap`, n.bumpTexture)), Promise.all(r)
        }
    },
    We = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_MATERIALS_ANISOTROPY
        }
        getMaterialType(e) {
            return P(this.parser, e, this.name) === null ? null : p
        }
        extendMaterialParams(e, t) {
            let n = P(this.parser, e, this.name);
            if (n === null) return Promise.resolve();
            let r = [];
            return n.anisotropyStrength !== void 0 && (t.anisotropy = n.anisotropyStrength), n.anisotropyRotation !== void 0 && (t.anisotropyRotation = n.anisotropyRotation), n.anisotropyTexture !== void 0 && r.push(this.parser.assignTexture(t, `anisotropyMap`, n.anisotropyTexture)), Promise.all(r)
        }
    },
    Ge = class {
        constructor(e) {
            this.parser = e, this.name = F.KHR_TEXTURE_BASISU
        }
        loadTexture(e) {
            let t = this.parser,
                n = t.json,
                r = n.textures[e];
            if (!r.extensions || !r.extensions[this.name]) return null;
            let i = r.extensions[this.name],
                a = t.options.ktx2Loader;
            if (!a) {
                if (n.extensionsRequired && n.extensionsRequired.indexOf(this.name) >= 0) throw Error(`THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures`);
                return null
            }
            return t.loadTextureImage(e, i.source, a)
        }
    },
    Ke = class {
        constructor(e) {
            this.parser = e, this.name = F.EXT_TEXTURE_WEBP
        }
        loadTexture(e) {
            let t = this.name,
                n = this.parser,
                r = n.json,
                i = r.textures[e];
            if (!i.extensions || !i.extensions[t]) return null;
            let a = i.extensions[t],
                o = r.images[a.source],
                s = n.textureLoader;
            if (o.uri) {
                let e = n.options.manager.getHandler(o.uri);
                e !== null && (s = e)
            }
            return n.loadTextureImage(e, a.source, s)
        }
    },
    qe = class {
        constructor(e) {
            this.parser = e, this.name = F.EXT_TEXTURE_AVIF
        }
        loadTexture(e) {
            let t = this.name,
                n = this.parser,
                r = n.json,
                i = r.textures[e];
            if (!i.extensions || !i.extensions[t]) return null;
            let a = i.extensions[t],
                o = r.images[a.source],
                s = n.textureLoader;
            if (o.uri) {
                let e = n.options.manager.getHandler(o.uri);
                e !== null && (s = e)
            }
            return n.loadTextureImage(e, a.source, s)
        }
    },
    I = class {
        constructor(e, t) {
            this.name = t, this.parser = e
        }
        loadBufferView(e) {
            let t = this.parser.json,
                n = t.bufferViews[e];
            if (n.extensions && n.extensions[this.name]) {
                let e = n.extensions[this.name],
                    r = this.parser.getDependency(`buffer`, e.buffer),
                    i = this.parser.options.meshoptDecoder;
                if (!i || !i.supported) {
                    if (t.extensionsRequired && t.extensionsRequired.indexOf(this.name) >= 0) throw Error(`THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files`);
                    return null
                }
                return r.then(function(t) {
                    let n = e.byteOffset || 0,
                        r = e.byteLength || 0,
                        a = e.count,
                        o = e.byteStride,
                        s = new Uint8Array(t, n, r);
                    return i.decodeGltfBufferAsync ? i.decodeGltfBufferAsync(a, o, s, e.mode, e.filter).then(function(e) {
                        return e.buffer
                    }) : i.ready.then(function() {
                        let t = new ArrayBuffer(a * o);
                        return i.decodeGltfBuffer(new Uint8Array(t), a, o, s, e.mode, e.filter), t
                    })
                })
            } else return null
        }
    },
    Je = class {
        constructor(e) {
            this.name = F.EXT_MESH_GPU_INSTANCING, this.parser = e
        }
        createNodeMesh(e) {
            let t = this.parser.json,
                n = t.nodes[e];
            if (!n.extensions || !n.extensions[this.name] || n.mesh === void 0) return null;
            let r = t.meshes[n.mesh];
            for (let e of r.primitives)
                if (e.mode !== V.TRIANGLES && e.mode !== V.TRIANGLE_STRIP && e.mode !== V.TRIANGLE_FAN && e.mode !== void 0) return null;
            let i = n.extensions[this.name].attributes,
                a = [],
                o = {};
            for (let e in i) a.push(this.parser.getDependency(`accessor`, i[e]).then(t => (o[e] = t, o[e])));
            return a.length < 1 ? null : (a.push(this.parser.createNodeMesh(e)), Promise.all(a).then(e => {
                let t = e.pop(),
                    n = t.isGroup ? t.children : [t],
                    r = e[0].count,
                    i = [];
                for (let e of n) {
                    let t = new x,
                        n = new D,
                        a = new k,
                        s = new D(1, 1, 1),
                        c = new ie(e.geometry, e.material, r);
                    for (let e = 0; e < r; e++) o.TRANSLATION && n.fromBufferAttribute(o.TRANSLATION, e), o.ROTATION && a.fromBufferAttribute(o.ROTATION, e), o.SCALE && s.fromBufferAttribute(o.SCALE, e), c.setMatrixAt(e, t.compose(n, a, s));
                    for (let t in o)
                        if (t === `_COLOR_0`) {
                            let e = o[t];
                            c.instanceColor = new Ee(e.array, e.itemSize, e.normalized)
                        } else t !== `TRANSLATION` && t !== `ROTATION` && t !== `SCALE` && e.geometry.setAttribute(t, o[t]);
                    O.prototype.copy.call(c, e), this.parser.assignFinalMaterial(c), i.push(c)
                }
                return t.isGroup ? (t.clear(), t.add(...i), t) : i[0]
            }))
        }
    },
    L = `glTF`,
    R = 12,
    z = {
        JSON: 1313821514,
        BIN: 5130562
    },
    Ye = class {
        constructor(e) {
            this.name = F.KHR_BINARY_GLTF, this.content = null, this.body = null;
            let t = new DataView(e, 0, R),
                n = new TextDecoder;
            if (this.header = {
                    magic: n.decode(new Uint8Array(e.slice(0, 4))),
                    version: t.getUint32(4, !0),
                    length: t.getUint32(8, !0)
                }, this.header.magic !== L) throw Error(`THREE.GLTFLoader: Unsupported glTF-Binary header.`);
            if (this.header.version < 2) throw Error(`THREE.GLTFLoader: Legacy binary file detected.`);
            let r = this.header.length - R,
                i = new DataView(e, R),
                a = 0;
            for (; a < r;) {
                let t = i.getUint32(a, !0);
                a += 4;
                let r = i.getUint32(a, !0);
                if (a += 4, r === z.JSON) {
                    let r = new Uint8Array(e, R + a, t);
                    this.content = n.decode(r)
                } else if (r === z.BIN) {
                    let n = R + a;
                    this.body = e.slice(n, n + t)
                }
                a += t
            }
            if (this.content === null) throw Error(`THREE.GLTFLoader: JSON content not found.`)
        }
    },
    Xe = class {
        constructor(e, t) {
            if (!t) throw Error(`THREE.GLTFLoader: No DRACOLoader instance provided.`);
            this.name = F.KHR_DRACO_MESH_COMPRESSION, this.json = e, this.dracoLoader = t, this.dracoLoader.preload()
        }
        decodePrimitive(e, t) {
            let n = this.json,
                r = this.dracoLoader,
                i = e.extensions[this.name].bufferView,
                a = e.extensions[this.name].attributes,
                o = {},
                s = {},
                c = {};
            for (let e in a) {
                let t = K[e] || e.toLowerCase();
                o[t] = a[e]
            }
            for (let t in e.attributes) {
                let r = K[t] || t.toLowerCase();
                if (a[t] !== void 0) {
                    let i = n.accessors[e.attributes[t]];
                    c[r] = H[i.componentType].name, s[r] = i.normalized === !0
                }
            }
            return t.getDependency(`bufferView`, i).then(function(e) {
                return new Promise(function(t, n) {
                    r.decodeDracoFile(e, function(e) {
                        for (let t in e.attributes) {
                            let n = e.attributes[t],
                                r = s[t];
                            r !== void 0 && (n.normalized = r)
                        }
                        t(e)
                    }, o, c, b, n)
                })
            })
        }
    },
    Ze = class {
        constructor() {
            this.name = F.KHR_TEXTURE_TRANSFORM
        }
        extendTexture(e, t) {
            return (t.texCoord === void 0 || t.texCoord === e.channel) && t.offset === void 0 && t.rotation === void 0 && t.scale === void 0 ? e : (e = e.clone(), t.texCoord !== void 0 && (e.channel = t.texCoord), t.offset !== void 0 && e.offset.fromArray(t.offset), t.rotation !== void 0 && (e.rotation = t.rotation), t.scale !== void 0 && e.repeat.fromArray(t.scale), e.needsUpdate = !0, e)
        }
    },
    Qe = class {
        constructor() {
            this.name = F.KHR_MESH_QUANTIZATION
        }
    },
    B = class extends ee {
        constructor(e, t, n, r) {
            super(e, t, n, r)
        }
        copySampleValue_(e) {
            let t = this.resultBuffer,
                n = this.sampleValues,
                r = this.valueSize,
                i = e * r * 3 + r;
            for (let e = 0; e !== r; e++) t[e] = n[i + e];
            return t
        }
        interpolate_(e, t, n, r) {
            let i = this.resultBuffer,
                a = this.sampleValues,
                o = this.valueSize,
                s = o * 2,
                c = o * 3,
                l = r - t,
                u = (n - t) / l,
                d = u * u,
                f = d * u,
                p = e * c,
                m = p - c,
                h = -2 * f + 3 * d,
                g = f - d,
                _ = 1 - h,
                v = g - d + u;
            for (let e = 0; e !== o; e++) {
                let t = a[m + e + o],
                    n = a[m + e + s] * l,
                    r = a[p + e + o],
                    c = a[p + e] * l;
                i[e] = _ * t + v * n + h * r + g * c
            }
            return i
        }
    },
    $e = new k,
    et = class extends B {
        interpolate_(e, t, n, r) {
            let i = super.interpolate_(e, t, n, r);
            return $e.fromArray(i).normalize().toArray(i), i
        }
    },
    V = {
        FLOAT: 5126,
        FLOAT_MAT3: 35675,
        FLOAT_MAT4: 35676,
        FLOAT_VEC2: 35664,
        FLOAT_VEC3: 35665,
        FLOAT_VEC4: 35666,
        LINEAR: 9729,
        REPEAT: 10497,
        SAMPLER_2D: 35678,
        POINTS: 0,
        LINES: 1,
        LINE_LOOP: 2,
        LINE_STRIP: 3,
        TRIANGLES: 4,
        TRIANGLE_STRIP: 5,
        TRIANGLE_FAN: 6,
        UNSIGNED_BYTE: 5121,
        UNSIGNED_SHORT: 5123
    },
    H = {
        5120: Int8Array,
        5121: Uint8Array,
        5122: Int16Array,
        5123: Uint16Array,
        5125: Uint32Array,
        5126: Float32Array
    },
    U = {
        9728: se,
        9729: l,
        9984: e,
        9985: h,
        9986: ne,
        9987: f
    },
    W = {
        33071: fe,
        33648: oe,
        10497: le
    },
    G = {
        SCALAR: 1,
        VEC2: 2,
        VEC3: 3,
        VEC4: 4,
        MAT2: 4,
        MAT3: 9,
        MAT4: 16
    },
    K = {
        POSITION: `position`,
        NORMAL: `normal`,
        TANGENT: `tangent`,
        TEXCOORD_0: `uv`,
        TEXCOORD_1: `uv1`,
        TEXCOORD_2: `uv2`,
        TEXCOORD_3: `uv3`,
        COLOR_0: `color`,
        WEIGHTS_0: `skinWeight`,
        JOINTS_0: `skinIndex`
    },
    q = {
        scale: `scale`,
        translation: `position`,
        rotation: `quaternion`,
        weights: `morphTargetInfluences`
    },
    tt = {
        CUBICSPLINE: void 0,
        LINEAR: t,
        STEP: ge
    },
    J = {
        OPAQUE: `OPAQUE`,
        MASK: `MASK`,
        BLEND: `BLEND`
    };

function nt(e) {
    return e.DefaultMaterial === void 0 && (e.DefaultMaterial = new S({
        color: 16777215,
        emissive: 0,
        metalness: 1,
        roughness: 1,
        transparent: !1,
        depthTest: !0,
        side: 0
    })), e.DefaultMaterial
}

function Y(e, t, n) {
    for (let r in n.extensions) e[r] === void 0 && (t.userData.gltfExtensions = t.userData.gltfExtensions || {}, t.userData.gltfExtensions[r] = n.extensions[r])
}

function X(e, t) {
    t.extras !== void 0 && typeof t.extras == `object` && Object.assign(e.userData, t.extras)
}

function rt(e, t, n) {
    let r = !1,
        i = !1,
        a = !1;
    for (let e = 0, n = t.length; e < n; e++) {
        let n = t[e];
        if (n.POSITION !== void 0 && (r = !0), n.NORMAL !== void 0 && (i = !0), n.COLOR_0 !== void 0 && (a = !0), r && i && a) break
    }
    if (!r && !i && !a) return Promise.resolve(e);
    let o = [],
        s = [],
        c = [];
    for (let l = 0, u = t.length; l < u; l++) {
        let u = t[l];
        if (r) {
            let t = u.POSITION === void 0 ? e.attributes.position : n.getDependency(`accessor`, u.POSITION);
            o.push(t)
        }
        if (i) {
            let t = u.NORMAL === void 0 ? e.attributes.normal : n.getDependency(`accessor`, u.NORMAL);
            s.push(t)
        }
        if (a) {
            let t = u.COLOR_0 === void 0 ? e.attributes.color : n.getDependency(`accessor`, u.COLOR_0);
            c.push(t)
        }
    }
    return Promise.all([Promise.all(o), Promise.all(s), Promise.all(c)]).then(function(t) {
        let n = t[0],
            o = t[1],
            s = t[2];
        return r && (e.morphAttributes.position = n), i && (e.morphAttributes.normal = o), a && (e.morphAttributes.color = s), e.morphTargetsRelative = !0, e
    })
}

function it(e, t) {
    if (e.updateMorphTargets(), t.weights !== void 0)
        for (let n = 0, r = t.weights.length; n < r; n++) e.morphTargetInfluences[n] = t.weights[n];
    if (t.extras && Array.isArray(t.extras.targetNames)) {
        let n = t.extras.targetNames;
        if (e.morphTargetInfluences.length === n.length) {
            e.morphTargetDictionary = {};
            for (let t = 0, r = n.length; t < r; t++) e.morphTargetDictionary[n[t]] = t
        }
    }
}

function at(e) {
    let t, n = e.extensions && e.extensions[F.KHR_DRACO_MESH_COMPRESSION];
    if (t = n ? `draco:` + n.bufferView + `:` + n.indices + `:` + Z(n.attributes) : e.indices + `:` + Z(e.attributes) + `:` + e.mode, e.targets !== void 0)
        for (let n = 0, r = e.targets.length; n < r; n++) t += `:` + Z(e.targets[n]);
    return t
}

function Z(e) {
    let t = ``,
        n = Object.keys(e).sort();
    for (let r = 0, i = n.length; r < i; r++) t += n[r] + `:` + e[n[r]] + `;`;
    return t
}

function Q(e) {
    switch (e) {
        case Int8Array:
            return 1 / 127;
        case Uint8Array:
            return 1 / 255;
        case Int16Array:
            return 1 / 32767;
        case Uint16Array:
            return 1 / 65535;
        default:
            throw Error(`THREE.GLTFLoader: Unsupported normalized accessor component type.`)
    }
}

function ot(e) {
    return e.search(/\.jpe?g($|\?)/i) > 0 || e.search(/^data\:image\/jpeg/) === 0 ? `image/jpeg` : e.search(/\.webp($|\?)/i) > 0 || e.search(/^data\:image\/webp/) === 0 ? `image/webp` : e.search(/\.ktx2($|\?)/i) > 0 || e.search(/^data\:image\/ktx2/) === 0 ? `image/ktx2` : `image/png`
}
var st = new x,
    ct = class {
        constructor(e = {}, t = {}) {
            this.json = e, this.extensions = {}, this.plugins = {}, this.options = t, this.cache = new je, this.associations = new Map, this.primitiveCache = {}, this.nodeCache = {}, this.meshCache = {
                refs: {},
                uses: {}
            }, this.cameraCache = {
                refs: {},
                uses: {}
            }, this.lightCache = {
                refs: {},
                uses: {}
            }, this.sourceCache = {}, this.textureCache = {}, this.nodeNamesUsed = {};
            let n = !1,
                r = -1,
                a = !1,
                o = -1;
            if (typeof navigator < `u` && navigator.userAgent !== void 0) {
                let e = navigator.userAgent;
                n = /^((?!chrome|android).)*safari/i.test(e) === !0;
                let t = e.match(/Version\/(\d+)/);
                r = n && t ? parseInt(t[1], 10) : -1, a = e.indexOf(`Firefox`) > -1, o = a ? e.match(/Firefox\/([0-9]+)\./)[1] : -1
            }
            typeof createImageBitmap > `u` || n && r < 17 || a && o < 98 ? this.textureLoader = new _e(this.options.manager) : this.textureLoader = new i(this.options.manager), this.textureLoader.setCrossOrigin(this.options.crossOrigin), this.textureLoader.setRequestHeader(this.options.requestHeader), this.fileLoader = new A(this.options.manager), this.fileLoader.setResponseType(`arraybuffer`), this.options.crossOrigin === `use-credentials` && this.fileLoader.setWithCredentials(!0)
        }
        setExtensions(e) {
            this.extensions = e
        }
        setPlugins(e) {
            this.plugins = e
        }
        parse(e, t) {
            let n = this,
                r = this.json,
                i = this.extensions;
            this.cache.removeAll(), this.nodeCache = {}, this._invokeAll(function(e) {
                return e._markDefs && e._markDefs()
            }), Promise.all(this._invokeAll(function(e) {
                return e.beforeRoot && e.beforeRoot()
            })).then(function() {
                return Promise.all([n.getDependencies(`scene`), n.getDependencies(`animation`), n.getDependencies(`camera`)])
            }).then(function(t) {
                let a = {
                    scene: t[0][r.scene || 0],
                    scenes: t[0],
                    animations: t[1],
                    cameras: t[2],
                    asset: r.asset,
                    parser: n,
                    userData: {}
                };
                return Y(i, a, r), X(a, r), Promise.all(n._invokeAll(function(e) {
                    return e.afterRoot && e.afterRoot(a)
                })).then(function() {
                    for (let e of a.scenes) e.updateMatrixWorld();
                    e(a)
                })
            }).catch(t)
        }
        _markDefs() {
            let e = this.json.nodes || [],
                t = this.json.skins || [],
                n = this.json.meshes || [];
            for (let n = 0, r = t.length; n < r; n++) {
                let r = t[n].joints;
                for (let t = 0, n = r.length; t < n; t++) e[r[t]].isBone = !0
            }
            for (let t = 0, r = e.length; t < r; t++) {
                let r = e[t];
                r.mesh !== void 0 && (this._addNodeRef(this.meshCache, r.mesh), r.skin !== void 0 && (n[r.mesh].isSkinnedMesh = !0)), r.camera !== void 0 && this._addNodeRef(this.cameraCache, r.camera)
            }
        }
        _addNodeRef(e, t) {
            t !== void 0 && (e.refs[t] === void 0 && (e.refs[t] = e.uses[t] = 0), e.refs[t]++)
        }
        _getNodeRef(e, t, n) {
            if (e.refs[t] <= 1) return n;
            let r = n.clone(),
                i = (e, t) => {
                    let n = this.associations.get(e);
                    n != null && this.associations.set(t, n);
                    for (let [n, r] of e.children.entries()) i(r, t.children[n])
                };
            return i(n, r), r.name += `_instance_` + e.uses[t]++, r
        }
        _invokeOne(e) {
            let t = Object.values(this.plugins);
            t.push(this);
            for (let n = 0; n < t.length; n++) {
                let r = e(t[n]);
                if (r) return r
            }
            return null
        }
        _invokeAll(e) {
            let t = Object.values(this.plugins);
            t.unshift(this);
            let n = [];
            for (let r = 0; r < t.length; r++) {
                let i = e(t[r]);
                i && n.push(i)
            }
            return n
        }
        getDependency(e, t) {
            let n = e + `:` + t,
                r = this.cache.get(n);
            if (!r) {
                switch (e) {
                    case `scene`:
                        r = this.loadScene(t);
                        break;
                    case `node`:
                        r = this._invokeOne(function(e) {
                            return e.loadNode && e.loadNode(t)
                        });
                        break;
                    case `mesh`:
                        r = this._invokeOne(function(e) {
                            return e.loadMesh && e.loadMesh(t)
                        });
                        break;
                    case `accessor`:
                        r = this.loadAccessor(t);
                        break;
                    case `bufferView`:
                        r = this._invokeOne(function(e) {
                            return e.loadBufferView && e.loadBufferView(t)
                        });
                        break;
                    case `buffer`:
                        r = this.loadBuffer(t);
                        break;
                    case `material`:
                        r = this._invokeOne(function(e) {
                            return e.loadMaterial && e.loadMaterial(t)
                        });
                        break;
                    case `texture`:
                        r = this._invokeOne(function(e) {
                            return e.loadTexture && e.loadTexture(t)
                        });
                        break;
                    case `skin`:
                        r = this.loadSkin(t);
                        break;
                    case `animation`:
                        r = this._invokeOne(function(e) {
                            return e.loadAnimation && e.loadAnimation(t)
                        });
                        break;
                    case `camera`:
                        r = this.loadCamera(t);
                        break;
                    default:
                        if (r = this._invokeOne(function(n) {
                                return n != this && n.getDependency && n.getDependency(e, t)
                            }), !r) throw Error(`Unknown type: ` + e);
                        break
                }
                this.cache.add(n, r)
            }
            return r
        }
        getDependencies(e) {
            let t = this.cache.get(e);
            if (!t) {
                let n = this,
                    r = this.json[e + (e === `mesh` ? `es` : `s`)] || [];
                t = Promise.all(r.map(function(t, r) {
                    return n.getDependency(e, r)
                })), this.cache.add(e, t)
            }
            return t
        }
        loadBuffer(e) {
            let t = this.json.buffers[e],
                n = this.fileLoader;
            if (t.type && t.type !== `arraybuffer`) throw Error(`THREE.GLTFLoader: ` + t.type + ` buffer type is not supported.`);
            if (t.uri === void 0 && e === 0) return Promise.resolve(this.extensions[F.KHR_BINARY_GLTF].body);
            let i = this.options;
            return new Promise(function(e, a) {
                n.load(r.resolveURL(t.uri, i.path), e, void 0, function() {
                    a(Error(`THREE.GLTFLoader: Failed to load buffer "` + t.uri + `".`))
                })
            })
        }
        loadBufferView(e) {
            let t = this.json.bufferViews[e];
            return this.getDependency(`buffer`, t.buffer).then(function(e) {
                let n = t.byteLength || 0,
                    r = t.byteOffset || 0;
                return e.slice(r, r + n)
            })
        }
        loadAccessor(e) {
            let t = this,
                n = this.json,
                r = this.json.accessors[e];
            if (r.bufferView === void 0 && r.sparse === void 0) {
                let e = G[r.type],
                    t = H[r.componentType],
                    n = r.normalized === !0,
                    i = new t(r.count * e);
                return Promise.resolve(new w(i, e, n))
            }
            let i = [];
            return r.bufferView === void 0 ? i.push(null) : i.push(this.getDependency(`bufferView`, r.bufferView)), r.sparse !== void 0 && (i.push(this.getDependency(`bufferView`, r.sparse.indices.bufferView)), i.push(this.getDependency(`bufferView`, r.sparse.values.bufferView))), Promise.all(i).then(function(e) {
                let i = e[0],
                    a = G[r.type],
                    c = H[r.componentType],
                    l = c.BYTES_PER_ELEMENT,
                    u = l * a,
                    d = r.byteOffset || 0,
                    f = r.bufferView === void 0 ? void 0 : n.bufferViews[r.bufferView].byteStride,
                    p = r.normalized === !0,
                    m, h;
                if (f && f !== u) {
                    let e = Math.floor(d / f),
                        n = `InterleavedBuffer:` + r.bufferView + `:` + r.componentType + `:` + e + `:` + r.count,
                        u = t.cache.get(n);
                    u || (m = new c(i, e * f, r.count * f / l), u = new s(m, f / l), t.cache.add(n, u)), h = new o(u, a, d % f / l, p)
                } else m = i === null ? new c(r.count * a) : new c(i, d, r.count * a), h = new w(m, a, p);
                if (r.sparse !== void 0) {
                    let t = G.SCALAR,
                        n = H[r.sparse.indices.componentType],
                        o = r.sparse.indices.byteOffset || 0,
                        s = r.sparse.values.byteOffset || 0,
                        l = new n(e[1], o, r.sparse.count * t),
                        u = new c(e[2], s, r.sparse.count * a);
                    i !== null && (h = new w(h.array.slice(), h.itemSize, h.normalized)), h.normalized = !1;
                    for (let e = 0, t = l.length; e < t; e++) {
                        let t = l[e];
                        if (h.setX(t, u[e * a]), a >= 2 && h.setY(t, u[e * a + 1]), a >= 3 && h.setZ(t, u[e * a + 2]), a >= 4 && h.setW(t, u[e * a + 3]), a >= 5) throw Error(`THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.`)
                    }
                    h.normalized = p
                }
                return h
            })
        }
        loadTexture(e) {
            let t = this.json,
                n = this.options,
                r = t.textures[e].source,
                i = t.images[r],
                a = this.textureLoader;
            if (i.uri) {
                let e = n.manager.getHandler(i.uri);
                e !== null && (a = e)
            }
            return this.loadTextureImage(e, r, a)
        }
        loadTextureImage(e, t, n) {
            let r = this,
                i = this.json,
                a = i.textures[e],
                o = i.images[t],
                s = (o.uri || o.bufferView) + `:` + a.sampler;
            if (this.textureCache[s]) return this.textureCache[s];
            let c = this.loadImageSource(t, n).then(function(t) {
                t.flipY = !1, t.name = a.name || o.name || ``, t.name === `` && typeof o.uri == `string` && o.uri.startsWith(`data:image/`) === !1 && (t.name = o.uri);
                let n = (i.samplers || {})[a.sampler] || {};
                return t.magFilter = U[n.magFilter] || 1006, t.minFilter = U[n.minFilter] || 1008, t.wrapS = W[n.wrapS] || 1e3, t.wrapT = W[n.wrapT] || 1e3, t.generateMipmaps = !t.isCompressedTexture && t.minFilter !== 1003 && t.minFilter !== 1006, r.associations.set(t, {
                    textures: e
                }), t
            }).catch(function() {
                return null
            });
            return this.textureCache[s] = c, c
        }
        loadImageSource(e, t) {
            let n = this,
                i = this.json,
                a = this.options;
            if (this.sourceCache[e] !== void 0) return this.sourceCache[e].then(e => e.clone());
            let o = i.images[e],
                s = self.URL || self.webkitURL,
                c = o.uri || ``,
                l = !1;
            if (o.bufferView !== void 0) c = n.getDependency(`bufferView`, o.bufferView).then(function(e) {
                l = !0;
                let t = new Blob([e], {
                    type: o.mimeType
                });
                return c = s.createObjectURL(t), c
            });
            else if (o.uri === void 0) throw Error(`THREE.GLTFLoader: Image ` + e + ` is missing URI and bufferView`);
            let u = Promise.resolve(c).then(function(e) {
                return new Promise(function(n, i) {
                    let o = n;
                    t.isImageBitmapLoader === !0 && (o = function(e) {
                        let t = new y(e);
                        t.needsUpdate = !0, n(t)
                    }), t.load(r.resolveURL(e, a.path), o, void 0, i)
                })
            }).then(function(e) {
                return l === !0 && s.revokeObjectURL(c), X(e, o), e.userData.mimeType = o.mimeType || ot(o.uri), e
            }).catch(function(e) {
                throw e
            });
            return this.sourceCache[e] = u, u
        }
        assignTexture(e, t, n, r) {
            let i = this;
            return this.getDependency(`texture`, n.index).then(function(a) {
                if (!a) return null;
                if (n.texCoord !== void 0 && n.texCoord > 0 && (a = a.clone(), a.channel = n.texCoord), i.extensions[F.KHR_TEXTURE_TRANSFORM]) {
                    let e = n.extensions === void 0 ? void 0 : n.extensions[F.KHR_TEXTURE_TRANSFORM];
                    if (e) {
                        let t = i.associations.get(a);
                        a = i.extensions[F.KHR_TEXTURE_TRANSFORM].extendTexture(a, e), i.associations.set(a, t)
                    }
                }
                return r !== void 0 && (a.colorSpace = r), e[t] = a, a
            })
        }
        assignFinalMaterial(e) {
            let t = e.geometry,
                n = e.material,
                r = t.attributes.tangent === void 0,
                i = t.attributes.color !== void 0,
                a = t.attributes.normal === void 0;
            if (e.isPoints) {
                let e = `PointsMaterial:` + n.uuid,
                    t = this.cache.get(e);
                t || (t = new de, d.prototype.copy.call(t, n), t.color.copy(n.color), t.map = n.map, t.sizeAttenuation = !1, this.cache.add(e, t)), n = t
            } else if (e.isLine) {
                let e = `LineBasicMaterial:` + n.uuid,
                    t = this.cache.get(e);
                t || (t = new g, d.prototype.copy.call(t, n), t.color.copy(n.color), t.map = n.map, this.cache.add(e, t)), n = t
            }
            if (r || i || a) {
                let e = `ClonedMaterial:` + n.uuid + `:`;
                r && (e += `derivative-tangents:`), i && (e += `vertex-colors:`), a && (e += `flat-shading:`);
                let t = this.cache.get(e);
                t || (t = n.clone(), i && (t.vertexColors = !0), a && (t.flatShading = !0), r && (t.normalScale && (t.normalScale.y *= -1), t.clearcoatNormalScale && (t.clearcoatNormalScale.y *= -1)), this.cache.add(e, t), this.associations.set(t, this.associations.get(n))), n = t
            }
            e.material = n
        }
        getMaterialType() {
            return S
        }
        loadMaterial(e) {
            let t = this,
                r = this.json,
                i = this.extensions,
                a = r.materials[e],
                o, s = {},
                c = a.extensions || {},
                l = [];
            if (c[F.KHR_MATERIALS_UNLIT]) {
                let e = i[F.KHR_MATERIALS_UNLIT];
                o = e.getMaterialType(), l.push(e.extendParams(s, a, t))
            } else {
                let n = a.pbrMetallicRoughness || {};
                if (s.color = new E(1, 1, 1), s.opacity = 1, Array.isArray(n.baseColorFactor)) {
                    let e = n.baseColorFactor;
                    s.color.setRGB(e[0], e[1], e[2], b), s.opacity = e[3]
                }
                n.baseColorTexture !== void 0 && l.push(t.assignTexture(s, `map`, n.baseColorTexture, j)), s.metalness = n.metallicFactor === void 0 ? 1 : n.metallicFactor, s.roughness = n.roughnessFactor === void 0 ? 1 : n.roughnessFactor, n.metallicRoughnessTexture !== void 0 && (l.push(t.assignTexture(s, `metalnessMap`, n.metallicRoughnessTexture)), l.push(t.assignTexture(s, `roughnessMap`, n.metallicRoughnessTexture))), o = this._invokeOne(function(t) {
                    return t.getMaterialType && t.getMaterialType(e)
                }), l.push(Promise.all(this._invokeAll(function(t) {
                    return t.extendMaterialParams && t.extendMaterialParams(e, s)
                })))
            }
            a.doubleSided === !0 && (s.side = 2);
            let u = a.alphaMode || J.OPAQUE;
            if (u === J.BLEND ? (s.transparent = !0, s.depthWrite = !1) : (s.transparent = !1, u === J.MASK && (s.alphaTest = a.alphaCutoff === void 0 ? .5 : a.alphaCutoff)), a.normalTexture !== void 0 && o !== m && (l.push(t.assignTexture(s, `normalMap`, a.normalTexture)), s.normalScale = new n(1, 1), a.normalTexture.scale !== void 0)) {
                let e = a.normalTexture.scale;
                s.normalScale.set(e, e)
            }
            if (a.occlusionTexture !== void 0 && o !== m && (l.push(t.assignTexture(s, `aoMap`, a.occlusionTexture)), a.occlusionTexture.strength !== void 0 && (s.aoMapIntensity = a.occlusionTexture.strength)), a.emissiveFactor !== void 0 && o !== m) {
                let e = a.emissiveFactor;
                s.emissive = new E().setRGB(e[0], e[1], e[2], b)
            }
            return a.emissiveTexture !== void 0 && o !== m && l.push(t.assignTexture(s, `emissiveMap`, a.emissiveTexture, j)), Promise.all(l).then(function() {
                let n = new o(s);
                return a.name && (n.name = a.name), X(n, a), t.associations.set(n, {
                    materials: e
                }), a.extensions && Y(i, n, a), n
            })
        }
        createUniqueName(e) {
            let t = ye.sanitizeNodeName(e || ``);
            return t in this.nodeNamesUsed ? t + `_` + ++this.nodeNamesUsed[t] : (this.nodeNamesUsed[t] = 0, t)
        }
        loadGeometries(e) {
            let t = this,
                n = this.extensions,
                r = this.primitiveCache;

            function i(e) {
                return n[F.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(e, t).then(function(n) {
                    return $(n, e, t)
                })
            }
            let a = [];
            for (let n = 0, o = e.length; n < o; n++) {
                let o = e[n],
                    s = at(o),
                    c = r[s];
                if (c) a.push(c.promise);
                else {
                    let e;
                    e = o.extensions && o.extensions[F.KHR_DRACO_MESH_COMPRESSION] ? i(o) : $(new ve, o, t), r[s] = {
                        primitive: o,
                        promise: e
                    }, a.push(e)
                }
            }
            return Promise.all(a)
        }
        loadMesh(e) {
            let t = this,
                n = this.json,
                r = this.extensions,
                i = n.meshes[e],
                a = i.primitives,
                o = [];
            for (let e = 0, t = a.length; e < t; e++) {
                let t = a[e].material === void 0 ? nt(this.cache) : this.getDependency(`material`, a[e].material);
                o.push(t)
            }
            return o.push(t.loadGeometries(a)), Promise.all(o).then(function(n) {
                let o = n.slice(0, n.length - 1),
                    s = n[n.length - 1],
                    c = [];
                for (let n = 0, l = s.length; n < l; n++) {
                    let l = s[n],
                        d = a[n],
                        f, p = o[n];
                    if (d.mode === V.TRIANGLES || d.mode === V.TRIANGLE_STRIP || d.mode === V.TRIANGLE_FAN || d.mode === void 0) f = i.isSkinnedMesh === !0 ? new re(l, p) : new u(l, p), f.isSkinnedMesh === !0 && f.normalizeSkinWeights(), d.mode === V.TRIANGLE_STRIP ? f.geometry = M(f.geometry, 1) : d.mode === V.TRIANGLE_FAN && (f.geometry = M(f.geometry, 2));
                    else if (d.mode === V.LINES) f = new te(l, p);
                    else if (d.mode === V.LINE_STRIP) f = new he(l, p);
                    else if (d.mode === V.LINE_LOOP) f = new v(l, p);
                    else if (d.mode === V.POINTS) f = new Te(l, p);
                    else throw Error(`THREE.GLTFLoader: Primitive mode unsupported: ` + d.mode);
                    Object.keys(f.geometry.morphAttributes).length > 0 && it(f, i), f.name = t.createUniqueName(i.name || `mesh_` + e), X(f, i), d.extensions && Y(r, f, d), t.assignFinalMaterial(f), c.push(f)
                }
                for (let n = 0, r = c.length; n < r; n++) t.associations.set(c[n], {
                    meshes: e,
                    primitives: n
                });
                if (c.length === 1) return i.extensions && Y(r, c[0], i), c[0];
                let l = new C;
                i.extensions && Y(r, l, i), t.associations.set(l, {
                    meshes: e
                });
                for (let e = 0, t = c.length; e < t; e++) l.add(c[e]);
                return l
            })
        }
        loadCamera(e) {
            let t, n = this.json.cameras[e],
                r = n[n.type];
            if (r) return n.type === `perspective` ? t = new we(ae.radToDeg(r.yfov), r.aspectRatio || 1, r.znear || 1, r.zfar || 2e6) : n.type === `orthographic` && (t = new be(-r.xmag, r.xmag, r.ymag, -r.ymag, r.znear, r.zfar)), n.name && (t.name = this.createUniqueName(n.name)), X(t, n), Promise.resolve(t)
        }
        loadSkin(e) {
            let t = this.json.skins[e],
                n = [];
            for (let e = 0, r = t.joints.length; e < r; e++) n.push(this._loadNodeShallow(t.joints[e]));
            return t.inverseBindMatrices === void 0 ? n.push(null) : n.push(this.getDependency(`accessor`, t.inverseBindMatrices)), Promise.all(n).then(function(e) {
                let t = e.pop(),
                    n = e,
                    r = [],
                    i = [];
                for (let e = 0, a = n.length; e < a; e++) {
                    let a = n[e];
                    if (a) {
                        r.push(a);
                        let n = new x;
                        t !== null && n.fromArray(t.array, e * 16), i.push(n)
                    }
                }
                return new De(r, i)
            })
        }
        loadAnimation(e) {
            let t = this.json,
                n = this,
                r = t.animations[e],
                i = r.name ? r.name : `animation_` + e,
                a = [],
                o = [],
                s = [],
                c = [],
                l = [];
            for (let e = 0, t = r.channels.length; e < t; e++) {
                let t = r.channels[e],
                    n = r.samplers[t.sampler],
                    i = t.target,
                    u = i.node,
                    d = r.parameters === void 0 ? n.input : r.parameters[n.input],
                    f = r.parameters === void 0 ? n.output : r.parameters[n.output];
                i.node !== void 0 && (a.push(this.getDependency(`node`, u)), o.push(this.getDependency(`accessor`, d)), s.push(this.getDependency(`accessor`, f)), c.push(n), l.push(i))
            }
            return Promise.all([Promise.all(a), Promise.all(o), Promise.all(s), Promise.all(c), Promise.all(l)]).then(function(e) {
                let t = e[0],
                    a = e[1],
                    o = e[2],
                    s = e[3],
                    c = e[4],
                    l = [];
                for (let e = 0, r = t.length; e < r; e++) {
                    let r = t[e],
                        i = a[e],
                        u = o[e],
                        d = s[e],
                        f = c[e];
                    if (r === void 0) continue;
                    r.updateMatrix && r.updateMatrix();
                    let p = n._createAnimationTracks(r, i, u, d, f);
                    if (p)
                        for (let e = 0; e < p.length; e++) l.push(p[e])
                }
                let u = new me(i, void 0, l);
                return X(u, r), u
            })
        }
        createNodeMesh(e) {
            let t = this.json,
                n = this,
                r = t.nodes[e];
            return r.mesh === void 0 ? null : n.getDependency(`mesh`, r.mesh).then(function(e) {
                let t = n._getNodeRef(n.meshCache, r.mesh, e);
                return r.weights !== void 0 && t.traverse(function(e) {
                    if (e.isMesh)
                        for (let t = 0, n = r.weights.length; t < n; t++) e.morphTargetInfluences[t] = r.weights[t]
                }), t
            })
        }
        loadNode(e) {
            let t = this.json,
                n = this,
                r = t.nodes[e],
                i = n._loadNodeShallow(e),
                a = [],
                o = r.children || [];
            for (let e = 0, t = o.length; e < t; e++) a.push(n.getDependency(`node`, o[e]));
            let s = r.skin === void 0 ? Promise.resolve(null) : n.getDependency(`skin`, r.skin);
            return Promise.all([i, Promise.all(a), s]).then(function(e) {
                let t = e[0],
                    n = e[1],
                    r = e[2];
                r !== null && t.traverse(function(e) {
                    e.isSkinnedMesh && e.bind(r, st)
                });
                for (let e = 0, r = n.length; e < r; e++) t.add(n[e]);
                if (t.userData.pivot !== void 0 && n.length > 0) {
                    let e = t.userData.pivot,
                        r = n[0];
                    t.pivot = new D().fromArray(e), t.position.x -= e[0], t.position.y -= e[1], t.position.z -= e[2], r.position.set(0, 0, 0), delete t.userData.pivot
                }
                return t
            })
        }
        _loadNodeShallow(e) {
            let t = this.json,
                n = this.extensions,
                r = this;
            if (this.nodeCache[e] !== void 0) return this.nodeCache[e];
            let i = t.nodes[e],
                a = i.name ? r.createUniqueName(i.name) : ``,
                o = [],
                s = r._invokeOne(function(t) {
                    return t.createNodeMesh && t.createNodeMesh(e)
                });
            return s && o.push(s), i.camera !== void 0 && o.push(r.getDependency(`camera`, i.camera).then(function(e) {
                return r._getNodeRef(r.cameraCache, i.camera, e)
            })), r._invokeAll(function(t) {
                return t.createNodeAttachment && t.createNodeAttachment(e)
            }).forEach(function(e) {
                o.push(e)
            }), this.nodeCache[e] = Promise.all(o).then(function(t) {
                let o;
                if (o = i.isBone === !0 ? new ue : t.length > 1 ? new C : t.length === 1 ? t[0] : new O, o !== t[0])
                    for (let e = 0, n = t.length; e < n; e++) o.add(t[e]);
                if (i.name && (o.userData.name = i.name, o.name = a), X(o, i), i.extensions && Y(n, o, i), i.matrix !== void 0) {
                    let e = new x;
                    e.fromArray(i.matrix), o.applyMatrix4(e)
                } else i.translation !== void 0 && o.position.fromArray(i.translation), i.rotation !== void 0 && o.quaternion.fromArray(i.rotation), i.scale !== void 0 && o.scale.fromArray(i.scale);
                if (!r.associations.has(o)) r.associations.set(o, {});
                else if (i.mesh !== void 0 && r.meshCache.refs[i.mesh] > 1) {
                    let e = r.associations.get(o);
                    r.associations.set(o, { ...e
                    })
                }
                return r.associations.get(o).nodes = e, o
            }), this.nodeCache[e]
        }
        loadScene(e) {
            let t = this.extensions,
                n = this.json.scenes[e],
                r = this,
                i = new C;
            n.name && (i.name = r.createUniqueName(n.name)), X(i, n), n.extensions && Y(t, i, n);
            let a = n.nodes || [],
                o = [];
            for (let e = 0, t = a.length; e < t; e++) o.push(r.getDependency(`node`, a[e]));
            return Promise.all(o).then(function(e) {
                for (let t = 0, n = e.length; t < n; t++) {
                    let n = e[t];
                    n.parent === null ? i.add(n) : i.add(ke(n))
                }
                return r.associations = (e => {
                    let t = new Map;
                    for (let [e, n] of r.associations)(e instanceof d || e instanceof y) && t.set(e, n);
                    return e.traverse(e => {
                        let n = r.associations.get(e);
                        n != null && t.set(e, n)
                    }), t
                })(i), i
            })
        }
        _createAnimationTracks(e, n, r, i, a) {
            let o = [],
                s = e.name ? e.name : e.uuid,
                c = [];

            function l(e) {
                e.morphTargetInfluences && c.push(e.name ? e.name : e.uuid)
            }
            q[a.path] === q.weights ? (l(e), e.isGroup && e.children.forEach(l)) : c.push(s);
            let u;
            switch (q[a.path]) {
                case q.weights:
                    u = pe;
                    break;
                case q.rotation:
                    u = T;
                    break;
                case q.translation:
                case q.scale:
                    u = _;
                    break;
                default:
                    switch (r.itemSize) {
                        case 1:
                            u = pe;
                            break;
                        default:
                            u = _;
                            break
                    }
                    break
            }
            let d = i.interpolation === void 0 ? t : tt[i.interpolation],
                f = this._getArrayFromAccessor(r);
            for (let e = 0, t = c.length; e < t; e++) {
                let t = new u(c[e] + `.` + q[a.path], n.array, f, d);
                i.interpolation === `CUBICSPLINE` && this._createCubicSplineTrackInterpolant(t), o.push(t)
            }
            return o
        }
        _getArrayFromAccessor(e) {
            let t = e.array;
            if (e.normalized) {
                let e = Q(t.constructor),
                    n = new Float32Array(t.length);
                for (let r = 0, i = t.length; r < i; r++) n[r] = t[r] * e;
                t = n
            }
            return t
        }
        _createCubicSplineTrackInterpolant(e) {
            e.createInterpolant = function(e) {
                return new(this instanceof T ? et : B)(this.times, this.values, this.getValueSize() / 3, e)
            }, e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = !0
        }
    };

function lt(e, t, n) {
    let r = t.attributes,
        i = new xe;
    if (r.POSITION !== void 0) {
        let e = n.json.accessors[r.POSITION],
            t = e.min,
            a = e.max;
        if (t !== void 0 && a !== void 0) {
            if (i.set(new D(t[0], t[1], t[2]), new D(a[0], a[1], a[2])), e.normalized) {
                let t = Q(H[e.componentType]);
                i.min.multiplyScalar(t), i.max.multiplyScalar(t)
            }
        } else return
    } else return;
    let o = t.targets;
    if (o !== void 0) {
        let e = new D,
            t = new D;
        for (let r = 0, i = o.length; r < i; r++) {
            let i = o[r];
            if (i.POSITION !== void 0) {
                let r = n.json.accessors[i.POSITION],
                    a = r.min,
                    o = r.max;
                if (a !== void 0 && o !== void 0) {
                    if (t.setX(Math.max(Math.abs(a[0]), Math.abs(o[0]))), t.setY(Math.max(Math.abs(a[1]), Math.abs(o[1]))), t.setZ(Math.max(Math.abs(a[2]), Math.abs(o[2]))), r.normalized) {
                        let e = Q(H[r.componentType]);
                        t.multiplyScalar(e)
                    }
                    e.max(t)
                }
            }
        }
        i.expandByVector(e)
    }
    e.boundingBox = i;
    let s = new a;
    i.getCenter(s.center), s.radius = i.min.distanceTo(i.max) / 2, e.boundingSphere = s
}

function $(e, t, n) {
    let r = t.attributes,
        i = [];

    function a(t, r) {
        return n.getDependency(`accessor`, t).then(function(t) {
            e.setAttribute(r, t)
        })
    }
    for (let t in r) {
        let n = K[t] || t.toLowerCase();
        n in e.attributes || i.push(a(r[t], n))
    }
    if (t.indices !== void 0 && !e.index) {
        let r = n.getDependency(`accessor`, t.indices).then(function(t) {
            e.setIndex(t)
        });
        i.push(r)
    }
    return Ce.workingColorSpace !== `srgb-linear` && `COLOR_0` in r, X(e, t), lt(e, t, n), Promise.all(i).then(function() {
        return t.targets === void 0 ? e : rt(e, t.targets, n)
    })
}
var ut = (function() {
    var e = `b9H79Tebbbe8Fv9Gbb9Gvuuuuueu9Giuuub9Geueu9Giuuueuixkbeeeddddillviebeoweuecj:Gdkr;Neqo9TW9T9VV95dbH9F9F939H79T9F9J9H229F9Jt9VV7bb8A9TW79O9V9Wt9F9KW9J9V9KW9wWVtW949c919M9MWVbeY9TW79O9V9Wt9F9KW9J9V9KW69U9KW949c919M9MWVbdE9TW79O9V9Wt9F9KW9J9V9KW69U9KW949tWG91W9U9JWbiL9TW79O9V9Wt9F9KW9J9V9KWS9P2tWV9p9JtblK9TW79O9V9Wt9F9KW9J9V9KWS9P2tWV9r919HtbvL9TW79O9V9Wt9F9KW9J9V9KWS9P2tWVT949WboY9TW79O9V9Wt9F9KW9J9V9KWS9P2tWVJ9V29VVbrl79IV9Rbwq:VZkdbk:XYi5ud9:du8Jjjjjbcj;kb9Rgv8Kjjjjbc9:hodnalTmbcuhoaiRbbgrc;WeGc:Ge9hmbarcsGgwce0mbc9:hoalcufadcd4cbawEgDadfgrcKcaawEgqaraq0Egk6mbaicefhxcj;abad9Uc;WFbGcjdadca0EhmaialfgPar9Rgoadfhsavaoadz:jjjjbgzceVhHcbhOdndninaeaO9nmeaPax9RaD6mdamaeaO9RaOamfgoae6EgAcsfglc9WGhCabaOad2fhXaAcethQaxaDfhiaOaeaoaeao6E9RhLalcl4cifcd4hKazcj;cbfaAfhYcbh8AazcjdfhEaHh3incbh5dnawTmbaxa8Acd4fRbbh5kcbh8Eazcj;cbfhqinaih8Fdndndndna5a8Ecet4ciGgoc9:fPdebdkaPa8F9RaA6mrazcj;cbfa8EaA2fa8FaAz:jjjjb8Aa8FaAfhixdkazcj;cbfa8EaA2fcbaAz:kjjjb8Aa8FhixekaPa8F9RaK6mva8FaKfhidnaCTmbaPai9RcK6mbaocdtc:q:G:cjbfcj:G:cjbawEhaczhrcbhlinargoc9Wfghaqfhrdndndndndndnaaa8Fahco4fRbbalcoG4ciGcdtfydbPDbedvivvvlvkar9cb83bwar9cb83bbxlkarcbaiRbdai8Xbb9c:c:qj:bw9:9c:q;c1:I1e:d9c:b:c:e1z9:gg9cjjjjjz:dg8J9qE86bbaqaofgrcGfcbaicdfa8J9c8N1:NfghRbbag9cjjjjjw:dg8J9qE86bbarcVfcbaha8J9c8M1:NfghRbbag9cjjjjjl:dg8J9qE86bbarc7fcbaha8J9c8L1:NfghRbbag9cjjjjjd:dg8J9qE86bbarctfcbaha8J9c8K1:NfghRbbag9cjjjjje:dg8J9qE86bbarc91fcbaha8J9c8J1:NfghRbbag9cjjjj;ab:dg8J9qE86bbarc4fcbaha8J9cg1:NfghRbbag9cjjjja:dg8J9qE86bbarc93fcbaha8J9ch1:NfghRbbag9cjjjjz:dgg9qE86bbarc94fcbahag9ca1:NfghRbbai8Xbe9c:c:qj:bw9:9c:q;c1:I1e:d9c:b:c:e1z9:gg9cjjjjjz:dg8J9qE86bbarc95fcbaha8J9c8N1:NfgiRbbag9cjjjjjw:dg8J9qE86bbarc96fcbaia8J9c8M1:NfgiRbbag9cjjjjjl:dg8J9qE86bbarc97fcbaia8J9c8L1:NfgiRbbag9cjjjjjd:dg8J9qE86bbarc98fcbaia8J9c8K1:NfgiRbbag9cjjjjje:dg8J9qE86bbarc99fcbaia8J9c8J1:NfgiRbbag9cjjjj;ab:dg8J9qE86bbarc9:fcbaia8J9cg1:NfgiRbbag9cjjjja:dg8J9qE86bbarcufcbaia8J9ch1:NfgiRbbag9cjjjjz:dgg9qE86bbaiag9ca1:NfhixikaraiRblaiRbbghco4g8Ka8KciSg8KE86bbaqaofgrcGfaiclfa8Kfg8KRbbahcl4ciGg8La8LciSg8LE86bbarcVfa8Ka8Lfg8KRbbahcd4ciGg8La8LciSg8LE86bbarc7fa8Ka8Lfg8KRbbahciGghahciSghE86bbarctfa8Kahfg8KRbbaiRbeghco4g8La8LciSg8LE86bbarc91fa8Ka8Lfg8KRbbahcl4ciGg8La8LciSg8LE86bbarc4fa8Ka8Lfg8KRbbahcd4ciGg8La8LciSg8LE86bbarc93fa8Ka8Lfg8KRbbahciGghahciSghE86bbarc94fa8Kahfg8KRbbaiRbdghco4g8La8LciSg8LE86bbarc95fa8Ka8Lfg8KRbbahcl4ciGg8La8LciSg8LE86bbarc96fa8Ka8Lfg8KRbbahcd4ciGg8La8LciSg8LE86bbarc97fa8Ka8Lfg8KRbbahciGghahciSghE86bbarc98fa8KahfghRbbaiRbigico4g8Ka8KciSg8KE86bbarc99faha8KfghRbbaicl4ciGg8Ka8KciSg8KE86bbarc9:faha8KfghRbbaicd4ciGg8Ka8KciSg8KE86bbarcufaha8KfgrRbbaiciGgiaiciSgiE86bbaraifhixdkaraiRbwaiRbbghcl4g8Ka8KcsSg8KE86bbaqaofgrcGfaicwfa8Kfg8KRbbahcsGghahcsSghE86bbarcVfa8KahfghRbbaiRbeg8Kcl4g8La8LcsSg8LE86bbarc7faha8LfghRbba8KcsGg8Ka8KcsSg8KE86bbarctfaha8KfghRbbaiRbdg8Kcl4g8La8LcsSg8LE86bbarc91faha8LfghRbba8KcsGg8Ka8KcsSg8KE86bbarc4faha8KfghRbbaiRbig8Kcl4g8La8LcsSg8LE86bbarc93faha8LfghRbba8KcsGg8Ka8KcsSg8KE86bbarc94faha8KfghRbbaiRblg8Kcl4g8La8LcsSg8LE86bbarc95faha8LfghRbba8KcsGg8Ka8KcsSg8KE86bbarc96faha8KfghRbbaiRbvg8Kcl4g8La8LcsSg8LE86bbarc97faha8LfghRbba8KcsGg8Ka8KcsSg8KE86bbarc98faha8KfghRbbaiRbog8Kcl4g8La8LcsSg8LE86bbarc99faha8LfghRbba8KcsGg8Ka8KcsSg8KE86bbarc9:faha8KfghRbbaiRbrgicl4g8Ka8KcsSg8KE86bbarcufaha8KfgrRbbaicsGgiaicsSgiE86bbaraifhixekarai8Pbw83bwarai8Pbb83bbaiczfhikdnaoaC9pmbalcdfhlaoczfhraPai9RcL0mekkaoaC6moaimexokaCmva8FTmvkaqaAfhqa8Ecefg8Ecl9hmbkdndndndnawTmbasa8Acd4fRbbgociGPlbedrbkaATmdaza8Afh8Fazcj;cbfhhcbh8EaEhaina8FRbbhraahocbhlinaoahalfRbbgqce4cbaqceG9R7arfgr86bbaoadfhoaAalcefgl9hmbkaacefhaa8Fcefh8FahaAfhha8Ecefg8Ecl9hmbxikkaATmeaza8Afhaazcj;cbfhhcbhoceh8EaYh8FinaEaofhlaa8Vbbhrcbhoinala8FaofRbbcwtahaofRbbgqVc;:FiGce4cbaqceG9R7arfgr87bbaladfhlaLaocefgofmbka8FaQfh8FcdhoaacdfhaahaQfhha8EceGhlcbh8EalmbxdkkaATmbaocl4h8Eaza8AfRbbhqcwhoa3hlinalRbbaotaqVhqalcefhlaocwfgoca9hmbkcbhhaEh8FaYhainazcj;cbfahfRbbhrcwhoaahlinalRbbaotarVhralaAfhlaocwfgoca9hmbkara8E94aq7hqcbhoa8Fhlinalaqao486bbalcefhlaocwfgoca9hmbka8Fadfh8FaacefhaahcefghaA9hmbkkaEclfhEa3clfh3a8Aclfg8Aad6mbkaXazcjdfaAad2z:jjjjb8AazazcjdfaAcufad2fadz:jjjjb8AaAaOfhOaihxaimbkc9:hoxdkcbc99aPax9RakSEhoxekc9:hokavcj;kbf8Kjjjjbaok:ysezu8Jjjjjbc;ae9Rgv8Kjjjjbc9:hodnalaeci9UgrcHf6mbcuhoaiRbbgwc;WeGc;Ge9hmbawcsGgDce0mbavc;abfcFecjez:kjjjb8Aav9cu83iUav9cu83i8Wav9cu83iyav9cu83iaav9cu83iKav9cu83izav9cu83iwav9cu83ibaialfc9WfhqaicefgwarfhldnaeTmbcmcsaDceSEhkcbhxcbhmcbhrcbhicbhoindnalaq9nmbc9:hoxikdndnawRbbgDc;Ve0mbavc;abfaoaDcu7gPcl4fcsGcitfgsydlhzasydbhHdndnaDcsGgsak9pmbavaiaPfcsGcdtfydbaxasEhDaxasTgOfhxxekdndnascsSmbcehOasc987asamffcefhDxekalcefhDal8SbbgscFeGhPdndnascu9mmbaDhlxekalcvfhlaPcFbGhPcrhsdninaD8SbbgOcFbGastaPVhPaOcu9kmeaDcefhDascrfgsc8J9hmbxdkkaDcefhlkcehOaPce4cbaPceG9R7amfhDkaDhmkavc;abfaocitfgsaDBdbasazBdlavaicdtfaDBdbavc;abfaocefcsGcitfgsaHBdbasaDBdlaocdfhoaOaifhidnadcd9hmbabarcetfgsaH87ebasclfaD87ebascdfaz87ebxdkabarcdtfgsaHBdbascwfaDBdbasclfazBdbxekdnaDcpe0mbavaiaqaDcsGfRbbgscl4gP9RcsGcdtfydbaxcefgOaPEhDavaias9RcsGcdtfydbaOaPTgzfgOascsGgPEhsaPThPdndnadcd9hmbabarcetfgHax87ebaHclfas87ebaHcdfaD87ebxekabarcdtfgHaxBdbaHcwfasBdbaHclfaDBdbkavaicdtfaxBdbavc;abfaocitfgHaDBdbaHaxBdlavaicefgicsGcdtfaDBdbavc;abfaocefcsGcitfgHasBdbaHaDBdlavaiazfgicsGcdtfasBdbavc;abfaocdfcsGcitfgDaxBdbaDasBdlaocifhoaiaPfhiaOaPfhxxekaxcbalRbbgsEgHaDc;:eSgDfhOascsGhAdndnascl4gCmbaOcefhzxekaOhzavaiaC9RcsGcdtfydbhOkdndnaAmbazcefhxxekazhxavaias9RcsGcdtfydbhzkdndnaDTmbalcefhDxekalcdfhDal8SbegPcFeGhsdnaPcu9kmbalcofhHascFbGhscrhldninaD8SbbgPcFbGaltasVhsaPcu9kmeaDcefhDalcrfglc8J9hmbkaHhDxekaDcefhDkasce4cbasceG9R7amfgmhHkdndnaCcsSmbaDhsxekaDcefhsaD8SbbglcFeGhPdnalcu9kmbaDcvfhOaPcFbGhPcrhldninas8SbbgDcFbGaltaPVhPaDcu9kmeascefhsalcrfglc8J9hmbkaOhsxekascefhskaPce4cbaPceG9R7amfgmhOkdndnaAcsSmbashlxekascefhlas8SbbgDcFeGhPdnaDcu9kmbascvfhzaPcFbGhPcrhDdninal8SbbgscFbGaDtaPVhPascu9kmealcefhlaDcrfgDc8J9hmbkazhlxekalcefhlkaPce4cbaPceG9R7amfgmhzkdndnadcd9hmbabarcetfgDaH87ebaDclfaz87ebaDcdfaO87ebxekabarcdtfgDaHBdbaDcwfazBdbaDclfaOBdbkavc;abfaocitfgDaOBdbaDaHBdlavaicdtfaHBdbavc;abfaocefcsGcitfgDazBdbaDaOBdlavaicefgicsGcdtfaOBdbavc;abfaocdfcsGcitfgDaHBdbaDazBdlavaiaCTaCcsSVfgicsGcdtfazBdbaiaATaAcsSVfhiaocifhokawcefhwaocsGhoaicsGhiarcifgrae6mbkkcbc99alaqSEhokavc;aef8Kjjjjbaok:clevu8Jjjjjbcz9Rhvdnalaecvf9pmbc9:skdnaiRbbc;:eGc;qeSmbcuskav9cb83iwaicefhoaialfc98fhrdnaeTmbdnadcdSmbcbhwindnaoar6mbc9:skaocefhlao8SbbgicFeGhddndnaicu9mmbalhoxekaocvfhoadcFbGhdcrhidninal8SbbgDcFbGaitadVhdaDcu9kmealcefhlaicrfgic8J9hmbxdkkalcefhokabawcdtfadc8Etc8F91adcd47avcwfadceGcdtVglydbfgiBdbalaiBdbawcefgwae9hmbxdkkcbhwindnaoar6mbc9:skaocefhlao8SbbgicFeGhddndnaicu9mmbalhoxekaocvfhoadcFbGhdcrhidninal8SbbgDcFbGaitadVhdaDcu9kmealcefhlaicrfgic8J9hmbxdkkalcefhokabawcetfadc8Etc8F91adcd47avcwfadceGcdtVglydbfgi87ebalaiBdbawcefgwae9hmbkkcbc99aoarSEk:Lvoeue99dud99eud99dndnadcl9hmbaeTmeindndnabcdfgd8Sbb:Yab8Sbbgi:Ygl:l:tabcefgv8Sbbgo:Ygr:l:tgwJbb;:9cawawNJbbbbawawJbbbb9GgDEgq:mgkaqaicb9iEalMgwawNakaqaocb9iEarMgqaqNMM:r:vglNJbbbZJbbb:;aDEMgr:lJbbb9p9DTmbar:Ohixekcjjjj94hikadai86bbdndnaqalNJbbbZJbbb:;aqJbbbb9GEMgq:lJbbb9p9DTmbaq:Ohdxekcjjjj94hdkavad86bbdndnawalNJbbbZJbbb:;awJbbbb9GEMgw:lJbbb9p9DTmbaw:Ohdxekcjjjj94hdkabad86bbabclfhbaecufgembxdkkaeTmbindndnabclfgd8Ueb:Yab8Uebgi:Ygl:l:tabcdfgv8Uebgo:Ygr:l:tgwJb;:FSawawNJbbbbawawJbbbb9GgDEgq:mgkaqaicb9iEalMgwawNakaqaocb9iEarMgqaqNMM:r:vglNJbbbZJbbb:;aDEMgr:lJbbb9p9DTmbar:Ohixekcjjjj94hikadai87ebdndnaqalNJbbbZJbbb:;aqJbbbb9GEMgq:lJbbb9p9DTmbaq:Ohdxekcjjjj94hdkavad87ebdndnawalNJbbbZJbbb:;awJbbbb9GEMgw:lJbbb9p9DTmbaw:Ohdxekcjjjj94hdkabad87ebabcwfhbaecufgembkkk:4ioiue99dud99dud99dnaeTmbcbhiabhlindndnal8Uebgv:YgoJ:ji:1Salcof8UebgrciVgw:Y:vgDNJbbbZJbbb:;avcu9kEMgq:lJbbb9p9DTmbaq:Ohkxekcjjjj94hkkalclf8Uebhvalcdf8UebhxalarcefciGcetfak87ebdndnax:YgqaDNJbbbZJbbb:;axcu9kEMgm:lJbbb9p9DTmbam:Ohxxekcjjjj94hxkabaiarciGgkfcd7cetfax87ebdndnav:YgmaDNJbbbZJbbb:;avcu9kEMgP:lJbbb9p9DTmbaP:Ohvxekcjjjj94hvkalarcufciGcetfav87ebdndnawaw2:ZgPaPMaoaoN:taqaqN:tamamN:tgoJbbbbaoJbbbb9GE:raDNJbbbZMgD:lJbbb9p9DTmbaD:Ohrxekcjjjj94hrkalakcetfar87ebalcwfhlaiclfhiaecufgembkkk9mbdnadcd4ae2gdTmbinababydbgecwtcw91:Yaece91cjjj98Gcjjj;8if::NUdbabclfhbadcufgdmbkkk:Tvirud99eudndnadcl9hmbaeTmeindndnabRbbgiabcefgl8Sbbgvabcdfgo8Sbbgrf9R:YJbbuJabcifgwRbbgdce4adVgDcd4aDVgDcl4aDVgD:Z:vgqNJbbbZMgk:lJbbb9p9DTmbak:Ohxxekcjjjj94hxkaoax86bbdndnaraif:YaqNJbbbZMgk:lJbbb9p9DTmbak:Ohoxekcjjjj94hokalao86bbdndnavaifar9R:YaqNJbbbZMgk:lJbbb9p9DTmbak:Ohixekcjjjj94hikabai86bbdndnaDadcetGadceGV:ZaqNJbbbZMgq:lJbbb9p9DTmbaq:Ohdxekcjjjj94hdkawad86bbabclfhbaecufgembxdkkaeTmbindndnab8Vebgiabcdfgl8Uebgvabclfgo8Uebgrf9R:YJbFu9habcofgw8Vebgdce4adVgDcd4aDVgDcl4aDVgDcw4aDVgD:Z:vgqNJbbbZMgk:lJbbb9p9DTmbak:Ohxxekcjjjj94hxkaoax87ebdndnaraif:YaqNJbbbZMgk:lJbbb9p9DTmbak:Ohoxekcjjjj94hokalao87ebdndnavaifar9R:YaqNJbbbZMgk:lJbbb9p9DTmbak:Ohixekcjjjj94hikabai87ebdndnaDadcetGadceGV:ZaqNJbbbZMgq:lJbbb9p9DTmbaq:Ohdxekcjjjj94hdkawad87ebabcwfhbaecufgembkkk9teiucbcbyd:K:G:cjbgeabcifc98GfgbBd:K:G:cjbdndnabZbcztgd9nmbcuhiabad9RcFFifcz4nbcuSmekaehikaik;LeeeudndnaeabVciGTmbabhixekdndnadcz9pmbabhixekabhiinaiaeydbBdbaiclfaeclfydbBdbaicwfaecwfydbBdbaicxfaecxfydbBdbaeczfheaiczfhiadc9Wfgdcs0mbkkadcl6mbinaiaeydbBdbaeclfheaiclfhiadc98fgdci0mbkkdnadTmbinaiaeRbb86bbaicefhiaecefheadcufgdmbkkabk;aeedudndnabciGTmbabhixekaecFeGc:b:c:ew2hldndnadcz9pmbabhixekabhiinaialBdbaicxfalBdbaicwfalBdbaiclfalBdbaiczfhiadc9Wfgdcs0mbkkadcl6mbinaialBdbaiclfhiadc98fgdci0mbkkdnadTmbinaiae86bbaicefhiadcufgdmbkkabkk83dbcj:Gdk8Kbbbbdbbblbbbwbbbbbbbebbbdbbblbbbwbbbbc:K:Gdkl8W:qbb`,
        t = `b9H79TebbbeKl9Gbb9Gvuuuuueu9Giuuub9Geueuixkbbebeeddddilve9Weeeviebeoweuecj:Gdkr;Neqo9TW9T9VV95dbH9F9F939H79T9F9J9H229F9Jt9VV7bb8A9TW79O9V9Wt9F9KW9J9V9KW9wWVtW949c919M9MWVbdY9TW79O9V9Wt9F9KW9J9V9KW69U9KW949c919M9MWVblE9TW79O9V9Wt9F9KW9J9V9KW69U9KW949tWG91W9U9JWbvL9TW79O9V9Wt9F9KW9J9V9KWS9P2tWV9p9JtboK9TW79O9V9Wt9F9KW9J9V9KWS9P2tWV9r919HtbrL9TW79O9V9Wt9F9KW9J9V9KWS9P2tWVT949WbwY9TW79O9V9Wt9F9KW9J9V9KWS9P2tWVJ9V29VVbDl79IV9Rbqq:W9Dklbzik94evu8Jjjjjbcz9Rhbcbheincbhdcbhiinabcwfadfaicjuaead4ceGglE86bbaialfhiadcefgdcw9hmbkaeai86b:q:W:cjbaecitab8Piw83i:q:G:cjbaecefgecjd9hmbkk:JBl8Aud97dur978Jjjjjbcj;kb9Rgv8Kjjjjbc9:hodnalTmbcuhoaiRbbgrc;WeGc:Ge9hmbarcsGgwce0mbc9:hoalcufadcd4cbawEgDadfgrcKcaawEgqaraq0Egk6mbaialfgxar9RhodnadTgmmbavaoad;8qbbkaicefhPcj;abad9Uc;WFbGcjdadca0EhsdndndnadTmbaoadfhzcbhHinaeaH9nmdaxaP9RaD6miabaHad2fhOaPaDfhAasaeaH9RaHasfae6EgCcsfgocl4cifcd4hXavcj;cbfaoc9WGgQcetfhLavcj;cbfaQci2fhKavcj;cbfaQfhYcbh8Aaoc;ab6hEincbh3dnawTmbaPa8Acd4fRbbh3kcbh5avcj;cbfh8Eindndndndna3a5cet4ciGgoc9:fPdebdkaxaA9RaQ6mwdnaQTmbavcj;cbfa5aQ2faAaQ;8qbbkaAaCfhAxdkaQTmeavcj;cbfa5aQ2fcbaQ;8kbxekaxaA9RaX6moaoclVcbawEhraAaXfhocbhidnaEmbaxao9Rc;Gb6mbcbhlina8EalfhidndndndndndnaAalco4fRbbgqciGarfPDbedibledibkaipxbbbbbbbbbbbbbbbbpklbxlkaiaopbblaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLg8Fcdp:mea8FpmbzeHdOiAlCvXoQrLpxiiiiiiiiiiiiiiiip9ogapxiiiiiiiiiiiiiiiip8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbahaoclffagRb:q:W:cjbfhoxikaiaopbbwaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLpxssssssssssssssssp9ogapxssssssssssssssssp8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbahaocwffagRb:q:W:cjbfhoxdkaiaopbbbpklbaoczfhoxekaiaopbbdaoRbbghcitpbi:q:G:cjbahRb:q:W:cjbghpsaoRbeggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPpklbahaocdffagRb:q:W:cjbfhokdndndndndndnaqcd4ciGarfPDbedibledibkaiczfpxbbbbbbbbbbbbbbbbpklbxlkaiczfaopbblaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLg8Fcdp:mea8FpmbzeHdOiAlCvXoQrLpxiiiiiiiiiiiiiiiip9ogapxiiiiiiiiiiiiiiiip8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbahaoclffagRb:q:W:cjbfhoxikaiczfaopbbwaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLpxssssssssssssssssp9ogapxssssssssssssssssp8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbahaocwffagRb:q:W:cjbfhoxdkaiczfaopbbbpklbaoczfhoxekaiczfaopbbdaoRbbghcitpbi:q:G:cjbahRb:q:W:cjbghpsaoRbeggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPpklbahaocdffagRb:q:W:cjbfhokdndndndndndnaqcl4ciGarfPDbedibledibkaicafpxbbbbbbbbbbbbbbbbpklbxlkaicafaopbblaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLg8Fcdp:mea8FpmbzeHdOiAlCvXoQrLpxiiiiiiiiiiiiiiiip9ogapxiiiiiiiiiiiiiiiip8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbahaoclffagRb:q:W:cjbfhoxikaicafaopbbwaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLpxssssssssssssssssp9ogapxssssssssssssssssp8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbahaocwffagRb:q:W:cjbfhoxdkaicafaopbbbpklbaoczfhoxekaicafaopbbdaoRbbghcitpbi:q:G:cjbahRb:q:W:cjbghpsaoRbeggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPpklbahaocdffagRb:q:W:cjbfhokdndndndndndnaqco4arfPDbedibledibkaic8Wfpxbbbbbbbbbbbbbbbbpklbxlkaic8Wfaopbblaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLg8Fcdp:mea8FpmbzeHdOiAlCvXoQrLpxiiiiiiiiiiiiiiiip9ogapxiiiiiiiiiiiiiiiip8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Ngicitpbi:q:G:cjbaiRb:q:W:cjbgipsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Ngqcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbaiaoclffaqRb:q:W:cjbfhoxikaic8Wfaopbbwaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLpxssssssssssssssssp9ogapxssssssssssssssssp8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Ngicitpbi:q:G:cjbaiRb:q:W:cjbgipsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Ngqcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spklbaiaocwffaqRb:q:W:cjbfhoxdkaic8Wfaopbbbpklbaoczfhoxekaic8WfaopbbdaoRbbgicitpbi:q:G:cjbaiRb:q:W:cjbgipsaoRbegqcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPpklbaiaocdffaqRb:q:W:cjbfhokalc;abfhialcjefaQ0meaihlaxao9Rc;Fb0mbkkdnaiaQ9pmbaici4hlinaxao9RcK6mwa8EaifhqdndndndndndnaAaico4fRbbalcoG4ciGarfPDbedibledibkaqpxbbbbbbbbbbbbbbbbpkbbxlkaqaopbblaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLg8Fcdp:mea8FpmbzeHdOiAlCvXoQrLpxiiiiiiiiiiiiiiiip9ogapxiiiiiiiiiiiiiiiip8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spkbbahaoclffagRb:q:W:cjbfhoxikaqaopbbwaopbbbg8Fclp:mea8FpmbzeHdOiAlCvXoQrLpxssssssssssssssssp9ogapxssssssssssssssssp8Jg8Fp5b9cjF;8;4;W;G;ab9:9cU1:Nghcitpbi:q:G:cjbahRb:q:W:cjbghpsa8Fp5e9cjF;8;4;W;G;ab9:9cU1:Nggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPaaa8Fp9spkbbahaocwffagRb:q:W:cjbfhoxdkaqaopbbbpkbbaoczfhoxekaqaopbbdaoRbbghcitpbi:q:G:cjbahRb:q:W:cjbghpsaoRbeggcitpbi:q:G:cjbp9UpmbedilvorzHOACXQLpPpkbbahaocdffagRb:q:W:cjbfhokalcdfhlaiczfgiaQ6mbkkaohAaoTmoka8EaQfh8Ea5cefg5cl9hmbkdndndndnawTmbaza8Acd4fRbbglciGPlbedwbkaQTmdavcjdfa8Afhlava8Afpbdbh8Jcbhoinalavcj;cbfaofpblbg8KaYaofpblbg8LpmbzeHdOiAlCvXoQrLg8MaLaofpblbg8NaKaofpblbgypmbzeHdOiAlCvXoQrLg8PpmbezHdiOAlvCXorQLg8Fcep9Ta8Fpxeeeeeeeeeeeeeeeegap9op9Hp9rg8Fa8Jp9Ug8Jp9Abbbaladfgla8Ja8Fa8Fpmlvorlvorlvorlvorp9Ug8Jp9Abbbaladfgla8Ja8Fa8FpmwDqkwDqkwDqkwDqkp9Ug8Jp9Abbbaladfgla8Ja8Fa8FpmxmPsxmPsxmPsxmPsp9Ug8Jp9Abbbaladfgla8Ja8Ma8PpmwDKYqk8AExm35Ps8E8Fg8Fcep9Ta8Faap9op9Hp9rg8Fp9Ug8Jp9Abbbaladfgla8Ja8Fa8Fpmlvorlvorlvorlvorp9Ug8Jp9Abbbaladfgla8Ja8Fa8FpmwDqkwDqkwDqkwDqkp9Ug8Jp9Abbbaladfgla8Ja8Fa8FpmxmPsxmPsxmPsxmPsp9Ug8Jp9Abbbaladfgla8Ja8Ka8LpmwKDYq8AkEx3m5P8Es8Fg8Ka8NaypmwKDYq8AkEx3m5P8Es8Fg8LpmbezHdiOAlvCXorQLg8Fcep9Ta8Faap9op9Hp9rg8Fp9Ug8Jp9Abbbaladfgla8Ja8Fa8Fpmlvorlvorlvorlvorp9Ug8Jp9Abbbaladfgla8Ja8Fa8FpmwDqkwDqkwDqkwDqkp9Ug8Jp9Abbbaladfgla8Ja8Fa8FpmxmPsxmPsxmPsxmPsp9Ug8Jp9Abbbaladfgla8Ja8Ka8LpmwDKYqk8AExm35Ps8E8Fg8Fcep9Ta8Faap9op9Hp9rg8Fp9Ugap9Abbbaladfglaaa8Fa8Fpmlvorlvorlvorlvorp9Ugap9Abbbaladfglaaa8Fa8FpmwDqkwDqkwDqkwDqkp9Ugap9Abbbaladfglaaa8Fa8FpmxmPsxmPsxmPsxmPsp9Ug8Jp9AbbbaladfhlaoczfgoaQ6mbxikkaQTmeavcjdfa8Afhlava8Afpbdbh8Jcbhoinalavcj;cbfaofpblbg8KaYaofpblbg8LpmbzeHdOiAlCvXoQrLg8MaLaofpblbg8NaKaofpblbgypmbzeHdOiAlCvXoQrLg8PpmbezHdiOAlvCXorQLg8Fcep:nea8Fpxebebebebebebebebgap9op:bep9rg8Fa8Jp:oeg8Jp9Abbbaladfgla8Ja8Fa8Fpmlvorlvorlvorlvorp:oeg8Jp9Abbbaladfgla8Ja8Fa8FpmwDqkwDqkwDqkwDqkp:oeg8Jp9Abbbaladfgla8Ja8Fa8FpmxmPsxmPsxmPsxmPsp:oeg8Jp9Abbbaladfgla8Ja8Ma8PpmwDKYqk8AExm35Ps8E8Fg8Fcep:nea8Faap9op:bep9rg8Fp:oeg8Jp9Abbbaladfgla8Ja8Fa8Fpmlvorlvorlvorlvorp:oeg8Jp9Abbbaladfgla8Ja8Fa8FpmwDqkwDqkwDqkwDqkp:oeg8Jp9Abbbaladfgla8Ja8Fa8FpmxmPsxmPsxmPsxmPsp:oeg8Jp9Abbbaladfgla8Ja8Ka8LpmwKDYq8AkEx3m5P8Es8Fg8Ka8NaypmwKDYq8AkEx3m5P8Es8Fg8LpmbezHdiOAlvCXorQLg8Fcep:nea8Faap9op:bep9rg8Fp:oeg8Jp9Abbbaladfgla8Ja8Fa8Fpmlvorlvorlvorlvorp:oeg8Jp9Abbbaladfgla8Ja8Fa8FpmwDqkwDqkwDqkwDqkp:oeg8Jp9Abbbaladfgla8Ja8Fa8FpmxmPsxmPsxmPsxmPsp:oeg8Jp9Abbbaladfgla8Ja8Ka8LpmwDKYqk8AExm35Ps8E8Fg8Fcep:nea8Faap9op:bep9rg8Fp:oegap9Abbbaladfglaaa8Fa8Fpmlvorlvorlvorlvorp:oegap9Abbbaladfglaaa8Fa8FpmwDqkwDqkwDqkwDqkp:oegap9Abbbaladfglaaa8Fa8FpmxmPsxmPsxmPsxmPsp:oeg8Jp9AbbbaladfhlaoczfgoaQ6mbxdkkaQTmbcbhocbalcl4gl9Rc8FGhiavcjdfa8Afhrava8Afpbdbhainaravcj;cbfaofpblbg8JaYaofpblbg8KpmbzeHdOiAlCvXoQrLg8LaLaofpblbg8MaKaofpblbg8NpmbzeHdOiAlCvXoQrLgypmbezHdiOAlvCXorQLg8Faip:Rea8Falp:Tep9qg8Faap9rgap9Abbbaradfgraaa8Fa8Fpmlvorlvorlvorlvorp9rgap9Abbbaradfgraaa8Fa8FpmwDqkwDqkwDqkwDqkp9rgap9Abbbaradfgraaa8Fa8FpmxmPsxmPsxmPsxmPsp9rgap9Abbbaradfgraaa8LaypmwDKYqk8AExm35Ps8E8Fg8Faip:Rea8Falp:Tep9qg8Fp9rgap9Abbbaradfgraaa8Fa8Fpmlvorlvorlvorlvorp9rgap9Abbbaradfgraaa8Fa8FpmwDqkwDqkwDqkwDqkp9rgap9Abbbaradfgraaa8Fa8FpmxmPsxmPsxmPsxmPsp9rgap9Abbbaradfgraaa8Ja8KpmwKDYq8AkEx3m5P8Es8Fg8Ja8Ma8NpmwKDYq8AkEx3m5P8Es8Fg8KpmbezHdiOAlvCXorQLg8Faip:Rea8Falp:Tep9qg8Fp9rgap9Abbbaradfgraaa8Fa8Fpmlvorlvorlvorlvorp9rgap9Abbbaradfgraaa8Fa8FpmwDqkwDqkwDqkwDqkp9rgap9Abbbaradfgraaa8Fa8FpmxmPsxmPsxmPsxmPsp9rgap9Abbbaradfgraaa8Ja8KpmwDKYqk8AExm35Ps8E8Fg8Faip:Rea8Falp:Tep9qg8Fp9rgap9Abbbaradfgraaa8Fa8Fpmlvorlvorlvorlvorp9rgap9Abbbaradfgraaa8Fa8FpmwDqkwDqkwDqkwDqkp9rgap9Abbbaradfgraaa8Fa8FpmxmPsxmPsxmPsxmPsp9rgap9AbbbaradfhraoczfgoaQ6mbkka8Aclfg8Aad6mbkdnaCad2goTmbaOavcjdfao;8qbbkdnammbavavcjdfaCcufad2fad;8qbbkaCaHfhHc9:hoaAhPaAmbxlkkaeTmbaDalfhrcbhocuhlinaralaD9RglfaD6mdasaeao9Raoasfae6Eaofgoae6mbkaial9RhPkcbc99axaP9RakSEhoxekc9:hokavcj;kbf8Kjjjjbaokwbz:bjjjbkNsezu8Jjjjjbc;ae9Rgv8Kjjjjbc9:hodnalaeci9UgrcHf6mbcuhoaiRbbgwc;WeGc;Ge9hmbawcsGgDce0mbavc;abfcFecje;8kbav9cu83iUav9cu83i8Wav9cu83iyav9cu83iaav9cu83iKav9cu83izav9cu83iwav9cu83ibaialfc9WfhqaicefgwarfhldnaeTmbcmcsaDceSEhkcbhxcbhmcbhrcbhicbhoindnalaq9nmbc9:hoxikdndnawRbbgDc;Ve0mbavc;abfaoaDcu7gPcl4fcsGcitfgsydlhzasydbhHdndnaDcsGgsak9pmbavaiaPfcsGcdtfydbaxasEhDaxasTgOfhxxekdndnascsSmbcehOasc987asamffcefhDxekalcefhDal8SbbgscFeGhPdndnascu9mmbaDhlxekalcvfhlaPcFbGhPcrhsdninaD8SbbgOcFbGastaPVhPaOcu9kmeaDcefhDascrfgsc8J9hmbxdkkaDcefhlkcehOaPce4cbaPceG9R7amfhDkaDhmkavc;abfaocitfgsaDBdbasazBdlavaicdtfaDBdbavc;abfaocefcsGcitfgsaHBdbasaDBdlaocdfhoaOaifhidnadcd9hmbabarcetfgsaH87ebasclfaD87ebascdfaz87ebxdkabarcdtfgsaHBdbascwfaDBdbasclfazBdbxekdnaDcpe0mbavaiaqaDcsGfRbbgscl4gP9RcsGcdtfydbaxcefgOaPEhDavaias9RcsGcdtfydbaOaPTgzfgOascsGgPEhsaPThPdndnadcd9hmbabarcetfgHax87ebaHclfas87ebaHcdfaD87ebxekabarcdtfgHaxBdbaHcwfasBdbaHclfaDBdbkavaicdtfaxBdbavc;abfaocitfgHaDBdbaHaxBdlavaicefgicsGcdtfaDBdbavc;abfaocefcsGcitfgHasBdbaHaDBdlavaiazfgicsGcdtfasBdbavc;abfaocdfcsGcitfgDaxBdbaDasBdlaocifhoaiaPfhiaOaPfhxxekaxcbalRbbgsEgHaDc;:eSgDfhOascsGhAdndnascl4gCmbaOcefhzxekaOhzavaiaC9RcsGcdtfydbhOkdndnaAmbazcefhxxekazhxavaias9RcsGcdtfydbhzkdndnaDTmbalcefhDxekalcdfhDal8SbegPcFeGhsdnaPcu9kmbalcofhHascFbGhscrhldninaD8SbbgPcFbGaltasVhsaPcu9kmeaDcefhDalcrfglc8J9hmbkaHhDxekaDcefhDkasce4cbasceG9R7amfgmhHkdndnaCcsSmbaDhsxekaDcefhsaD8SbbglcFeGhPdnalcu9kmbaDcvfhOaPcFbGhPcrhldninas8SbbgDcFbGaltaPVhPaDcu9kmeascefhsalcrfglc8J9hmbkaOhsxekascefhskaPce4cbaPceG9R7amfgmhOkdndnaAcsSmbashlxekascefhlas8SbbgDcFeGhPdnaDcu9kmbascvfhzaPcFbGhPcrhDdninal8SbbgscFbGaDtaPVhPascu9kmealcefhlaDcrfgDc8J9hmbkazhlxekalcefhlkaPce4cbaPceG9R7amfgmhzkdndnadcd9hmbabarcetfgDaH87ebaDclfaz87ebaDcdfaO87ebxekabarcdtfgDaHBdbaDcwfazBdbaDclfaOBdbkavc;abfaocitfgDaOBdbaDaHBdlavaicdtfaHBdbavc;abfaocefcsGcitfgDazBdbaDaOBdlavaicefgicsGcdtfaOBdbavc;abfaocdfcsGcitfgDaHBdbaDazBdlavaiaCTaCcsSVfgicsGcdtfazBdbaiaATaAcsSVfhiaocifhokawcefhwaocsGhoaicsGhiarcifgrae6mbkkcbc99alaqSEhokavc;aef8Kjjjjbaok:clevu8Jjjjjbcz9Rhvdnalaecvf9pmbc9:skdnaiRbbc;:eGc;qeSmbcuskav9cb83iwaicefhoaialfc98fhrdnaeTmbdnadcdSmbcbhwindnaoar6mbc9:skaocefhlao8SbbgicFeGhddndnaicu9mmbalhoxekaocvfhoadcFbGhdcrhidninal8SbbgDcFbGaitadVhdaDcu9kmealcefhlaicrfgic8J9hmbxdkkalcefhokabawcdtfadc8Etc8F91adcd47avcwfadceGcdtVglydbfgiBdbalaiBdbawcefgwae9hmbxdkkcbhwindnaoar6mbc9:skaocefhlao8SbbgicFeGhddndnaicu9mmbalhoxekaocvfhoadcFbGhdcrhidninal8SbbgDcFbGaitadVhdaDcu9kmealcefhlaicrfgic8J9hmbxdkkalcefhokabawcetfadc8Etc8F91adcd47avcwfadceGcdtVglydbfgi87ebalaiBdbawcefgwae9hmbkkcbc99aoarSEk;Toio97eue97aec98Ghedndnadcl9hmbaeTmecbhdinababpbbbgicKp:RecKp:Sep;6eglaicwp:RecKp:Sep;6ealp;Geaiczp:RecKp:Sep;6egvp;Gep;Kep;Legopxbbbbbbbbbbbbbbbbp:2egralpxbbbjbbbjbbbjbbbjgwp9op9rp;Keglpxbb;:9cbb;:9cbb;:9cbb;:9calalp;Meaoaop;Meavaravawp9op9rp;Keglalp;Mep;Kep;Kep;Jep;Negvp;Mepxbbn0bbn0bbn0bbn0grp;KepxFbbbFbbbFbbbFbbbp9oaipxbbbFbbbFbbbFbbbFp9op9qalavp;Mearp;Kecwp:RepxbFbbbFbbbFbbbFbbp9op9qaoavp;Mearp;Keczp:RepxbbFbbbFbbbFbbbFbp9op9qpkbbabczfhbadclfgdae6mbxdkkaeTmbcbhdinabczfgDaDpbbbgipxbbbbbbFFbbbbbbFFgwp9oabpbbbgoaipmbediwDqkzHOAKY8AEgvczp:Reczp:Sep;6eglaoaipmlvorxmPsCXQL358E8FpxFubbFubbFubbFubbp9op;6eavczp:Sep;6egvp;Gealp;Gep;Kep;Legipxbbbbbbbbbbbbbbbbp:2egralpxbbbjbbbjbbbjbbbjgqp9op9rp;Keglpxb;:FSb;:FSb;:FSb;:FSalalp;Meaiaip;Meavaravaqp9op9rp;Keglalp;Mep;Kep;Kep;Jep;Negvp;Mepxbbn0bbn0bbn0bbn0grp;KepxFFbbFFbbFFbbFFbbp9oaiavp;Mearp;Keczp:Rep9qgialavp;Mearp;KepxFFbbFFbbFFbbFFbbp9oglpmwDKYqk8AExm35Ps8E8Fp9qpkbbabaoawp9oaialpmbezHdiOAlvCXorQLp9qpkbbabcafhbadclfgdae6mbkkk;2ileue97euo97dnaec98GgiTmbcbheinabcKfpx:ji:1S:ji:1S:ji:1S:ji:1SabpbbbglabczfgvpbbbgopmlvorxmPsCXQL358E8Fgrczp:Segwpxibbbibbbibbbibbbp9qp;6egDp;NegqaDaDp;MegDaDp;KealaopmbediwDqkzHOAKY8AEgDczp:Reczp:Sep;6eglalp;MeaDczp:Sep;6egoaop;Mearczp:Reczp:Sep;6egrarp;Mep;Kep;Kep;Lepxbbbbbbbbbbbbbbbbp:4ep;Jep;Mepxbbn0bbn0bbn0bbn0gDp;KepxFFbbFFbbFFbbFFbbgkp9oaqaop;MeaDp;Keczp:Rep9qgoaqalp;MeaDp;Keakp9oaqarp;MeaDp;Keczp:Rep9qgDpmwDKYqk8AExm35Ps8E8Fglp5eawclp:RegqpEi:T:j83ibavalp5baqpEd:T:j83ibabcwfaoaDpmbezHdiOAlvCXorQLgDp5eaqpEe:T:j83ibabaDp5baqpEb:T:j83ibabcafhbaeclfgeai6mbkkkuee97dnadcd4ae2c98GgeTmbcbhdinababpbbbgicwp:Recwp:Sep;6eaicep:SepxbbjFbbjFbbjFbbjFp9opxbbjZbbjZbbjZbbjZp:Uep;Mepkbbabczfhbadclfgdae6mbkkk:Sodw97euaec98Ghedndnadcl9hmbaeTmecbhdinabpxbbuJbbuJbbuJbbuJabpbbbgicKp:TeglaicYp:Tep9qgvcdp:Teavp9qgvclp:Teavp9qgop;6ep;Negvaicwp:RecKp:SegraipxFbbbFbbbFbbbFbbbgwp9ogDp:Uep;6ep;Mepxbbn0bbn0bbn0bbn0gqp;Kecwp:RepxbFbbbFbbbFbbbFbbp9oavaDarp:Xeaiczp:RecKp:Segip:Uep;6ep;Meaqp;Keawp9op9qavaDaraip:Uep:Xep;6ep;Meaqp;Keczp:RepxbbFbbbFbbbFbbbFbp9op9qavaoalcep:Rep9oalpxebbbebbbebbbebbbp9op9qp;6ep;Meaqp;KecKp:Rep9qpkbbabczfhbadclfgdae6mbxdkkaeTmbcbhdinabczfgkpxbFu9hbFu9hbFu9hbFu9habpbbbglakpbbbgrpmlvorxmPsCXQL358E8Fgvczp:TegqavcHp:Tep9qgicdp:Teaip9qgiclp:Teaip9qgicwp:Teaip9qgop;6ep;NegialarpmbediwDqkzHOAKY8AEgDpxFFbbFFbbFFbbFFbbglp9ograDczp:Segwp:Ueavczp:Reczp:SegDp:Xep;6ep;Mepxbbn0bbn0bbn0bbn0gvp;Kealp9oaiarawaDp:Uep:Xep;6ep;Meavp;Keczp:Rep9qgwaiaoaqcep:Rep9oaqpxebbbebbbebbbebbbp9op9qp;6ep;Meavp;Keczp:ReaiaDarp:Uep;6ep;Meavp;Kealp9op9qgipmwDKYqk8AExm35Ps8E8FpkbbabawaipmbezHdiOAlvCXorQLpkbbabcafhbadclfgdae6mbkkk9teiucbcbydj:G:cjbgeabcifc98GfgbBdj:G:cjbdndnabZbcztgd9nmbcuhiabad9RcFFifcz4nbcuSmekaehikaikkxebcj:Gdklz:zbb`,
        n = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 3, 2, 0, 0, 5, 3, 1, 0, 1, 12, 1, 0, 10, 22, 2, 12, 0, 65, 0, 65, 0, 65, 0, 252, 10, 0, 0, 11, 7, 0, 65, 0, 253, 15, 26, 11]),
        r = new Uint8Array([32, 0, 65, 2, 1, 106, 34, 33, 3, 128, 11, 4, 13, 64, 6, 253, 10, 7, 15, 116, 127, 5, 8, 12, 40, 16, 19, 54, 20, 9, 27, 255, 113, 17, 42, 67, 24, 23, 146, 148, 18, 14, 22, 45, 70, 69, 56, 114, 101, 21, 25, 63, 75, 136, 108, 28, 118, 29, 73, 115]);
    if (typeof WebAssembly != `object`) return {
        supported: !1
    };
    var i = WebAssembly.validate(n) ? s(t) : s(e),
        a, o = WebAssembly.instantiate(i, {}).then(function(e) {
            a = e.instance, a.exports.__wasm_call_ctors()
        });

    function s(e) {
        for (var t = new Uint8Array(e.length), n = 0; n < e.length; ++n) {
            var i = e.charCodeAt(n);
            t[n] = i > 96 ? i - 97 : i > 64 ? i - 39 : i + 4
        }
        for (var a = 0, n = 0; n < e.length; ++n) t[a++] = t[n] < 60 ? r[t[n]] : (t[n] - 60) * 64 + t[++n];
        return t.buffer.slice(0, a)
    }

    function c(e, t, n, r, i, a, o) {
        var s = e.exports.sbrk,
            c = r + 3 & -4,
            l = s(c * i),
            u = s(a.length),
            d = new Uint8Array(e.exports.memory.buffer);
        d.set(a, u);
        var f = t(l, r, i, u, a.length);
        if (f == 0 && o && o(l, c, i), n.set(d.subarray(l, l + r * i)), s(l - s(0)), f != 0) throw Error(`Malformed buffer data: ` + f)
    }
    var l = {
            NONE: ``,
            OCTAHEDRAL: `meshopt_decodeFilterOct`,
            QUATERNION: `meshopt_decodeFilterQuat`,
            EXPONENTIAL: `meshopt_decodeFilterExp`,
            COLOR: `meshopt_decodeFilterColor`
        },
        u = {
            ATTRIBUTES: `meshopt_decodeVertexBuffer`,
            TRIANGLES: `meshopt_decodeIndexBuffer`,
            INDICES: `meshopt_decodeIndexSequence`
        },
        d = [],
        f = 0;

    function p(e) {
        var t = {
            object: new Worker(e),
            pending: 0,
            requests: {}
        };
        return t.object.onmessage = function(e) {
            var n = e.data;
            t.pending -= n.count, t.requests[n.id][n.action](n.value), delete t.requests[n.id]
        }, t
    }

    function m(e) {
        for (var t = `self.ready = WebAssembly.instantiate(new Uint8Array([` + new Uint8Array(i) + `]), {}).then(function(result) { result.instance.exports.__wasm_call_ctors(); return result.instance; });self.onmessage = ` + g.name + `;` + c.toString() + g.toString(), n = new Blob([t], {
                type: `text/javascript`
            }), r = URL.createObjectURL(n), a = d.length; a < e; ++a) d[a] = p(r);
        for (var a = e; a < d.length; ++a) d[a].object.postMessage({});
        d.length = e, URL.revokeObjectURL(r)
    }

    function h(e, t, n, r, i) {
        for (var a = d[0], o = 1; o < d.length; ++o) d[o].pending < a.pending && (a = d[o]);
        return new Promise(function(o, s) {
            var c = new Uint8Array(n),
                l = ++f;
            a.pending += e, a.requests[l] = {
                resolve: o,
                reject: s
            }, a.object.postMessage({
                id: l,
                count: e,
                size: t,
                source: c,
                mode: r,
                filter: i
            }, [c.buffer])
        })
    }

    function g(e) {
        var t = e.data;
        self.ready.then(function(e) {
            if (!t.id) return self.close();
            try {
                var n = new Uint8Array(t.count * t.size);
                c(e, e.exports[t.mode], n, t.count, t.size, t.source, e.exports[t.filter]), self.postMessage({
                    id: t.id,
                    count: t.count,
                    action: `resolve`,
                    value: n
                }, [n.buffer])
            } catch (e) {
                self.postMessage({
                    id: t.id,
                    count: t.count,
                    action: `reject`,
                    value: e
                })
            }
        })
    }
    return {
        ready: o,
        supported: !0,
        useWorkers: function(e) {
            m(e)
        },
        decodeVertexBuffer: function(e, t, n, r, i) {
            c(a, a.exports.meshopt_decodeVertexBuffer, e, t, n, r, a.exports[l[i]])
        },
        decodeIndexBuffer: function(e, t, n, r) {
            c(a, a.exports.meshopt_decodeIndexBuffer, e, t, n, r)
        },
        decodeIndexSequence: function(e, t, n, r) {
            c(a, a.exports.meshopt_decodeIndexSequence, e, t, n, r)
        },
        decodeGltfBuffer: function(e, t, n, r, i, o) {
            c(a, a.exports[u[i]], e, t, n, r, a.exports[l[o]])
        },
        decodeGltfBufferAsync: function(e, t, n, r, i) {
            return d.length > 0 ? h(e, t, n, u[r], l[i]) : o.then(function() {
                var o = new Uint8Array(e * t);
                return c(a, a.exports[u[r]], o, e, t, n, a.exports[l[i]]), o
            })
        }
    }
})();
export {
    Ae as n, ut as t
};