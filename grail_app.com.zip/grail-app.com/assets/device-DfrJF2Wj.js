function e() {
    return typeof matchMedia < `u` && matchMedia(`(pointer: coarse)`).matches
}

function t() {
    return typeof location < `u` && /[?&]forceMobile=1/.test(location.search) ? !0 : typeof screen > `u` ? !1 : e() && Math.min(screen.width, screen.height) < 820
}
var n = null;

function r() {
    if (n !== null) return n;
    if (n = !1, typeof document > `u`) return !1;
    try {
        let e = document.createElement(`canvas`);
        e.width = e.height = 1;
        let t = e.getContext(`webgl`, {
            failIfMajorPerformanceCaveat: !0
        });
        if (!t) return n = !0, !0;
        let r = t.getExtension(`WEBGL_debug_renderer_info`),
            i = String(r ? t.getParameter(r.UNMASKED_RENDERER_WEBGL) : t.getParameter(t.RENDERER));
        n = /swiftshader|llvmpipe|softpipe|software|basic render|mesa offscreen/i.test(i), n || t.getExtension(`WEBGL_lose_context`) ? .loseContext()
    } catch {
        n = !1
    }
    return n
}

function i(e, n) {
    return r() ? .5 : Math.min(t() ? n : e, window.devicePixelRatio || 1)
}

function a() {
    return !t() && !r()
}

function o() {
    return typeof matchMedia == `function` && matchMedia(`(prefers-reduced-motion: reduce)`).matches
}
export {
    o as a, r as i, e as n, a as o, t as r, i as t
};