import {
    a as e
} from "./chunk-BEqpzyXh.js";
import {
    n as t,
    t as n
} from "./jsx-runtime-B4RpOl0S.js";
import {
    t as r
} from "./viewport-DYDJlLll.js";
import {
    a as i,
    o as a,
    t as o
} from "./device-DfrJF2Wj.js";
import {
    G as s,
    S as c,
    Y as l,
    b as u,
    f as d,
    jt as f,
    n as p,
    o as m,
    ot as h,
    rt as ee,
    t as te,
    u as g,
    vt as _,
    yt as v
} from "./three.module-DHIuxIYb.js";
import {
    n as y,
    t as ne
} from "./meshopt_decoder.module-CjHzRMB6.js";
var b = e(t(), 1),
    x = n(),
    S = new d(`#c79650`),
    C = 1440 / 900,
    w = 2.6,
    T = [`backOut`, `cubic`, `quint`, `expo`, `linear`, `bezier`],
    E = {
        dur: 1.1,
        offset: 5.9,
        rot: .26,
        enterScale: 2.3,
        exitScale: .2,
        overshoot: 1.9,
        ease: `expo`,
        bez: [.971, -.309, .359, 1.368]
    },
    re = {
        color: `#ffffff`,
        intensity: 20,
        distance: 7,
        pos: [2.29, -.29, 1.11]
    },
    ie = {
        color: `#9fb6ff`,
        intensity: 24.5,
        distance: 5.90679931640625,
        pos: [-1.8, .2, -1.1]
    };

function ae() {
    let e = document.createElement(`canvas`);
    e.width = 1024, e.height = 512;
    let t = e.getContext(`2d`),
        n = t.createLinearGradient(0, 0, 0, 512);
    n.addColorStop(0, `#23252b`), n.addColorStop(.5, `#0d0e10`), n.addColorStop(1, `#050506`), t.fillStyle = n, t.fillRect(0, 0, 1024, 512), n = t.createRadialGradient(360, 150, 10, 360, 150, 300), n.addColorStop(0, `#fff5e2`), n.addColorStop(.45, `#caa86e`), n.addColorStop(1, `rgba(0,0,0,0)`), t.fillStyle = n, t.fillRect(0, 0, 1024, 512), n = t.createRadialGradient(800, 200, 6, 800, 200, 190), n.addColorStop(0, `#dbe3ff`), n.addColorStop(1, `rgba(0,0,0,0)`), t.fillStyle = n, t.fillRect(0, 0, 1024, 512);
    let r = new g(e);
    return r.mapping = 303, r.colorSpace = _, r
}
var D = (e, t, n) => Math.max(t, Math.min(n, e)),
    O = e => e < .5 ? 4 * e * e * e : 1 - (-2 * e + 2) ** 3 / 2;

function k(e, t, n, r, i) {
    if (e <= 0) return 0;
    if (e >= 1) return 1;
    let a = e => 3 * (1 - e) * (1 - e) * e * t + 3 * (1 - e) * e * e * r + e * e * e,
        o = e => 3 * (1 - e) * (1 - e) * e * n + 3 * (1 - e) * e * e * i + e * e * e,
        s = 0,
        c = 1,
        l = e;
    for (let t = 0; t < 24; t++) l = (s + c) / 2, a(l) < e ? s = l : c = l;
    return o(l)
}

function A(e, t, n, r = E.bez) {
    switch (t) {
        case `linear`:
            return e;
        case `bezier`:
            return k(e, r[0], r[1], r[2], r[3]);
        case `cubic`:
            return O(e);
        case `quint`:
            return e < .5 ? 16 * e * e * e * e * e : 1 - (-2 * e + 2) ** 5 / 2;
        case `expo`:
            return e === 0 || e === 1 ? e : e < .5 ? 2 ** (20 * e - 10) / 2 : (2 - 2 ** (-20 * e + 10)) / 2;
        default:
            {
                if (e < .5) return 4 * e * e * e;
                let t = n * 1.525;
                return ((2 * e - 2) ** 2 * ((t + 1) * (2 * e - 2) + t) + 2) / 2
            }
    }
}

function j(e) {
    let t = [];
    e.traverse(e => {
        (e.isLight || e.isCamera) && t.push(e)
    }), t.forEach(e => e.removeFromParent())
}

function M(e) {
    e.traverse(e => {
        let t = e;
        t.isMesh && (t.geometry ? .dispose(), (Array.isArray(t.material) ? t.material : [t.material]).forEach(e => e ? .dispose()))
    })
}

function N({
    modelPath: e,
    baseRotY: t = 0,
    mirror: n = !1,
    dir: g = 1,
    active: _ = !0,
    tiltGain: T = .32,
    motion: k = E,
    className: N
}) {
    let P = (0, b.useRef)(null),
        F = (0, b.useRef)(t),
        I = (0, b.useRef)(n),
        L = (0, b.useRef)(g),
        R = (0, b.useRef)(_),
        z = (0, b.useRef)(T),
        B = (0, b.useRef)(k);
    (0, b.useEffect)(() => {
        B.current = k
    }, [k]), (0, b.useEffect)(() => {
        F.current = t
    }, [t]), (0, b.useEffect)(() => {
        I.current = n
    }, [n]), (0, b.useEffect)(() => {
        L.current = g
    }, [g]), (0, b.useEffect)(() => {
        R.current = _
    }, [_]), (0, b.useEffect)(() => {
        z.current = T
    }, [T]);
    let V = (0, b.useRef)(null);
    return (0, b.useEffect)(() => {
        let e = P.current,
            t = new p({
                canvas: e,
                antialias: a(),
                alpha: !0
            });
        t.setPixelRatio(o(2, 1.5)), t.setClearColor(0, 0), t.toneMapping = 7, t.toneMappingExposure = .95;
        let n = new v,
            g = new ee(34, 1, .1, 100);
        g.position.set(0, .15, 5.2), g.lookAt(0, 0, 0);
        let _ = new te(t),
            b = ae(),
            x = _.fromEquirectangular(b).texture;
        b.dispose();
        let T = e => {
            let t = new h(new d(e.color), e.intensity, e.distance, 2);
            return t.position.set(e.pos[0], e.pos[1], e.pos[2]), t
        };
        n.add(T(re), T(ie));
        let E = [],
            k = 0,
            N = new y().setMeshoptDecoder(ne);
        V.current = {
            load: e => {
                let t = ++k,
                    r = I.current,
                    i = F.current,
                    a = L.current;
                N.load(e, e => {
                    if (t !== k) {
                        M(e.scene);
                        return
                    }
                    let o = new u,
                        s = e.scene;
                    j(s);
                    let c = new m().setFromObject(s).getSize(new f),
                        l = w / Math.max(c.x, c.y, c.z || 1);
                    s.scale.set(r ? -l : l, l, l);
                    let d = new m().setFromObject(s).getCenter(new f);
                    s.position.sub(d);
                    let p = [];
                    s.traverse(e => {
                        let t = e;
                        t.isMesh && (Array.isArray(t.material) ? t.material : [t.material]).forEach(e => {
                            let t = e;
                            t ? .isMeshStandardMaterial && p.push(t)
                        })
                    });
                    let h = !p.some(e => e.map);
                    for (let e of p) e.envMap = h ? x : null, e.envMapIntensity = 1, r && (e.side = 2), h && (e.color.copy(S), e.metalness = 1, e.roughness = .3), e.needsUpdate = !0;
                    o.add(s), o.position.x = a * B.current.offset, o.scale.setScalar(B.current.enterScale), n.add(o);
                    for (let e = E.length - 1; e >= 0; e--) {
                        let t = E[e];
                        t.mode === `exit` ? (n.remove(t.group), M(t.group), E.splice(e, 1)) : (t.mode = `exit`, t.t = 0, t.dir = a)
                    }
                    E.push({
                        group: o,
                        mode: `enter`,
                        t: 0,
                        rotY: i,
                        dir: a
                    })
                }, void 0, e => {
                    if (t !== k) return;
                    let r = new u,
                        o = new s(new c(w * .42, 1), new l({
                            color: S,
                            metalness: 1,
                            roughness: .3,
                            envMap: x
                        }));
                    r.add(o), r.position.x = a * B.current.offset, r.scale.setScalar(B.current.enterScale), n.add(r);
                    for (let e = E.length - 1; e >= 0; e--) {
                        let t = E[e];
                        t.mode === `exit` ? (n.remove(t.group), M(t.group), E.splice(e, 1)) : (t.mode = `exit`, t.t = 0, t.dir = a)
                    }
                    E.push({
                        group: r,
                        mode: `enter`,
                        t: 0,
                        rotY: i,
                        dir: a
                    })
                })
            }
        };
        let H = {
                x: 0,
                y: 0,
                active: !1
            },
            U = t => {
                let n = e.getBoundingClientRect();
                !n.width || !n.height || (H.x = (t.clientX - n.left) / n.width * 2 - 1, H.y = -((t.clientY - n.top) / n.height * 2 - 1), H.active = t.clientX >= n.left && t.clientX <= n.right && t.clientY >= n.top && t.clientY <= n.bottom)
            },
            W = () => {
                H.active = !1
            };
        window.addEventListener(`pointermove`, U), window.addEventListener(`pointerleave`, W);
        let G = () => {
            let n = e.clientWidth,
                r = e.clientHeight;
            !n || !r || (t.setSize(n, r, !1), g.aspect = n / r, g.zoom = Math.min(1, n / r / C), g.updateProjectionMatrix())
        };
        G();
        let K = r(G),
            q = 0,
            J = !0,
            Y = 0,
            X = 0,
            Z = performance.now() / 1e3,
            Q = i(),
            $ = () => {
                if (!J) return;
                let e = performance.now() / 1e3,
                    r = Math.min(.05, e - Z);
                if (Z = e, !R.current) {
                    q = requestAnimationFrame($);
                    return
                }
                let i = H.active && !Q ? z.current : 0,
                    a = D(H.x * i, -.5, .5),
                    o = D(-H.y * i, -.4, .4),
                    s = Math.min(1, r * 4);
                X += (a - X) * s, Y += (o - Y) * s;
                let c = Q ? 0 : Math.sin(e * .6) * .07,
                    l = Q ? 0 : Math.sin(e * .45) * .06,
                    u = Q ? 0 : Math.sin(e * .5 + 1.3) * .025,
                    d = B.current;
                for (let e = E.length - 1; e >= 0; e--) {
                    let t = E[e],
                        i = 0;
                    if (t.mode !== `idle` && (t.t = Math.min(1, t.t + r / d.dur)), t.mode === `enter`) {
                        let e = A(t.t, d.ease, d.overshoot, d.bez),
                            n = O(t.t);
                        t.group.position.x = t.dir * d.offset * (1 - e), t.group.scale.setScalar(d.enterScale - (d.enterScale - 1) * n), i = t.dir * d.rot * (1 - n), t.t >= 1 && (t.mode = `idle`)
                    } else if (t.mode === `exit`) {
                        let r = A(t.t, d.ease, d.overshoot, d.bez),
                            a = O(t.t);
                        if (t.group.position.x = -t.dir * d.offset * r, t.group.scale.setScalar(1 - (1 - d.exitScale) * a), i = -t.dir * d.rot * a, t.t >= 1) {
                            n.remove(t.group), M(t.group), E.splice(e, 1);
                            continue
                        }
                    } else t.group.position.x = 0, t.group.scale.setScalar(1);
                    t.group.position.y = c, t.group.rotation.set(Y, t.rotY + X + i + l, u)
                }
                t.render(n, g), q = requestAnimationFrame($)
            };
        return q = requestAnimationFrame($), () => {
            J = !1, cancelAnimationFrame(q), window.removeEventListener(`pointermove`, U), window.removeEventListener(`pointerleave`, W), K();
            for (let e of E) M(e.group);
            x.dispose(), _.dispose(), t.dispose()
        }
    }, []), (0, b.useEffect)(() => {
        V.current ? .load(e)
    }, [e]), (0, x.jsx)(`canvas`, {
        ref: P,
        className: N,
        "aria-hidden": !0
    })
}
export {
    T as EASES, E as TOTEM_MOTION, N as TotemStage, A as slidePos
};