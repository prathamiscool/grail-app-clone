const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/LandingPage-CTc69vQU.js", "assets/chunk-BEqpzyXh.js", "assets/supabase-ne8yL6rH.js", "assets/useQuizScoring-ncRVLOCD.js", "assets/animations-o_7QUgnV.js", "assets/jsx-runtime-B4RpOl0S.js", "assets/questions-T987a5CK.js", "assets/stats-oN4uzy8W.js", "assets/analytics-CTl5M4iv.js", "assets/preload-helper-rov5CBGT.js", "assets/LandingPage-BJZjf0PY.css", "assets/AdminPage-jFGRsJNv.js", "assets/AdminPage-BwX-4mjO.css", "assets/QuestPreviewPage-DsyUOMYq.js", "assets/chunk-QFMPRPBF-DfRS6Yst.js", "assets/QuestPreviewPage-D7I_vr-8.css", "assets/VinePage-DRdU3128.js", "assets/vineGarden-CW1PICZE.js", "assets/VinePage-BlgmFZI1.css", "assets/VineGardenPage-DThsOHDb.js", "assets/VoiceGarden-B9VM_bVK.js", "assets/viewport-DYDJlLll.js", "assets/VineGardenPage-BcjtD_OU.css", "assets/TotemLabPage-BVmcCZ5j.js", "assets/three.module-DHIuxIYb.js", "assets/meshopt_decoder.module-CjHzRMB6.js", "assets/totems-6Ag_iF3F.js", "assets/device-DfrJF2Wj.js", "assets/TotemLabPage.module-C5BOdBEu.js", "assets/TotemLabPage-L-ycAzFZ.css", "assets/TotemMotionLabPage-fR4PRscq.js", "assets/TotemStage-K55W8ci8.js", "assets/LegalPage-CJ5YXgPP.js", "assets/LegalPage-CIJXVgBV.css", "assets/LightLabPage-DXIfYTrs.js", "assets/LightLabPage-BTmHSbeQ.css", "assets/WarpPage-CSnFt4vc.js", "assets/warpFill-CfnOsA5y.js", "assets/WarpPage-C0THLjrk.css", "assets/SpiralPage-DMepWIBc.js", "assets/quests-CQ2WangE.js", "assets/SpiralPage-Bv3Esskb.css", "assets/LoaderLabPage-gJopzEng.js", "assets/HomePage-SelUD7Yz.js", "assets/HomePage-B7z74ohK.css", "assets/LoaderLabPage-Ce2y-gDp.css", "assets/App-DWONLjzX.js", "assets/App-bFKQRKWI.css"]))) => i.map(i => d[i]);
import {
    a as e,
    t
} from "./chunk-BEqpzyXh.js";
import {
    n,
    t as r
} from "./jsx-runtime-B4RpOl0S.js";
import {
    a as i,
    c as a,
    l as o,
    o as s,
    s as c,
    t as l
} from "./HomePage-SelUD7Yz.js";
import {
    t as u
} from "./preload-helper-rov5CBGT.js";
import {
    i as d,
    r as f,
    t as p
} from "./chunk-QFMPRPBF-DfRS6Yst.js";
import {
    n as m
} from "./analytics-CTl5M4iv.js";
(function() {
    let e = document.createElement(`link`).relList;
    if (e && e.supports && e.supports(`modulepreload`)) return;
    for (let e of document.querySelectorAll(`link[rel="modulepreload"]`)) n(e);
    new MutationObserver(e => {
        for (let t of e)
            if (t.type === `childList`)
                for (let e of t.addedNodes) e.tagName === `LINK` && e.rel === `modulepreload` && n(e)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function t(e) {
        let t = {};
        return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), e.crossOrigin === `use-credentials` ? t.credentials = `include` : e.crossOrigin === `anonymous` ? t.credentials = `omit` : t.credentials = `same-origin`, t
    }

    function n(e) {
        if (e.ep) return;
        e.ep = !0;
        let n = t(e);
        fetch(e.href, n)
    }
})();
var h = t((e => {
        function t(e, t) {
            var n = e.length;
            e.push(t);
            a: for (; 0 < n;) {
                var r = n - 1 >>> 1,
                    a = e[r];
                if (0 < i(a, t)) e[r] = t, e[n] = a, n = r;
                else break a
            }
        }

        function n(e) {
            return e.length === 0 ? null : e[0]
        }

        function r(e) {
            if (e.length === 0) return null;
            var t = e[0],
                n = e.pop();
            if (n !== t) {
                e[0] = n;
                a: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
                    var s = 2 * (r + 1) - 1,
                        c = e[s],
                        l = s + 1,
                        u = e[l];
                    if (0 > i(c, n)) l < a && 0 > i(u, c) ? (e[r] = u, e[l] = n, r = l) : (e[r] = c, e[s] = n, r = s);
                    else if (l < a && 0 > i(u, n)) e[r] = u, e[l] = n, r = l;
                    else break a
                }
            }
            return t
        }

        function i(e, t) {
            var n = e.sortIndex - t.sortIndex;
            return n === 0 ? e.id - t.id : n
        }
        if (e.unstable_now = void 0, typeof performance == `object` && typeof performance.now == `function`) {
            var a = performance;
            e.unstable_now = function() {
                return a.now()
            }
        } else {
            var o = Date,
                s = o.now();
            e.unstable_now = function() {
                return o.now() - s
            }
        }
        var c = [],
            l = [],
            u = 1,
            d = null,
            f = 3,
            p = !1,
            m = !1,
            h = !1,
            g = !1,
            _ = typeof setTimeout == `function` ? setTimeout : null,
            v = typeof clearTimeout == `function` ? clearTimeout : null,
            y = typeof setImmediate < `u` ? setImmediate : null;

        function b(e) {
            for (var i = n(l); i !== null;) {
                if (i.callback === null) r(l);
                else if (i.startTime <= e) r(l), i.sortIndex = i.expirationTime, t(c, i);
                else break;
                i = n(l)
            }
        }

        function x(e) {
            if (h = !1, b(e), !m)
                if (n(c) !== null) m = !0, ee || (ee = !0, S());
                else {
                    var t = n(l);
                    t !== null && se(x, t.startTime - e)
                }
        }
        var ee = !1,
            te = -1,
            ne = 5,
            re = -1;

        function ie() {
            return g ? !0 : !(e.unstable_now() - re < ne)
        }

        function ae() {
            if (g = !1, ee) {
                var t = e.unstable_now();
                re = t;
                var i = !0;
                try {
                    a: {
                        m = !1,
                        h && (h = !1, v(te), te = -1),
                        p = !0;
                        var a = f;
                        try {
                            b: {
                                for (b(t), d = n(c); d !== null && !(d.expirationTime > t && ie());) {
                                    var o = d.callback;
                                    if (typeof o == `function`) {
                                        d.callback = null, f = d.priorityLevel;
                                        var s = o(d.expirationTime <= t);
                                        if (t = e.unstable_now(), typeof s == `function`) {
                                            d.callback = s, b(t), i = !0;
                                            break b
                                        }
                                        d === n(c) && r(c), b(t)
                                    } else r(c);
                                    d = n(c)
                                }
                                if (d !== null) i = !0;
                                else {
                                    var u = n(l);
                                    u !== null && se(x, u.startTime - t), i = !1
                                }
                            }
                            break a
                        }
                        finally {
                            d = null, f = a, p = !1
                        }
                        i = void 0
                    }
                }
                finally {
                    i ? S() : ee = !1
                }
            }
        }
        var S;
        if (typeof y == `function`) S = function() {
            y(ae)
        };
        else if (typeof MessageChannel < `u`) {
            var C = new MessageChannel,
                oe = C.port2;
            C.port1.onmessage = ae, S = function() {
                oe.postMessage(null)
            }
        } else S = function() {
            _(ae, 0)
        };

        function se(t, n) {
            te = _(function() {
                t(e.unstable_now())
            }, n)
        }
        e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(e) {
            e.callback = null
        }, e.unstable_forceFrameRate = function(e) {
            0 > e || 125 < e || (ne = 0 < e ? Math.floor(1e3 / e) : 5)
        }, e.unstable_getCurrentPriorityLevel = function() {
            return f
        }, e.unstable_next = function(e) {
            switch (f) {
                case 1:
                case 2:
                case 3:
                    var t = 3;
                    break;
                default:
                    t = f
            }
            var n = f;
            f = t;
            try {
                return e()
            } finally {
                f = n
            }
        }, e.unstable_requestPaint = function() {
            g = !0
        }, e.unstable_runWithPriority = function(e, t) {
            switch (e) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                default:
                    e = 3
            }
            var n = f;
            f = e;
            try {
                return t()
            } finally {
                f = n
            }
        }, e.unstable_scheduleCallback = function(r, i, a) {
            var o = e.unstable_now();
            switch (typeof a == `object` && a ? (a = a.delay, a = typeof a == `number` && 0 < a ? o + a : o) : a = o, r) {
                case 1:
                    var s = -1;
                    break;
                case 2:
                    s = 250;
                    break;
                case 5:
                    s = 1073741823;
                    break;
                case 4:
                    s = 1e4;
                    break;
                default:
                    s = 5e3
            }
            return s = a + s, r = {
                id: u++,
                callback: i,
                priorityLevel: r,
                startTime: a,
                expirationTime: s,
                sortIndex: -1
            }, a > o ? (r.sortIndex = a, t(l, r), n(c) === null && r === n(l) && (h ? (v(te), te = -1) : h = !0, se(x, a - o))) : (r.sortIndex = s, t(c, r), m || p || (m = !0, ee || (ee = !0, S()))), r
        }, e.unstable_shouldYield = ie, e.unstable_wrapCallback = function(e) {
            var t = f;
            return function() {
                var n = f;
                f = t;
                try {
                    return e.apply(this, arguments)
                } finally {
                    f = n
                }
            }
        }
    })),
    g = t(((e, t) => {
        t.exports = h()
    })),
    _ = t((e => {
        var t = g(),
            r = n(),
            i = o();

        function a(e) {
            var t = `https://react.dev/errors/` + e;
            if (1 < arguments.length) {
                t += `?args[]=` + encodeURIComponent(arguments[1]);
                for (var n = 2; n < arguments.length; n++) t += `&args[]=` + encodeURIComponent(arguments[n])
            }
            return `Minified React error #` + e + `; visit ` + t + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
        }

        function s(e) {
            return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
        }

        function c(e) {
            var t = e,
                n = e;
            if (e.alternate)
                for (; t.return;) t = t.return;
            else {
                e = t;
                do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
            }
            return t.tag === 3 ? n : null
        }

        function l(e) {
            if (e.tag === 13) {
                var t = e.memoizedState;
                if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
            }
            return null
        }

        function u(e) {
            if (e.tag === 31) {
                var t = e.memoizedState;
                if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
            }
            return null
        }

        function d(e) {
            if (c(e) !== e) throw Error(a(188))
        }

        function f(e) {
            var t = e.alternate;
            if (!t) {
                if (t = c(e), t === null) throw Error(a(188));
                return t === e ? e : null
            }
            for (var n = e, r = t;;) {
                var i = n.return;
                if (i === null) break;
                var o = i.alternate;
                if (o === null) {
                    if (r = i.return, r !== null) {
                        n = r;
                        continue
                    }
                    break
                }
                if (i.child === o.child) {
                    for (o = i.child; o;) {
                        if (o === n) return d(i), e;
                        if (o === r) return d(i), t;
                        o = o.sibling
                    }
                    throw Error(a(188))
                }
                if (n.return !== r.return) n = i, r = o;
                else {
                    for (var s = !1, l = i.child; l;) {
                        if (l === n) {
                            s = !0, n = i, r = o;
                            break
                        }
                        if (l === r) {
                            s = !0, r = i, n = o;
                            break
                        }
                        l = l.sibling
                    }
                    if (!s) {
                        for (l = o.child; l;) {
                            if (l === n) {
                                s = !0, n = o, r = i;
                                break
                            }
                            if (l === r) {
                                s = !0, r = o, n = i;
                                break
                            }
                            l = l.sibling
                        }
                        if (!s) throw Error(a(189))
                    }
                }
                if (n.alternate !== r) throw Error(a(190))
            }
            if (n.tag !== 3) throw Error(a(188));
            return n.stateNode.current === n ? e : t
        }

        function p(e) {
            var t = e.tag;
            if (t === 5 || t === 26 || t === 27 || t === 6) return e;
            for (e = e.child; e !== null;) {
                if (t = p(e), t !== null) return t;
                e = e.sibling
            }
            return null
        }
        var m = Object.assign,
            h = Symbol.for(`react.element`),
            _ = Symbol.for(`react.transitional.element`),
            v = Symbol.for(`react.portal`),
            y = Symbol.for(`react.fragment`),
            b = Symbol.for(`react.strict_mode`),
            x = Symbol.for(`react.profiler`),
            ee = Symbol.for(`react.consumer`),
            te = Symbol.for(`react.context`),
            ne = Symbol.for(`react.forward_ref`),
            re = Symbol.for(`react.suspense`),
            ie = Symbol.for(`react.suspense_list`),
            ae = Symbol.for(`react.memo`),
            S = Symbol.for(`react.lazy`),
            C = Symbol.for(`react.activity`),
            oe = Symbol.for(`react.memo_cache_sentinel`),
            se = Symbol.iterator;

        function ce(e) {
            return typeof e != `object` || !e ? null : (e = se && e[se] || e[`@@iterator`], typeof e == `function` ? e : null)
        }
        var le = Symbol.for(`react.client.reference`);

        function ue(e) {
            if (e == null) return null;
            if (typeof e == `function`) return e.$$typeof === le ? null : e.displayName || e.name || null;
            if (typeof e == `string`) return e;
            switch (e) {
                case y:
                    return `Fragment`;
                case x:
                    return `Profiler`;
                case b:
                    return `StrictMode`;
                case re:
                    return `Suspense`;
                case ie:
                    return `SuspenseList`;
                case C:
                    return `Activity`
            }
            if (typeof e == `object`) switch (e.$$typeof) {
                case v:
                    return `Portal`;
                case te:
                    return e.displayName || `Context`;
                case ee:
                    return (e._context.displayName || `Context`) + `.Consumer`;
                case ne:
                    var t = e.render;
                    return e = e.displayName, e || = (e = t.displayName || t.name || ``, e === `` ? `ForwardRef` : `ForwardRef(` + e + `)`), e;
                case ae:
                    return t = e.displayName || null, t === null ? ue(e.type) || `Memo` : t;
                case S:
                    t = e._payload, e = e._init;
                    try {
                        return ue(e(t))
                    } catch {}
            }
            return null
        }
        var de = Array.isArray,
            w = r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
            T = i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
            fe = {
                pending: !1,
                data: null,
                method: null,
                action: null
            },
            pe = [],
            me = -1;

        function he(e) {
            return {
                current: e
            }
        }

        function E(e) {
            0 > me || (e.current = pe[me], pe[me] = null, me--)
        }

        function D(e, t) {
            me++, pe[me] = e.current, e.current = t
        }
        var ge = he(null),
            _e = he(null),
            ve = he(null),
            ye = he(null);

        function be(e, t) {
            switch (D(ve, t), D(_e, e), D(ge, null), t.nodeType) {
                case 9:
                case 11:
                    e = (e = t.documentElement) && (e = e.namespaceURI) ? Vd(e) : 0;
                    break;
                default:
                    if (e = t.tagName, t = t.namespaceURI) t = Vd(t), e = Hd(t, e);
                    else switch (e) {
                        case `svg`:
                            e = 1;
                            break;
                        case `math`:
                            e = 2;
                            break;
                        default:
                            e = 0
                    }
            }
            E(ge), D(ge, e)
        }

        function xe() {
            E(ge), E(_e), E(ve)
        }

        function Se(e) {
            e.memoizedState !== null && D(ye, e);
            var t = ge.current,
                n = Hd(t, e.type);
            t !== n && (D(_e, e), D(ge, n))
        }

        function Ce(e) {
            _e.current === e && (E(ge), E(_e)), ye.current === e && (E(ye), Qf._currentValue = fe)
        }
        var we, Te;

        function Ee(e) {
            if (we === void 0) try {
                throw Error()
            } catch (e) {
                var t = e.stack.trim().match(/\n( *(at )?)/);
                we = t && t[1] || ``, Te = -1 < e.stack.indexOf(`
    at`) ? ` (<anonymous>)` : -1 < e.stack.indexOf(`@`) ? `@unknown:0:0` : ``
            }
            return `
` + we + e + Te
        }
        var De = !1;

        function Oe(e, t) {
            if (!e || De) return ``;
            De = !0;
            var n = Error.prepareStackTrace;
            Error.prepareStackTrace = void 0;
            try {
                var r = {
                    DetermineComponentFrameRoot: function() {
                        try {
                            if (t) {
                                var n = function() {
                                    throw Error()
                                };
                                if (Object.defineProperty(n.prototype, `props`, {
                                        set: function() {
                                            throw Error()
                                        }
                                    }), typeof Reflect == `object` && Reflect.construct) {
                                    try {
                                        Reflect.construct(n, [])
                                    } catch (e) {
                                        var r = e
                                    }
                                    Reflect.construct(e, [], n)
                                } else {
                                    try {
                                        n.call()
                                    } catch (e) {
                                        r = e
                                    }
                                    e.call(n.prototype)
                                }
                            } else {
                                try {
                                    throw Error()
                                } catch (e) {
                                    r = e
                                }(n = e()) && typeof n.catch == `function` && n.catch(function() {})
                            }
                        } catch (e) {
                            if (e && r && typeof e.stack == `string`) return [e.stack, r.stack]
                        }
                        return [null, null]
                    }
                };
                r.DetermineComponentFrameRoot.displayName = `DetermineComponentFrameRoot`;
                var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, `name`);
                i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, `name`, {
                    value: `DetermineComponentFrameRoot`
                });
                var a = r.DetermineComponentFrameRoot(),
                    o = a[0],
                    s = a[1];
                if (o && s) {
                    var c = o.split(`
`),
                        l = s.split(`
`);
                    for (i = r = 0; r < c.length && !c[r].includes(`DetermineComponentFrameRoot`);) r++;
                    for (; i < l.length && !l[i].includes(`DetermineComponentFrameRoot`);) i++;
                    if (r === c.length || i === l.length)
                        for (r = c.length - 1, i = l.length - 1; 1 <= r && 0 <= i && c[r] !== l[i];) i--;
                    for (; 1 <= r && 0 <= i; r--, i--)
                        if (c[r] !== l[i]) {
                            if (r !== 1 || i !== 1)
                                do
                                    if (r--, i--, 0 > i || c[r] !== l[i]) {
                                        var u = `
` + c[r].replace(` at new `, ` at `);
                                        return e.displayName && u.includes(`<anonymous>`) && (u = u.replace(`<anonymous>`, e.displayName)), u
                                    }
                            while (1 <= r && 0 <= i);
                            break
                        }
                }
            } finally {
                De = !1, Error.prepareStackTrace = n
            }
            return (n = e ? e.displayName || e.name : ``) ? Ee(n) : ``
        }

        function ke(e, t) {
            switch (e.tag) {
                case 26:
                case 27:
                case 5:
                    return Ee(e.type);
                case 16:
                    return Ee(`Lazy`);
                case 13:
                    return e.child !== t && t !== null ? Ee(`Suspense Fallback`) : Ee(`Suspense`);
                case 19:
                    return Ee(`SuspenseList`);
                case 0:
                case 15:
                    return Oe(e.type, !1);
                case 11:
                    return Oe(e.type.render, !1);
                case 1:
                    return Oe(e.type, !0);
                case 31:
                    return Ee(`Activity`);
                default:
                    return ``
            }
        }

        function Ae(e) {
            try {
                var t = ``,
                    n = null;
                do t += ke(e, n), n = e, e = e.return; while (e);
                return t
            } catch (e) {
                return `
Error generating stack: ` + e.message + `
` + e.stack
            }
        }
        var je = Object.prototype.hasOwnProperty,
            Me = t.unstable_scheduleCallback,
            Ne = t.unstable_cancelCallback,
            Pe = t.unstable_shouldYield,
            Fe = t.unstable_requestPaint,
            Ie = t.unstable_now,
            Le = t.unstable_getCurrentPriorityLevel,
            Re = t.unstable_ImmediatePriority,
            ze = t.unstable_UserBlockingPriority,
            Be = t.unstable_NormalPriority,
            Ve = t.unstable_LowPriority,
            He = t.unstable_IdlePriority,
            Ue = t.log,
            We = t.unstable_setDisableYieldValue,
            Ge = null,
            Ke = null;

        function qe(e) {
            if (typeof Ue == `function` && We(e), Ke && typeof Ke.setStrictMode == `function`) try {
                Ke.setStrictMode(Ge, e)
            } catch {}
        }
        var Je = Math.clz32 ? Math.clz32 : Ze,
            Ye = Math.log,
            Xe = Math.LN2;

        function Ze(e) {
            return e >>>= 0, e === 0 ? 32 : 31 - (Ye(e) / Xe | 0) | 0
        }
        var Qe = 256,
            $e = 262144,
            et = 4194304;

        function tt(e) {
            var t = e & 42;
            if (t !== 0) return t;
            switch (e & -e) {
                case 1:
                    return 1;
                case 2:
                    return 2;
                case 4:
                    return 4;
                case 8:
                    return 8;
                case 16:
                    return 16;
                case 32:
                    return 32;
                case 64:
                    return 64;
                case 128:
                    return 128;
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                    return e & 261888;
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                    return e & 3932160;
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    return e & 62914560;
                case 67108864:
                    return 67108864;
                case 134217728:
                    return 134217728;
                case 268435456:
                    return 268435456;
                case 536870912:
                    return 536870912;
                case 1073741824:
                    return 0;
                default:
                    return e
            }
        }

        function nt(e, t, n) {
            var r = e.pendingLanes;
            if (r === 0) return 0;
            var i = 0,
                a = e.suspendedLanes,
                o = e.pingedLanes;
            e = e.warmLanes;
            var s = r & 134217727;
            return s === 0 ? (s = r & ~a, s === 0 ? o === 0 ? n || (n = r & ~e, n !== 0 && (i = tt(n))) : i = tt(o) : i = tt(s)) : (r = s & ~a, r === 0 ? (o &= s, o === 0 ? n || (n = s & ~e, n !== 0 && (i = tt(n))) : i = tt(o)) : i = tt(r)), i === 0 ? 0 : t !== 0 && t !== i && (t & a) === 0 && (a = i & -i, n = t & -t, a >= n || a === 32 && n & 4194048) ? t : i
        }

        function rt(e, t) {
            return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0
        }

        function it(e, t) {
            switch (e) {
                case 1:
                case 2:
                case 4:
                case 8:
                case 64:
                    return t + 250;
                case 16:
                case 32:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                    return t + 5e3;
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    return -1;
                case 67108864:
                case 134217728:
                case 268435456:
                case 536870912:
                case 1073741824:
                    return -1;
                default:
                    return -1
            }
        }

        function at() {
            var e = et;
            return et <<= 1, !(et & 62914560) && (et = 4194304), e
        }

        function ot(e) {
            for (var t = [], n = 0; 31 > n; n++) t.push(e);
            return t
        }

        function st(e, t) {
            e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0)
        }

        function ct(e, t, n, r, i, a) {
            var o = e.pendingLanes;
            e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
            var s = e.entanglements,
                c = e.expirationTimes,
                l = e.hiddenUpdates;
            for (n = o & ~n; 0 < n;) {
                var u = 31 - Je(n),
                    d = 1 << u;
                s[u] = 0, c[u] = -1;
                var f = l[u];
                if (f !== null)
                    for (l[u] = null, u = 0; u < f.length; u++) {
                        var p = f[u];
                        p !== null && (p.lane &= -536870913)
                    }
                n &= ~d
            }
            r !== 0 && lt(e, r, 0), a !== 0 && i === 0 && e.tag !== 0 && (e.suspendedLanes |= a & ~(o & ~t))
        }

        function lt(e, t, n) {
            e.pendingLanes |= t, e.suspendedLanes &= ~t;
            var r = 31 - Je(t);
            e.entangledLanes |= t, e.entanglements[r] = e.entanglements[r] | 1073741824 | n & 261930
        }

        function ut(e, t) {
            var n = e.entangledLanes |= t;
            for (e = e.entanglements; n;) {
                var r = 31 - Je(n),
                    i = 1 << r;
                i & t | e[r] & t && (e[r] |= t), n &= ~i
            }
        }

        function dt(e, t) {
            var n = t & -t;
            return n = n & 42 ? 1 : ft(n), (n & (e.suspendedLanes | t)) === 0 ? n : 0
        }

        function ft(e) {
            switch (e) {
                case 2:
                    e = 1;
                    break;
                case 8:
                    e = 4;
                    break;
                case 32:
                    e = 16;
                    break;
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    e = 128;
                    break;
                case 268435456:
                    e = 134217728;
                    break;
                default:
                    e = 0
            }
            return e
        }

        function pt(e) {
            return e &= -e, 2 < e ? 8 < e ? e & 134217727 ? 32 : 268435456 : 8 : 2
        }

        function mt() {
            var e = T.p;
            return e === 0 ? (e = window.event, e === void 0 ? 32 : mp(e.type)) : e
        }

        function ht(e, t) {
            var n = T.p;
            try {
                return T.p = e, t()
            } finally {
                T.p = n
            }
        }
        var gt = Math.random().toString(36).slice(2),
            _t = `__reactFiber$` + gt,
            vt = `__reactProps$` + gt,
            yt = `__reactContainer$` + gt,
            bt = `__reactEvents$` + gt,
            xt = `__reactListeners$` + gt,
            St = `__reactHandles$` + gt,
            Ct = `__reactResources$` + gt,
            wt = `__reactMarker$` + gt;

        function Tt(e) {
            delete e[_t], delete e[vt], delete e[bt], delete e[xt], delete e[St]
        }

        function Et(e) {
            var t = e[_t];
            if (t) return t;
            for (var n = e.parentNode; n;) {
                if (t = n[yt] || n[_t]) {
                    if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                        for (e = df(e); e !== null;) {
                            if (n = e[_t]) return n;
                            e = df(e)
                        }
                    return t
                }
                e = n, n = e.parentNode
            }
            return null
        }

        function Dt(e) {
            if (e = e[_t] || e[yt]) {
                var t = e.tag;
                if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3) return e
            }
            return null
        }

        function Ot(e) {
            var t = e.tag;
            if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
            throw Error(a(33))
        }

        function kt(e) {
            var t = e[Ct];
            return t || = e[Ct] = {
                hoistableStyles: new Map,
                hoistableScripts: new Map
            }, t
        }

        function O(e) {
            e[wt] = !0
        }
        var At = new Set,
            jt = {};

        function Mt(e, t) {
            Nt(e, t), Nt(e + `Capture`, t)
        }

        function Nt(e, t) {
            for (jt[e] = t, e = 0; e < t.length; e++) At.add(t[e])
        }
        var Pt = RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),
            Ft = {},
            It = {};

        function Lt(e) {
            return je.call(It, e) ? !0 : je.call(Ft, e) ? !1 : Pt.test(e) ? It[e] = !0 : (Ft[e] = !0, !1)
        }

        function Rt(e, t, n) {
            if (Lt(t))
                if (n === null) e.removeAttribute(t);
                else {
                    switch (typeof n) {
                        case `undefined`:
                        case `function`:
                        case `symbol`:
                            e.removeAttribute(t);
                            return;
                        case `boolean`:
                            var r = t.toLowerCase().slice(0, 5);
                            if (r !== `data-` && r !== `aria-`) {
                                e.removeAttribute(t);
                                return
                            }
                    }
                    e.setAttribute(t, `` + n)
                }
        }

        function zt(e, t, n) {
            if (n === null) e.removeAttribute(t);
            else {
                switch (typeof n) {
                    case `undefined`:
                    case `function`:
                    case `symbol`:
                    case `boolean`:
                        e.removeAttribute(t);
                        return
                }
                e.setAttribute(t, `` + n)
            }
        }

        function Bt(e, t, n, r) {
            if (r === null) e.removeAttribute(n);
            else {
                switch (typeof r) {
                    case `undefined`:
                    case `function`:
                    case `symbol`:
                    case `boolean`:
                        e.removeAttribute(n);
                        return
                }
                e.setAttributeNS(t, n, `` + r)
            }
        }

        function Vt(e) {
            switch (typeof e) {
                case `bigint`:
                case `boolean`:
                case `number`:
                case `string`:
                case `undefined`:
                    return e;
                case `object`:
                    return e;
                default:
                    return ``
            }
        }

        function Ht(e) {
            var t = e.type;
            return (e = e.nodeName) && e.toLowerCase() === `input` && (t === `checkbox` || t === `radio`)
        }

        function Ut(e, t, n) {
            var r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
            if (!e.hasOwnProperty(t) && r !== void 0 && typeof r.get == `function` && typeof r.set == `function`) {
                var i = r.get,
                    a = r.set;
                return Object.defineProperty(e, t, {
                    configurable: !0,
                    get: function() {
                        return i.call(this)
                    },
                    set: function(e) {
                        n = `` + e, a.call(this, e)
                    }
                }), Object.defineProperty(e, t, {
                    enumerable: r.enumerable
                }), {
                    getValue: function() {
                        return n
                    },
                    setValue: function(e) {
                        n = `` + e
                    },
                    stopTracking: function() {
                        e._valueTracker = null, delete e[t]
                    }
                }
            }
        }

        function Wt(e) {
            if (!e._valueTracker) {
                var t = Ht(e) ? `checked` : `value`;
                e._valueTracker = Ut(e, t, `` + e[t])
            }
        }

        function Gt(e) {
            if (!e) return !1;
            var t = e._valueTracker;
            if (!t) return !0;
            var n = t.getValue(),
                r = ``;
            return e && (r = Ht(e) ? e.checked ? `true` : `false` : e.value), e = r, e === n ? !1 : (t.setValue(e), !0)
        }

        function Kt(e) {
            if (e || = typeof document < `u` ? document : void 0, e === void 0) return null;
            try {
                return e.activeElement || e.body
            } catch {
                return e.body
            }
        }
        var qt = /[\n"\\]/g;

        function Jt(e) {
            return e.replace(qt, function(e) {
                return `\\` + e.charCodeAt(0).toString(16) + ` `
            })
        }

        function Yt(e, t, n, r, i, a, o, s) {
            e.name = ``, o != null && typeof o != `function` && typeof o != `symbol` && typeof o != `boolean` ? e.type = o : e.removeAttribute(`type`), t == null ? o !== `submit` && o !== `reset` || e.removeAttribute(`value`) : o === `number` ? (t === 0 && e.value === `` || e.value != t) && (e.value = `` + Vt(t)) : e.value !== `` + Vt(t) && (e.value = `` + Vt(t)), t == null ? n == null ? r != null && e.removeAttribute(`value`) : Zt(e, o, Vt(n)) : Zt(e, o, Vt(t)), i == null && a != null && (e.defaultChecked = !!a), i != null && (e.checked = i && typeof i != `function` && typeof i != `symbol`), s != null && typeof s != `function` && typeof s != `symbol` && typeof s != `boolean` ? e.name = `` + Vt(s) : e.removeAttribute(`name`)
        }

        function Xt(e, t, n, r, i, a, o, s) {
            if (a != null && typeof a != `function` && typeof a != `symbol` && typeof a != `boolean` && (e.type = a), t != null || n != null) {
                if (!(a !== `submit` && a !== `reset` || t != null)) {
                    Wt(e);
                    return
                }
                n = n == null ? `` : `` + Vt(n), t = t == null ? n : `` + Vt(t), s || t === e.value || (e.value = t), e.defaultValue = t
            }
            r ? ? = i, r = typeof r != `function` && typeof r != `symbol` && !!r, e.checked = s ? e.checked : !!r, e.defaultChecked = !!r, o != null && typeof o != `function` && typeof o != `symbol` && typeof o != `boolean` && (e.name = o), Wt(e)
        }

        function Zt(e, t, n) {
            t === `number` && Kt(e.ownerDocument) === e || e.defaultValue === `` + n || (e.defaultValue = `` + n)
        }

        function Qt(e, t, n, r) {
            if (e = e.options, t) {
                t = {};
                for (var i = 0; i < n.length; i++) t[`$` + n[i]] = !0;
                for (n = 0; n < e.length; n++) i = t.hasOwnProperty(`$` + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
            } else {
                for (n = `` + Vt(n), t = null, i = 0; i < e.length; i++) {
                    if (e[i].value === n) {
                        e[i].selected = !0, r && (e[i].defaultSelected = !0);
                        return
                    }
                    t !== null || e[i].disabled || (t = e[i])
                }
                t !== null && (t.selected = !0)
            }
        }

        function $t(e, t, n) {
            if (t != null && (t = `` + Vt(t), t !== e.value && (e.value = t), n == null)) {
                e.defaultValue !== t && (e.defaultValue = t);
                return
            }
            e.defaultValue = n == null ? `` : `` + Vt(n)
        }

        function en(e, t, n, r) {
            if (t == null) {
                if (r != null) {
                    if (n != null) throw Error(a(92));
                    if (de(r)) {
                        if (1 < r.length) throw Error(a(93));
                        r = r[0]
                    }
                    n = r
                }
                n ? ? = ``, t = n
            }
            n = Vt(t), e.defaultValue = n, r = e.textContent, r === n && r !== `` && r !== null && (e.value = r), Wt(e)
        }

        function tn(e, t) {
            if (t) {
                var n = e.firstChild;
                if (n && n === e.lastChild && n.nodeType === 3) {
                    n.nodeValue = t;
                    return
                }
            }
            e.textContent = t
        }
        var nn = new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));

        function rn(e, t, n) {
            var r = t.indexOf(`--`) === 0;
            n == null || typeof n == `boolean` || n === `` ? r ? e.setProperty(t, ``) : t === `float` ? e.cssFloat = `` : e[t] = `` : r ? e.setProperty(t, n) : typeof n != `number` || n === 0 || nn.has(t) ? t === `float` ? e.cssFloat = n : e[t] = (`` + n).trim() : e[t] = n + `px`
        }

        function an(e, t, n) {
            if (t != null && typeof t != `object`) throw Error(a(62));
            if (e = e.style, n != null) {
                for (var r in n) !n.hasOwnProperty(r) || t != null && t.hasOwnProperty(r) || (r.indexOf(`--`) === 0 ? e.setProperty(r, ``) : r === `float` ? e.cssFloat = `` : e[r] = ``);
                for (var i in t) r = t[i], t.hasOwnProperty(i) && n[i] !== r && rn(e, i, r)
            } else
                for (var o in t) t.hasOwnProperty(o) && rn(e, o, t[o])
        }

        function on(e) {
            if (e.indexOf(`-`) === -1) return !1;
            switch (e) {
                case `annotation-xml`:
                case `color-profile`:
                case `font-face`:
                case `font-face-src`:
                case `font-face-uri`:
                case `font-face-format`:
                case `font-face-name`:
                case `missing-glyph`:
                    return !1;
                default:
                    return !0
            }
        }
        var sn = new Map([
                [`acceptCharset`, `accept-charset`],
                [`htmlFor`, `for`],
                [`httpEquiv`, `http-equiv`],
                [`crossOrigin`, `crossorigin`],
                [`accentHeight`, `accent-height`],
                [`alignmentBaseline`, `alignment-baseline`],
                [`arabicForm`, `arabic-form`],
                [`baselineShift`, `baseline-shift`],
                [`capHeight`, `cap-height`],
                [`clipPath`, `clip-path`],
                [`clipRule`, `clip-rule`],
                [`colorInterpolation`, `color-interpolation`],
                [`colorInterpolationFilters`, `color-interpolation-filters`],
                [`colorProfile`, `color-profile`],
                [`colorRendering`, `color-rendering`],
                [`dominantBaseline`, `dominant-baseline`],
                [`enableBackground`, `enable-background`],
                [`fillOpacity`, `fill-opacity`],
                [`fillRule`, `fill-rule`],
                [`floodColor`, `flood-color`],
                [`floodOpacity`, `flood-opacity`],
                [`fontFamily`, `font-family`],
                [`fontSize`, `font-size`],
                [`fontSizeAdjust`, `font-size-adjust`],
                [`fontStretch`, `font-stretch`],
                [`fontStyle`, `font-style`],
                [`fontVariant`, `font-variant`],
                [`fontWeight`, `font-weight`],
                [`glyphName`, `glyph-name`],
                [`glyphOrientationHorizontal`, `glyph-orientation-horizontal`],
                [`glyphOrientationVertical`, `glyph-orientation-vertical`],
                [`horizAdvX`, `horiz-adv-x`],
                [`horizOriginX`, `horiz-origin-x`],
                [`imageRendering`, `image-rendering`],
                [`letterSpacing`, `letter-spacing`],
                [`lightingColor`, `lighting-color`],
                [`markerEnd`, `marker-end`],
                [`markerMid`, `marker-mid`],
                [`markerStart`, `marker-start`],
                [`overlinePosition`, `overline-position`],
                [`overlineThickness`, `overline-thickness`],
                [`paintOrder`, `paint-order`],
                [`panose-1`, `panose-1`],
                [`pointerEvents`, `pointer-events`],
                [`renderingIntent`, `rendering-intent`],
                [`shapeRendering`, `shape-rendering`],
                [`stopColor`, `stop-color`],
                [`stopOpacity`, `stop-opacity`],
                [`strikethroughPosition`, `strikethrough-position`],
                [`strikethroughThickness`, `strikethrough-thickness`],
                [`strokeDasharray`, `stroke-dasharray`],
                [`strokeDashoffset`, `stroke-dashoffset`],
                [`strokeLinecap`, `stroke-linecap`],
                [`strokeLinejoin`, `stroke-linejoin`],
                [`strokeMiterlimit`, `stroke-miterlimit`],
                [`strokeOpacity`, `stroke-opacity`],
                [`strokeWidth`, `stroke-width`],
                [`textAnchor`, `text-anchor`],
                [`textDecoration`, `text-decoration`],
                [`textRendering`, `text-rendering`],
                [`transformOrigin`, `transform-origin`],
                [`underlinePosition`, `underline-position`],
                [`underlineThickness`, `underline-thickness`],
                [`unicodeBidi`, `unicode-bidi`],
                [`unicodeRange`, `unicode-range`],
                [`unitsPerEm`, `units-per-em`],
                [`vAlphabetic`, `v-alphabetic`],
                [`vHanging`, `v-hanging`],
                [`vIdeographic`, `v-ideographic`],
                [`vMathematical`, `v-mathematical`],
                [`vectorEffect`, `vector-effect`],
                [`vertAdvY`, `vert-adv-y`],
                [`vertOriginX`, `vert-origin-x`],
                [`vertOriginY`, `vert-origin-y`],
                [`wordSpacing`, `word-spacing`],
                [`writingMode`, `writing-mode`],
                [`xmlnsXlink`, `xmlns:xlink`],
                [`xHeight`, `x-height`]
            ]),
            cn = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

        function ln(e) {
            return cn.test(`` + e) ? `javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')` : e
        }

        function un() {}
        var dn = null;

        function fn(e) {
            return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
        }
        var pn = null,
            mn = null;

        function hn(e) {
            var t = Dt(e);
            if (t && (e = t.stateNode)) {
                var n = e[vt] || null;
                a: switch (e = t.stateNode, t.type) {
                    case `input`:
                        if (Yt(e, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), t = n.name, n.type === `radio` && t != null) {
                            for (n = e; n.parentNode;) n = n.parentNode;
                            for (n = n.querySelectorAll(`input[name="` + Jt(`` + t) + `"][type="radio"]`), t = 0; t < n.length; t++) {
                                var r = n[t];
                                if (r !== e && r.form === e.form) {
                                    var i = r[vt] || null;
                                    if (!i) throw Error(a(90));
                                    Yt(r, i.value, i.defaultValue, i.defaultValue, i.checked, i.defaultChecked, i.type, i.name)
                                }
                            }
                            for (t = 0; t < n.length; t++) r = n[t], r.form === e.form && Gt(r)
                        }
                        break a;
                    case `textarea`:
                        $t(e, n.value, n.defaultValue);
                        break a;
                    case `select`:
                        t = n.value, t != null && Qt(e, !!n.multiple, t, !1)
                }
            }
        }
        var gn = !1;

        function _n(e, t, n) {
            if (gn) return e(t, n);
            gn = !0;
            try {
                return e(t)
            } finally {
                if (gn = !1, (pn !== null || mn !== null) && (bu(), pn && (t = pn, e = mn, mn = pn = null, hn(t), e)))
                    for (t = 0; t < e.length; t++) hn(e[t])
            }
        }

        function vn(e, t) {
            var n = e.stateNode;
            if (n === null) return null;
            var r = n[vt] || null;
            if (r === null) return null;
            n = r[t];
            a: switch (t) {
                case `onClick`:
                case `onClickCapture`:
                case `onDoubleClick`:
                case `onDoubleClickCapture`:
                case `onMouseDown`:
                case `onMouseDownCapture`:
                case `onMouseMove`:
                case `onMouseMoveCapture`:
                case `onMouseUp`:
                case `onMouseUpCapture`:
                case `onMouseEnter`:
                    (r = !r.disabled) || (e = e.type, r = !(e === `button` || e === `input` || e === `select` || e === `textarea`)), e = !r;
                    break a;
                default:
                    e = !1
            }
            if (e) return null;
            if (n && typeof n != `function`) throw Error(a(231, t, typeof n));
            return n
        }
        var yn = !(typeof window > `u` || window.document === void 0 || window.document.createElement === void 0),
            bn = !1;
        if (yn) try {
            var xn = {};
            Object.defineProperty(xn, `passive`, {
                get: function() {
                    bn = !0
                }
            }), window.addEventListener(`test`, xn, xn), window.removeEventListener(`test`, xn, xn)
        } catch {
            bn = !1
        }
        var Sn = null,
            Cn = null,
            wn = null;

        function Tn() {
            if (wn) return wn;
            var e, t = Cn,
                n = t.length,
                r, i = `value` in Sn ? Sn.value : Sn.textContent,
                a = i.length;
            for (e = 0; e < n && t[e] === i[e]; e++);
            var o = n - e;
            for (r = 1; r <= o && t[n - r] === i[a - r]; r++);
            return wn = i.slice(e, 1 < r ? 1 - r : void 0)
        }

        function En(e) {
            var t = e.keyCode;
            return `charCode` in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
        }

        function Dn() {
            return !0
        }

        function On() {
            return !1
        }

        function kn(e) {
            function t(t, n, r, i, a) {
                for (var o in this._reactName = t, this._targetInst = r, this.type = n, this.nativeEvent = i, this.target = a, this.currentTarget = null, e) e.hasOwnProperty(o) && (t = e[o], this[o] = t ? t(i) : i[o]);
                return this.isDefaultPrevented = (i.defaultPrevented == null ? !1 === i.returnValue : i.defaultPrevented) ? Dn : On, this.isPropagationStopped = On, this
            }
            return m(t.prototype, {
                preventDefault: function() {
                    this.defaultPrevented = !0;
                    var e = this.nativeEvent;
                    e && (e.preventDefault ? e.preventDefault() : typeof e.returnValue != `unknown` && (e.returnValue = !1), this.isDefaultPrevented = Dn)
                },
                stopPropagation: function() {
                    var e = this.nativeEvent;
                    e && (e.stopPropagation ? e.stopPropagation() : typeof e.cancelBubble != `unknown` && (e.cancelBubble = !0), this.isPropagationStopped = Dn)
                },
                persist: function() {},
                isPersistent: Dn
            }), t
        }
        var An = {
                eventPhase: 0,
                bubbles: 0,
                cancelable: 0,
                timeStamp: function(e) {
                    return e.timeStamp || Date.now()
                },
                defaultPrevented: 0,
                isTrusted: 0
            },
            jn = kn(An),
            Mn = m({}, An, {
                view: 0,
                detail: 0
            }),
            Nn = kn(Mn),
            Pn, Fn, In, Ln = m({}, Mn, {
                screenX: 0,
                screenY: 0,
                clientX: 0,
                clientY: 0,
                pageX: 0,
                pageY: 0,
                ctrlKey: 0,
                shiftKey: 0,
                altKey: 0,
                metaKey: 0,
                getModifierState: Jn,
                button: 0,
                buttons: 0,
                relatedTarget: function(e) {
                    return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
                },
                movementX: function(e) {
                    return `movementX` in e ? e.movementX : (e !== In && (In && e.type === `mousemove` ? (Pn = e.screenX - In.screenX, Fn = e.screenY - In.screenY) : Fn = Pn = 0, In = e), Pn)
                },
                movementY: function(e) {
                    return `movementY` in e ? e.movementY : Fn
                }
            }),
            Rn = kn(Ln),
            zn = kn(m({}, Ln, {
                dataTransfer: 0
            })),
            Bn = kn(m({}, Mn, {
                relatedTarget: 0
            })),
            Vn = kn(m({}, An, {
                animationName: 0,
                elapsedTime: 0,
                pseudoElement: 0
            })),
            Hn = kn(m({}, An, {
                clipboardData: function(e) {
                    return `clipboardData` in e ? e.clipboardData : window.clipboardData
                }
            })),
            Un = kn(m({}, An, {
                data: 0
            })),
            Wn = {
                Esc: `Escape`,
                Spacebar: ` `,
                Left: `ArrowLeft`,
                Up: `ArrowUp`,
                Right: `ArrowRight`,
                Down: `ArrowDown`,
                Del: `Delete`,
                Win: `OS`,
                Menu: `ContextMenu`,
                Apps: `ContextMenu`,
                Scroll: `ScrollLock`,
                MozPrintableKey: `Unidentified`
            },
            Gn = {
                8: `Backspace`,
                9: `Tab`,
                12: `Clear`,
                13: `Enter`,
                16: `Shift`,
                17: `Control`,
                18: `Alt`,
                19: `Pause`,
                20: `CapsLock`,
                27: `Escape`,
                32: ` `,
                33: `PageUp`,
                34: `PageDown`,
                35: `End`,
                36: `Home`,
                37: `ArrowLeft`,
                38: `ArrowUp`,
                39: `ArrowRight`,
                40: `ArrowDown`,
                45: `Insert`,
                46: `Delete`,
                112: `F1`,
                113: `F2`,
                114: `F3`,
                115: `F4`,
                116: `F5`,
                117: `F6`,
                118: `F7`,
                119: `F8`,
                120: `F9`,
                121: `F10`,
                122: `F11`,
                123: `F12`,
                144: `NumLock`,
                145: `ScrollLock`,
                224: `Meta`
            },
            Kn = {
                Alt: `altKey`,
                Control: `ctrlKey`,
                Meta: `metaKey`,
                Shift: `shiftKey`
            };

        function qn(e) {
            var t = this.nativeEvent;
            return t.getModifierState ? t.getModifierState(e) : (e = Kn[e]) ? !!t[e] : !1
        }

        function Jn() {
            return qn
        }
        var Yn = kn(m({}, Mn, {
                key: function(e) {
                    if (e.key) {
                        var t = Wn[e.key] || e.key;
                        if (t !== `Unidentified`) return t
                    }
                    return e.type === `keypress` ? (e = En(e), e === 13 ? `Enter` : String.fromCharCode(e)) : e.type === `keydown` || e.type === `keyup` ? Gn[e.keyCode] || `Unidentified` : ``
                },
                code: 0,
                location: 0,
                ctrlKey: 0,
                shiftKey: 0,
                altKey: 0,
                metaKey: 0,
                repeat: 0,
                locale: 0,
                getModifierState: Jn,
                charCode: function(e) {
                    return e.type === `keypress` ? En(e) : 0
                },
                keyCode: function(e) {
                    return e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0
                },
                which: function(e) {
                    return e.type === `keypress` ? En(e) : e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0
                }
            })),
            Xn = kn(m({}, Ln, {
                pointerId: 0,
                width: 0,
                height: 0,
                pressure: 0,
                tangentialPressure: 0,
                tiltX: 0,
                tiltY: 0,
                twist: 0,
                pointerType: 0,
                isPrimary: 0
            })),
            Zn = kn(m({}, Mn, {
                touches: 0,
                targetTouches: 0,
                changedTouches: 0,
                altKey: 0,
                metaKey: 0,
                ctrlKey: 0,
                shiftKey: 0,
                getModifierState: Jn
            })),
            Qn = kn(m({}, An, {
                propertyName: 0,
                elapsedTime: 0,
                pseudoElement: 0
            })),
            $n = kn(m({}, Ln, {
                deltaX: function(e) {
                    return `deltaX` in e ? e.deltaX : `wheelDeltaX` in e ? -e.wheelDeltaX : 0
                },
                deltaY: function(e) {
                    return `deltaY` in e ? e.deltaY : `wheelDeltaY` in e ? -e.wheelDeltaY : `wheelDelta` in e ? -e.wheelDelta : 0
                },
                deltaZ: 0,
                deltaMode: 0
            })),
            er = kn(m({}, An, {
                newState: 0,
                oldState: 0
            })),
            tr = [9, 13, 27, 32],
            nr = yn && `CompositionEvent` in window,
            rr = null;
        yn && `documentMode` in document && (rr = document.documentMode);
        var ir = yn && `TextEvent` in window && !rr,
            ar = yn && (!nr || rr && 8 < rr && 11 >= rr),
            or = ` `,
            sr = !1;

        function cr(e, t) {
            switch (e) {
                case `keyup`:
                    return tr.indexOf(t.keyCode) !== -1;
                case `keydown`:
                    return t.keyCode !== 229;
                case `keypress`:
                case `mousedown`:
                case `focusout`:
                    return !0;
                default:
                    return !1
            }
        }

        function lr(e) {
            return e = e.detail, typeof e == `object` && `data` in e ? e.data : null
        }
        var ur = !1;

        function dr(e, t) {
            switch (e) {
                case `compositionend`:
                    return lr(t);
                case `keypress`:
                    return t.which === 32 ? (sr = !0, or) : null;
                case `textInput`:
                    return e = t.data, e === or && sr ? null : e;
                default:
                    return null
            }
        }

        function fr(e, t) {
            if (ur) return e === `compositionend` || !nr && cr(e, t) ? (e = Tn(), wn = Cn = Sn = null, ur = !1, e) : null;
            switch (e) {
                case `paste`:
                    return null;
                case `keypress`:
                    if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                        if (t.char && 1 < t.char.length) return t.char;
                        if (t.which) return String.fromCharCode(t.which)
                    }
                    return null;
                case `compositionend`:
                    return ar && t.locale !== `ko` ? null : t.data;
                default:
                    return null
            }
        }
        var pr = {
            color: !0,
            date: !0,
            datetime: !0,
            "datetime-local": !0,
            email: !0,
            month: !0,
            number: !0,
            password: !0,
            range: !0,
            search: !0,
            tel: !0,
            text: !0,
            time: !0,
            url: !0,
            week: !0
        };

        function mr(e) {
            var t = e && e.nodeName && e.nodeName.toLowerCase();
            return t === `input` ? !!pr[e.type] : t === `textarea`
        }

        function hr(e, t, n, r) {
            pn ? mn ? mn.push(r) : mn = [r] : pn = r, t = Ed(t, `onChange`), 0 < t.length && (n = new jn(`onChange`, `change`, null, n, r), e.push({
                event: n,
                listeners: t
            }))
        }
        var gr = null,
            _r = null;

        function vr(e) {
            yd(e, 0)
        }

        function yr(e) {
            if (Gt(Ot(e))) return e
        }

        function br(e, t) {
            if (e === `change`) return t
        }
        var xr = !1;
        if (yn) {
            var Sr;
            if (yn) {
                var Cr = `oninput` in document;
                if (!Cr) {
                    var wr = document.createElement(`div`);
                    wr.setAttribute(`oninput`, `return;`), Cr = typeof wr.oninput == `function`
                }
                Sr = Cr
            } else Sr = !1;
            xr = Sr && (!document.documentMode || 9 < document.documentMode)
        }

        function Tr() {
            gr && (gr.detachEvent(`onpropertychange`, Er), _r = gr = null)
        }

        function Er(e) {
            if (e.propertyName === `value` && yr(_r)) {
                var t = [];
                hr(t, _r, e, fn(e)), _n(vr, t)
            }
        }

        function Dr(e, t, n) {
            e === `focusin` ? (Tr(), gr = t, _r = n, gr.attachEvent(`onpropertychange`, Er)) : e === `focusout` && Tr()
        }

        function Or(e) {
            if (e === `selectionchange` || e === `keyup` || e === `keydown`) return yr(_r)
        }

        function kr(e, t) {
            if (e === `click`) return yr(t)
        }

        function Ar(e, t) {
            if (e === `input` || e === `change`) return yr(t)
        }

        function jr(e, t) {
            return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
        }
        var Mr = typeof Object.is == `function` ? Object.is : jr;

        function Nr(e, t) {
            if (Mr(e, t)) return !0;
            if (typeof e != `object` || !e || typeof t != `object` || !t) return !1;
            var n = Object.keys(e),
                r = Object.keys(t);
            if (n.length !== r.length) return !1;
            for (r = 0; r < n.length; r++) {
                var i = n[r];
                if (!je.call(t, i) || !Mr(e[i], t[i])) return !1
            }
            return !0
        }

        function Pr(e) {
            for (; e && e.firstChild;) e = e.firstChild;
            return e
        }

        function Fr(e, t) {
            var n = Pr(e);
            e = 0;
            for (var r; n;) {
                if (n.nodeType === 3) {
                    if (r = e + n.textContent.length, e <= t && r >= t) return {
                        node: n,
                        offset: t - e
                    };
                    e = r
                }
                a: {
                    for (; n;) {
                        if (n.nextSibling) {
                            n = n.nextSibling;
                            break a
                        }
                        n = n.parentNode
                    }
                    n = void 0
                }
                n = Pr(n)
            }
        }

        function Ir(e, t) {
            return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Ir(e, t.parentNode) : `contains` in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
        }

        function Lr(e) {
            e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
            for (var t = Kt(e.document); t instanceof e.HTMLIFrameElement;) {
                try {
                    var n = typeof t.contentWindow.location.href == `string`
                } catch {
                    n = !1
                }
                if (n) e = t.contentWindow;
                else break;
                t = Kt(e.document)
            }
            return t
        }

        function Rr(e) {
            var t = e && e.nodeName && e.nodeName.toLowerCase();
            return t && (t === `input` && (e.type === `text` || e.type === `search` || e.type === `tel` || e.type === `url` || e.type === `password`) || t === `textarea` || e.contentEditable === `true`)
        }
        var zr = yn && `documentMode` in document && 11 >= document.documentMode,
            Br = null,
            Vr = null,
            Hr = null,
            Ur = !1;

        function Wr(e, t, n) {
            var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
            Ur || Br == null || Br !== Kt(r) || (r = Br, `selectionStart` in r && Rr(r) ? r = {
                start: r.selectionStart,
                end: r.selectionEnd
            } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
                anchorNode: r.anchorNode,
                anchorOffset: r.anchorOffset,
                focusNode: r.focusNode,
                focusOffset: r.focusOffset
            }), Hr && Nr(Hr, r) || (Hr = r, r = Ed(Vr, `onSelect`), 0 < r.length && (t = new jn(`onSelect`, `select`, null, t, n), e.push({
                event: t,
                listeners: r
            }), t.target = Br)))
        }

        function Gr(e, t) {
            var n = {};
            return n[e.toLowerCase()] = t.toLowerCase(), n[`Webkit` + e] = `webkit` + t, n[`Moz` + e] = `moz` + t, n
        }
        var Kr = {
                animationend: Gr(`Animation`, `AnimationEnd`),
                animationiteration: Gr(`Animation`, `AnimationIteration`),
                animationstart: Gr(`Animation`, `AnimationStart`),
                transitionrun: Gr(`Transition`, `TransitionRun`),
                transitionstart: Gr(`Transition`, `TransitionStart`),
                transitioncancel: Gr(`Transition`, `TransitionCancel`),
                transitionend: Gr(`Transition`, `TransitionEnd`)
            },
            qr = {},
            Jr = {};
        yn && (Jr = document.createElement(`div`).style, `AnimationEvent` in window || (delete Kr.animationend.animation, delete Kr.animationiteration.animation, delete Kr.animationstart.animation), `TransitionEvent` in window || delete Kr.transitionend.transition);

        function Yr(e) {
            if (qr[e]) return qr[e];
            if (!Kr[e]) return e;
            var t = Kr[e],
                n;
            for (n in t)
                if (t.hasOwnProperty(n) && n in Jr) return qr[e] = t[n];
            return e
        }
        var Xr = Yr(`animationend`),
            Zr = Yr(`animationiteration`),
            Qr = Yr(`animationstart`),
            $r = Yr(`transitionrun`),
            ei = Yr(`transitionstart`),
            ti = Yr(`transitioncancel`),
            ni = Yr(`transitionend`),
            ri = new Map,
            ii = `abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);
        ii.push(`scrollEnd`);

        function ai(e, t) {
            ri.set(e, t), Mt(t, [e])
        }
        var oi = typeof reportError == `function` ? reportError : function(e) {
                if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
                    var t = new window.ErrorEvent(`error`, {
                        bubbles: !0,
                        cancelable: !0,
                        message: typeof e == `object` && e && typeof e.message == `string` ? String(e.message) : String(e),
                        error: e
                    });
                    if (!window.dispatchEvent(t)) return
                } else if (typeof process == `object` && typeof process.emit == `function`) {
                    process.emit(`uncaughtException`, e);
                    return
                }
            },
            si = [],
            ci = 0,
            li = 0;

        function ui() {
            for (var e = ci, t = li = ci = 0; t < e;) {
                var n = si[t];
                si[t++] = null;
                var r = si[t];
                si[t++] = null;
                var i = si[t];
                si[t++] = null;
                var a = si[t];
                if (si[t++] = null, r !== null && i !== null) {
                    var o = r.pending;
                    o === null ? i.next = i : (i.next = o.next, o.next = i), r.pending = i
                }
                a !== 0 && mi(n, i, a)
            }
        }

        function di(e, t, n, r) {
            si[ci++] = e, si[ci++] = t, si[ci++] = n, si[ci++] = r, li |= r, e.lanes |= r, e = e.alternate, e !== null && (e.lanes |= r)
        }

        function fi(e, t, n, r) {
            return di(e, t, n, r), hi(e)
        }

        function pi(e, t) {
            return di(e, null, null, t), hi(e)
        }

        function mi(e, t, n) {
            e.lanes |= n;
            var r = e.alternate;
            r !== null && (r.lanes |= n);
            for (var i = !1, a = e.return; a !== null;) a.childLanes |= n, r = a.alternate, r !== null && (r.childLanes |= n), a.tag === 22 && (e = a.stateNode, e === null || e._visibility & 1 || (i = !0)), e = a, a = a.return;
            return e.tag === 3 ? (a = e.stateNode, i && t !== null && (i = 31 - Je(n), e = a.hiddenUpdates, r = e[i], r === null ? e[i] = [t] : r.push(t), t.lane = n | 536870912), a) : null
        }

        function hi(e) {
            if (50 < du) throw du = 0, fu = null, Error(a(185));
            for (var t = e.return; t !== null;) e = t, t = e.return;
            return e.tag === 3 ? e.stateNode : null
        }
        var gi = {};

        function _i(e, t, n, r) {
            this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
        }

        function vi(e, t, n, r) {
            return new _i(e, t, n, r)
        }

        function yi(e) {
            return e = e.prototype, !(!e || !e.isReactComponent)
        }

        function bi(e, t) {
            var n = e.alternate;
            return n === null ? (n = vi(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 65011712, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
                lanes: t.lanes,
                firstContext: t.firstContext
            }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.refCleanup = e.refCleanup, n
        }

        function xi(e, t) {
            e.flags &= 65011714;
            var n = e.alternate;
            return n === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = t === null ? null : {
                lanes: t.lanes,
                firstContext: t.firstContext
            }), e
        }

        function Si(e, t, n, r, i, o) {
            var s = 0;
            if (r = e, typeof e == `function`) yi(e) && (s = 1);
            else if (typeof e == `string`) s = Uf(e, n, ge.current) ? 26 : e === `html` || e === `head` || e === `body` ? 27 : 5;
            else a: switch (e) {
                case C:
                    return e = vi(31, n, t, i), e.elementType = C, e.lanes = o, e;
                case y:
                    return Ci(n.children, i, o, t);
                case b:
                    s = 8, i |= 24;
                    break;
                case x:
                    return e = vi(12, n, t, i | 2), e.elementType = x, e.lanes = o, e;
                case re:
                    return e = vi(13, n, t, i), e.elementType = re, e.lanes = o, e;
                case ie:
                    return e = vi(19, n, t, i), e.elementType = ie, e.lanes = o, e;
                default:
                    if (typeof e == `object` && e) switch (e.$$typeof) {
                        case te:
                            s = 10;
                            break a;
                        case ee:
                            s = 9;
                            break a;
                        case ne:
                            s = 11;
                            break a;
                        case ae:
                            s = 14;
                            break a;
                        case S:
                            s = 16, r = null;
                            break a
                    }
                    s = 29, n = Error(a(130, e === null ? `null` : typeof e, ``)), r = null
            }
            return t = vi(s, n, t, i), t.elementType = e, t.type = r, t.lanes = o, t
        }

        function Ci(e, t, n, r) {
            return e = vi(7, e, r, t), e.lanes = n, e
        }

        function wi(e, t, n) {
            return e = vi(6, e, null, t), e.lanes = n, e
        }

        function Ti(e) {
            var t = vi(18, null, null, 0);
            return t.stateNode = e, t
        }

        function Ei(e, t, n) {
            return t = vi(4, e.children === null ? [] : e.children, e.key, t), t.lanes = n, t.stateNode = {
                containerInfo: e.containerInfo,
                pendingChildren: null,
                implementation: e.implementation
            }, t
        }
        var Di = new WeakMap;

        function Oi(e, t) {
            if (typeof e == `object` && e) {
                var n = Di.get(e);
                return n === void 0 ? (t = {
                    value: e,
                    source: t,
                    stack: Ae(t)
                }, Di.set(e, t), t) : n
            }
            return {
                value: e,
                source: t,
                stack: Ae(t)
            }
        }
        var ki = [],
            Ai = 0,
            ji = null,
            Mi = 0,
            Ni = [],
            Pi = 0,
            Fi = null,
            Ii = 1,
            Li = ``;

        function Ri(e, t) {
            ki[Ai++] = Mi, ki[Ai++] = ji, ji = e, Mi = t
        }

        function zi(e, t, n) {
            Ni[Pi++] = Ii, Ni[Pi++] = Li, Ni[Pi++] = Fi, Fi = e;
            var r = Ii;
            e = Li;
            var i = 32 - Je(r) - 1;
            r &= ~(1 << i), n += 1;
            var a = 32 - Je(t) + i;
            if (30 < a) {
                var o = i - i % 5;
                a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, Ii = 1 << 32 - Je(t) + i | n << i | r, Li = a + e
            } else Ii = 1 << a | n << i | r, Li = e
        }

        function Bi(e) {
            e.return !== null && (Ri(e, 1), zi(e, 1, 0))
        }

        function Vi(e) {
            for (; e === ji;) ji = ki[--Ai], ki[Ai] = null, Mi = ki[--Ai], ki[Ai] = null;
            for (; e === Fi;) Fi = Ni[--Pi], Ni[Pi] = null, Li = Ni[--Pi], Ni[Pi] = null, Ii = Ni[--Pi], Ni[Pi] = null
        }

        function Hi(e, t) {
            Ni[Pi++] = Ii, Ni[Pi++] = Li, Ni[Pi++] = Fi, Ii = t.id, Li = t.overflow, Fi = e
        }
        var k = null,
            A = null,
            j = !1,
            Ui = null,
            Wi = !1,
            Gi = Error(a(519));

        function Ki(e) {
            throw Qi(Oi(Error(a(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? `text` : `HTML`, ``)), e)), Gi
        }

        function qi(e) {
            var t = e.stateNode,
                n = e.type,
                r = e.memoizedProps;
            switch (t[_t] = e, t[vt] = r, n) {
                case `dialog`:
                    Q(`cancel`, t), Q(`close`, t);
                    break;
                case `iframe`:
                case `object`:
                case `embed`:
                    Q(`load`, t);
                    break;
                case `video`:
                case `audio`:
                    for (n = 0; n < _d.length; n++) Q(_d[n], t);
                    break;
                case `source`:
                    Q(`error`, t);
                    break;
                case `img`:
                case `image`:
                case `link`:
                    Q(`error`, t), Q(`load`, t);
                    break;
                case `details`:
                    Q(`toggle`, t);
                    break;
                case `input`:
                    Q(`invalid`, t), Xt(t, r.value, r.defaultValue, r.checked, r.defaultChecked, r.type, r.name, !0);
                    break;
                case `select`:
                    Q(`invalid`, t);
                    break;
                case `textarea`:
                    Q(`invalid`, t), en(t, r.value, r.defaultValue, r.children)
            }
            n = r.children, typeof n != `string` && typeof n != `number` && typeof n != `bigint` || t.textContent === `` + n || !0 === r.suppressHydrationWarning || Md(t.textContent, n) ? (r.popover != null && (Q(`beforetoggle`, t), Q(`toggle`, t)), r.onScroll != null && Q(`scroll`, t), r.onScrollEnd != null && Q(`scrollend`, t), r.onClick != null && (t.onclick = un), t = !0) : t = !1, t || Ki(e, !0)
        }

        function Ji(e) {
            for (k = e.return; k;) switch (k.tag) {
                case 5:
                case 31:
                case 13:
                    Wi = !1;
                    return;
                case 27:
                case 3:
                    Wi = !0;
                    return;
                default:
                    k = k.return
            }
        }

        function Yi(e) {
            if (e !== k) return !1;
            if (!j) return Ji(e), j = !0, !1;
            var t = e.tag,
                n;
            if ((n = t !== 3 && t !== 27) && ((n = t === 5) && (n = e.type, n = !(n !== `form` && n !== `button`) || Ud(e.type, e.memoizedProps)), n = !n), n && A && Ki(e), Ji(e), t === 13) {
                if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(a(317));
                A = uf(e)
            } else if (t === 31) {
                if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(a(317));
                A = uf(e)
            } else t === 27 ? (t = A, Zd(e.type) ? (e = lf, lf = null, A = e) : A = t) : A = k ? cf(e.stateNode.nextSibling) : null;
            return !0
        }

        function Xi() {
            A = k = null, j = !1
        }

        function Zi() {
            var e = Ui;
            return e !== null && (Ql === null ? Ql = e : Ql.push.apply(Ql, e), Ui = null), e
        }

        function Qi(e) {
            Ui === null ? Ui = [e] : Ui.push(e)
        }
        var $i = he(null),
            ea = null,
            ta = null;

        function na(e, t, n) {
            D($i, t._currentValue), t._currentValue = n
        }

        function ra(e) {
            e._currentValue = $i.current, E($i)
        }

        function ia(e, t, n) {
            for (; e !== null;) {
                var r = e.alternate;
                if ((e.childLanes & t) === t ? r !== null && (r.childLanes & t) !== t && (r.childLanes |= t) : (e.childLanes |= t, r !== null && (r.childLanes |= t)), e === n) break;
                e = e.return
            }
        }

        function aa(e, t, n, r) {
            var i = e.child;
            for (i !== null && (i.return = e); i !== null;) {
                var o = i.dependencies;
                if (o !== null) {
                    var s = i.child;
                    o = o.firstContext;
                    a: for (; o !== null;) {
                        var c = o;
                        o = i;
                        for (var l = 0; l < t.length; l++)
                            if (c.context === t[l]) {
                                o.lanes |= n, c = o.alternate, c !== null && (c.lanes |= n), ia(o.return, n, e), r || (s = null);
                                break a
                            }
                        o = c.next
                    }
                } else if (i.tag === 18) {
                    if (s = i.return, s === null) throw Error(a(341));
                    s.lanes |= n, o = s.alternate, o !== null && (o.lanes |= n), ia(s, n, e), s = null
                } else s = i.child;
                if (s !== null) s.return = i;
                else
                    for (s = i; s !== null;) {
                        if (s === e) {
                            s = null;
                            break
                        }
                        if (i = s.sibling, i !== null) {
                            i.return = s.return, s = i;
                            break
                        }
                        s = s.return
                    }
                i = s
            }
        }

        function oa(e, t, n, r) {
            e = null;
            for (var i = t, o = !1; i !== null;) {
                if (!o) {
                    if (i.flags & 524288) o = !0;
                    else if (i.flags & 262144) break
                }
                if (i.tag === 10) {
                    var s = i.alternate;
                    if (s === null) throw Error(a(387));
                    if (s = s.memoizedProps, s !== null) {
                        var c = i.type;
                        Mr(i.pendingProps.value, s.value) || (e === null ? e = [c] : e.push(c))
                    }
                } else if (i === ye.current) {
                    if (s = i.alternate, s === null) throw Error(a(387));
                    s.memoizedState.memoizedState !== i.memoizedState.memoizedState && (e === null ? e = [Qf] : e.push(Qf))
                }
                i = i.return
            }
            e !== null && aa(t, e, n, r), t.flags |= 262144
        }

        function sa(e) {
            for (e = e.firstContext; e !== null;) {
                if (!Mr(e.context._currentValue, e.memoizedValue)) return !0;
                e = e.next
            }
            return !1
        }

        function ca(e) {
            ea = e, ta = null, e = e.dependencies, e !== null && (e.firstContext = null)
        }

        function la(e) {
            return da(ea, e)
        }

        function ua(e, t) {
            return ea === null && ca(e), da(e, t)
        }

        function da(e, t) {
            var n = t._currentValue;
            if (t = {
                    context: t,
                    memoizedValue: n,
                    next: null
                }, ta === null) {
                if (e === null) throw Error(a(308));
                ta = t, e.dependencies = {
                    lanes: 0,
                    firstContext: t
                }, e.flags |= 524288
            } else ta = ta.next = t;
            return n
        }
        var fa = typeof AbortController < `u` ? AbortController : function() {
                var e = [],
                    t = this.signal = {
                        aborted: !1,
                        addEventListener: function(t, n) {
                            e.push(n)
                        }
                    };
                this.abort = function() {
                    t.aborted = !0, e.forEach(function(e) {
                        return e()
                    })
                }
            },
            pa = t.unstable_scheduleCallback,
            ma = t.unstable_NormalPriority,
            M = {
                $$typeof: te,
                Consumer: null,
                Provider: null,
                _currentValue: null,
                _currentValue2: null,
                _threadCount: 0
            };

        function ha() {
            return {
                controller: new fa,
                data: new Map,
                refCount: 0
            }
        }

        function ga(e) {
            e.refCount--, e.refCount === 0 && pa(ma, function() {
                e.controller.abort()
            })
        }
        var _a = null,
            va = 0,
            ya = 0,
            ba = null;

        function xa(e, t) {
            if (_a === null) {
                var n = _a = [];
                va = 0, ya = dd(), ba = {
                    status: `pending`,
                    value: void 0,
                    then: function(e) {
                        n.push(e)
                    }
                }
            }
            return va++, t.then(Sa, Sa), t
        }

        function Sa() {
            if (--va === 0 && _a !== null) {
                ba !== null && (ba.status = `fulfilled`);
                var e = _a;
                _a = null, ya = 0, ba = null;
                for (var t = 0; t < e.length; t++)(0, e[t])()
            }
        }

        function Ca(e, t) {
            var n = [],
                r = {
                    status: `pending`,
                    value: null,
                    reason: null,
                    then: function(e) {
                        n.push(e)
                    }
                };
            return e.then(function() {
                r.status = `fulfilled`, r.value = t;
                for (var e = 0; e < n.length; e++)(0, n[e])(t)
            }, function(e) {
                for (r.status = `rejected`, r.reason = e, e = 0; e < n.length; e++)(0, n[e])(void 0)
            }), r
        }
        var wa = w.S;
        w.S = function(e, t) {
            tu = Ie(), typeof t == `object` && t && typeof t.then == `function` && xa(e, t), wa !== null && wa(e, t)
        };
        var Ta = he(null);

        function Ea() {
            var e = Ta.current;
            return e === null ? G.pooledCache : e
        }

        function Da(e, t) {
            t === null ? D(Ta, Ta.current) : D(Ta, t.pool)
        }

        function Oa() {
            var e = Ea();
            return e === null ? null : {
                parent: M._currentValue,
                pool: e
            }
        }
        var ka = Error(a(460)),
            Aa = Error(a(474)),
            ja = Error(a(542)),
            Ma = {
                then: function() {}
            };

        function Na(e) {
            return e = e.status, e === `fulfilled` || e === `rejected`
        }

        function Pa(e, t, n) {
            switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(un, un), t = n), t.status) {
                case `fulfilled`:
                    return t.value;
                case `rejected`:
                    throw e = t.reason, Ra(e), e;
                default:
                    if (typeof t.status == `string`) t.then(un, un);
                    else {
                        if (e = G, e !== null && 100 < e.shellSuspendCounter) throw Error(a(482));
                        e = t, e.status = `pending`, e.then(function(e) {
                            if (t.status === `pending`) {
                                var n = t;
                                n.status = `fulfilled`, n.value = e
                            }
                        }, function(e) {
                            if (t.status === `pending`) {
                                var n = t;
                                n.status = `rejected`, n.reason = e
                            }
                        })
                    }
                    switch (t.status) {
                        case `fulfilled`:
                            return t.value;
                        case `rejected`:
                            throw e = t.reason, Ra(e), e
                    }
                    throw Ia = t, ka
            }
        }

        function Fa(e) {
            try {
                var t = e._init;
                return t(e._payload)
            } catch (e) {
                throw typeof e == `object` && e && typeof e.then == `function` ? (Ia = e, ka) : e
            }
        }
        var Ia = null;

        function La() {
            if (Ia === null) throw Error(a(459));
            var e = Ia;
            return Ia = null, e
        }

        function Ra(e) {
            if (e === ka || e === ja) throw Error(a(483))
        }
        var za = null,
            Ba = 0;

        function Va(e) {
            var t = Ba;
            return Ba += 1, za === null && (za = []), Pa(za, e, t)
        }

        function Ha(e, t) {
            t = t.props.ref, e.ref = t === void 0 ? null : t
        }

        function Ua(e, t) {
            throw t.$$typeof === h ? Error(a(525)) : (e = Object.prototype.toString.call(t), Error(a(31, e === `[object Object]` ? `object with keys {` + Object.keys(t).join(`, `) + `}` : e)))
        }

        function Wa(e) {
            function t(t, n) {
                if (e) {
                    var r = t.deletions;
                    r === null ? (t.deletions = [n], t.flags |= 16) : r.push(n)
                }
            }

            function n(n, r) {
                if (!e) return null;
                for (; r !== null;) t(n, r), r = r.sibling;
                return null
            }

            function r(e) {
                for (var t = new Map; e !== null;) e.key === null ? t.set(e.index, e) : t.set(e.key, e), e = e.sibling;
                return t
            }

            function i(e, t) {
                return e = bi(e, t), e.index = 0, e.sibling = null, e
            }

            function o(t, n, r) {
                return t.index = r, e ? (r = t.alternate, r === null ? (t.flags |= 67108866, n) : (r = r.index, r < n ? (t.flags |= 67108866, n) : r)) : (t.flags |= 1048576, n)
            }

            function s(t) {
                return e && t.alternate === null && (t.flags |= 67108866), t
            }

            function c(e, t, n, r) {
                return t === null || t.tag !== 6 ? (t = wi(n, e.mode, r), t.return = e, t) : (t = i(t, n), t.return = e, t)
            }

            function l(e, t, n, r) {
                var a = n.type;
                return a === y ? d(e, t, n.props.children, r, n.key) : t !== null && (t.elementType === a || typeof a == `object` && a && a.$$typeof === S && Fa(a) === t.type) ? (t = i(t, n.props), Ha(t, n), t.return = e, t) : (t = Si(n.type, n.key, n.props, null, e.mode, r), Ha(t, n), t.return = e, t)
            }

            function u(e, t, n, r) {
                return t === null || t.tag !== 4 || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? (t = Ei(n, e.mode, r), t.return = e, t) : (t = i(t, n.children || []), t.return = e, t)
            }

            function d(e, t, n, r, a) {
                return t === null || t.tag !== 7 ? (t = Ci(n, e.mode, r, a), t.return = e, t) : (t = i(t, n), t.return = e, t)
            }

            function f(e, t, n) {
                if (typeof t == `string` && t !== `` || typeof t == `number` || typeof t == `bigint`) return t = wi(`` + t, e.mode, n), t.return = e, t;
                if (typeof t == `object` && t) {
                    switch (t.$$typeof) {
                        case _:
                            return n = Si(t.type, t.key, t.props, null, e.mode, n), Ha(n, t), n.return = e, n;
                        case v:
                            return t = Ei(t, e.mode, n), t.return = e, t;
                        case S:
                            return t = Fa(t), f(e, t, n)
                    }
                    if (de(t) || ce(t)) return t = Ci(t, e.mode, n, null), t.return = e, t;
                    if (typeof t.then == `function`) return f(e, Va(t), n);
                    if (t.$$typeof === te) return f(e, ua(e, t), n);
                    Ua(e, t)
                }
                return null
            }

            function p(e, t, n, r) {
                var i = t === null ? null : t.key;
                if (typeof n == `string` && n !== `` || typeof n == `number` || typeof n == `bigint`) return i === null ? c(e, t, `` + n, r) : null;
                if (typeof n == `object` && n) {
                    switch (n.$$typeof) {
                        case _:
                            return n.key === i ? l(e, t, n, r) : null;
                        case v:
                            return n.key === i ? u(e, t, n, r) : null;
                        case S:
                            return n = Fa(n), p(e, t, n, r)
                    }
                    if (de(n) || ce(n)) return i === null ? d(e, t, n, r, null) : null;
                    if (typeof n.then == `function`) return p(e, t, Va(n), r);
                    if (n.$$typeof === te) return p(e, t, ua(e, n), r);
                    Ua(e, n)
                }
                return null
            }

            function m(e, t, n, r, i) {
                if (typeof r == `string` && r !== `` || typeof r == `number` || typeof r == `bigint`) return e = e.get(n) || null, c(t, e, `` + r, i);
                if (typeof r == `object` && r) {
                    switch (r.$$typeof) {
                        case _:
                            return e = e.get(r.key === null ? n : r.key) || null, l(t, e, r, i);
                        case v:
                            return e = e.get(r.key === null ? n : r.key) || null, u(t, e, r, i);
                        case S:
                            return r = Fa(r), m(e, t, n, r, i)
                    }
                    if (de(r) || ce(r)) return e = e.get(n) || null, d(t, e, r, i, null);
                    if (typeof r.then == `function`) return m(e, t, n, Va(r), i);
                    if (r.$$typeof === te) return m(e, t, n, ua(t, r), i);
                    Ua(t, r)
                }
                return null
            }

            function h(i, a, s, c) {
                for (var l = null, u = null, d = a, h = a = 0, g = null; d !== null && h < s.length; h++) {
                    d.index > h ? (g = d, d = null) : g = d.sibling;
                    var _ = p(i, d, s[h], c);
                    if (_ === null) {
                        d === null && (d = g);
                        break
                    }
                    e && d && _.alternate === null && t(i, d), a = o(_, a, h), u === null ? l = _ : u.sibling = _, u = _, d = g
                }
                if (h === s.length) return n(i, d), j && Ri(i, h), l;
                if (d === null) {
                    for (; h < s.length; h++) d = f(i, s[h], c), d !== null && (a = o(d, a, h), u === null ? l = d : u.sibling = d, u = d);
                    return j && Ri(i, h), l
                }
                for (d = r(d); h < s.length; h++) g = m(d, i, h, s[h], c), g !== null && (e && g.alternate !== null && d.delete(g.key === null ? h : g.key), a = o(g, a, h), u === null ? l = g : u.sibling = g, u = g);
                return e && d.forEach(function(e) {
                    return t(i, e)
                }), j && Ri(i, h), l
            }

            function g(i, s, c, l) {
                if (c == null) throw Error(a(151));
                for (var u = null, d = null, h = s, g = s = 0, _ = null, v = c.next(); h !== null && !v.done; g++, v = c.next()) {
                    h.index > g ? (_ = h, h = null) : _ = h.sibling;
                    var y = p(i, h, v.value, l);
                    if (y === null) {
                        h === null && (h = _);
                        break
                    }
                    e && h && y.alternate === null && t(i, h), s = o(y, s, g), d === null ? u = y : d.sibling = y, d = y, h = _
                }
                if (v.done) return n(i, h), j && Ri(i, g), u;
                if (h === null) {
                    for (; !v.done; g++, v = c.next()) v = f(i, v.value, l), v !== null && (s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
                    return j && Ri(i, g), u
                }
                for (h = r(h); !v.done; g++, v = c.next()) v = m(h, i, g, v.value, l), v !== null && (e && v.alternate !== null && h.delete(v.key === null ? g : v.key), s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
                return e && h.forEach(function(e) {
                    return t(i, e)
                }), j && Ri(i, g), u
            }

            function b(e, r, o, c) {
                if (typeof o == `object` && o && o.type === y && o.key === null && (o = o.props.children), typeof o == `object` && o) {
                    switch (o.$$typeof) {
                        case _:
                            a: {
                                for (var l = o.key; r !== null;) {
                                    if (r.key === l) {
                                        if (l = o.type, l === y) {
                                            if (r.tag === 7) {
                                                n(e, r.sibling), c = i(r, o.props.children), c.return = e, e = c;
                                                break a
                                            }
                                        } else if (r.elementType === l || typeof l == `object` && l && l.$$typeof === S && Fa(l) === r.type) {
                                            n(e, r.sibling), c = i(r, o.props), Ha(c, o), c.return = e, e = c;
                                            break a
                                        }
                                        n(e, r);
                                        break
                                    } else t(e, r);
                                    r = r.sibling
                                }
                                o.type === y ? (c = Ci(o.props.children, e.mode, c, o.key), c.return = e, e = c) : (c = Si(o.type, o.key, o.props, null, e.mode, c), Ha(c, o), c.return = e, e = c)
                            }
                            return s(e);
                        case v:
                            a: {
                                for (l = o.key; r !== null;) {
                                    if (r.key === l)
                                        if (r.tag === 4 && r.stateNode.containerInfo === o.containerInfo && r.stateNode.implementation === o.implementation) {
                                            n(e, r.sibling), c = i(r, o.children || []), c.return = e, e = c;
                                            break a
                                        } else {
                                            n(e, r);
                                            break
                                        }
                                    else t(e, r);
                                    r = r.sibling
                                }
                                c = Ei(o, e.mode, c),
                                c.return = e,
                                e = c
                            }
                            return s(e);
                        case S:
                            return o = Fa(o), b(e, r, o, c)
                    }
                    if (de(o)) return h(e, r, o, c);
                    if (ce(o)) {
                        if (l = ce(o), typeof l != `function`) throw Error(a(150));
                        return o = l.call(o), g(e, r, o, c)
                    }
                    if (typeof o.then == `function`) return b(e, r, Va(o), c);
                    if (o.$$typeof === te) return b(e, r, ua(e, o), c);
                    Ua(e, o)
                }
                return typeof o == `string` && o !== `` || typeof o == `number` || typeof o == `bigint` ? (o = `` + o, r !== null && r.tag === 6 ? (n(e, r.sibling), c = i(r, o), c.return = e, e = c) : (n(e, r), c = wi(o, e.mode, c), c.return = e, e = c), s(e)) : n(e, r)
            }
            return function(e, t, n, r) {
                try {
                    Ba = 0;
                    var i = b(e, t, n, r);
                    return za = null, i
                } catch (t) {
                    if (t === ka || t === ja) throw t;
                    var a = vi(29, t, null, e.mode);
                    return a.lanes = r, a.return = e, a
                }
            }
        }
        var Ga = Wa(!0),
            Ka = Wa(!1),
            qa = !1;

        function Ja(e) {
            e.updateQueue = {
                baseState: e.memoizedState,
                firstBaseUpdate: null,
                lastBaseUpdate: null,
                shared: {
                    pending: null,
                    lanes: 0,
                    hiddenCallbacks: null
                },
                callbacks: null
            }
        }

        function Ya(e, t) {
            e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
                baseState: e.baseState,
                firstBaseUpdate: e.firstBaseUpdate,
                lastBaseUpdate: e.lastBaseUpdate,
                shared: e.shared,
                callbacks: null
            })
        }

        function Xa(e) {
            return {
                lane: e,
                tag: 0,
                payload: null,
                callback: null,
                next: null
            }
        }

        function Za(e, t, n) {
            var r = e.updateQueue;
            if (r === null) return null;
            if (r = r.shared, W & 2) {
                var i = r.pending;
                return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, t = hi(e), mi(e, null, n), t
            }
            return di(e, r, t, n), hi(e)
        }

        function Qa(e, t, n) {
            if (t = t.updateQueue, t !== null && (t = t.shared, n & 4194048)) {
                var r = t.lanes;
                r &= e.pendingLanes, n |= r, t.lanes = n, ut(e, n)
            }
        }

        function $a(e, t) {
            var n = e.updateQueue,
                r = e.alternate;
            if (r !== null && (r = r.updateQueue, n === r)) {
                var i = null,
                    a = null;
                if (n = n.firstBaseUpdate, n !== null) {
                    do {
                        var o = {
                            lane: n.lane,
                            tag: n.tag,
                            payload: n.payload,
                            callback: null,
                            next: null
                        };
                        a === null ? i = a = o : a = a.next = o, n = n.next
                    } while (n !== null);
                    a === null ? i = a = t : a = a.next = t
                } else i = a = t;
                n = {
                    baseState: r.baseState,
                    firstBaseUpdate: i,
                    lastBaseUpdate: a,
                    shared: r.shared,
                    callbacks: r.callbacks
                }, e.updateQueue = n;
                return
            }
            e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
        }
        var eo = !1;

        function to() {
            if (eo) {
                var e = ba;
                if (e !== null) throw e
            }
        }

        function no(e, t, n, r) {
            eo = !1;
            var i = e.updateQueue;
            qa = !1;
            var a = i.firstBaseUpdate,
                o = i.lastBaseUpdate,
                s = i.shared.pending;
            if (s !== null) {
                i.shared.pending = null;
                var c = s,
                    l = c.next;
                c.next = null, o === null ? a = l : o.next = l, o = c;
                var u = e.alternate;
                u !== null && (u = u.updateQueue, s = u.lastBaseUpdate, s !== o && (s === null ? u.firstBaseUpdate = l : s.next = l, u.lastBaseUpdate = c))
            }
            if (a !== null) {
                var d = i.baseState;
                o = 0, u = l = c = null, s = a;
                do {
                    var f = s.lane & -536870913,
                        p = f !== s.lane;
                    if (p ? (q & f) === f : (r & f) === f) {
                        f !== 0 && f === ya && (eo = !0), u !== null && (u = u.next = {
                            lane: 0,
                            tag: s.tag,
                            payload: s.payload,
                            callback: null,
                            next: null
                        });
                        a: {
                            var h = e,
                                g = s;f = t;
                            var _ = n;
                            switch (g.tag) {
                                case 1:
                                    if (h = g.payload, typeof h == `function`) {
                                        d = h.call(_, d, f);
                                        break a
                                    }
                                    d = h;
                                    break a;
                                case 3:
                                    h.flags = h.flags & -65537 | 128;
                                case 0:
                                    if (h = g.payload, f = typeof h == `function` ? h.call(_, d, f) : h, f == null) break a;
                                    d = m({}, d, f);
                                    break a;
                                case 2:
                                    qa = !0
                            }
                        }
                        f = s.callback, f !== null && (e.flags |= 64, p && (e.flags |= 8192), p = i.callbacks, p === null ? i.callbacks = [f] : p.push(f))
                    } else p = {
                        lane: f,
                        tag: s.tag,
                        payload: s.payload,
                        callback: s.callback,
                        next: null
                    }, u === null ? (l = u = p, c = d) : u = u.next = p, o |= f;
                    if (s = s.next, s === null) {
                        if (s = i.shared.pending, s === null) break;
                        p = s, s = p.next, p.next = null, i.lastBaseUpdate = p, i.shared.pending = null
                    }
                } while (1);
                u === null && (c = d), i.baseState = c, i.firstBaseUpdate = l, i.lastBaseUpdate = u, a === null && (i.shared.lanes = 0), Kl |= o, e.lanes = o, e.memoizedState = d
            }
        }

        function ro(e, t) {
            if (typeof e != `function`) throw Error(a(191, e));
            e.call(t)
        }

        function io(e, t) {
            var n = e.callbacks;
            if (n !== null)
                for (e.callbacks = null, e = 0; e < n.length; e++) ro(n[e], t)
        }
        var ao = he(null),
            oo = he(0);

        function so(e, t) {
            e = Gl, D(oo, e), D(ao, t), Gl = e | t.baseLanes
        }

        function co() {
            D(oo, Gl), D(ao, ao.current)
        }

        function lo() {
            Gl = oo.current, E(ao), E(oo)
        }
        var uo = he(null),
            fo = null;

        function po(e) {
            var t = e.alternate;
            D(N, N.current & 1), D(uo, e), fo === null && (t === null || ao.current !== null || t.memoizedState !== null) && (fo = e)
        }

        function mo(e) {
            D(N, N.current), D(uo, e), fo === null && (fo = e)
        }

        function ho(e) {
            e.tag === 22 ? (D(N, N.current), D(uo, e), fo === null && (fo = e)) : go(e)
        }

        function go() {
            D(N, N.current), D(uo, uo.current)
        }

        function _o(e) {
            E(uo), fo === e && (fo = null), E(N)
        }
        var N = he(0);

        function vo(e) {
            for (var t = e; t !== null;) {
                if (t.tag === 13) {
                    var n = t.memoizedState;
                    if (n !== null && (n = n.dehydrated, n === null || af(n) || of (n))) return t
                } else if (t.tag === 19 && (t.memoizedProps.revealOrder === `forwards` || t.memoizedProps.revealOrder === `backwards` || t.memoizedProps.revealOrder === `unstable_legacy-backwards` || t.memoizedProps.revealOrder === `together`)) {
                    if (t.flags & 128) return t
                } else if (t.child !== null) {
                    t.child.return = t, t = t.child;
                    continue
                }
                if (t === e) break;
                for (; t.sibling === null;) {
                    if (t.return === null || t.return === e) return null;
                    t = t.return
                }
                t.sibling.return = t.return, t = t.sibling
            }
            return null
        }
        var yo = 0,
            P = null,
            F = null,
            I = null,
            bo = !1,
            xo = !1,
            So = !1,
            Co = 0,
            wo = 0,
            To = null,
            Eo = 0;

        function L() {
            throw Error(a(321))
        }

        function Do(e, t) {
            if (t === null) return !1;
            for (var n = 0; n < t.length && n < e.length; n++)
                if (!Mr(e[n], t[n])) return !1;
            return !0
        }

        function Oo(e, t, n, r, i, a) {
            return yo = a, P = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, w.H = e === null || e.memoizedState === null ? Ws : Gs, So = !1, a = n(r, i), So = !1, xo && (a = Ao(t, n, r, i)), ko(e), a
        }

        function ko(e) {
            w.H = Us;
            var t = F !== null && F.next !== null;
            if (yo = 0, I = F = P = null, bo = !1, wo = 0, To = null, t) throw Error(a(300));
            e === null || z || (e = e.dependencies, e !== null && sa(e) && (z = !0))
        }

        function Ao(e, t, n, r) {
            P = e;
            var i = 0;
            do {
                if (xo && (To = null), wo = 0, xo = !1, 25 <= i) throw Error(a(301));
                if (i += 1, I = F = null, e.updateQueue != null) {
                    var o = e.updateQueue;
                    o.lastEffect = null, o.events = null, o.stores = null, o.memoCache != null && (o.memoCache.index = 0)
                }
                w.H = Ks, o = t(n, r)
            } while (xo);
            return o
        }

        function jo() {
            var e = w.H,
                t = e.useState()[0];
            return t = typeof t.then == `function` ? Lo(t) : t, e = e.useState()[0], (F === null ? null : F.memoizedState) !== e && (P.flags |= 1024), t
        }

        function Mo() {
            var e = Co !== 0;
            return Co = 0, e
        }

        function No(e, t, n) {
            t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n
        }

        function Po(e) {
            if (bo) {
                for (e = e.memoizedState; e !== null;) {
                    var t = e.queue;
                    t !== null && (t.pending = null), e = e.next
                }
                bo = !1
            }
            yo = 0, I = F = P = null, xo = !1, wo = Co = 0, To = null
        }

        function Fo() {
            var e = {
                memoizedState: null,
                baseState: null,
                baseQueue: null,
                queue: null,
                next: null
            };
            return I === null ? P.memoizedState = I = e : I = I.next = e, I
        }

        function R() {
            if (F === null) {
                var e = P.alternate;
                e = e === null ? null : e.memoizedState
            } else e = F.next;
            var t = I === null ? P.memoizedState : I.next;
            if (t !== null) I = t, F = e;
            else {
                if (e === null) throw P.alternate === null ? Error(a(467)) : Error(a(310));
                F = e, e = {
                    memoizedState: F.memoizedState,
                    baseState: F.baseState,
                    baseQueue: F.baseQueue,
                    queue: F.queue,
                    next: null
                }, I === null ? P.memoizedState = I = e : I = I.next = e
            }
            return I
        }

        function Io() {
            return {
                lastEffect: null,
                events: null,
                stores: null,
                memoCache: null
            }
        }

        function Lo(e) {
            var t = wo;
            return wo += 1, To === null && (To = []), e = Pa(To, e, t), t = P, (I === null ? t.memoizedState : I.next) === null && (t = t.alternate, w.H = t === null || t.memoizedState === null ? Ws : Gs), e
        }

        function Ro(e) {
            if (typeof e == `object` && e) {
                if (typeof e.then == `function`) return Lo(e);
                if (e.$$typeof === te) return la(e)
            }
            throw Error(a(438, String(e)))
        }

        function zo(e) {
            var t = null,
                n = P.updateQueue;
            if (n !== null && (t = n.memoCache), t == null) {
                var r = P.alternate;
                r !== null && (r = r.updateQueue, r !== null && (r = r.memoCache, r != null && (t = {
                    data: r.data.map(function(e) {
                        return e.slice()
                    }),
                    index: 0
                })))
            }
            if (t ? ? = {
                    data: [],
                    index: 0
                }, n === null && (n = Io(), P.updateQueue = n), n.memoCache = t, n = t.data[t.index], n === void 0)
                for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = oe;
            return t.index++, n
        }

        function Bo(e, t) {
            return typeof t == `function` ? t(e) : t
        }

        function Vo(e) {
            return Ho(R(), F, e)
        }

        function Ho(e, t, n) {
            var r = e.queue;
            if (r === null) throw Error(a(311));
            r.lastRenderedReducer = n;
            var i = e.baseQueue,
                o = r.pending;
            if (o !== null) {
                if (i !== null) {
                    var s = i.next;
                    i.next = o.next, o.next = s
                }
                t.baseQueue = i = o, r.pending = null
            }
            if (o = e.baseState, i === null) e.memoizedState = o;
            else {
                t = i.next;
                var c = s = null,
                    l = null,
                    u = t,
                    d = !1;
                do {
                    var f = u.lane & -536870913;
                    if (f === u.lane ? (yo & f) === f : (q & f) === f) {
                        var p = u.revertLane;
                        if (p === 0) l !== null && (l = l.next = {
                            lane: 0,
                            revertLane: 0,
                            gesture: null,
                            action: u.action,
                            hasEagerState: u.hasEagerState,
                            eagerState: u.eagerState,
                            next: null
                        }), f === ya && (d = !0);
                        else if ((yo & p) === p) {
                            u = u.next, p === ya && (d = !0);
                            continue
                        } else f = {
                            lane: 0,
                            revertLane: u.revertLane,
                            gesture: null,
                            action: u.action,
                            hasEagerState: u.hasEagerState,
                            eagerState: u.eagerState,
                            next: null
                        }, l === null ? (c = l = f, s = o) : l = l.next = f, P.lanes |= p, Kl |= p;
                        f = u.action, So && n(o, f), o = u.hasEagerState ? u.eagerState : n(o, f)
                    } else p = {
                        lane: f,
                        revertLane: u.revertLane,
                        gesture: u.gesture,
                        action: u.action,
                        hasEagerState: u.hasEagerState,
                        eagerState: u.eagerState,
                        next: null
                    }, l === null ? (c = l = p, s = o) : l = l.next = p, P.lanes |= f, Kl |= f;
                    u = u.next
                } while (u !== null && u !== t);
                if (l === null ? s = o : l.next = c, !Mr(o, e.memoizedState) && (z = !0, d && (n = ba, n !== null))) throw n;
                e.memoizedState = o, e.baseState = s, e.baseQueue = l, r.lastRenderedState = o
            }
            return i === null && (r.lanes = 0), [e.memoizedState, r.dispatch]
        }

        function Uo(e) {
            var t = R(),
                n = t.queue;
            if (n === null) throw Error(a(311));
            n.lastRenderedReducer = e;
            var r = n.dispatch,
                i = n.pending,
                o = t.memoizedState;
            if (i !== null) {
                n.pending = null;
                var s = i = i.next;
                do o = e(o, s.action), s = s.next; while (s !== i);
                Mr(o, t.memoizedState) || (z = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o
            }
            return [o, r]
        }

        function Wo(e, t, n) {
            var r = P,
                i = R(),
                o = j;
            if (o) {
                if (n === void 0) throw Error(a(407));
                n = n()
            } else n = t();
            var s = !Mr((F || i).memoizedState, n);
            if (s && (i.memoizedState = n, z = !0), i = i.queue, hs(qo.bind(null, r, i, e), [e]), i.getSnapshot !== t || s || I !== null && I.memoizedState.tag & 1) {
                if (r.flags |= 2048, us(9, {
                        destroy: void 0
                    }, Ko.bind(null, r, i, n, t), null), G === null) throw Error(a(349));
                o || yo & 127 || Go(r, t, n)
            }
            return n
        }

        function Go(e, t, n) {
            e.flags |= 16384, e = {
                getSnapshot: t,
                value: n
            }, t = P.updateQueue, t === null ? (t = Io(), P.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
        }

        function Ko(e, t, n, r) {
            t.value = n, t.getSnapshot = r, Jo(t) && Yo(e)
        }

        function qo(e, t, n) {
            return n(function() {
                Jo(t) && Yo(e)
            })
        }

        function Jo(e) {
            var t = e.getSnapshot;
            e = e.value;
            try {
                var n = t();
                return !Mr(e, n)
            } catch {
                return !0
            }
        }

        function Yo(e) {
            var t = pi(e, 2);
            t !== null && hu(t, e, 2)
        }

        function Xo(e) {
            var t = Fo();
            if (typeof e == `function`) {
                var n = e;
                if (e = n(), So) {
                    qe(!0);
                    try {
                        n()
                    } finally {
                        qe(!1)
                    }
                }
            }
            return t.memoizedState = t.baseState = e, t.queue = {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: Bo,
                lastRenderedState: e
            }, t
        }

        function Zo(e, t, n, r) {
            return e.baseState = n, Ho(e, F, typeof r == `function` ? r : Bo)
        }

        function Qo(e, t, n, r, i) {
            if (Bs(e)) throw Error(a(485));
            if (e = t.action, e !== null) {
                var o = {
                    payload: i,
                    action: e,
                    next: null,
                    isTransition: !0,
                    status: `pending`,
                    value: null,
                    reason: null,
                    listeners: [],
                    then: function(e) {
                        o.listeners.push(e)
                    }
                };
                w.T === null ? o.isTransition = !1 : n(!0), r(o), n = t.pending, n === null ? (o.next = t.pending = o, $o(t, o)) : (o.next = n.next, t.pending = n.next = o)
            }
        }

        function $o(e, t) {
            var n = t.action,
                r = t.payload,
                i = e.state;
            if (t.isTransition) {
                var a = w.T,
                    o = {};
                w.T = o;
                try {
                    var s = n(i, r),
                        c = w.S;
                    c !== null && c(o, s), es(e, t, s)
                } catch (n) {
                    ns(e, t, n)
                } finally {
                    a !== null && o.types !== null && (a.types = o.types), w.T = a
                }
            } else try {
                a = n(i, r), es(e, t, a)
            } catch (n) {
                ns(e, t, n)
            }
        }

        function es(e, t, n) {
            typeof n == `object` && n && typeof n.then == `function` ? n.then(function(n) {
                ts(e, t, n)
            }, function(n) {
                return ns(e, t, n)
            }) : ts(e, t, n)
        }

        function ts(e, t, n) {
            t.status = `fulfilled`, t.value = n, rs(t), e.state = n, t = e.pending, t !== null && (n = t.next, n === t ? e.pending = null : (n = n.next, t.next = n, $o(e, n)))
        }

        function ns(e, t, n) {
            var r = e.pending;
            if (e.pending = null, r !== null) {
                r = r.next;
                do t.status = `rejected`, t.reason = n, rs(t), t = t.next; while (t !== r)
            }
            e.action = null
        }

        function rs(e) {
            e = e.listeners;
            for (var t = 0; t < e.length; t++)(0, e[t])()
        }

        function is(e, t) {
            return t
        }

        function as(e, t) {
            if (j) {
                var n = G.formState;
                if (n !== null) {
                    a: {
                        var r = P;
                        if (j) {
                            if (A) {
                                b: {
                                    for (var i = A, a = Wi; i.nodeType !== 8;) {
                                        if (!a) {
                                            i = null;
                                            break b
                                        }
                                        if (i = cf(i.nextSibling), i === null) {
                                            i = null;
                                            break b
                                        }
                                    }
                                    a = i.data,
                                    i = a === `F!` || a === `F` ? i : null
                                }
                                if (i) {
                                    A = cf(i.nextSibling), r = i.data === `F!`;
                                    break a
                                }
                            }
                            Ki(r)
                        }
                        r = !1
                    }
                    r && (t = n[0])
                }
            }
            return n = Fo(), n.memoizedState = n.baseState = t, r = {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: is,
                lastRenderedState: t
            }, n.queue = r, n = Ls.bind(null, P, r), r.dispatch = n, r = Xo(!1), a = zs.bind(null, P, !1, r.queue), r = Fo(), i = {
                state: t,
                dispatch: null,
                action: e,
                pending: null
            }, r.queue = i, n = Qo.bind(null, P, i, a, n), i.dispatch = n, r.memoizedState = e, [t, n, !1]
        }

        function os(e) {
            return ss(R(), F, e)
        }

        function ss(e, t, n) {
            if (t = Ho(e, t, is)[0], e = Vo(Bo)[0], typeof t == `object` && t && typeof t.then == `function`) try {
                var r = Lo(t)
            } catch (e) {
                throw e === ka ? ja : e
            } else r = t;
            t = R();
            var i = t.queue,
                a = i.dispatch;
            return n !== t.memoizedState && (P.flags |= 2048, us(9, {
                destroy: void 0
            }, cs.bind(null, i, n), null)), [r, a, e]
        }

        function cs(e, t) {
            e.action = t
        }

        function ls(e) {
            var t = R(),
                n = F;
            if (n !== null) return ss(t, n, e);
            R(), t = t.memoizedState, n = R();
            var r = n.queue.dispatch;
            return n.memoizedState = e, [t, r, !1]
        }

        function us(e, t, n, r) {
            return e = {
                tag: e,
                create: n,
                deps: r,
                inst: t,
                next: null
            }, t = P.updateQueue, t === null && (t = Io(), P.updateQueue = t), n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e
        }

        function ds() {
            return R().memoizedState
        }

        function fs(e, t, n, r) {
            var i = Fo();
            P.flags |= e, i.memoizedState = us(1 | t, {
                destroy: void 0
            }, n, r === void 0 ? null : r)
        }

        function ps(e, t, n, r) {
            var i = R();
            r = r === void 0 ? null : r;
            var a = i.memoizedState.inst;
            F !== null && r !== null && Do(r, F.memoizedState.deps) ? i.memoizedState = us(t, a, n, r) : (P.flags |= e, i.memoizedState = us(1 | t, a, n, r))
        }

        function ms(e, t) {
            fs(8390656, 8, e, t)
        }

        function hs(e, t) {
            ps(2048, 8, e, t)
        }

        function gs(e) {
            P.flags |= 4;
            var t = P.updateQueue;
            if (t === null) t = Io(), P.updateQueue = t, t.events = [e];
            else {
                var n = t.events;
                n === null ? t.events = [e] : n.push(e)
            }
        }

        function _s(e) {
            var t = R().memoizedState;
            return gs({
                    ref: t,
                    nextImpl: e
                }),
                function() {
                    if (W & 2) throw Error(a(440));
                    return t.impl.apply(void 0, arguments)
                }
        }

        function vs(e, t) {
            return ps(4, 2, e, t)
        }

        function ys(e, t) {
            return ps(4, 4, e, t)
        }

        function bs(e, t) {
            if (typeof t == `function`) {
                e = e();
                var n = t(e);
                return function() {
                    typeof n == `function` ? n() : t(null)
                }
            }
            if (t != null) return e = e(), t.current = e,
                function() {
                    t.current = null
                }
        }

        function xs(e, t, n) {
            n = n == null ? null : n.concat([e]), ps(4, 4, bs.bind(null, t, e), n)
        }

        function Ss() {}

        function Cs(e, t) {
            var n = R();
            t = t === void 0 ? null : t;
            var r = n.memoizedState;
            return t !== null && Do(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
        }

        function ws(e, t) {
            var n = R();
            t = t === void 0 ? null : t;
            var r = n.memoizedState;
            if (t !== null && Do(t, r[1])) return r[0];
            if (r = e(), So) {
                qe(!0);
                try {
                    e()
                } finally {
                    qe(!1)
                }
            }
            return n.memoizedState = [r, t], r
        }

        function Ts(e, t, n) {
            return n === void 0 || yo & 1073741824 && !(q & 261930) ? e.memoizedState = t : (e.memoizedState = n, e = mu(), P.lanes |= e, Kl |= e, n)
        }

        function Es(e, t, n, r) {
            return Mr(n, t) ? n : ao.current === null ? !(yo & 42) || yo & 1073741824 && !(q & 261930) ? (z = !0, e.memoizedState = n) : (e = mu(), P.lanes |= e, Kl |= e, t) : (e = Ts(e, n, r), Mr(e, t) || (z = !0), e)
        }

        function Ds(e, t, n, r, i) {
            var a = T.p;
            T.p = a !== 0 && 8 > a ? a : 8;
            var o = w.T,
                s = {};
            w.T = s, zs(e, !1, t, n);
            try {
                var c = i(),
                    l = w.S;
                l !== null && l(s, c), typeof c == `object` && c && typeof c.then == `function` ? Rs(e, t, Ca(c, r), pu(e)) : Rs(e, t, r, pu(e))
            } catch (n) {
                Rs(e, t, {
                    then: function() {},
                    status: `rejected`,
                    reason: n
                }, pu())
            } finally {
                T.p = a, o !== null && s.types !== null && (o.types = s.types), w.T = o
            }
        }

        function Os() {}

        function ks(e, t, n, r) {
            if (e.tag !== 5) throw Error(a(476));
            var i = As(e).queue;
            Ds(e, i, t, fe, n === null ? Os : function() {
                return js(e), n(r)
            })
        }

        function As(e) {
            var t = e.memoizedState;
            if (t !== null) return t;
            t = {
                memoizedState: fe,
                baseState: fe,
                baseQueue: null,
                queue: {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: Bo,
                    lastRenderedState: fe
                },
                next: null
            };
            var n = {};
            return t.next = {
                memoizedState: n,
                baseState: n,
                baseQueue: null,
                queue: {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: Bo,
                    lastRenderedState: n
                },
                next: null
            }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t
        }

        function js(e) {
            var t = As(e);
            t.next === null && (t = e.alternate.memoizedState), Rs(e, t.next.queue, {}, pu())
        }

        function Ms() {
            return la(Qf)
        }

        function Ns() {
            return R().memoizedState
        }

        function Ps() {
            return R().memoizedState
        }

        function Fs(e) {
            for (var t = e.return; t !== null;) {
                switch (t.tag) {
                    case 24:
                    case 3:
                        var n = pu();
                        e = Xa(n);
                        var r = Za(t, e, n);
                        r !== null && (hu(r, t, n), Qa(r, t, n)), t = {
                            cache: ha()
                        }, e.payload = t;
                        return
                }
                t = t.return
            }
        }

        function Is(e, t, n) {
            var r = pu();
            n = {
                lane: r,
                revertLane: 0,
                gesture: null,
                action: n,
                hasEagerState: !1,
                eagerState: null,
                next: null
            }, Bs(e) ? Vs(t, n) : (n = fi(e, t, n, r), n !== null && (hu(n, e, r), Hs(n, t, r)))
        }

        function Ls(e, t, n) {
            Rs(e, t, n, pu())
        }

        function Rs(e, t, n, r) {
            var i = {
                lane: r,
                revertLane: 0,
                gesture: null,
                action: n,
                hasEagerState: !1,
                eagerState: null,
                next: null
            };
            if (Bs(e)) Vs(t, i);
            else {
                var a = e.alternate;
                if (e.lanes === 0 && (a === null || a.lanes === 0) && (a = t.lastRenderedReducer, a !== null)) try {
                    var o = t.lastRenderedState,
                        s = a(o, n);
                    if (i.hasEagerState = !0, i.eagerState = s, Mr(s, o)) return di(e, t, i, 0), G === null && ui(), !1
                } catch {}
                if (n = fi(e, t, i, r), n !== null) return hu(n, e, r), Hs(n, t, r), !0
            }
            return !1
        }

        function zs(e, t, n, r) {
            if (r = {
                    lane: 2,
                    revertLane: dd(),
                    gesture: null,
                    action: r,
                    hasEagerState: !1,
                    eagerState: null,
                    next: null
                }, Bs(e)) {
                if (t) throw Error(a(479))
            } else t = fi(e, n, r, 2), t !== null && hu(t, e, 2)
        }

        function Bs(e) {
            var t = e.alternate;
            return e === P || t !== null && t === P
        }

        function Vs(e, t) {
            xo = bo = !0;
            var n = e.pending;
            n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
        }

        function Hs(e, t, n) {
            if (n & 4194048) {
                var r = t.lanes;
                r &= e.pendingLanes, n |= r, t.lanes = n, ut(e, n)
            }
        }
        var Us = {
            readContext: la,
            use: Ro,
            useCallback: L,
            useContext: L,
            useEffect: L,
            useImperativeHandle: L,
            useLayoutEffect: L,
            useInsertionEffect: L,
            useMemo: L,
            useReducer: L,
            useRef: L,
            useState: L,
            useDebugValue: L,
            useDeferredValue: L,
            useTransition: L,
            useSyncExternalStore: L,
            useId: L,
            useHostTransitionStatus: L,
            useFormState: L,
            useActionState: L,
            useOptimistic: L,
            useMemoCache: L,
            useCacheRefresh: L
        };
        Us.useEffectEvent = L;
        var Ws = {
                readContext: la,
                use: Ro,
                useCallback: function(e, t) {
                    return Fo().memoizedState = [e, t === void 0 ? null : t], e
                },
                useContext: la,
                useEffect: ms,
                useImperativeHandle: function(e, t, n) {
                    n = n == null ? null : n.concat([e]), fs(4194308, 4, bs.bind(null, t, e), n)
                },
                useLayoutEffect: function(e, t) {
                    return fs(4194308, 4, e, t)
                },
                useInsertionEffect: function(e, t) {
                    fs(4, 2, e, t)
                },
                useMemo: function(e, t) {
                    var n = Fo();
                    t = t === void 0 ? null : t;
                    var r = e();
                    if (So) {
                        qe(!0);
                        try {
                            e()
                        } finally {
                            qe(!1)
                        }
                    }
                    return n.memoizedState = [r, t], r
                },
                useReducer: function(e, t, n) {
                    var r = Fo();
                    if (n !== void 0) {
                        var i = n(t);
                        if (So) {
                            qe(!0);
                            try {
                                n(t)
                            } finally {
                                qe(!1)
                            }
                        }
                    } else i = t;
                    return r.memoizedState = r.baseState = i, e = {
                        pending: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: e,
                        lastRenderedState: i
                    }, r.queue = e, e = e.dispatch = Is.bind(null, P, e), [r.memoizedState, e]
                },
                useRef: function(e) {
                    var t = Fo();
                    return e = {
                        current: e
                    }, t.memoizedState = e
                },
                useState: function(e) {
                    e = Xo(e);
                    var t = e.queue,
                        n = Ls.bind(null, P, t);
                    return t.dispatch = n, [e.memoizedState, n]
                },
                useDebugValue: Ss,
                useDeferredValue: function(e, t) {
                    return Ts(Fo(), e, t)
                },
                useTransition: function() {
                    var e = Xo(!1);
                    return e = Ds.bind(null, P, e.queue, !0, !1), Fo().memoizedState = e, [!1, e]
                },
                useSyncExternalStore: function(e, t, n) {
                    var r = P,
                        i = Fo();
                    if (j) {
                        if (n === void 0) throw Error(a(407));
                        n = n()
                    } else {
                        if (n = t(), G === null) throw Error(a(349));
                        q & 127 || Go(r, t, n)
                    }
                    i.memoizedState = n;
                    var o = {
                        value: n,
                        getSnapshot: t
                    };
                    return i.queue = o, ms(qo.bind(null, r, o, e), [e]), r.flags |= 2048, us(9, {
                        destroy: void 0
                    }, Ko.bind(null, r, o, n, t), null), n
                },
                useId: function() {
                    var e = Fo(),
                        t = G.identifierPrefix;
                    if (j) {
                        var n = Li,
                            r = Ii;
                        n = (r & ~(1 << 32 - Je(r) - 1)).toString(32) + n, t = `_` + t + `R_` + n, n = Co++, 0 < n && (t += `H` + n.toString(32)), t += `_`
                    } else n = Eo++, t = `_` + t + `r_` + n.toString(32) + `_`;
                    return e.memoizedState = t
                },
                useHostTransitionStatus: Ms,
                useFormState: as,
                useActionState: as,
                useOptimistic: function(e) {
                    var t = Fo();
                    t.memoizedState = t.baseState = e;
                    var n = {
                        pending: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: null,
                        lastRenderedState: null
                    };
                    return t.queue = n, t = zs.bind(null, P, !0, n), n.dispatch = t, [e, t]
                },
                useMemoCache: zo,
                useCacheRefresh: function() {
                    return Fo().memoizedState = Fs.bind(null, P)
                },
                useEffectEvent: function(e) {
                    var t = Fo(),
                        n = {
                            impl: e
                        };
                    return t.memoizedState = n,
                        function() {
                            if (W & 2) throw Error(a(440));
                            return n.impl.apply(void 0, arguments)
                        }
                }
            },
            Gs = {
                readContext: la,
                use: Ro,
                useCallback: Cs,
                useContext: la,
                useEffect: hs,
                useImperativeHandle: xs,
                useInsertionEffect: vs,
                useLayoutEffect: ys,
                useMemo: ws,
                useReducer: Vo,
                useRef: ds,
                useState: function() {
                    return Vo(Bo)
                },
                useDebugValue: Ss,
                useDeferredValue: function(e, t) {
                    return Es(R(), F.memoizedState, e, t)
                },
                useTransition: function() {
                    var e = Vo(Bo)[0],
                        t = R().memoizedState;
                    return [typeof e == `boolean` ? e : Lo(e), t]
                },
                useSyncExternalStore: Wo,
                useId: Ns,
                useHostTransitionStatus: Ms,
                useFormState: os,
                useActionState: os,
                useOptimistic: function(e, t) {
                    return Zo(R(), F, e, t)
                },
                useMemoCache: zo,
                useCacheRefresh: Ps
            };
        Gs.useEffectEvent = _s;
        var Ks = {
            readContext: la,
            use: Ro,
            useCallback: Cs,
            useContext: la,
            useEffect: hs,
            useImperativeHandle: xs,
            useInsertionEffect: vs,
            useLayoutEffect: ys,
            useMemo: ws,
            useReducer: Uo,
            useRef: ds,
            useState: function() {
                return Uo(Bo)
            },
            useDebugValue: Ss,
            useDeferredValue: function(e, t) {
                var n = R();
                return F === null ? Ts(n, e, t) : Es(n, F.memoizedState, e, t)
            },
            useTransition: function() {
                var e = Uo(Bo)[0],
                    t = R().memoizedState;
                return [typeof e == `boolean` ? e : Lo(e), t]
            },
            useSyncExternalStore: Wo,
            useId: Ns,
            useHostTransitionStatus: Ms,
            useFormState: ls,
            useActionState: ls,
            useOptimistic: function(e, t) {
                var n = R();
                return F === null ? (n.baseState = e, [e, n.queue.dispatch]) : Zo(n, F, e, t)
            },
            useMemoCache: zo,
            useCacheRefresh: Ps
        };
        Ks.useEffectEvent = _s;

        function qs(e, t, n, r) {
            t = e.memoizedState, n = n(r, t), n = n == null ? t : m({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
        }
        var Js = {
            enqueueSetState: function(e, t, n) {
                e = e._reactInternals;
                var r = pu(),
                    i = Xa(r);
                i.payload = t, n != null && (i.callback = n), t = Za(e, i, r), t !== null && (hu(t, e, r), Qa(t, e, r))
            },
            enqueueReplaceState: function(e, t, n) {
                e = e._reactInternals;
                var r = pu(),
                    i = Xa(r);
                i.tag = 1, i.payload = t, n != null && (i.callback = n), t = Za(e, i, r), t !== null && (hu(t, e, r), Qa(t, e, r))
            },
            enqueueForceUpdate: function(e, t) {
                e = e._reactInternals;
                var n = pu(),
                    r = Xa(n);
                r.tag = 2, t != null && (r.callback = t), t = Za(e, r, n), t !== null && (hu(t, e, n), Qa(t, e, n))
            }
        };

        function Ys(e, t, n, r, i, a, o) {
            return e = e.stateNode, typeof e.shouldComponentUpdate == `function` ? e.shouldComponentUpdate(r, a, o) : t.prototype && t.prototype.isPureReactComponent ? !Nr(n, r) || !Nr(i, a) : !0
        }

        function Xs(e, t, n, r) {
            e = t.state, typeof t.componentWillReceiveProps == `function` && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == `function` && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Js.enqueueReplaceState(t, t.state, null)
        }

        function Zs(e, t) {
            var n = t;
            if (`ref` in t)
                for (var r in n = {}, t) r !== `ref` && (n[r] = t[r]);
            if (e = e.defaultProps)
                for (var i in n === t && (n = m({}, n)), e) n[i] === void 0 && (n[i] = e[i]);
            return n
        }

        function Qs(e) {
            oi(e)
        }

        function $s(e) {}

        function ec(e) {
            oi(e)
        }

        function tc(e, t) {
            try {
                var n = e.onUncaughtError;
                n(t.value, {
                    componentStack: t.stack
                })
            } catch (e) {
                setTimeout(function() {
                    throw e
                })
            }
        }

        function nc(e, t, n) {
            try {
                var r = e.onCaughtError;
                r(n.value, {
                    componentStack: n.stack,
                    errorBoundary: t.tag === 1 ? t.stateNode : null
                })
            } catch (e) {
                setTimeout(function() {
                    throw e
                })
            }
        }

        function rc(e, t, n) {
            return n = Xa(n), n.tag = 3, n.payload = {
                element: null
            }, n.callback = function() {
                tc(e, t)
            }, n
        }

        function ic(e) {
            return e = Xa(e), e.tag = 3, e
        }

        function ac(e, t, n, r) {
            var i = n.type.getDerivedStateFromError;
            if (typeof i == `function`) {
                var a = r.value;
                e.payload = function() {
                    return i(a)
                }, e.callback = function() {
                    nc(t, n, r)
                }
            }
            var o = n.stateNode;
            o !== null && typeof o.componentDidCatch == `function` && (e.callback = function() {
                nc(t, n, r), typeof i != `function` && (iu === null ? iu = new Set([this]) : iu.add(this));
                var e = r.stack;
                this.componentDidCatch(r.value, {
                    componentStack: e === null ? `` : e
                })
            })
        }

        function oc(e, t, n, r, i) {
            if (n.flags |= 32768, typeof r == `object` && r && typeof r.then == `function`) {
                if (t = n.alternate, t !== null && oa(t, n, i, !0), n = uo.current, n !== null) {
                    switch (n.tag) {
                        case 31:
                        case 13:
                            return fo === null ? Du() : n.alternate === null && Y === 0 && (Y = 3), n.flags &= -257, n.flags |= 65536, n.lanes = i, r === Ma ? n.flags |= 16384 : (t = n.updateQueue, t === null ? n.updateQueue = new Set([r]) : t.add(r), Gu(e, r, i)), !1;
                        case 22:
                            return n.flags |= 65536, r === Ma ? n.flags |= 16384 : (t = n.updateQueue, t === null ? (t = {
                                transitions: null,
                                markerInstances: null,
                                retryQueue: new Set([r])
                            }, n.updateQueue = t) : (n = t.retryQueue, n === null ? t.retryQueue = new Set([r]) : n.add(r)), Gu(e, r, i)), !1
                    }
                    throw Error(a(435, n.tag))
                }
                return Gu(e, r, i), Du(), !1
            }
            if (j) return t = uo.current, t === null ? (r !== Gi && (t = Error(a(423), {
                cause: r
            }), Qi(Oi(t, n))), e = e.current.alternate, e.flags |= 65536, i &= -i, e.lanes |= i, r = Oi(r, n), i = rc(e.stateNode, r, i), $a(e, i), Y !== 4 && (Y = 2)) : (!(t.flags & 65536) && (t.flags |= 256), t.flags |= 65536, t.lanes = i, r !== Gi && (e = Error(a(422), {
                cause: r
            }), Qi(Oi(e, n)))), !1;
            var o = Error(a(520), {
                cause: r
            });
            if (o = Oi(o, n), Zl === null ? Zl = [o] : Zl.push(o), Y !== 4 && (Y = 2), t === null) return !0;
            r = Oi(r, n), n = t;
            do {
                switch (n.tag) {
                    case 3:
                        return n.flags |= 65536, e = i & -i, n.lanes |= e, e = rc(n.stateNode, r, e), $a(n, e), !1;
                    case 1:
                        if (t = n.type, o = n.stateNode, !(n.flags & 128) && (typeof t.getDerivedStateFromError == `function` || o !== null && typeof o.componentDidCatch == `function` && (iu === null || !iu.has(o)))) return n.flags |= 65536, i &= -i, n.lanes |= i, i = ic(i), ac(i, e, n, r), $a(n, i), !1
                }
                n = n.return
            } while (n !== null);
            return !1
        }
        var sc = Error(a(461)),
            z = !1;

        function cc(e, t, n, r) {
            t.child = e === null ? Ka(t, null, n, r) : Ga(t, e.child, n, r)
        }

        function lc(e, t, n, r, i) {
            n = n.render;
            var a = t.ref;
            if (`ref` in r) {
                var o = {};
                for (var s in r) s !== `ref` && (o[s] = r[s])
            } else o = r;
            return ca(t), r = Oo(e, t, n, o, a, i), s = Mo(), e !== null && !z ? (No(e, t, i), Nc(e, t, i)) : (j && s && Bi(t), t.flags |= 1, cc(e, t, r, i), t.child)
        }

        function uc(e, t, n, r, i) {
            if (e === null) {
                var a = n.type;
                return typeof a == `function` && !yi(a) && a.defaultProps === void 0 && n.compare === null ? (t.tag = 15, t.type = a, dc(e, t, a, r, i)) : (e = Si(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e)
            }
            if (a = e.child, !Pc(e, i)) {
                var o = a.memoizedProps;
                if (n = n.compare, n = n === null ? Nr : n, n(o, r) && e.ref === t.ref) return Nc(e, t, i)
            }
            return t.flags |= 1, e = bi(a, r), e.ref = t.ref, e.return = t, t.child = e
        }

        function dc(e, t, n, r, i) {
            if (e !== null) {
                var a = e.memoizedProps;
                if (Nr(a, r) && e.ref === t.ref)
                    if (z = !1, t.pendingProps = r = a, Pc(e, i)) e.flags & 131072 && (z = !0);
                    else return t.lanes = e.lanes, Nc(e, t, i)
            }
            return yc(e, t, n, r, i)
        }

        function fc(e, t, n, r) {
            var i = r.children,
                a = e === null ? null : e.memoizedState;
            if (e === null && t.stateNode === null && (t.stateNode = {
                    _visibility: 1,
                    _pendingMarkers: null,
                    _retryCache: null,
                    _transitions: null
                }), r.mode === `hidden`) {
                if (t.flags & 128) {
                    if (a = a === null ? n : a.baseLanes | n, e !== null) {
                        for (r = t.child = e.child, i = 0; r !== null;) i = i | r.lanes | r.childLanes, r = r.sibling;
                        r = i & ~a
                    } else r = 0, t.child = null;
                    return mc(e, t, a, n, r)
                }
                if (n & 536870912) t.memoizedState = {
                    baseLanes: 0,
                    cachePool: null
                }, e !== null && Da(t, a === null ? null : a.cachePool), a === null ? co() : so(t, a), ho(t);
                else return r = t.lanes = 536870912, mc(e, t, a === null ? n : a.baseLanes | n, n, r)
            } else a === null ? (e !== null && Da(t, null), co(), go(t)) : (Da(t, a.cachePool), so(t, a), go(t), t.memoizedState = null);
            return cc(e, t, i, n), t.child
        }

        function pc(e, t) {
            return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
                _visibility: 1,
                _pendingMarkers: null,
                _retryCache: null,
                _transitions: null
            }), t.sibling
        }

        function mc(e, t, n, r, i) {
            var a = Ea();
            return a = a === null ? null : {
                parent: M._currentValue,
                pool: a
            }, t.memoizedState = {
                baseLanes: n,
                cachePool: a
            }, e !== null && Da(t, null), co(), ho(t), e !== null && oa(e, t, r, !0), t.childLanes = i, null
        }

        function hc(e, t) {
            return t = Oc({
                mode: t.mode,
                children: t.children
            }, e.mode), t.ref = e.ref, e.child = t, t.return = e, t
        }

        function gc(e, t, n) {
            return Ga(t, e.child, null, n), e = hc(t, t.pendingProps), e.flags |= 2, _o(t), t.memoizedState = null, e
        }

        function _c(e, t, n) {
            var r = t.pendingProps,
                i = (t.flags & 128) != 0;
            if (t.flags &= -129, e === null) {
                if (j) {
                    if (r.mode === `hidden`) return e = hc(t, r), t.lanes = 536870912, pc(null, e);
                    if (mo(t), (e = A) ? (e = rf(e, Wi), e = e !== null && e.data === `&` ? e : null, e !== null && (t.memoizedState = {
                            dehydrated: e,
                            treeContext: Fi === null ? null : {
                                id: Ii,
                                overflow: Li
                            },
                            retryLane: 536870912,
                            hydrationErrors: null
                        }, n = Ti(e), n.return = t, t.child = n, k = t, A = null)) : e = null, e === null) throw Ki(t);
                    return t.lanes = 536870912, null
                }
                return hc(t, r)
            }
            var o = e.memoizedState;
            if (o !== null) {
                var s = o.dehydrated;
                if (mo(t), i)
                    if (t.flags & 256) t.flags &= -257, t = gc(e, t, n);
                    else if (t.memoizedState !== null) t.child = e.child, t.flags |= 128, t = null;
                else throw Error(a(558));
                else if (z || oa(e, t, n, !1), i = (n & e.childLanes) !== 0, z || i) {
                    if (r = G, r !== null && (s = dt(r, n), s !== 0 && s !== o.retryLane)) throw o.retryLane = s, pi(e, s), hu(r, e, s), sc;
                    Du(), t = gc(e, t, n)
                } else e = o.treeContext, A = cf(s.nextSibling), k = t, j = !0, Ui = null, Wi = !1, e !== null && Hi(t, e), t = hc(t, r), t.flags |= 4096;
                return t
            }
            return e = bi(e.child, {
                mode: r.mode,
                children: r.children
            }), e.ref = t.ref, t.child = e, e.return = t, e
        }

        function vc(e, t) {
            var n = t.ref;
            if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
            else {
                if (typeof n != `function` && typeof n != `object`) throw Error(a(284));
                (e === null || e.ref !== n) && (t.flags |= 4194816)
            }
        }

        function yc(e, t, n, r, i) {
            return ca(t), n = Oo(e, t, n, r, void 0, i), r = Mo(), e !== null && !z ? (No(e, t, i), Nc(e, t, i)) : (j && r && Bi(t), t.flags |= 1, cc(e, t, n, i), t.child)
        }

        function bc(e, t, n, r, i, a) {
            return ca(t), t.updateQueue = null, n = Ao(t, r, n, i), ko(e), r = Mo(), e !== null && !z ? (No(e, t, a), Nc(e, t, a)) : (j && r && Bi(t), t.flags |= 1, cc(e, t, n, a), t.child)
        }

        function xc(e, t, n, r, i) {
            if (ca(t), t.stateNode === null) {
                var a = gi,
                    o = n.contextType;
                typeof o == `object` && o && (a = la(o)), a = new n(r, a), t.memoizedState = a.state !== null && a.state !== void 0 ? a.state : null, a.updater = Js, t.stateNode = a, a._reactInternals = t, a = t.stateNode, a.props = r, a.state = t.memoizedState, a.refs = {}, Ja(t), o = n.contextType, a.context = typeof o == `object` && o ? la(o) : gi, a.state = t.memoizedState, o = n.getDerivedStateFromProps, typeof o == `function` && (qs(t, n, o, r), a.state = t.memoizedState), typeof n.getDerivedStateFromProps == `function` || typeof a.getSnapshotBeforeUpdate == `function` || typeof a.UNSAFE_componentWillMount != `function` && typeof a.componentWillMount != `function` || (o = a.state, typeof a.componentWillMount == `function` && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == `function` && a.UNSAFE_componentWillMount(), o !== a.state && Js.enqueueReplaceState(a, a.state, null), no(t, r, a, i), to(), a.state = t.memoizedState), typeof a.componentDidMount == `function` && (t.flags |= 4194308), r = !0
            } else if (e === null) {
                a = t.stateNode;
                var s = t.memoizedProps,
                    c = Zs(n, s);
                a.props = c;
                var l = a.context,
                    u = n.contextType;
                o = gi, typeof u == `object` && u && (o = la(u));
                var d = n.getDerivedStateFromProps;
                u = typeof d == `function` || typeof a.getSnapshotBeforeUpdate == `function`, s = t.pendingProps !== s, u || typeof a.UNSAFE_componentWillReceiveProps != `function` && typeof a.componentWillReceiveProps != `function` || (s || l !== o) && Xs(t, a, r, o), qa = !1;
                var f = t.memoizedState;
                a.state = f, no(t, r, a, i), to(), l = t.memoizedState, s || f !== l || qa ? (typeof d == `function` && (qs(t, n, d, r), l = t.memoizedState), (c = qa || Ys(t, n, c, r, f, l, o)) ? (u || typeof a.UNSAFE_componentWillMount != `function` && typeof a.componentWillMount != `function` || (typeof a.componentWillMount == `function` && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == `function` && a.UNSAFE_componentWillMount()), typeof a.componentDidMount == `function` && (t.flags |= 4194308)) : (typeof a.componentDidMount == `function` && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = l), a.props = r, a.state = l, a.context = o, r = c) : (typeof a.componentDidMount == `function` && (t.flags |= 4194308), r = !1)
            } else {
                a = t.stateNode, Ya(e, t), o = t.memoizedProps, u = Zs(n, o), a.props = u, d = t.pendingProps, f = a.context, l = n.contextType, c = gi, typeof l == `object` && l && (c = la(l)), s = n.getDerivedStateFromProps, (l = typeof s == `function` || typeof a.getSnapshotBeforeUpdate == `function`) || typeof a.UNSAFE_componentWillReceiveProps != `function` && typeof a.componentWillReceiveProps != `function` || (o !== d || f !== c) && Xs(t, a, r, c), qa = !1, f = t.memoizedState, a.state = f, no(t, r, a, i), to();
                var p = t.memoizedState;
                o !== d || f !== p || qa || e !== null && e.dependencies !== null && sa(e.dependencies) ? (typeof s == `function` && (qs(t, n, s, r), p = t.memoizedState), (u = qa || Ys(t, n, u, r, f, p, c) || e !== null && e.dependencies !== null && sa(e.dependencies)) ? (l || typeof a.UNSAFE_componentWillUpdate != `function` && typeof a.componentWillUpdate != `function` || (typeof a.componentWillUpdate == `function` && a.componentWillUpdate(r, p, c), typeof a.UNSAFE_componentWillUpdate == `function` && a.UNSAFE_componentWillUpdate(r, p, c)), typeof a.componentDidUpdate == `function` && (t.flags |= 4), typeof a.getSnapshotBeforeUpdate == `function` && (t.flags |= 1024)) : (typeof a.componentDidUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = p), a.props = r, a.state = p, a.context = c, r = u) : (typeof a.componentDidUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1)
            }
            return a = r, vc(e, t), r = (t.flags & 128) != 0, a || r ? (a = t.stateNode, n = r && typeof n.getDerivedStateFromError != `function` ? null : a.render(), t.flags |= 1, e !== null && r ? (t.child = Ga(t, e.child, null, i), t.child = Ga(t, null, n, i)) : cc(e, t, n, i), t.memoizedState = a.state, e = t.child) : e = Nc(e, t, i), e
        }

        function Sc(e, t, n, r) {
            return Xi(), t.flags |= 256, cc(e, t, n, r), t.child
        }
        var Cc = {
            dehydrated: null,
            treeContext: null,
            retryLane: 0,
            hydrationErrors: null
        };

        function wc(e) {
            return {
                baseLanes: e,
                cachePool: Oa()
            }
        }

        function Tc(e, t, n) {
            return e = e === null ? 0 : e.childLanes & ~n, t && (e |= Yl), e
        }

        function Ec(e, t, n) {
            var r = t.pendingProps,
                i = !1,
                o = (t.flags & 128) != 0,
                s;
            if ((s = o) || (s = e !== null && e.memoizedState === null ? !1 : (N.current & 2) != 0), s && (i = !0, t.flags &= -129), s = (t.flags & 32) != 0, t.flags &= -33, e === null) {
                if (j) {
                    if (i ? po(t) : go(t), (e = A) ? (e = rf(e, Wi), e = e !== null && e.data !== `&` ? e : null, e !== null && (t.memoizedState = {
                            dehydrated: e,
                            treeContext: Fi === null ? null : {
                                id: Ii,
                                overflow: Li
                            },
                            retryLane: 536870912,
                            hydrationErrors: null
                        }, n = Ti(e), n.return = t, t.child = n, k = t, A = null)) : e = null, e === null) throw Ki(t);
                    return of(e) ? t.lanes = 32 : t.lanes = 536870912, null
                }
                var c = r.children;
                return r = r.fallback, i ? (go(t), i = t.mode, c = Oc({
                    mode: `hidden`,
                    children: c
                }, i), r = Ci(r, i, n, null), c.return = t, r.return = t, c.sibling = r, t.child = c, r = t.child, r.memoizedState = wc(n), r.childLanes = Tc(e, s, n), t.memoizedState = Cc, pc(null, r)) : (po(t), Dc(t, c))
            }
            var l = e.memoizedState;
            if (l !== null && (c = l.dehydrated, c !== null)) {
                if (o) t.flags & 256 ? (po(t), t.flags &= -257, t = kc(e, t, n)) : t.memoizedState === null ? (go(t), c = r.fallback, i = t.mode, r = Oc({
                    mode: `visible`,
                    children: r.children
                }, i), c = Ci(c, i, n, null), c.flags |= 2, r.return = t, c.return = t, r.sibling = c, t.child = r, Ga(t, e.child, null, n), r = t.child, r.memoizedState = wc(n), r.childLanes = Tc(e, s, n), t.memoizedState = Cc, t = pc(null, r)) : (go(t), t.child = e.child, t.flags |= 128, t = null);
                else if (po(t), of (c)) {
                    if (s = c.nextSibling && c.nextSibling.dataset, s) var u = s.dgst;
                    s = u, r = Error(a(419)), r.stack = ``, r.digest = s, Qi({
                        value: r,
                        source: null,
                        stack: null
                    }), t = kc(e, t, n)
                } else if (z || oa(e, t, n, !1), s = (n & e.childLanes) !== 0, z || s) {
                    if (s = G, s !== null && (r = dt(s, n), r !== 0 && r !== l.retryLane)) throw l.retryLane = r, pi(e, r), hu(s, e, r), sc;
                    af(c) || Du(), t = kc(e, t, n)
                } else af(c) ? (t.flags |= 192, t.child = e.child, t = null) : (e = l.treeContext, A = cf(c.nextSibling), k = t, j = !0, Ui = null, Wi = !1, e !== null && Hi(t, e), t = Dc(t, r.children), t.flags |= 4096);
                return t
            }
            return i ? (go(t), c = r.fallback, i = t.mode, l = e.child, u = l.sibling, r = bi(l, {
                mode: `hidden`,
                children: r.children
            }), r.subtreeFlags = l.subtreeFlags & 65011712, u === null ? (c = Ci(c, i, n, null), c.flags |= 2) : c = bi(u, c), c.return = t, r.return = t, r.sibling = c, t.child = r, pc(null, r), r = t.child, c = e.child.memoizedState, c === null ? c = wc(n) : (i = c.cachePool, i === null ? i = Oa() : (l = M._currentValue, i = i.parent === l ? i : {
                parent: l,
                pool: l
            }), c = {
                baseLanes: c.baseLanes | n,
                cachePool: i
            }), r.memoizedState = c, r.childLanes = Tc(e, s, n), t.memoizedState = Cc, pc(e.child, r)) : (po(t), n = e.child, e = n.sibling, n = bi(n, {
                mode: `visible`,
                children: r.children
            }), n.return = t, n.sibling = null, e !== null && (s = t.deletions, s === null ? (t.deletions = [e], t.flags |= 16) : s.push(e)), t.child = n, t.memoizedState = null, n)
        }

        function Dc(e, t) {
            return t = Oc({
                mode: `visible`,
                children: t
            }, e.mode), t.return = e, e.child = t
        }

        function Oc(e, t) {
            return e = vi(22, e, null, t), e.lanes = 0, e
        }

        function kc(e, t, n) {
            return Ga(t, e.child, null, n), e = Dc(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
        }

        function Ac(e, t, n) {
            e.lanes |= t;
            var r = e.alternate;
            r !== null && (r.lanes |= t), ia(e.return, t, n)
        }

        function jc(e, t, n, r, i, a) {
            var o = e.memoizedState;
            o === null ? e.memoizedState = {
                isBackwards: t,
                rendering: null,
                renderingStartTime: 0,
                last: r,
                tail: n,
                tailMode: i,
                treeForkCount: a
            } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i, o.treeForkCount = a)
        }

        function Mc(e, t, n) {
            var r = t.pendingProps,
                i = r.revealOrder,
                a = r.tail;
            r = r.children;
            var o = N.current,
                s = (o & 2) != 0;
            if (s ? (o = o & 1 | 2, t.flags |= 128) : o &= 1, D(N, o), cc(e, t, r, n), r = j ? Mi : 0, !s && e !== null && e.flags & 128) a: for (e = t.child; e !== null;) {
                if (e.tag === 13) e.memoizedState !== null && Ac(e, n, t);
                else if (e.tag === 19) Ac(e, n, t);
                else if (e.child !== null) {
                    e.child.return = e, e = e.child;
                    continue
                }
                if (e === t) break a;
                for (; e.sibling === null;) {
                    if (e.return === null || e.return === t) break a;
                    e = e.return
                }
                e.sibling.return = e.return, e = e.sibling
            }
            switch (i) {
                case `forwards`:
                    for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && vo(e) === null && (i = n), n = n.sibling;
                    n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), jc(t, !1, i, n, a, r);
                    break;
                case `backwards`:
                case `unstable_legacy-backwards`:
                    for (n = null, i = t.child, t.child = null; i !== null;) {
                        if (e = i.alternate, e !== null && vo(e) === null) {
                            t.child = i;
                            break
                        }
                        e = i.sibling, i.sibling = n, n = i, i = e
                    }
                    jc(t, !0, n, null, a, r);
                    break;
                case `together`:
                    jc(t, !1, null, null, void 0, r);
                    break;
                default:
                    t.memoizedState = null
            }
            return t.child
        }

        function Nc(e, t, n) {
            if (e !== null && (t.dependencies = e.dependencies), Kl |= t.lanes, (n & t.childLanes) === 0)
                if (e !== null) {
                    if (oa(e, t, n, !1), (n & t.childLanes) === 0) return null
                } else return null;
            if (e !== null && t.child !== e.child) throw Error(a(153));
            if (t.child !== null) {
                for (e = t.child, n = bi(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = bi(e, e.pendingProps), n.return = t;
                n.sibling = null
            }
            return t.child
        }

        function Pc(e, t) {
            return (e.lanes & t) === 0 ? (e = e.dependencies, !!(e !== null && sa(e))) : !0
        }

        function Fc(e, t, n) {
            switch (t.tag) {
                case 3:
                    be(t, t.stateNode.containerInfo), na(t, M, e.memoizedState.cache), Xi();
                    break;
                case 27:
                case 5:
                    Se(t);
                    break;
                case 4:
                    be(t, t.stateNode.containerInfo);
                    break;
                case 10:
                    na(t, t.type, t.memoizedProps.value);
                    break;
                case 31:
                    if (t.memoizedState !== null) return t.flags |= 128, mo(t), null;
                    break;
                case 13:
                    var r = t.memoizedState;
                    if (r !== null) return r.dehydrated === null ? (n & t.child.childLanes) === 0 ? (po(t), e = Nc(e, t, n), e === null ? null : e.sibling) : Ec(e, t, n) : (po(t), t.flags |= 128, null);
                    po(t);
                    break;
                case 19:
                    var i = (e.flags & 128) != 0;
                    if (r = (n & t.childLanes) !== 0, r || = (oa(e, t, n, !1), (n & t.childLanes) !== 0), i) {
                        if (r) return Mc(e, t, n);
                        t.flags |= 128
                    }
                    if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), D(N, N.current), r) break;
                    return null;
                case 22:
                    return t.lanes = 0, fc(e, t, n, t.pendingProps);
                case 24:
                    na(t, M, e.memoizedState.cache)
            }
            return Nc(e, t, n)
        }

        function Ic(e, t, n) {
            if (e !== null)
                if (e.memoizedProps !== t.pendingProps) z = !0;
                else {
                    if (!Pc(e, n) && !(t.flags & 128)) return z = !1, Fc(e, t, n);
                    z = !!(e.flags & 131072)
                }
            else z = !1, j && t.flags & 1048576 && zi(t, Mi, t.index);
            switch (t.lanes = 0, t.tag) {
                case 16:
                    a: {
                        var r = t.pendingProps;
                        if (e = Fa(t.elementType), t.type = e, typeof e == `function`) yi(e) ? (r = Zs(e, r), t.tag = 1, t = xc(null, t, e, r, n)) : (t.tag = 0, t = yc(null, t, e, r, n));
                        else {
                            if (e != null) {
                                var i = e.$$typeof;
                                if (i === ne) {
                                    t.tag = 11, t = lc(null, t, e, r, n);
                                    break a
                                } else if (i === ae) {
                                    t.tag = 14, t = uc(null, t, e, r, n);
                                    break a
                                }
                            }
                            throw t = ue(e) || e, Error(a(306, t, ``))
                        }
                    }
                    return t;
                case 0:
                    return yc(e, t, t.type, t.pendingProps, n);
                case 1:
                    return r = t.type, i = Zs(r, t.pendingProps), xc(e, t, r, i, n);
                case 3:
                    a: {
                        if (be(t, t.stateNode.containerInfo), e === null) throw Error(a(387));r = t.pendingProps;
                        var o = t.memoizedState;i = o.element,
                        Ya(e, t),
                        no(t, r, null, n);
                        var s = t.memoizedState;
                        if (r = s.cache, na(t, M, r), r !== o.cache && aa(t, [M], n, !0), to(), r = s.element, o.isDehydrated)
                            if (o = {
                                    element: r,
                                    isDehydrated: !1,
                                    cache: s.cache
                                }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
                                t = Sc(e, t, r, n);
                                break a
                            } else if (r !== i) {
                            i = Oi(Error(a(424)), t), Qi(i), t = Sc(e, t, r, n);
                            break a
                        } else {
                            switch (e = t.stateNode.containerInfo, e.nodeType) {
                                case 9:
                                    e = e.body;
                                    break;
                                default:
                                    e = e.nodeName === `HTML` ? e.ownerDocument.body : e
                            }
                            for (A = cf(e.firstChild), k = t, j = !0, Ui = null, Wi = !0, n = Ka(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling
                        } else {
                            if (Xi(), r === i) {
                                t = Nc(e, t, n);
                                break a
                            }
                            cc(e, t, r, n)
                        }
                        t = t.child
                    }
                    return t;
                case 26:
                    return vc(e, t), e === null ? (n = kf(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : j || (n = t.type, e = t.pendingProps, r = Bd(ve.current).createElement(n), r[_t] = t, r[vt] = e, Pd(r, n, e), O(r), t.stateNode = r) : t.memoizedState = kf(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
                case 27:
                    return Se(t), e === null && j && (r = t.stateNode = ff(t.type, t.pendingProps, ve.current), k = t, Wi = !0, i = A, Zd(t.type) ? (lf = i, A = cf(r.firstChild)) : A = i), cc(e, t, t.pendingProps.children, n), vc(e, t), e === null && (t.flags |= 4194304), t.child;
                case 5:
                    return e === null && j && ((i = r = A) && (r = tf(r, t.type, t.pendingProps, Wi), r === null ? i = !1 : (t.stateNode = r, k = t, A = cf(r.firstChild), Wi = !1, i = !0)), i || Ki(t)), Se(t), i = t.type, o = t.pendingProps, s = e === null ? null : e.memoizedProps, r = o.children, Ud(i, o) ? r = null : s !== null && Ud(i, s) && (t.flags |= 32), t.memoizedState !== null && (i = Oo(e, t, jo, null, null, n), Qf._currentValue = i), vc(e, t), cc(e, t, r, n), t.child;
                case 6:
                    return e === null && j && ((e = n = A) && (n = nf(n, t.pendingProps, Wi), n === null ? e = !1 : (t.stateNode = n, k = t, A = null, e = !0)), e || Ki(t)), null;
                case 13:
                    return Ec(e, t, n);
                case 4:
                    return be(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = Ga(t, null, r, n) : cc(e, t, r, n), t.child;
                case 11:
                    return lc(e, t, t.type, t.pendingProps, n);
                case 7:
                    return cc(e, t, t.pendingProps, n), t.child;
                case 8:
                    return cc(e, t, t.pendingProps.children, n), t.child;
                case 12:
                    return cc(e, t, t.pendingProps.children, n), t.child;
                case 10:
                    return r = t.pendingProps, na(t, t.type, r.value), cc(e, t, r.children, n), t.child;
                case 9:
                    return i = t.type._context, r = t.pendingProps.children, ca(t), i = la(i), r = r(i), t.flags |= 1, cc(e, t, r, n), t.child;
                case 14:
                    return uc(e, t, t.type, t.pendingProps, n);
                case 15:
                    return dc(e, t, t.type, t.pendingProps, n);
                case 19:
                    return Mc(e, t, n);
                case 31:
                    return _c(e, t, n);
                case 22:
                    return fc(e, t, n, t.pendingProps);
                case 24:
                    return ca(t), r = la(M), e === null ? (i = Ea(), i === null && (i = G, o = ha(), i.pooledCache = o, o.refCount++, o !== null && (i.pooledCacheLanes |= n), i = o), t.memoizedState = {
                        parent: r,
                        cache: i
                    }, Ja(t), na(t, M, i)) : ((e.lanes & n) !== 0 && (Ya(e, t), no(t, null, null, n), to()), i = e.memoizedState, o = t.memoizedState, i.parent === r ? (r = o.cache, na(t, M, r), r !== i.cache && aa(t, [M], n, !0)) : (i = {
                        parent: r,
                        cache: r
                    }, t.memoizedState = i, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = i), na(t, M, r))), cc(e, t, t.pendingProps.children, n), t.child;
                case 29:
                    throw t.pendingProps
            }
            throw Error(a(156, t.tag))
        }

        function Lc(e) {
            e.flags |= 4
        }

        function Rc(e, t, n, r, i) {
            if ((t = (e.mode & 32) != 0) && (t = !1), t) {
                if (e.flags |= 16777216, (i & 335544128) === i)
                    if (e.stateNode.complete) e.flags |= 8192;
                    else if (wu()) e.flags |= 8192;
                else throw Ia = Ma, Aa
            } else e.flags &= -16777217
        }

        function zc(e, t) {
            if (t.type !== `stylesheet` || t.state.loading & 4) e.flags &= -16777217;
            else if (e.flags |= 16777216, !Wf(t))
                if (wu()) e.flags |= 8192;
                else throw Ia = Ma, Aa
        }

        function Bc(e, t) {
            t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag === 22 ? 536870912 : at(), e.lanes |= t, Xl |= t)
        }

        function Vc(e, t) {
            if (!j) switch (e.tailMode) {
                case `hidden`:
                    t = e.tail;
                    for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
                    n === null ? e.tail = null : n.sibling = null;
                    break;
                case `collapsed`:
                    n = e.tail;
                    for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
                    r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
            }
        }

        function B(e) {
            var t = e.alternate !== null && e.alternate.child === e.child,
                n = 0,
                r = 0;
            if (t)
                for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 65011712, r |= i.flags & 65011712, i.return = e, i = i.sibling;
            else
                for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
            return e.subtreeFlags |= r, e.childLanes = n, t
        }

        function Hc(e, t, n) {
            var r = t.pendingProps;
            switch (Vi(t), t.tag) {
                case 16:
                case 15:
                case 0:
                case 11:
                case 7:
                case 8:
                case 12:
                case 9:
                case 14:
                    return B(t), null;
                case 1:
                    return B(t), null;
                case 3:
                    return n = t.stateNode, r = null, e !== null && (r = e.memoizedState.cache), t.memoizedState.cache !== r && (t.flags |= 2048), ra(M), xe(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (Yi(t) ? Lc(t) : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Zi())), B(t), null;
                case 26:
                    var i = t.type,
                        o = t.memoizedState;
                    return e === null ? (Lc(t), o === null ? (B(t), Rc(t, i, null, r, n)) : (B(t), zc(t, o))) : o ? o === e.memoizedState ? (B(t), t.flags &= -16777217) : (Lc(t), B(t), zc(t, o)) : (e = e.memoizedProps, e !== r && Lc(t), B(t), Rc(t, i, e, r, n)), null;
                case 27:
                    if (Ce(t), n = ve.current, i = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && Lc(t);
                    else {
                        if (!r) {
                            if (t.stateNode === null) throw Error(a(166));
                            return B(t), null
                        }
                        e = ge.current, Yi(t) ? qi(t, e) : (e = ff(i, r, n), t.stateNode = e, Lc(t))
                    }
                    return B(t), null;
                case 5:
                    if (Ce(t), i = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && Lc(t);
                    else {
                        if (!r) {
                            if (t.stateNode === null) throw Error(a(166));
                            return B(t), null
                        }
                        if (o = ge.current, Yi(t)) qi(t, o);
                        else {
                            var s = Bd(ve.current);
                            switch (o) {
                                case 1:
                                    o = s.createElementNS(`http://www.w3.org/2000/svg`, i);
                                    break;
                                case 2:
                                    o = s.createElementNS(`http://www.w3.org/1998/Math/MathML`, i);
                                    break;
                                default:
                                    switch (i) {
                                        case `svg`:
                                            o = s.createElementNS(`http://www.w3.org/2000/svg`, i);
                                            break;
                                        case `math`:
                                            o = s.createElementNS(`http://www.w3.org/1998/Math/MathML`, i);
                                            break;
                                        case `script`:
                                            o = s.createElement(`div`), o.innerHTML = `<script><\/script>`, o = o.removeChild(o.firstChild);
                                            break;
                                        case `select`:
                                            o = typeof r.is == `string` ? s.createElement(`select`, {
                                                is: r.is
                                            }) : s.createElement(`select`), r.multiple ? o.multiple = !0 : r.size && (o.size = r.size);
                                            break;
                                        default:
                                            o = typeof r.is == `string` ? s.createElement(i, {
                                                is: r.is
                                            }) : s.createElement(i)
                                    }
                            }
                            o[_t] = t, o[vt] = r;
                            a: for (s = t.child; s !== null;) {
                                if (s.tag === 5 || s.tag === 6) o.appendChild(s.stateNode);
                                else if (s.tag !== 4 && s.tag !== 27 && s.child !== null) {
                                    s.child.return = s, s = s.child;
                                    continue
                                }
                                if (s === t) break a;
                                for (; s.sibling === null;) {
                                    if (s.return === null || s.return === t) break a;
                                    s = s.return
                                }
                                s.sibling.return = s.return, s = s.sibling
                            }
                            t.stateNode = o;
                            a: switch (Pd(o, i, r), i) {
                                case `button`:
                                case `input`:
                                case `select`:
                                case `textarea`:
                                    r = !!r.autoFocus;
                                    break a;
                                case `img`:
                                    r = !0;
                                    break a;
                                default:
                                    r = !1
                            }
                            r && Lc(t)
                        }
                    }
                    return B(t), Rc(t, t.type, e === null ? null : e.memoizedProps, t.pendingProps, n), null;
                case 6:
                    if (e && t.stateNode != null) e.memoizedProps !== r && Lc(t);
                    else {
                        if (typeof r != `string` && t.stateNode === null) throw Error(a(166));
                        if (e = ve.current, Yi(t)) {
                            if (e = t.stateNode, n = t.memoizedProps, r = null, i = k, i !== null) switch (i.tag) {
                                case 27:
                                case 5:
                                    r = i.memoizedProps
                            }
                            e[_t] = t, e = !!(e.nodeValue === n || r !== null && !0 === r.suppressHydrationWarning || Md(e.nodeValue, n)), e || Ki(t, !0)
                        } else e = Bd(e).createTextNode(r), e[_t] = t, t.stateNode = e
                    }
                    return B(t), null;
                case 31:
                    if (n = t.memoizedState, e === null || e.memoizedState !== null) {
                        if (r = Yi(t), n !== null) {
                            if (e === null) {
                                if (!r) throw Error(a(318));
                                if (e = t.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(a(557));
                                e[_t] = t
                            } else Xi(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                            B(t), e = !1
                        } else n = Zi(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = n), e = !0;
                        if (!e) return t.flags & 256 ? (_o(t), t) : (_o(t), null);
                        if (t.flags & 128) throw Error(a(558))
                    }
                    return B(t), null;
                case 13:
                    if (r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                        if (i = Yi(t), r !== null && r.dehydrated !== null) {
                            if (e === null) {
                                if (!i) throw Error(a(318));
                                if (i = t.memoizedState, i = i === null ? null : i.dehydrated, !i) throw Error(a(317));
                                i[_t] = t
                            } else Xi(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                            B(t), i = !1
                        } else i = Zi(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = i), i = !0;
                        if (!i) return t.flags & 256 ? (_o(t), t) : (_o(t), null)
                    }
                    return _o(t), t.flags & 128 ? (t.lanes = n, t) : (n = r !== null, e = e !== null && e.memoizedState !== null, n && (r = t.child, i = null, r.alternate !== null && r.alternate.memoizedState !== null && r.alternate.memoizedState.cachePool !== null && (i = r.alternate.memoizedState.cachePool.pool), o = null, r.memoizedState !== null && r.memoizedState.cachePool !== null && (o = r.memoizedState.cachePool.pool), o !== i && (r.flags |= 2048)), n !== e && n && (t.child.flags |= 8192), Bc(t, t.updateQueue), B(t), null);
                case 4:
                    return xe(), e === null && Sd(t.stateNode.containerInfo), B(t), null;
                case 10:
                    return ra(t.type), B(t), null;
                case 19:
                    if (E(N), r = t.memoizedState, r === null) return B(t), null;
                    if (i = (t.flags & 128) != 0, o = r.rendering, o === null)
                        if (i) Vc(r, !1);
                        else {
                            if (Y !== 0 || e !== null && e.flags & 128)
                                for (e = t.child; e !== null;) {
                                    if (o = vo(e), o !== null) {
                                        for (t.flags |= 128, Vc(r, !1), e = o.updateQueue, t.updateQueue = e, Bc(t, e), t.subtreeFlags = 0, e = n, n = t.child; n !== null;) xi(n, e), n = n.sibling;
                                        return D(N, N.current & 1 | 2), j && Ri(t, r.treeForkCount), t.child
                                    }
                                    e = e.sibling
                                }
                            r.tail !== null && Ie() > nu && (t.flags |= 128, i = !0, Vc(r, !1), t.lanes = 4194304)
                        }
                    else {
                        if (!i)
                            if (e = vo(o), e !== null) {
                                if (t.flags |= 128, i = !0, e = e.updateQueue, t.updateQueue = e, Bc(t, e), Vc(r, !0), r.tail === null && r.tailMode === `hidden` && !o.alternate && !j) return B(t), null
                            } else 2 * Ie() - r.renderingStartTime > nu && n !== 536870912 && (t.flags |= 128, i = !0, Vc(r, !1), t.lanes = 4194304);
                        r.isBackwards ? (o.sibling = t.child, t.child = o) : (e = r.last, e === null ? t.child = o : e.sibling = o, r.last = o)
                    }
                    return r.tail === null ? (B(t), null) : (e = r.tail, r.rendering = e, r.tail = e.sibling, r.renderingStartTime = Ie(), e.sibling = null, n = N.current, D(N, i ? n & 1 | 2 : n & 1), j && Ri(t, r.treeForkCount), e);
                case 22:
                case 23:
                    return _o(t), lo(), r = t.memoizedState !== null, e === null ? r && (t.flags |= 8192) : e.memoizedState !== null !== r && (t.flags |= 8192), r ? n & 536870912 && !(t.flags & 128) && (B(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : B(t), n = t.updateQueue, n !== null && Bc(t, n.retryQueue), n = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), r = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (r = t.memoizedState.cachePool.pool), r !== n && (t.flags |= 2048), e !== null && E(Ta), null;
                case 24:
                    return n = null, e !== null && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), ra(M), B(t), null;
                case 25:
                    return null;
                case 30:
                    return null
            }
            throw Error(a(156, t.tag))
        }

        function Uc(e, t) {
            switch (Vi(t), t.tag) {
                case 1:
                    return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 3:
                    return ra(M), xe(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
                case 26:
                case 27:
                case 5:
                    return Ce(t), null;
                case 31:
                    if (t.memoizedState !== null) {
                        if (_o(t), t.alternate === null) throw Error(a(340));
                        Xi()
                    }
                    return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 13:
                    if (_o(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                        if (t.alternate === null) throw Error(a(340));
                        Xi()
                    }
                    return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 19:
                    return E(N), null;
                case 4:
                    return xe(), null;
                case 10:
                    return ra(t.type), null;
                case 22:
                case 23:
                    return _o(t), lo(), e !== null && E(Ta), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 24:
                    return ra(M), null;
                case 25:
                    return null;
                default:
                    return null
            }
        }

        function Wc(e, t) {
            switch (Vi(t), t.tag) {
                case 3:
                    ra(M), xe();
                    break;
                case 26:
                case 27:
                case 5:
                    Ce(t);
                    break;
                case 4:
                    xe();
                    break;
                case 31:
                    t.memoizedState !== null && _o(t);
                    break;
                case 13:
                    _o(t);
                    break;
                case 19:
                    E(N);
                    break;
                case 10:
                    ra(t.type);
                    break;
                case 22:
                case 23:
                    _o(t), lo(), e !== null && E(Ta);
                    break;
                case 24:
                    ra(M)
            }
        }

        function Gc(e, t) {
            try {
                var n = t.updateQueue,
                    r = n === null ? null : n.lastEffect;
                if (r !== null) {
                    var i = r.next;
                    n = i;
                    do {
                        if ((n.tag & e) === e) {
                            r = void 0;
                            var a = n.create,
                                o = n.inst;
                            r = a(), o.destroy = r
                        }
                        n = n.next
                    } while (n !== i)
                }
            } catch (e) {
                Z(t, t.return, e)
            }
        }

        function Kc(e, t, n) {
            try {
                var r = t.updateQueue,
                    i = r === null ? null : r.lastEffect;
                if (i !== null) {
                    var a = i.next;
                    r = a;
                    do {
                        if ((r.tag & e) === e) {
                            var o = r.inst,
                                s = o.destroy;
                            if (s !== void 0) {
                                o.destroy = void 0, i = t;
                                var c = n,
                                    l = s;
                                try {
                                    l()
                                } catch (e) {
                                    Z(i, c, e)
                                }
                            }
                        }
                        r = r.next
                    } while (r !== a)
                }
            } catch (e) {
                Z(t, t.return, e)
            }
        }

        function qc(e) {
            var t = e.updateQueue;
            if (t !== null) {
                var n = e.stateNode;
                try {
                    io(t, n)
                } catch (t) {
                    Z(e, e.return, t)
                }
            }
        }

        function Jc(e, t, n) {
            n.props = Zs(e.type, e.memoizedProps), n.state = e.memoizedState;
            try {
                n.componentWillUnmount()
            } catch (n) {
                Z(e, t, n)
            }
        }

        function Yc(e, t) {
            try {
                var n = e.ref;
                if (n !== null) {
                    switch (e.tag) {
                        case 26:
                        case 27:
                        case 5:
                            var r = e.stateNode;
                            break;
                        case 30:
                            r = e.stateNode;
                            break;
                        default:
                            r = e.stateNode
                    }
                    typeof n == `function` ? e.refCleanup = n(r) : n.current = r
                }
            } catch (n) {
                Z(e, t, n)
            }
        }

        function Xc(e, t) {
            var n = e.ref,
                r = e.refCleanup;
            if (n !== null)
                if (typeof r == `function`) try {
                    r()
                } catch (n) {
                    Z(e, t, n)
                } finally {
                    e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null)
                } else if (typeof n == `function`) try {
                    n(null)
                } catch (n) {
                    Z(e, t, n)
                } else n.current = null
        }

        function Zc(e) {
            var t = e.type,
                n = e.memoizedProps,
                r = e.stateNode;
            try {
                a: switch (t) {
                    case `button`:
                    case `input`:
                    case `select`:
                    case `textarea`:
                        n.autoFocus && r.focus();
                        break a;
                    case `img`:
                        n.src ? r.src = n.src : n.srcSet && (r.srcset = n.srcSet)
                }
            }
            catch (t) {
                Z(e, e.return, t)
            }
        }

        function Qc(e, t, n) {
            try {
                var r = e.stateNode;
                Fd(r, e.type, n, t), r[vt] = t
            } catch (t) {
                Z(e, e.return, t)
            }
        }

        function $c(e) {
            return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && Zd(e.type) || e.tag === 4
        }

        function el(e) {
            a: for (;;) {
                for (; e.sibling === null;) {
                    if (e.return === null || $c(e.return)) return null;
                    e = e.return
                }
                for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
                    if (e.tag === 27 && Zd(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue a;
                    e.child.return = e, e = e.child
                }
                if (!(e.flags & 2)) return e.stateNode
            }
        }

        function tl(e, t, n) {
            var r = e.tag;
            if (r === 5 || r === 6) e = e.stateNode, t ? (n.nodeType === 9 ? n.body : n.nodeName === `HTML` ? n.ownerDocument.body : n).insertBefore(e, t) : (t = n.nodeType === 9 ? n.body : n.nodeName === `HTML` ? n.ownerDocument.body : n, t.appendChild(e), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = un));
            else if (r !== 4 && (r === 27 && Zd(e.type) && (n = e.stateNode, t = null), e = e.child, e !== null))
                for (tl(e, t, n), e = e.sibling; e !== null;) tl(e, t, n), e = e.sibling
        }

        function nl(e, t, n) {
            var r = e.tag;
            if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
            else if (r !== 4 && (r === 27 && Zd(e.type) && (n = e.stateNode), e = e.child, e !== null))
                for (nl(e, t, n), e = e.sibling; e !== null;) nl(e, t, n), e = e.sibling
        }

        function rl(e) {
            var t = e.stateNode,
                n = e.memoizedProps;
            try {
                for (var r = e.type, i = t.attributes; i.length;) t.removeAttributeNode(i[0]);
                Pd(t, r, n), t[_t] = e, t[vt] = n
            } catch (t) {
                Z(e, e.return, t)
            }
        }
        var il = !1,
            V = !1,
            al = !1,
            ol = typeof WeakSet == `function` ? WeakSet : Set,
            H = null;

        function sl(e, t) {
            if (e = e.containerInfo, Rd = sp, e = Lr(e), Rr(e)) {
                if (`selectionStart` in e) var n = {
                    start: e.selectionStart,
                    end: e.selectionEnd
                };
                else a: {
                    n = (n = e.ownerDocument) && n.defaultView || window;
                    var r = n.getSelection && n.getSelection();
                    if (r && r.rangeCount !== 0) {
                        n = r.anchorNode;
                        var i = r.anchorOffset,
                            o = r.focusNode;
                        r = r.focusOffset;
                        try {
                            n.nodeType, o.nodeType
                        } catch {
                            n = null;
                            break a
                        }
                        var s = 0,
                            c = -1,
                            l = -1,
                            u = 0,
                            d = 0,
                            f = e,
                            p = null;
                        b: for (;;) {
                            for (var m; f !== n || i !== 0 && f.nodeType !== 3 || (c = s + i), f !== o || r !== 0 && f.nodeType !== 3 || (l = s + r), f.nodeType === 3 && (s += f.nodeValue.length), (m = f.firstChild) !== null;) p = f, f = m;
                            for (;;) {
                                if (f === e) break b;
                                if (p === n && ++u === i && (c = s), p === o && ++d === r && (l = s), (m = f.nextSibling) !== null) break;
                                f = p, p = f.parentNode
                            }
                            f = m
                        }
                        n = c === -1 || l === -1 ? null : {
                            start: c,
                            end: l
                        }
                    } else n = null
                }
                n || = {
                    start: 0,
                    end: 0
                }
            } else n = null;
            for (zd = {
                    focusedElem: e,
                    selectionRange: n
                }, sp = !1, H = t; H !== null;)
                if (t = H, e = t.child, t.subtreeFlags & 1028 && e !== null) e.return = t, H = e;
                else
                    for (; H !== null;) {
                        switch (t = H, o = t.alternate, e = t.flags, t.tag) {
                            case 0:
                                if (e & 4 && (e = t.updateQueue, e = e === null ? null : e.events, e !== null))
                                    for (n = 0; n < e.length; n++) i = e[n], i.ref.impl = i.nextImpl;
                                break;
                            case 11:
                            case 15:
                                break;
                            case 1:
                                if (e & 1024 && o !== null) {
                                    e = void 0, n = t, i = o.memoizedProps, o = o.memoizedState, r = n.stateNode;
                                    try {
                                        var h = Zs(n.type, i);
                                        e = r.getSnapshotBeforeUpdate(h, o), r.__reactInternalSnapshotBeforeUpdate = e
                                    } catch (e) {
                                        Z(n, n.return, e)
                                    }
                                }
                                break;
                            case 3:
                                if (e & 1024) {
                                    if (e = t.stateNode.containerInfo, n = e.nodeType, n === 9) ef(e);
                                    else if (n === 1) switch (e.nodeName) {
                                        case `HEAD`:
                                        case `HTML`:
                                        case `BODY`:
                                            ef(e);
                                            break;
                                        default:
                                            e.textContent = ``
                                    }
                                }
                                break;
                            case 5:
                            case 26:
                            case 27:
                            case 6:
                            case 4:
                            case 17:
                                break;
                            default:
                                if (e & 1024) throw Error(a(163))
                        }
                        if (e = t.sibling, e !== null) {
                            e.return = t.return, H = e;
                            break
                        }
                        H = t.return
                    }
        }

        function cl(e, t, n) {
            var r = n.flags;
            switch (n.tag) {
                case 0:
                case 11:
                case 15:
                    Sl(e, n), r & 4 && Gc(5, n);
                    break;
                case 1:
                    if (Sl(e, n), r & 4)
                        if (e = n.stateNode, t === null) try {
                            e.componentDidMount()
                        } catch (e) {
                            Z(n, n.return, e)
                        } else {
                            var i = Zs(n.type, t.memoizedProps);
                            t = t.memoizedState;
                            try {
                                e.componentDidUpdate(i, t, e.__reactInternalSnapshotBeforeUpdate)
                            } catch (e) {
                                Z(n, n.return, e)
                            }
                        }
                    r & 64 && qc(n), r & 512 && Yc(n, n.return);
                    break;
                case 3:
                    if (Sl(e, n), r & 64 && (e = n.updateQueue, e !== null)) {
                        if (t = null, n.child !== null) switch (n.child.tag) {
                            case 27:
                            case 5:
                                t = n.child.stateNode;
                                break;
                            case 1:
                                t = n.child.stateNode
                        }
                        try {
                            io(e, t)
                        } catch (e) {
                            Z(n, n.return, e)
                        }
                    }
                    break;
                case 27:
                    t === null && r & 4 && rl(n);
                case 26:
                case 5:
                    Sl(e, n), t === null && r & 4 && Zc(n), r & 512 && Yc(n, n.return);
                    break;
                case 12:
                    Sl(e, n);
                    break;
                case 31:
                    Sl(e, n), r & 4 && pl(e, n);
                    break;
                case 13:
                    Sl(e, n), r & 4 && ml(e, n), r & 64 && (e = n.memoizedState, e !== null && (e = e.dehydrated, e !== null && (n = Ju.bind(null, n), sf(e, n))));
                    break;
                case 22:
                    if (r = n.memoizedState !== null || il, !r) {
                        t = t !== null && t.memoizedState !== null || V, i = il;
                        var a = V;
                        il = r, (V = t) && !a ? wl(e, n, (n.subtreeFlags & 8772) != 0) : Sl(e, n), il = i, V = a
                    }
                    break;
                case 30:
                    break;
                default:
                    Sl(e, n)
            }
        }

        function ll(e) {
            var t = e.alternate;
            t !== null && (e.alternate = null, ll(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && Tt(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
        }
        var U = null,
            ul = !1;

        function dl(e, t, n) {
            for (n = n.child; n !== null;) fl(e, t, n), n = n.sibling
        }

        function fl(e, t, n) {
            if (Ke && typeof Ke.onCommitFiberUnmount == `function`) try {
                Ke.onCommitFiberUnmount(Ge, n)
            } catch {}
            switch (n.tag) {
                case 26:
                    V || Xc(n, t), dl(e, t, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && (n = n.stateNode, n.parentNode.removeChild(n));
                    break;
                case 27:
                    V || Xc(n, t);
                    var r = U,
                        i = ul;
                    Zd(n.type) && (U = n.stateNode, ul = !1), dl(e, t, n), pf(n.stateNode), U = r, ul = i;
                    break;
                case 5:
                    V || Xc(n, t);
                case 6:
                    if (r = U, i = ul, U = null, dl(e, t, n), U = r, ul = i, U !== null)
                        if (ul) try {
                            (U.nodeType === 9 ? U.body : U.nodeName === `HTML` ? U.ownerDocument.body : U).removeChild(n.stateNode)
                        } catch (e) {
                            Z(n, t, e)
                        } else try {
                            U.removeChild(n.stateNode)
                        } catch (e) {
                            Z(n, t, e)
                        }
                    break;
                case 18:
                    U !== null && (ul ? (e = U, Qd(e.nodeType === 9 ? e.body : e.nodeName === `HTML` ? e.ownerDocument.body : e, n.stateNode), Np(e)) : Qd(U, n.stateNode));
                    break;
                case 4:
                    r = U, i = ul, U = n.stateNode.containerInfo, ul = !0, dl(e, t, n), U = r, ul = i;
                    break;
                case 0:
                case 11:
                case 14:
                case 15:
                    Kc(2, n, t), V || Kc(4, n, t), dl(e, t, n);
                    break;
                case 1:
                    V || (Xc(n, t), r = n.stateNode, typeof r.componentWillUnmount == `function` && Jc(n, t, r)), dl(e, t, n);
                    break;
                case 21:
                    dl(e, t, n);
                    break;
                case 22:
                    V = (r = V) || n.memoizedState !== null, dl(e, t, n), V = r;
                    break;
                default:
                    dl(e, t, n)
            }
        }

        function pl(e, t) {
            if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
                e = e.dehydrated;
                try {
                    Np(e)
                } catch (e) {
                    Z(t, t.return, e)
                }
            }
        }

        function ml(e, t) {
            if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
                Np(e)
            } catch (e) {
                Z(t, t.return, e)
            }
        }

        function hl(e) {
            switch (e.tag) {
                case 31:
                case 13:
                case 19:
                    var t = e.stateNode;
                    return t === null && (t = e.stateNode = new ol), t;
                case 22:
                    return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new ol), t;
                default:
                    throw Error(a(435, e.tag))
            }
        }

        function gl(e, t) {
            var n = hl(e);
            t.forEach(function(t) {
                if (!n.has(t)) {
                    n.add(t);
                    var r = Yu.bind(null, e, t);
                    t.then(r, r)
                }
            })
        }

        function _l(e, t) {
            var n = t.deletions;
            if (n !== null)
                for (var r = 0; r < n.length; r++) {
                    var i = n[r],
                        o = e,
                        s = t,
                        c = s;
                    a: for (; c !== null;) {
                        switch (c.tag) {
                            case 27:
                                if (Zd(c.type)) {
                                    U = c.stateNode, ul = !1;
                                    break a
                                }
                                break;
                            case 5:
                                U = c.stateNode, ul = !1;
                                break a;
                            case 3:
                            case 4:
                                U = c.stateNode.containerInfo, ul = !0;
                                break a
                        }
                        c = c.return
                    }
                    if (U === null) throw Error(a(160));
                    fl(o, s, i), U = null, ul = !1, o = i.alternate, o !== null && (o.return = null), i.return = null
                }
            if (t.subtreeFlags & 13886)
                for (t = t.child; t !== null;) yl(t, e), t = t.sibling
        }
        var vl = null;

        function yl(e, t) {
            var n = e.alternate,
                r = e.flags;
            switch (e.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    _l(t, e), bl(e), r & 4 && (Kc(3, e, e.return), Gc(3, e), Kc(5, e, e.return));
                    break;
                case 1:
                    _l(t, e), bl(e), r & 512 && (V || n === null || Xc(n, n.return)), r & 64 && il && (e = e.updateQueue, e !== null && (r = e.callbacks, r !== null && (n = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = n === null ? r : n.concat(r))));
                    break;
                case 26:
                    var i = vl;
                    if (_l(t, e), bl(e), r & 512 && (V || n === null || Xc(n, n.return)), r & 4) {
                        var o = n === null ? null : n.memoizedState;
                        if (r = e.memoizedState, n === null)
                            if (r === null)
                                if (e.stateNode === null) {
                                    a: {
                                        r = e.type,
                                        n = e.memoizedProps,
                                        i = i.ownerDocument || i;b: switch (r) {
                                            case `title`:
                                                o = i.getElementsByTagName(`title`)[0], (!o || o[wt] || o[_t] || o.namespaceURI === `http://www.w3.org/2000/svg` || o.hasAttribute(`itemprop`)) && (o = i.createElement(r), i.head.insertBefore(o, i.querySelector(`head > title`))), Pd(o, r, n), o[_t] = e, O(o), r = o;
                                                break a;
                                            case `link`:
                                                var s = Vf(`link`, `href`, i).get(r + (n.href || ``));
                                                if (s) {
                                                    for (var c = 0; c < s.length; c++)
                                                        if (o = s[c], o.getAttribute(`href`) === (n.href == null || n.href === `` ? null : n.href) && o.getAttribute(`rel`) === (n.rel == null ? null : n.rel) && o.getAttribute(`title`) === (n.title == null ? null : n.title) && o.getAttribute(`crossorigin`) === (n.crossOrigin == null ? null : n.crossOrigin)) {
                                                            s.splice(c, 1);
                                                            break b
                                                        }
                                                }
                                                o = i.createElement(r), Pd(o, r, n), i.head.appendChild(o);
                                                break;
                                            case `meta`:
                                                if (s = Vf(`meta`, `content`, i).get(r + (n.content || ``))) {
                                                    for (c = 0; c < s.length; c++)
                                                        if (o = s[c], o.getAttribute(`content`) === (n.content == null ? null : `` + n.content) && o.getAttribute(`name`) === (n.name == null ? null : n.name) && o.getAttribute(`property`) === (n.property == null ? null : n.property) && o.getAttribute(`http-equiv`) === (n.httpEquiv == null ? null : n.httpEquiv) && o.getAttribute(`charset`) === (n.charSet == null ? null : n.charSet)) {
                                                            s.splice(c, 1);
                                                            break b
                                                        }
                                                }
                                                o = i.createElement(r), Pd(o, r, n), i.head.appendChild(o);
                                                break;
                                            default:
                                                throw Error(a(468, r))
                                        }
                                        o[_t] = e,
                                        O(o),
                                        r = o
                                    }
                                    e.stateNode = r
                                }
                        else Hf(i, e.type, e.stateNode);
                        else e.stateNode = If(i, r, e.memoizedProps);
                        else o === r ? r === null && e.stateNode !== null && Qc(e, e.memoizedProps, n.memoizedProps) : (o === null ? n.stateNode !== null && (n = n.stateNode, n.parentNode.removeChild(n)) : o.count--, r === null ? Hf(i, e.type, e.stateNode) : If(i, r, e.memoizedProps))
                    }
                    break;
                case 27:
                    _l(t, e), bl(e), r & 512 && (V || n === null || Xc(n, n.return)), n !== null && r & 4 && Qc(e, e.memoizedProps, n.memoizedProps);
                    break;
                case 5:
                    if (_l(t, e), bl(e), r & 512 && (V || n === null || Xc(n, n.return)), e.flags & 32) {
                        i = e.stateNode;
                        try {
                            tn(i, ``)
                        } catch (t) {
                            Z(e, e.return, t)
                        }
                    }
                    r & 4 && e.stateNode != null && (i = e.memoizedProps, Qc(e, i, n === null ? i : n.memoizedProps)), r & 1024 && (al = !0);
                    break;
                case 6:
                    if (_l(t, e), bl(e), r & 4) {
                        if (e.stateNode === null) throw Error(a(162));
                        r = e.memoizedProps, n = e.stateNode;
                        try {
                            n.nodeValue = r
                        } catch (t) {
                            Z(e, e.return, t)
                        }
                    }
                    break;
                case 3:
                    if (Bf = null, i = vl, vl = gf(t.containerInfo), _l(t, e), vl = i, bl(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                        Np(t.containerInfo)
                    } catch (t) {
                        Z(e, e.return, t)
                    }
                    al && (al = !1, xl(e));
                    break;
                case 4:
                    r = vl, vl = gf(e.stateNode.containerInfo), _l(t, e), bl(e), vl = r;
                    break;
                case 12:
                    _l(t, e), bl(e);
                    break;
                case 31:
                    _l(t, e), bl(e), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, gl(e, r)));
                    break;
                case 13:
                    _l(t, e), bl(e), e.child.flags & 8192 && e.memoizedState !== null != (n !== null && n.memoizedState !== null) && (eu = Ie()), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, gl(e, r)));
                    break;
                case 22:
                    i = e.memoizedState !== null;
                    var l = n !== null && n.memoizedState !== null,
                        u = il,
                        d = V;
                    if (il = u || i, V = d || l, _l(t, e), V = d, il = u, bl(e), r & 8192) a: for (t = e.stateNode, t._visibility = i ? t._visibility & -2 : t._visibility | 1, i && (n === null || l || il || V || Cl(e)), n = null, t = e;;) {
                        if (t.tag === 5 || t.tag === 26) {
                            if (n === null) {
                                l = n = t;
                                try {
                                    if (o = l.stateNode, i) s = o.style, typeof s.setProperty == `function` ? s.setProperty(`display`, `none`, `important`) : s.display = `none`;
                                    else {
                                        c = l.stateNode;
                                        var f = l.memoizedProps.style,
                                            p = f != null && f.hasOwnProperty(`display`) ? f.display : null;
                                        c.style.display = p == null || typeof p == `boolean` ? `` : (`` + p).trim()
                                    }
                                } catch (e) {
                                    Z(l, l.return, e)
                                }
                            }
                        } else if (t.tag === 6) {
                            if (n === null) {
                                l = t;
                                try {
                                    l.stateNode.nodeValue = i ? `` : l.memoizedProps
                                } catch (e) {
                                    Z(l, l.return, e)
                                }
                            }
                        } else if (t.tag === 18) {
                            if (n === null) {
                                l = t;
                                try {
                                    var m = l.stateNode;
                                    i ? $d(m, !0) : $d(l.stateNode, !1)
                                } catch (e) {
                                    Z(l, l.return, e)
                                }
                            }
                        } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === e) && t.child !== null) {
                            t.child.return = t, t = t.child;
                            continue
                        }
                        if (t === e) break a;
                        for (; t.sibling === null;) {
                            if (t.return === null || t.return === e) break a;
                            n === t && (n = null), t = t.return
                        }
                        n === t && (n = null), t.sibling.return = t.return, t = t.sibling
                    }
                    r & 4 && (r = e.updateQueue, r !== null && (n = r.retryQueue, n !== null && (r.retryQueue = null, gl(e, n))));
                    break;
                case 19:
                    _l(t, e), bl(e), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, gl(e, r)));
                    break;
                case 30:
                    break;
                case 21:
                    break;
                default:
                    _l(t, e), bl(e)
            }
        }

        function bl(e) {
            var t = e.flags;
            if (t & 2) {
                try {
                    for (var n, r = e.return; r !== null;) {
                        if ($c(r)) {
                            n = r;
                            break
                        }
                        r = r.return
                    }
                    if (n == null) throw Error(a(160));
                    switch (n.tag) {
                        case 27:
                            var i = n.stateNode;
                            nl(e, el(e), i);
                            break;
                        case 5:
                            var o = n.stateNode;
                            n.flags & 32 && (tn(o, ``), n.flags &= -33), nl(e, el(e), o);
                            break;
                        case 3:
                        case 4:
                            var s = n.stateNode.containerInfo;
                            tl(e, el(e), s);
                            break;
                        default:
                            throw Error(a(161))
                    }
                } catch (t) {
                    Z(e, e.return, t)
                }
                e.flags &= -3
            }
            t & 4096 && (e.flags &= -4097)
        }

        function xl(e) {
            if (e.subtreeFlags & 1024)
                for (e = e.child; e !== null;) {
                    var t = e;
                    xl(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), e = e.sibling
                }
        }

        function Sl(e, t) {
            if (t.subtreeFlags & 8772)
                for (t = t.child; t !== null;) cl(e, t.alternate, t), t = t.sibling
        }

        function Cl(e) {
            for (e = e.child; e !== null;) {
                var t = e;
                switch (t.tag) {
                    case 0:
                    case 11:
                    case 14:
                    case 15:
                        Kc(4, t, t.return), Cl(t);
                        break;
                    case 1:
                        Xc(t, t.return);
                        var n = t.stateNode;
                        typeof n.componentWillUnmount == `function` && Jc(t, t.return, n), Cl(t);
                        break;
                    case 27:
                        pf(t.stateNode);
                    case 26:
                    case 5:
                        Xc(t, t.return), Cl(t);
                        break;
                    case 22:
                        t.memoizedState === null && Cl(t);
                        break;
                    case 30:
                        Cl(t);
                        break;
                    default:
                        Cl(t)
                }
                e = e.sibling
            }
        }

        function wl(e, t, n) {
            for (n && = (t.subtreeFlags & 8772) != 0, t = t.child; t !== null;) {
                var r = t.alternate,
                    i = e,
                    a = t,
                    o = a.flags;
                switch (a.tag) {
                    case 0:
                    case 11:
                    case 15:
                        wl(i, a, n), Gc(4, a);
                        break;
                    case 1:
                        if (wl(i, a, n), r = a, i = r.stateNode, typeof i.componentDidMount == `function`) try {
                            i.componentDidMount()
                        } catch (e) {
                            Z(r, r.return, e)
                        }
                        if (r = a, i = r.updateQueue, i !== null) {
                            var s = r.stateNode;
                            try {
                                var c = i.shared.hiddenCallbacks;
                                if (c !== null)
                                    for (i.shared.hiddenCallbacks = null, i = 0; i < c.length; i++) ro(c[i], s)
                            } catch (e) {
                                Z(r, r.return, e)
                            }
                        }
                        n && o & 64 && qc(a), Yc(a, a.return);
                        break;
                    case 27:
                        rl(a);
                    case 26:
                    case 5:
                        wl(i, a, n), n && r === null && o & 4 && Zc(a), Yc(a, a.return);
                        break;
                    case 12:
                        wl(i, a, n);
                        break;
                    case 31:
                        wl(i, a, n), n && o & 4 && pl(i, a);
                        break;
                    case 13:
                        wl(i, a, n), n && o & 4 && ml(i, a);
                        break;
                    case 22:
                        a.memoizedState === null && wl(i, a, n), Yc(a, a.return);
                        break;
                    case 30:
                        break;
                    default:
                        wl(i, a, n)
                }
                t = t.sibling
            }
        }

        function Tl(e, t) {
            var n = null;
            e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== n && (e != null && e.refCount++, n != null && ga(n))
        }

        function El(e, t) {
            e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && ga(e))
        }

        function Dl(e, t, n, r) {
            if (t.subtreeFlags & 10256)
                for (t = t.child; t !== null;) Ol(e, t, n, r), t = t.sibling
        }

        function Ol(e, t, n, r) {
            var i = t.flags;
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    Dl(e, t, n, r), i & 2048 && Gc(9, t);
                    break;
                case 1:
                    Dl(e, t, n, r);
                    break;
                case 3:
                    Dl(e, t, n, r), i & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && ga(e)));
                    break;
                case 12:
                    if (i & 2048) {
                        Dl(e, t, n, r), e = t.stateNode;
                        try {
                            var a = t.memoizedProps,
                                o = a.id,
                                s = a.onPostCommit;
                            typeof s == `function` && s(o, t.alternate === null ? `mount` : `update`, e.passiveEffectDuration, -0)
                        } catch (e) {
                            Z(t, t.return, e)
                        }
                    } else Dl(e, t, n, r);
                    break;
                case 31:
                    Dl(e, t, n, r);
                    break;
                case 13:
                    Dl(e, t, n, r);
                    break;
                case 23:
                    break;
                case 22:
                    a = t.stateNode, o = t.alternate, t.memoizedState === null ? a._visibility & 2 ? Dl(e, t, n, r) : (a._visibility |= 2, kl(e, t, n, r, (t.subtreeFlags & 10256) != 0 || !1)) : a._visibility & 2 ? Dl(e, t, n, r) : Al(e, t), i & 2048 && Tl(o, t);
                    break;
                case 24:
                    Dl(e, t, n, r), i & 2048 && El(t.alternate, t);
                    break;
                default:
                    Dl(e, t, n, r)
            }
        }

        function kl(e, t, n, r, i) {
            for (i && = (t.subtreeFlags & 10256) != 0 || !1, t = t.child; t !== null;) {
                var a = e,
                    o = t,
                    s = n,
                    c = r,
                    l = o.flags;
                switch (o.tag) {
                    case 0:
                    case 11:
                    case 15:
                        kl(a, o, s, c, i), Gc(8, o);
                        break;
                    case 23:
                        break;
                    case 22:
                        var u = o.stateNode;
                        o.memoizedState === null ? (u._visibility |= 2, kl(a, o, s, c, i)) : u._visibility & 2 ? kl(a, o, s, c, i) : Al(a, o), i && l & 2048 && Tl(o.alternate, o);
                        break;
                    case 24:
                        kl(a, o, s, c, i), i && l & 2048 && El(o.alternate, o);
                        break;
                    default:
                        kl(a, o, s, c, i)
                }
                t = t.sibling
            }
        }

        function Al(e, t) {
            if (t.subtreeFlags & 10256)
                for (t = t.child; t !== null;) {
                    var n = e,
                        r = t,
                        i = r.flags;
                    switch (r.tag) {
                        case 22:
                            Al(n, r), i & 2048 && Tl(r.alternate, r);
                            break;
                        case 24:
                            Al(n, r), i & 2048 && El(r.alternate, r);
                            break;
                        default:
                            Al(n, r)
                    }
                    t = t.sibling
                }
        }
        var jl = 8192;

        function Ml(e, t, n) {
            if (e.subtreeFlags & jl)
                for (e = e.child; e !== null;) Nl(e, t, n), e = e.sibling
        }

        function Nl(e, t, n) {
            switch (e.tag) {
                case 26:
                    Ml(e, t, n), e.flags & jl && e.memoizedState !== null && Gf(n, vl, e.memoizedState, e.memoizedProps);
                    break;
                case 5:
                    Ml(e, t, n);
                    break;
                case 3:
                case 4:
                    var r = vl;
                    vl = gf(e.stateNode.containerInfo), Ml(e, t, n), vl = r;
                    break;
                case 22:
                    e.memoizedState === null && (r = e.alternate, r !== null && r.memoizedState !== null ? (r = jl, jl = 16777216, Ml(e, t, n), jl = r) : Ml(e, t, n));
                    break;
                default:
                    Ml(e, t, n)
            }
        }

        function Pl(e) {
            var t = e.alternate;
            if (t !== null && (e = t.child, e !== null)) {
                t.child = null;
                do t = e.sibling, e.sibling = null, e = t; while (e !== null)
            }
        }

        function Fl(e) {
            var t = e.deletions;
            if (e.flags & 16) {
                if (t !== null)
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        H = r, Rl(r, e)
                    }
                Pl(e)
            }
            if (e.subtreeFlags & 10256)
                for (e = e.child; e !== null;) Il(e), e = e.sibling
        }

        function Il(e) {
            switch (e.tag) {
                case 0:
                case 11:
                case 15:
                    Fl(e), e.flags & 2048 && Kc(9, e, e.return);
                    break;
                case 3:
                    Fl(e);
                    break;
                case 12:
                    Fl(e);
                    break;
                case 22:
                    var t = e.stateNode;
                    e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, Ll(e)) : Fl(e);
                    break;
                default:
                    Fl(e)
            }
        }

        function Ll(e) {
            var t = e.deletions;
            if (e.flags & 16) {
                if (t !== null)
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        H = r, Rl(r, e)
                    }
                Pl(e)
            }
            for (e = e.child; e !== null;) {
                switch (t = e, t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        Kc(8, t, t.return), Ll(t);
                        break;
                    case 22:
                        n = t.stateNode, n._visibility & 2 && (n._visibility &= -3, Ll(t));
                        break;
                    default:
                        Ll(t)
                }
                e = e.sibling
            }
        }

        function Rl(e, t) {
            for (; H !== null;) {
                var n = H;
                switch (n.tag) {
                    case 0:
                    case 11:
                    case 15:
                        Kc(8, n, t);
                        break;
                    case 23:
                    case 22:
                        if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
                            var r = n.memoizedState.cachePool.pool;
                            r != null && r.refCount++
                        }
                        break;
                    case 24:
                        ga(n.memoizedState.cache)
                }
                if (r = n.child, r !== null) r.return = n, H = r;
                else a: for (n = e; H !== null;) {
                    r = H;
                    var i = r.sibling,
                        a = r.return;
                    if (ll(r), r === n) {
                        H = null;
                        break a
                    }
                    if (i !== null) {
                        i.return = a, H = i;
                        break a
                    }
                    H = a
                }
            }
        }
        var zl = {
                getCacheForType: function(e) {
                    var t = la(M),
                        n = t.data.get(e);
                    return n === void 0 && (n = e(), t.data.set(e, n)), n
                },
                cacheSignal: function() {
                    return la(M).controller.signal
                }
            },
            Bl = typeof WeakMap == `function` ? WeakMap : Map,
            W = 0,
            G = null,
            K = null,
            q = 0,
            J = 0,
            Vl = null,
            Hl = !1,
            Ul = !1,
            Wl = !1,
            Gl = 0,
            Y = 0,
            Kl = 0,
            ql = 0,
            Jl = 0,
            Yl = 0,
            Xl = 0,
            Zl = null,
            Ql = null,
            $l = !1,
            eu = 0,
            tu = 0,
            nu = 1 / 0,
            ru = null,
            iu = null,
            X = 0,
            au = null,
            ou = null,
            su = 0,
            cu = 0,
            lu = null,
            uu = null,
            du = 0,
            fu = null;

        function pu() {
            return W & 2 && q !== 0 ? q & -q : w.T === null ? mt() : dd()
        }

        function mu() {
            if (Yl === 0)
                if (!(q & 536870912) || j) {
                    var e = $e;
                    $e <<= 1, !($e & 3932160) && ($e = 262144), Yl = e
                } else Yl = 536870912;
            return e = uo.current, e !== null && (e.flags |= 32), Yl
        }

        function hu(e, t, n) {
            (e === G && (J === 2 || J === 9) || e.cancelPendingCommit !== null) && (Su(e, 0), yu(e, q, Yl, !1)), st(e, n), (!(W & 2) || e !== G) && (e === G && (!(W & 2) && (ql |= n), Y === 4 && yu(e, q, Yl, !1)), rd(e))
        }

        function gu(e, t, n) {
            if (W & 6) throw Error(a(327));
            var r = !n && (t & 127) == 0 && (t & e.expiredLanes) === 0 || rt(e, t),
                i = r ? Au(e, t) : Ou(e, t, !0),
                o = r;
            do {
                if (i === 0) {
                    Ul && !r && yu(e, t, 0, !1);
                    break
                } else {
                    if (n = e.current.alternate, o && !vu(n)) {
                        i = Ou(e, t, !1), o = !1;
                        continue
                    }
                    if (i === 2) {
                        if (o = t, e.errorRecoveryDisabledLanes & o) var s = 0;
                        else s = e.pendingLanes & -536870913, s = s === 0 ? s & 536870912 ? 536870912 : 0 : s;
                        if (s !== 0) {
                            t = s;
                            a: {
                                var c = e;i = Zl;
                                var l = c.current.memoizedState.isDehydrated;
                                if (l && (Su(c, s).flags |= 256), s = Ou(c, s, !1), s !== 2) {
                                    if (Wl && !l) {
                                        c.errorRecoveryDisabledLanes |= o, ql |= o, i = 4;
                                        break a
                                    }
                                    o = Ql, Ql = i, o !== null && (Ql === null ? Ql = o : Ql.push.apply(Ql, o))
                                }
                                i = s
                            }
                            if (o = !1, i !== 2) continue
                        }
                    }
                    if (i === 1) {
                        Su(e, 0), yu(e, t, 0, !0);
                        break
                    }
                    a: {
                        switch (r = e, o = i, o) {
                            case 0:
                            case 1:
                                throw Error(a(345));
                            case 4:
                                if ((t & 4194048) !== t) break;
                            case 6:
                                yu(r, t, Yl, !Hl);
                                break a;
                            case 2:
                                Ql = null;
                                break;
                            case 3:
                            case 5:
                                break;
                            default:
                                throw Error(a(329))
                        }
                        if ((t & 62914560) === t && (i = eu + 300 - Ie(), 10 < i)) {
                            if (yu(r, t, Yl, !Hl), nt(r, 0, !0) !== 0) break a;
                            su = t, r.timeoutHandle = Kd(_u.bind(null, r, n, Ql, ru, $l, t, Yl, ql, Xl, Hl, o, `Throttled`, -0, 0), i);
                            break a
                        }
                        _u(r, n, Ql, ru, $l, t, Yl, ql, Xl, Hl, o, null, -0, 0)
                    }
                }
                break
            } while (1);
            rd(e)
        }

        function _u(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
            if (e.timeoutHandle = -1, d = t.subtreeFlags, d & 8192 || (d & 16785408) == 16785408) {
                d = {
                    stylesheets: null,
                    count: 0,
                    imgCount: 0,
                    imgBytes: 0,
                    suspenseyImages: [],
                    waitingForImages: !0,
                    waitingForViewTransition: !1,
                    unsuspend: un
                }, Nl(t, a, d);
                var m = (a & 62914560) === a ? eu - Ie() : (a & 4194048) === a ? tu - Ie() : 0;
                if (m = qf(d, m), m !== null) {
                    su = a, e.cancelPendingCommit = m(Lu.bind(null, e, t, a, n, r, i, o, s, c, u, d, null, f, p)), yu(e, a, o, !l);
                    return
                }
            }
            Lu(e, t, a, n, r, i, o, s, c)
        }

        function vu(e) {
            for (var t = e;;) {
                var n = t.tag;
                if ((n === 0 || n === 11 || n === 15) && t.flags & 16384 && (n = t.updateQueue, n !== null && (n = n.stores, n !== null)))
                    for (var r = 0; r < n.length; r++) {
                        var i = n[r],
                            a = i.getSnapshot;
                        i = i.value;
                        try {
                            if (!Mr(a(), i)) return !1
                        } catch {
                            return !1
                        }
                    }
                if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
                else {
                    if (t === e) break;
                    for (; t.sibling === null;) {
                        if (t.return === null || t.return === e) return !0;
                        t = t.return
                    }
                    t.sibling.return = t.return, t = t.sibling
                }
            }
            return !0
        }

        function yu(e, t, n, r) {
            t &= ~Jl, t &= ~ql, e.suspendedLanes |= t, e.pingedLanes &= ~t, r && (e.warmLanes |= t), r = e.expirationTimes;
            for (var i = t; 0 < i;) {
                var a = 31 - Je(i),
                    o = 1 << a;
                r[a] = -1, i &= ~o
            }
            n !== 0 && lt(e, n, t)
        }

        function bu() {
            return W & 6 ? !0 : (id(0, !1), !1)
        }

        function xu() {
            if (K !== null) {
                if (J === 0) var e = K.return;
                else e = K, ta = ea = null, Po(e), za = null, Ba = 0, e = K;
                for (; e !== null;) Wc(e.alternate, e), e = e.return;
                K = null
            }
        }

        function Su(e, t) {
            var n = e.timeoutHandle;
            n !== -1 && (e.timeoutHandle = -1, qd(n)), n = e.cancelPendingCommit, n !== null && (e.cancelPendingCommit = null, n()), su = 0, xu(), G = e, K = n = bi(e.current, null), q = t, J = 0, Vl = null, Hl = !1, Ul = rt(e, t), Wl = !1, Xl = Yl = Jl = ql = Kl = Y = 0, Ql = Zl = null, $l = !1, t & 8 && (t |= t & 32);
            var r = e.entangledLanes;
            if (r !== 0)
                for (e = e.entanglements, r &= t; 0 < r;) {
                    var i = 31 - Je(r),
                        a = 1 << i;
                    t |= e[i], r &= ~a
                }
            return Gl = t, ui(), n
        }

        function Cu(e, t) {
            P = null, w.H = Us, t === ka || t === ja ? (t = La(), J = 3) : t === Aa ? (t = La(), J = 4) : J = t === sc ? 8 : typeof t == `object` && t && typeof t.then == `function` ? 6 : 1, Vl = t, K === null && (Y = 1, tc(e, Oi(t, e.current)))
        }

        function wu() {
            var e = uo.current;
            return e === null ? !0 : (q & 4194048) === q ? fo === null : (q & 62914560) === q || q & 536870912 ? e === fo : !1
        }

        function Tu() {
            var e = w.H;
            return w.H = Us, e === null ? Us : e
        }

        function Eu() {
            var e = w.A;
            return w.A = zl, e
        }

        function Du() {
            Y = 4, Hl || (q & 4194048) !== q && uo.current !== null || (Ul = !0), !(Kl & 134217727) && !(ql & 134217727) || G === null || yu(G, q, Yl, !1)
        }

        function Ou(e, t, n) {
            var r = W;
            W |= 2;
            var i = Tu(),
                a = Eu();
            (G !== e || q !== t) && (ru = null, Su(e, t)), t = !1;
            var o = Y;
            a: do try {
                    if (J !== 0 && K !== null) {
                        var s = K,
                            c = Vl;
                        switch (J) {
                            case 8:
                                xu(), o = 6;
                                break a;
                            case 3:
                            case 2:
                            case 9:
                            case 6:
                                uo.current === null && (t = !0);
                                var l = J;
                                if (J = 0, Vl = null, Pu(e, s, c, l), n && Ul) {
                                    o = 0;
                                    break a
                                }
                                break;
                            default:
                                l = J, J = 0, Vl = null, Pu(e, s, c, l)
                        }
                    }
                    ku(), o = Y;
                    break
                } catch (t) {
                    Cu(e, t)
                }
                while (1);
                return t && e.shellSuspendCounter++, ta = ea = null, W = r, w.H = i, w.A = a, K === null && (G = null, q = 0, ui()), o
        }

        function ku() {
            for (; K !== null;) Mu(K)
        }

        function Au(e, t) {
            var n = W;
            W |= 2;
            var r = Tu(),
                i = Eu();
            G !== e || q !== t ? (ru = null, nu = Ie() + 500, Su(e, t)) : Ul = rt(e, t);
            a: do try {
                    if (J !== 0 && K !== null) {
                        t = K;
                        var o = Vl;
                        b: switch (J) {
                            case 1:
                                J = 0, Vl = null, Pu(e, t, o, 1);
                                break;
                            case 2:
                            case 9:
                                if (Na(o)) {
                                    J = 0, Vl = null, Nu(t);
                                    break
                                }
                                t = function() {
                                    J !== 2 && J !== 9 || G !== e || (J = 7), rd(e)
                                }, o.then(t, t);
                                break a;
                            case 3:
                                J = 7;
                                break a;
                            case 4:
                                J = 5;
                                break a;
                            case 7:
                                Na(o) ? (J = 0, Vl = null, Nu(t)) : (J = 0, Vl = null, Pu(e, t, o, 7));
                                break;
                            case 5:
                                var s = null;
                                switch (K.tag) {
                                    case 26:
                                        s = K.memoizedState;
                                    case 5:
                                    case 27:
                                        var c = K;
                                        if (s ? Wf(s) : c.stateNode.complete) {
                                            J = 0, Vl = null;
                                            var l = c.sibling;
                                            if (l !== null) K = l;
                                            else {
                                                var u = c.return;
                                                u === null ? K = null : (K = u, Fu(u))
                                            }
                                            break b
                                        }
                                }
                                J = 0, Vl = null, Pu(e, t, o, 5);
                                break;
                            case 6:
                                J = 0, Vl = null, Pu(e, t, o, 6);
                                break;
                            case 8:
                                xu(), Y = 6;
                                break a;
                            default:
                                throw Error(a(462))
                        }
                    }
                    ju();
                    break
                } catch (t) {
                    Cu(e, t)
                }
                while (1);
                return ta = ea = null, w.H = r, w.A = i, W = n, K === null ? (G = null, q = 0, ui(), Y) : 0
        }

        function ju() {
            for (; K !== null && !Pe();) Mu(K)
        }

        function Mu(e) {
            var t = Ic(e.alternate, e, Gl);
            e.memoizedProps = e.pendingProps, t === null ? Fu(e) : K = t
        }

        function Nu(e) {
            var t = e,
                n = t.alternate;
            switch (t.tag) {
                case 15:
                case 0:
                    t = bc(n, t, t.pendingProps, t.type, void 0, q);
                    break;
                case 11:
                    t = bc(n, t, t.pendingProps, t.type.render, t.ref, q);
                    break;
                case 5:
                    Po(t);
                default:
                    Wc(n, t), t = K = xi(t, Gl), t = Ic(n, t, Gl)
            }
            e.memoizedProps = e.pendingProps, t === null ? Fu(e) : K = t
        }

        function Pu(e, t, n, r) {
            ta = ea = null, Po(t), za = null, Ba = 0;
            var i = t.return;
            try {
                if (oc(e, i, t, n, q)) {
                    Y = 1, tc(e, Oi(n, e.current)), K = null;
                    return
                }
            } catch (t) {
                if (i !== null) throw K = i, t;
                Y = 1, tc(e, Oi(n, e.current)), K = null;
                return
            }
            t.flags & 32768 ? (j || r === 1 ? e = !0 : Ul || q & 536870912 ? e = !1 : (Hl = e = !0, (r === 2 || r === 9 || r === 3 || r === 6) && (r = uo.current, r !== null && r.tag === 13 && (r.flags |= 16384))), Iu(t, e)) : Fu(t)
        }

        function Fu(e) {
            var t = e;
            do {
                if (t.flags & 32768) {
                    Iu(t, Hl);
                    return
                }
                e = t.return;
                var n = Hc(t.alternate, t, Gl);
                if (n !== null) {
                    K = n;
                    return
                }
                if (t = t.sibling, t !== null) {
                    K = t;
                    return
                }
                K = t = e
            } while (t !== null);
            Y === 0 && (Y = 5)
        }

        function Iu(e, t) {
            do {
                var n = Uc(e.alternate, e);
                if (n !== null) {
                    n.flags &= 32767, K = n;
                    return
                }
                if (n = e.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && (e = e.sibling, e !== null)) {
                    K = e;
                    return
                }
                K = e = n
            } while (e !== null);
            Y = 6, K = null
        }

        function Lu(e, t, n, r, i, o, s, c, l) {
            e.cancelPendingCommit = null;
            do Hu(); while (X !== 0);
            if (W & 6) throw Error(a(327));
            if (t !== null) {
                if (t === e.current) throw Error(a(177));
                if (o = t.lanes | t.childLanes, o |= li, ct(e, n, o, s, c, l), e === G && (K = G = null, q = 0), ou = t, au = e, su = n, cu = o, lu = i, uu = r, t.subtreeFlags & 10256 || t.flags & 10256 ? (e.callbackNode = null, e.callbackPriority = 0, Xu(Be, function() {
                        return Uu(), null
                    })) : (e.callbackNode = null, e.callbackPriority = 0), r = (t.flags & 13878) != 0, t.subtreeFlags & 13878 || r) {
                    r = w.T, w.T = null, i = T.p, T.p = 2, s = W, W |= 4;
                    try {
                        sl(e, t, n)
                    } finally {
                        W = s, T.p = i, w.T = r
                    }
                }
                X = 1, Ru(), zu(), Bu()
            }
        }

        function Ru() {
            if (X === 1) {
                X = 0;
                var e = au,
                    t = ou,
                    n = (t.flags & 13878) != 0;
                if (t.subtreeFlags & 13878 || n) {
                    n = w.T, w.T = null;
                    var r = T.p;
                    T.p = 2;
                    var i = W;
                    W |= 4;
                    try {
                        yl(t, e);
                        var a = zd,
                            o = Lr(e.containerInfo),
                            s = a.focusedElem,
                            c = a.selectionRange;
                        if (o !== s && s && s.ownerDocument && Ir(s.ownerDocument.documentElement, s)) {
                            if (c !== null && Rr(s)) {
                                var l = c.start,
                                    u = c.end;
                                if (u === void 0 && (u = l), `selectionStart` in s) s.selectionStart = l, s.selectionEnd = Math.min(u, s.value.length);
                                else {
                                    var d = s.ownerDocument || document,
                                        f = d && d.defaultView || window;
                                    if (f.getSelection) {
                                        var p = f.getSelection(),
                                            m = s.textContent.length,
                                            h = Math.min(c.start, m),
                                            g = c.end === void 0 ? h : Math.min(c.end, m);
                                        !p.extend && h > g && (o = g, g = h, h = o);
                                        var _ = Fr(s, h),
                                            v = Fr(s, g);
                                        if (_ && v && (p.rangeCount !== 1 || p.anchorNode !== _.node || p.anchorOffset !== _.offset || p.focusNode !== v.node || p.focusOffset !== v.offset)) {
                                            var y = d.createRange();
                                            y.setStart(_.node, _.offset), p.removeAllRanges(), h > g ? (p.addRange(y), p.extend(v.node, v.offset)) : (y.setEnd(v.node, v.offset), p.addRange(y))
                                        }
                                    }
                                }
                            }
                            for (d = [], p = s; p = p.parentNode;) p.nodeType === 1 && d.push({
                                element: p,
                                left: p.scrollLeft,
                                top: p.scrollTop
                            });
                            for (typeof s.focus == `function` && s.focus(), s = 0; s < d.length; s++) {
                                var b = d[s];
                                b.element.scrollLeft = b.left, b.element.scrollTop = b.top
                            }
                        }
                        sp = !!Rd, zd = Rd = null
                    } finally {
                        W = i, T.p = r, w.T = n
                    }
                }
                e.current = t, X = 2
            }
        }

        function zu() {
            if (X === 2) {
                X = 0;
                var e = au,
                    t = ou,
                    n = (t.flags & 8772) != 0;
                if (t.subtreeFlags & 8772 || n) {
                    n = w.T, w.T = null;
                    var r = T.p;
                    T.p = 2;
                    var i = W;
                    W |= 4;
                    try {
                        cl(e, t.alternate, t)
                    } finally {
                        W = i, T.p = r, w.T = n
                    }
                }
                X = 3
            }
        }

        function Bu() {
            if (X === 4 || X === 3) {
                X = 0, Fe();
                var e = au,
                    t = ou,
                    n = su,
                    r = uu;
                t.subtreeFlags & 10256 || t.flags & 10256 ? X = 5 : (X = 0, ou = au = null, Vu(e, e.pendingLanes));
                var i = e.pendingLanes;
                if (i === 0 && (iu = null), pt(n), t = t.stateNode, Ke && typeof Ke.onCommitFiberRoot == `function`) try {
                    Ke.onCommitFiberRoot(Ge, t, void 0, (t.current.flags & 128) == 128)
                } catch {}
                if (r !== null) {
                    t = w.T, i = T.p, T.p = 2, w.T = null;
                    try {
                        for (var a = e.onRecoverableError, o = 0; o < r.length; o++) {
                            var s = r[o];
                            a(s.value, {
                                componentStack: s.stack
                            })
                        }
                    } finally {
                        w.T = t, T.p = i
                    }
                }
                su & 3 && Hu(), rd(e), i = e.pendingLanes, n & 261930 && i & 42 ? e === fu ? du++ : (du = 0, fu = e) : du = 0, id(0, !1)
            }
        }

        function Vu(e, t) {
            (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, ga(t)))
        }

        function Hu() {
            return Ru(), zu(), Bu(), Uu()
        }

        function Uu() {
            if (X !== 5) return !1;
            var e = au,
                t = cu;
            cu = 0;
            var n = pt(su),
                r = w.T,
                i = T.p;
            try {
                T.p = 32 > n ? 32 : n, w.T = null, n = lu, lu = null;
                var o = au,
                    s = su;
                if (X = 0, ou = au = null, su = 0, W & 6) throw Error(a(331));
                var c = W;
                if (W |= 4, Il(o.current), Ol(o, o.current, s, n), W = c, id(0, !1), Ke && typeof Ke.onPostCommitFiberRoot == `function`) try {
                    Ke.onPostCommitFiberRoot(Ge, o)
                } catch {}
                return !0
            } finally {
                T.p = i, w.T = r, Vu(e, t)
            }
        }

        function Wu(e, t, n) {
            t = Oi(n, t), t = rc(e.stateNode, t, 2), e = Za(e, t, 2), e !== null && (st(e, 2), rd(e))
        }

        function Z(e, t, n) {
            if (e.tag === 3) Wu(e, e, n);
            else
                for (; t !== null;) {
                    if (t.tag === 3) {
                        Wu(t, e, n);
                        break
                    } else if (t.tag === 1) {
                        var r = t.stateNode;
                        if (typeof t.type.getDerivedStateFromError == `function` || typeof r.componentDidCatch == `function` && (iu === null || !iu.has(r))) {
                            e = Oi(n, e), n = ic(2), r = Za(t, n, 2), r !== null && (ac(n, r, t, e), st(r, 2), rd(r));
                            break
                        }
                    }
                    t = t.return
                }
        }

        function Gu(e, t, n) {
            var r = e.pingCache;
            if (r === null) {
                r = e.pingCache = new Bl;
                var i = new Set;
                r.set(t, i)
            } else i = r.get(t), i === void 0 && (i = new Set, r.set(t, i));
            i.has(n) || (Wl = !0, i.add(n), e = Ku.bind(null, e, t, n), t.then(e, e))
        }

        function Ku(e, t, n) {
            var r = e.pingCache;
            r !== null && r.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, G === e && (q & n) === n && (Y === 4 || Y === 3 && (q & 62914560) === q && 300 > Ie() - eu ? !(W & 2) && Su(e, 0) : Jl |= n, Xl === q && (Xl = 0)), rd(e)
        }

        function qu(e, t) {
            t === 0 && (t = at()), e = pi(e, t), e !== null && (st(e, t), rd(e))
        }

        function Ju(e) {
            var t = e.memoizedState,
                n = 0;
            t !== null && (n = t.retryLane), qu(e, n)
        }

        function Yu(e, t) {
            var n = 0;
            switch (e.tag) {
                case 31:
                case 13:
                    var r = e.stateNode,
                        i = e.memoizedState;
                    i !== null && (n = i.retryLane);
                    break;
                case 19:
                    r = e.stateNode;
                    break;
                case 22:
                    r = e.stateNode._retryCache;
                    break;
                default:
                    throw Error(a(314))
            }
            r !== null && r.delete(t), qu(e, n)
        }

        function Xu(e, t) {
            return Me(e, t)
        }
        var Zu = null,
            Qu = null,
            $u = !1,
            ed = !1,
            td = !1,
            nd = 0;

        function rd(e) {
            e !== Qu && e.next === null && (Qu === null ? Zu = Qu = e : Qu = Qu.next = e), ed = !0, $u || ($u = !0, ud())
        }

        function id(e, t) {
            if (!td && ed) {
                td = !0;
                do
                    for (var n = !1, r = Zu; r !== null;) {
                        if (!t)
                            if (e !== 0) {
                                var i = r.pendingLanes;
                                if (i === 0) var a = 0;
                                else {
                                    var o = r.suspendedLanes,
                                        s = r.pingedLanes;
                                    a = (1 << 31 - Je(42 | e) + 1) - 1, a &= i & ~(o & ~s), a = a & 201326741 ? a & 201326741 | 1 : a ? a | 2 : 0
                                }
                                a !== 0 && (n = !0, ld(r, a))
                            } else a = q, a = nt(r, r === G ? a : 0, r.cancelPendingCommit !== null || r.timeoutHandle !== -1), !(a & 3) || rt(r, a) || (n = !0, ld(r, a));
                        r = r.next
                    }
                while (n);
                td = !1
            }
        }

        function ad() {
            od()
        }

        function od() {
            ed = $u = !1;
            var e = 0;
            nd !== 0 && Gd() && (e = nd);
            for (var t = Ie(), n = null, r = Zu; r !== null;) {
                var i = r.next,
                    a = sd(r, t);
                a === 0 ? (r.next = null, n === null ? Zu = i : n.next = i, i === null && (Qu = n)) : (n = r, (e !== 0 || a & 3) && (ed = !0)), r = i
            }
            X !== 0 && X !== 5 || id(e, !1), nd !== 0 && (nd = 0)
        }

        function sd(e, t) {
            for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, a = e.pendingLanes & -62914561; 0 < a;) {
                var o = 31 - Je(a),
                    s = 1 << o,
                    c = i[o];
                c === -1 ? ((s & n) === 0 || (s & r) !== 0) && (i[o] = it(s, t)) : c <= t && (e.expiredLanes |= s), a &= ~s
            }
            if (t = G, n = q, n = nt(e, e === t ? n : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r = e.callbackNode, n === 0 || e === t && (J === 2 || J === 9) || e.cancelPendingCommit !== null) return r !== null && r !== null && Ne(r), e.callbackNode = null, e.callbackPriority = 0;
            if (!(n & 3) || rt(e, n)) {
                if (t = n & -n, t === e.callbackPriority) return t;
                switch (r !== null && Ne(r), pt(n)) {
                    case 2:
                    case 8:
                        n = ze;
                        break;
                    case 32:
                        n = Be;
                        break;
                    case 268435456:
                        n = He;
                        break;
                    default:
                        n = Be
                }
                return r = cd.bind(null, e), n = Me(n, r), e.callbackPriority = t, e.callbackNode = n, t
            }
            return r !== null && r !== null && Ne(r), e.callbackPriority = 2, e.callbackNode = null, 2
        }

        function cd(e, t) {
            if (X !== 0 && X !== 5) return e.callbackNode = null, e.callbackPriority = 0, null;
            var n = e.callbackNode;
            if (Hu() && e.callbackNode !== n) return null;
            var r = q;
            return r = nt(e, e === G ? r : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r === 0 ? null : (gu(e, r, t), sd(e, Ie()), e.callbackNode != null && e.callbackNode === n ? cd.bind(null, e) : null)
        }

        function ld(e, t) {
            if (Hu()) return null;
            gu(e, t, !0)
        }

        function ud() {
            Yd(function() {
                W & 6 ? Me(Re, ad) : od()
            })
        }

        function dd() {
            if (nd === 0) {
                var e = ya;
                e === 0 && (e = Qe, Qe <<= 1, !(Qe & 261888) && (Qe = 256)), nd = e
            }
            return nd
        }

        function fd(e) {
            return e == null || typeof e == `symbol` || typeof e == `boolean` ? null : typeof e == `function` ? e : ln(`` + e)
        }

        function pd(e, t) {
            var n = t.ownerDocument.createElement(`input`);
            return n.name = t.name, n.value = t.value, e.id && n.setAttribute(`form`, e.id), t.parentNode.insertBefore(n, t), e = new FormData(e), n.parentNode.removeChild(n), e
        }

        function md(e, t, n, r, i) {
            if (t === `submit` && n && n.stateNode === i) {
                var a = fd((i[vt] || null).action),
                    o = r.submitter;
                o && (t = (t = o[vt] || null) ? fd(t.formAction) : o.getAttribute(`formAction`), t !== null && (a = t, o = null));
                var s = new jn(`action`, `action`, null, r, i);
                e.push({
                    event: s,
                    listeners: [{
                        instance: null,
                        listener: function() {
                            if (r.defaultPrevented) {
                                if (nd !== 0) {
                                    var e = o ? pd(i, o) : new FormData(i);
                                    ks(n, {
                                        pending: !0,
                                        data: e,
                                        method: i.method,
                                        action: a
                                    }, null, e)
                                }
                            } else typeof a == `function` && (s.preventDefault(), e = o ? pd(i, o) : new FormData(i), ks(n, {
                                pending: !0,
                                data: e,
                                method: i.method,
                                action: a
                            }, a, e))
                        },
                        currentTarget: i
                    }]
                })
            }
        }
        for (var hd = 0; hd < ii.length; hd++) {
            var gd = ii[hd];
            ai(gd.toLowerCase(), `on` + (gd[0].toUpperCase() + gd.slice(1)))
        }
        ai(Xr, `onAnimationEnd`), ai(Zr, `onAnimationIteration`), ai(Qr, `onAnimationStart`), ai(`dblclick`, `onDoubleClick`), ai(`focusin`, `onFocus`), ai(`focusout`, `onBlur`), ai($r, `onTransitionRun`), ai(ei, `onTransitionStart`), ai(ti, `onTransitionCancel`), ai(ni, `onTransitionEnd`), Nt(`onMouseEnter`, [`mouseout`, `mouseover`]), Nt(`onMouseLeave`, [`mouseout`, `mouseover`]), Nt(`onPointerEnter`, [`pointerout`, `pointerover`]), Nt(`onPointerLeave`, [`pointerout`, `pointerover`]), Mt(`onChange`, `change click focusin focusout input keydown keyup selectionchange`.split(` `)), Mt(`onSelect`, `focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)), Mt(`onBeforeInput`, [`compositionend`, `keypress`, `textInput`, `paste`]), Mt(`onCompositionEnd`, `compositionend focusout keydown keypress keyup mousedown`.split(` `)), Mt(`onCompositionStart`, `compositionstart focusout keydown keypress keyup mousedown`.split(` `)), Mt(`onCompositionUpdate`, `compositionupdate focusout keydown keypress keyup mousedown`.split(` `));
        var _d = `abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),
            vd = new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(_d));

        function yd(e, t) {
            t = (t & 4) != 0;
            for (var n = 0; n < e.length; n++) {
                var r = e[n],
                    i = r.event;
                r = r.listeners;
                a: {
                    var a = void 0;
                    if (t)
                        for (var o = r.length - 1; 0 <= o; o--) {
                            var s = r[o],
                                c = s.instance,
                                l = s.currentTarget;
                            if (s = s.listener, c !== a && i.isPropagationStopped()) break a;
                            a = s, i.currentTarget = l;
                            try {
                                a(i)
                            } catch (e) {
                                oi(e)
                            }
                            i.currentTarget = null, a = c
                        } else
                            for (o = 0; o < r.length; o++) {
                                if (s = r[o], c = s.instance, l = s.currentTarget, s = s.listener, c !== a && i.isPropagationStopped()) break a;
                                a = s, i.currentTarget = l;
                                try {
                                    a(i)
                                } catch (e) {
                                    oi(e)
                                }
                                i.currentTarget = null, a = c
                            }
                }
            }
        }

        function Q(e, t) {
            var n = t[bt];
            n === void 0 && (n = t[bt] = new Set);
            var r = e + `__bubble`;
            n.has(r) || (Cd(t, e, 2, !1), n.add(r))
        }

        function bd(e, t, n) {
            var r = 0;
            t && (r |= 4), Cd(n, e, r, t)
        }
        var xd = `_reactListening` + Math.random().toString(36).slice(2);

        function Sd(e) {
            if (!e[xd]) {
                e[xd] = !0, At.forEach(function(t) {
                    t !== `selectionchange` && (vd.has(t) || bd(t, !1, e), bd(t, !0, e))
                });
                var t = e.nodeType === 9 ? e : e.ownerDocument;
                t === null || t[xd] || (t[xd] = !0, bd(`selectionchange`, !1, t))
            }
        }

        function Cd(e, t, n, r) {
            switch (mp(t)) {
                case 2:
                    var i = cp;
                    break;
                case 8:
                    i = lp;
                    break;
                default:
                    i = up
            }
            n = i.bind(null, t, n, e), i = void 0, !bn || t !== `touchstart` && t !== `touchmove` && t !== `wheel` || (i = !0), r ? i === void 0 ? e.addEventListener(t, n, !0) : e.addEventListener(t, n, {
                capture: !0,
                passive: i
            }) : i === void 0 ? e.addEventListener(t, n, !1) : e.addEventListener(t, n, {
                passive: i
            })
        }

        function wd(e, t, n, r, i) {
            var a = r;
            if (!(t & 1) && !(t & 2) && r !== null) a: for (;;) {
                if (r === null) return;
                var o = r.tag;
                if (o === 3 || o === 4) {
                    var s = r.stateNode.containerInfo;
                    if (s === i) break;
                    if (o === 4)
                        for (o = r.return; o !== null;) {
                            var l = o.tag;
                            if ((l === 3 || l === 4) && o.stateNode.containerInfo === i) return;
                            o = o.return
                        }
                    for (; s !== null;) {
                        if (o = Et(s), o === null) return;
                        if (l = o.tag, l === 5 || l === 6 || l === 26 || l === 27) {
                            r = a = o;
                            continue a
                        }
                        s = s.parentNode
                    }
                }
                r = r.return
            }
            _n(function() {
                var r = a,
                    i = fn(n),
                    o = [];
                a: {
                    var s = ri.get(e);
                    if (s !== void 0) {
                        var l = jn,
                            u = e;
                        switch (e) {
                            case `keypress`:
                                if (En(n) === 0) break a;
                            case `keydown`:
                            case `keyup`:
                                l = Yn;
                                break;
                            case `focusin`:
                                u = `focus`, l = Bn;
                                break;
                            case `focusout`:
                                u = `blur`, l = Bn;
                                break;
                            case `beforeblur`:
                            case `afterblur`:
                                l = Bn;
                                break;
                            case `click`:
                                if (n.button === 2) break a;
                            case `auxclick`:
                            case `dblclick`:
                            case `mousedown`:
                            case `mousemove`:
                            case `mouseup`:
                            case `mouseout`:
                            case `mouseover`:
                            case `contextmenu`:
                                l = Rn;
                                break;
                            case `drag`:
                            case `dragend`:
                            case `dragenter`:
                            case `dragexit`:
                            case `dragleave`:
                            case `dragover`:
                            case `dragstart`:
                            case `drop`:
                                l = zn;
                                break;
                            case `touchcancel`:
                            case `touchend`:
                            case `touchmove`:
                            case `touchstart`:
                                l = Zn;
                                break;
                            case Xr:
                            case Zr:
                            case Qr:
                                l = Vn;
                                break;
                            case ni:
                                l = Qn;
                                break;
                            case `scroll`:
                            case `scrollend`:
                                l = Nn;
                                break;
                            case `wheel`:
                                l = $n;
                                break;
                            case `copy`:
                            case `cut`:
                            case `paste`:
                                l = Hn;
                                break;
                            case `gotpointercapture`:
                            case `lostpointercapture`:
                            case `pointercancel`:
                            case `pointerdown`:
                            case `pointermove`:
                            case `pointerout`:
                            case `pointerover`:
                            case `pointerup`:
                                l = Xn;
                                break;
                            case `toggle`:
                            case `beforetoggle`:
                                l = er
                        }
                        var d = (t & 4) != 0,
                            f = !d && (e === `scroll` || e === `scrollend`),
                            p = d ? s === null ? null : s + `Capture` : s;
                        d = [];
                        for (var m = r, h; m !== null;) {
                            var g = m;
                            if (h = g.stateNode, g = g.tag, g !== 5 && g !== 26 && g !== 27 || h === null || p === null || (g = vn(m, p), g != null && d.push(Td(m, g, h))), f) break;
                            m = m.return
                        }
                        0 < d.length && (s = new l(s, u, null, n, i), o.push({
                            event: s,
                            listeners: d
                        }))
                    }
                }
                if (!(t & 7)) {
                    a: {
                        if (s = e === `mouseover` || e === `pointerover`, l = e === `mouseout` || e === `pointerout`, s && n !== dn && (u = n.relatedTarget || n.fromElement) && (Et(u) || u[yt])) break a;
                        if ((l || s) && (s = i.window === i ? i : (s = i.ownerDocument) ? s.defaultView || s.parentWindow : window, l ? (u = n.relatedTarget || n.toElement, l = r, u = u ? Et(u) : null, u !== null && (f = c(u), d = u.tag, u !== f || d !== 5 && d !== 27 && d !== 6) && (u = null)) : (l = null, u = r), l !== u)) {
                            if (d = Rn, g = `onMouseLeave`, p = `onMouseEnter`, m = `mouse`, (e === `pointerout` || e === `pointerover`) && (d = Xn, g = `onPointerLeave`, p = `onPointerEnter`, m = `pointer`), f = l == null ? s : Ot(l), h = u == null ? s : Ot(u), s = new d(g, m + `leave`, l, n, i), s.target = f, s.relatedTarget = h, g = null, Et(i) === r && (d = new d(p, m + `enter`, u, n, i), d.target = h, d.relatedTarget = f, g = d), f = g, l && u) b: {
                                for (d = Dd, p = l, m = u, h = 0, g = p; g; g = d(g)) h++;g = 0;
                                for (var _ = m; _; _ = d(_)) g++;
                                for (; 0 < h - g;) p = d(p),
                                h--;
                                for (; 0 < g - h;) m = d(m),
                                g--;
                                for (; h--;) {
                                    if (p === m || m !== null && p === m.alternate) {
                                        d = p;
                                        break b
                                    }
                                    p = d(p), m = d(m)
                                }
                                d = null
                            }
                            else d = null;
                            l !== null && Od(o, s, l, d, !1), u !== null && f !== null && Od(o, f, u, d, !0)
                        }
                    }
                    a: {
                        if (s = r ? Ot(r) : window, l = s.nodeName && s.nodeName.toLowerCase(), l === `select` || l === `input` && s.type === `file`) var v = br;
                        else if (mr(s))
                            if (xr) v = Ar;
                            else {
                                v = Or;
                                var y = Dr
                            }
                        else l = s.nodeName,
                        !l || l.toLowerCase() !== `input` || s.type !== `checkbox` && s.type !== `radio` ? r && on(r.elementType) && (v = br) : v = kr;
                        if (v && = v(e, r)) {
                            hr(o, v, n, i);
                            break a
                        }
                        y && y(e, s, r),
                        e === `focusout` && r && s.type === `number` && r.memoizedProps.value != null && Zt(s, `number`, s.value)
                    }
                    switch (y = r ? Ot(r) : window, e) {
                        case `focusin`:
                            (mr(y) || y.contentEditable === `true`) && (Br = y, Vr = r, Hr = null);
                            break;
                        case `focusout`:
                            Hr = Vr = Br = null;
                            break;
                        case `mousedown`:
                            Ur = !0;
                            break;
                        case `contextmenu`:
                        case `mouseup`:
                        case `dragend`:
                            Ur = !1, Wr(o, n, i);
                            break;
                        case `selectionchange`:
                            if (zr) break;
                        case `keydown`:
                        case `keyup`:
                            Wr(o, n, i)
                    }
                    var b;
                    if (nr) b: {
                        switch (e) {
                            case `compositionstart`:
                                var x = `onCompositionStart`;
                                break b;
                            case `compositionend`:
                                x = `onCompositionEnd`;
                                break b;
                            case `compositionupdate`:
                                x = `onCompositionUpdate`;
                                break b
                        }
                        x = void 0
                    }
                    else ur ? cr(e, n) && (x = `onCompositionEnd`) : e === `keydown` && n.keyCode === 229 && (x = `onCompositionStart`);x && (ar && n.locale !== `ko` && (ur || x !== `onCompositionStart` ? x === `onCompositionEnd` && ur && (b = Tn()) : (Sn = i, Cn = `value` in Sn ? Sn.value : Sn.textContent, ur = !0)), y = Ed(r, x), 0 < y.length && (x = new Un(x, e, null, n, i), o.push({
                        event: x,
                        listeners: y
                    }), b ? x.data = b : (b = lr(n), b !== null && (x.data = b)))),
                    (b = ir ? dr(e, n) : fr(e, n)) && (x = Ed(r, `onBeforeInput`), 0 < x.length && (y = new Un(`onBeforeInput`, `beforeinput`, null, n, i), o.push({
                        event: y,
                        listeners: x
                    }), y.data = b)),
                    md(o, e, r, n, i)
                }
                yd(o, t)
            })
        }

        function Td(e, t, n) {
            return {
                instance: e,
                listener: t,
                currentTarget: n
            }
        }

        function Ed(e, t) {
            for (var n = t + `Capture`, r = []; e !== null;) {
                var i = e,
                    a = i.stateNode;
                if (i = i.tag, i !== 5 && i !== 26 && i !== 27 || a === null || (i = vn(e, n), i != null && r.unshift(Td(e, i, a)), i = vn(e, t), i != null && r.push(Td(e, i, a))), e.tag === 3) return r;
                e = e.return
            }
            return []
        }

        function Dd(e) {
            if (e === null) return null;
            do e = e.return; while (e && e.tag !== 5 && e.tag !== 27);
            return e || null
        }

        function Od(e, t, n, r, i) {
            for (var a = t._reactName, o = []; n !== null && n !== r;) {
                var s = n,
                    c = s.alternate,
                    l = s.stateNode;
                if (s = s.tag, c !== null && c === r) break;
                s !== 5 && s !== 26 && s !== 27 || l === null || (c = l, i ? (l = vn(n, a), l != null && o.unshift(Td(n, l, c))) : i || (l = vn(n, a), l != null && o.push(Td(n, l, c)))), n = n.return
            }
            o.length !== 0 && e.push({
                event: t,
                listeners: o
            })
        }
        var kd = /\r\n?/g,
            Ad = /\u0000|\uFFFD/g;

        function jd(e) {
            return (typeof e == `string` ? e : `` + e).replace(kd, `
`).replace(Ad, ``)
        }

        function Md(e, t) {
            return t = jd(t), jd(e) === t
        }

        function $(e, t, n, r, i, o) {
            switch (n) {
                case `children`:
                    typeof r == `string` ? t === `body` || t === `textarea` && r === `` || tn(e, r) : (typeof r == `number` || typeof r == `bigint`) && t !== `body` && tn(e, `` + r);
                    break;
                case `className`:
                    zt(e, `class`, r);
                    break;
                case `tabIndex`:
                    zt(e, `tabindex`, r);
                    break;
                case `dir`:
                case `role`:
                case `viewBox`:
                case `width`:
                case `height`:
                    zt(e, n, r);
                    break;
                case `style`:
                    an(e, r, o);
                    break;
                case `data`:
                    if (t !== `object`) {
                        zt(e, `data`, r);
                        break
                    }
                case `src`:
                case `href`:
                    if (r === `` && (t !== `a` || n !== `href`)) {
                        e.removeAttribute(n);
                        break
                    }
                    if (r == null || typeof r == `function` || typeof r == `symbol` || typeof r == `boolean`) {
                        e.removeAttribute(n);
                        break
                    }
                    r = ln(`` + r), e.setAttribute(n, r);
                    break;
                case `action`:
                case `formAction`:
                    if (typeof r == `function`) {
                        e.setAttribute(n, `javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);
                        break
                    } else typeof o == `function` && (n === `formAction` ? (t !== `input` && $(e, t, `name`, i.name, i, null), $(e, t, `formEncType`, i.formEncType, i, null), $(e, t, `formMethod`, i.formMethod, i, null), $(e, t, `formTarget`, i.formTarget, i, null)) : ($(e, t, `encType`, i.encType, i, null), $(e, t, `method`, i.method, i, null), $(e, t, `target`, i.target, i, null)));
                    if (r == null || typeof r == `symbol` || typeof r == `boolean`) {
                        e.removeAttribute(n);
                        break
                    }
                    r = ln(`` + r), e.setAttribute(n, r);
                    break;
                case `onClick`:
                    r != null && (e.onclick = un);
                    break;
                case `onScroll`:
                    r != null && Q(`scroll`, e);
                    break;
                case `onScrollEnd`:
                    r != null && Q(`scrollend`, e);
                    break;
                case `dangerouslySetInnerHTML`:
                    if (r != null) {
                        if (typeof r != `object` || !(`__html` in r)) throw Error(a(61));
                        if (n = r.__html, n != null) {
                            if (i.children != null) throw Error(a(60));
                            e.innerHTML = n
                        }
                    }
                    break;
                case `multiple`:
                    e.multiple = r && typeof r != `function` && typeof r != `symbol`;
                    break;
                case `muted`:
                    e.muted = r && typeof r != `function` && typeof r != `symbol`;
                    break;
                case `suppressContentEditableWarning`:
                case `suppressHydrationWarning`:
                case `defaultValue`:
                case `defaultChecked`:
                case `innerHTML`:
                case `ref`:
                    break;
                case `autoFocus`:
                    break;
                case `xlinkHref`:
                    if (r == null || typeof r == `function` || typeof r == `boolean` || typeof r == `symbol`) {
                        e.removeAttribute(`xlink:href`);
                        break
                    }
                    n = ln(`` + r), e.setAttributeNS(`http://www.w3.org/1999/xlink`, `xlink:href`, n);
                    break;
                case `contentEditable`:
                case `spellCheck`:
                case `draggable`:
                case `value`:
                case `autoReverse`:
                case `externalResourcesRequired`:
                case `focusable`:
                case `preserveAlpha`:
                    r != null && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, `` + r) : e.removeAttribute(n);
                    break;
                case `inert`:
                case `allowFullScreen`:
                case `async`:
                case `autoPlay`:
                case `controls`:
                case `default`:
                case `defer`:
                case `disabled`:
                case `disablePictureInPicture`:
                case `disableRemotePlayback`:
                case `formNoValidate`:
                case `hidden`:
                case `loop`:
                case `noModule`:
                case `noValidate`:
                case `open`:
                case `playsInline`:
                case `readOnly`:
                case `required`:
                case `reversed`:
                case `scoped`:
                case `seamless`:
                case `itemScope`:
                    r && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, ``) : e.removeAttribute(n);
                    break;
                case `capture`:
                case `download`:
                    !0 === r ? e.setAttribute(n, ``) : !1 !== r && r != null && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, r) : e.removeAttribute(n);
                    break;
                case `cols`:
                case `rows`:
                case `size`:
                case `span`:
                    r != null && typeof r != `function` && typeof r != `symbol` && !isNaN(r) && 1 <= r ? e.setAttribute(n, r) : e.removeAttribute(n);
                    break;
                case `rowSpan`:
                case `start`:
                    r == null || typeof r == `function` || typeof r == `symbol` || isNaN(r) ? e.removeAttribute(n) : e.setAttribute(n, r);
                    break;
                case `popover`:
                    Q(`beforetoggle`, e), Q(`toggle`, e), Rt(e, `popover`, r);
                    break;
                case `xlinkActuate`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:actuate`, r);
                    break;
                case `xlinkArcrole`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:arcrole`, r);
                    break;
                case `xlinkRole`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:role`, r);
                    break;
                case `xlinkShow`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:show`, r);
                    break;
                case `xlinkTitle`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:title`, r);
                    break;
                case `xlinkType`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:type`, r);
                    break;
                case `xmlBase`:
                    Bt(e, `http://www.w3.org/XML/1998/namespace`, `xml:base`, r);
                    break;
                case `xmlLang`:
                    Bt(e, `http://www.w3.org/XML/1998/namespace`, `xml:lang`, r);
                    break;
                case `xmlSpace`:
                    Bt(e, `http://www.w3.org/XML/1998/namespace`, `xml:space`, r);
                    break;
                case `is`:
                    Rt(e, `is`, r);
                    break;
                case `innerText`:
                case `textContent`:
                    break;
                default:
                    (!(2 < n.length) || n[0] !== `o` && n[0] !== `O` || n[1] !== `n` && n[1] !== `N`) && (n = sn.get(n) || n, Rt(e, n, r))
            }
        }

        function Nd(e, t, n, r, i, o) {
            switch (n) {
                case `style`:
                    an(e, r, o);
                    break;
                case `dangerouslySetInnerHTML`:
                    if (r != null) {
                        if (typeof r != `object` || !(`__html` in r)) throw Error(a(61));
                        if (n = r.__html, n != null) {
                            if (i.children != null) throw Error(a(60));
                            e.innerHTML = n
                        }
                    }
                    break;
                case `children`:
                    typeof r == `string` ? tn(e, r) : (typeof r == `number` || typeof r == `bigint`) && tn(e, `` + r);
                    break;
                case `onScroll`:
                    r != null && Q(`scroll`, e);
                    break;
                case `onScrollEnd`:
                    r != null && Q(`scrollend`, e);
                    break;
                case `onClick`:
                    r != null && (e.onclick = un);
                    break;
                case `suppressContentEditableWarning`:
                case `suppressHydrationWarning`:
                case `innerHTML`:
                case `ref`:
                    break;
                case `innerText`:
                case `textContent`:
                    break;
                default:
                    if (!jt.hasOwnProperty(n)) a: {
                        if (n[0] === `o` && n[1] === `n` && (i = n.endsWith(`Capture`), t = n.slice(2, i ? n.length - 7 : void 0), o = e[vt] || null, o = o == null ? null : o[n], typeof o == `function` && e.removeEventListener(t, o, i), typeof r == `function`)) {
                            typeof o != `function` && o !== null && (n in e ? e[n] = null : e.hasAttribute(n) && e.removeAttribute(n)), e.addEventListener(t, r, i);
                            break a
                        }
                        n in e ? e[n] = r : !0 === r ? e.setAttribute(n, ``) : Rt(e, n, r)
                    }
            }
        }

        function Pd(e, t, n) {
            switch (t) {
                case `div`:
                case `span`:
                case `svg`:
                case `path`:
                case `a`:
                case `g`:
                case `p`:
                case `li`:
                    break;
                case `img`:
                    Q(`error`, e), Q(`load`, e);
                    var r = !1,
                        i = !1,
                        o;
                    for (o in n)
                        if (n.hasOwnProperty(o)) {
                            var s = n[o];
                            if (s != null) switch (o) {
                                case `src`:
                                    r = !0;
                                    break;
                                case `srcSet`:
                                    i = !0;
                                    break;
                                case `children`:
                                case `dangerouslySetInnerHTML`:
                                    throw Error(a(137, t));
                                default:
                                    $(e, t, o, s, n, null)
                            }
                        }
                    i && $(e, t, `srcSet`, n.srcSet, n, null), r && $(e, t, `src`, n.src, n, null);
                    return;
                case `input`:
                    Q(`invalid`, e);
                    var c = o = s = i = null,
                        l = null,
                        u = null;
                    for (r in n)
                        if (n.hasOwnProperty(r)) {
                            var d = n[r];
                            if (d != null) switch (r) {
                                case `name`:
                                    i = d;
                                    break;
                                case `type`:
                                    s = d;
                                    break;
                                case `checked`:
                                    l = d;
                                    break;
                                case `defaultChecked`:
                                    u = d;
                                    break;
                                case `value`:
                                    o = d;
                                    break;
                                case `defaultValue`:
                                    c = d;
                                    break;
                                case `children`:
                                case `dangerouslySetInnerHTML`:
                                    if (d != null) throw Error(a(137, t));
                                    break;
                                default:
                                    $(e, t, r, d, n, null)
                            }
                        }
                    Xt(e, o, c, l, u, s, i, !1);
                    return;
                case `select`:
                    for (i in Q(`invalid`, e), r = s = o = null, n)
                        if (n.hasOwnProperty(i) && (c = n[i], c != null)) switch (i) {
                            case `value`:
                                o = c;
                                break;
                            case `defaultValue`:
                                s = c;
                                break;
                            case `multiple`:
                                r = c;
                            default:
                                $(e, t, i, c, n, null)
                        }
                    t = o, n = s, e.multiple = !!r, t == null ? n != null && Qt(e, !!r, n, !0) : Qt(e, !!r, t, !1);
                    return;
                case `textarea`:
                    for (s in Q(`invalid`, e), o = i = r = null, n)
                        if (n.hasOwnProperty(s) && (c = n[s], c != null)) switch (s) {
                            case `value`:
                                r = c;
                                break;
                            case `defaultValue`:
                                i = c;
                                break;
                            case `children`:
                                o = c;
                                break;
                            case `dangerouslySetInnerHTML`:
                                if (c != null) throw Error(a(91));
                                break;
                            default:
                                $(e, t, s, c, n, null)
                        }
                    en(e, r, i, o);
                    return;
                case `option`:
                    for (l in n)
                        if (n.hasOwnProperty(l) && (r = n[l], r != null)) switch (l) {
                            case `selected`:
                                e.selected = r && typeof r != `function` && typeof r != `symbol`;
                                break;
                            default:
                                $(e, t, l, r, n, null)
                        }
                    return;
                case `dialog`:
                    Q(`beforetoggle`, e), Q(`toggle`, e), Q(`cancel`, e), Q(`close`, e);
                    break;
                case `iframe`:
                case `object`:
                    Q(`load`, e);
                    break;
                case `video`:
                case `audio`:
                    for (r = 0; r < _d.length; r++) Q(_d[r], e);
                    break;
                case `image`:
                    Q(`error`, e), Q(`load`, e);
                    break;
                case `details`:
                    Q(`toggle`, e);
                    break;
                case `embed`:
                case `source`:
                case `link`:
                    Q(`error`, e), Q(`load`, e);
                case `area`:
                case `base`:
                case `br`:
                case `col`:
                case `hr`:
                case `keygen`:
                case `meta`:
                case `param`:
                case `track`:
                case `wbr`:
                case `menuitem`:
                    for (u in n)
                        if (n.hasOwnProperty(u) && (r = n[u], r != null)) switch (u) {
                            case `children`:
                            case `dangerouslySetInnerHTML`:
                                throw Error(a(137, t));
                            default:
                                $(e, t, u, r, n, null)
                        }
                    return;
                default:
                    if (on(t)) {
                        for (d in n) n.hasOwnProperty(d) && (r = n[d], r !== void 0 && Nd(e, t, d, r, n, void 0));
                        return
                    }
            }
            for (c in n) n.hasOwnProperty(c) && (r = n[c], r != null && $(e, t, c, r, n, null))
        }

        function Fd(e, t, n, r) {
            switch (t) {
                case `div`:
                case `span`:
                case `svg`:
                case `path`:
                case `a`:
                case `g`:
                case `p`:
                case `li`:
                    break;
                case `input`:
                    var i = null,
                        o = null,
                        s = null,
                        c = null,
                        l = null,
                        u = null,
                        d = null;
                    for (m in n) {
                        var f = n[m];
                        if (n.hasOwnProperty(m) && f != null) switch (m) {
                            case `checked`:
                                break;
                            case `value`:
                                break;
                            case `defaultValue`:
                                l = f;
                            default:
                                r.hasOwnProperty(m) || $(e, t, m, null, r, f)
                        }
                    }
                    for (var p in r) {
                        var m = r[p];
                        if (f = n[p], r.hasOwnProperty(p) && (m != null || f != null)) switch (p) {
                            case `type`:
                                o = m;
                                break;
                            case `name`:
                                i = m;
                                break;
                            case `checked`:
                                u = m;
                                break;
                            case `defaultChecked`:
                                d = m;
                                break;
                            case `value`:
                                s = m;
                                break;
                            case `defaultValue`:
                                c = m;
                                break;
                            case `children`:
                            case `dangerouslySetInnerHTML`:
                                if (m != null) throw Error(a(137, t));
                                break;
                            default:
                                m !== f && $(e, t, p, m, r, f)
                        }
                    }
                    Yt(e, s, c, l, u, d, o, i);
                    return;
                case `select`:
                    for (o in m = s = c = p = null, n)
                        if (l = n[o], n.hasOwnProperty(o) && l != null) switch (o) {
                            case `value`:
                                break;
                            case `multiple`:
                                m = l;
                            default:
                                r.hasOwnProperty(o) || $(e, t, o, null, r, l)
                        }
                    for (i in r)
                        if (o = r[i], l = n[i], r.hasOwnProperty(i) && (o != null || l != null)) switch (i) {
                            case `value`:
                                p = o;
                                break;
                            case `defaultValue`:
                                c = o;
                                break;
                            case `multiple`:
                                s = o;
                            default:
                                o !== l && $(e, t, i, o, r, l)
                        }
                    t = c, n = s, r = m, p == null ? !!r != !!n && (t == null ? Qt(e, !!n, n ? [] : ``, !1) : Qt(e, !!n, t, !0)) : Qt(e, !!n, p, !1);
                    return;
                case `textarea`:
                    for (c in m = p = null, n)
                        if (i = n[c], n.hasOwnProperty(c) && i != null && !r.hasOwnProperty(c)) switch (c) {
                            case `value`:
                                break;
                            case `children`:
                                break;
                            default:
                                $(e, t, c, null, r, i)
                        }
                    for (s in r)
                        if (i = r[s], o = n[s], r.hasOwnProperty(s) && (i != null || o != null)) switch (s) {
                            case `value`:
                                p = i;
                                break;
                            case `defaultValue`:
                                m = i;
                                break;
                            case `children`:
                                break;
                            case `dangerouslySetInnerHTML`:
                                if (i != null) throw Error(a(91));
                                break;
                            default:
                                i !== o && $(e, t, s, i, r, o)
                        }
                    $t(e, p, m);
                    return;
                case `option`:
                    for (var h in n)
                        if (p = n[h], n.hasOwnProperty(h) && p != null && !r.hasOwnProperty(h)) switch (h) {
                            case `selected`:
                                e.selected = !1;
                                break;
                            default:
                                $(e, t, h, null, r, p)
                        }
                    for (l in r)
                        if (p = r[l], m = n[l], r.hasOwnProperty(l) && p !== m && (p != null || m != null)) switch (l) {
                            case `selected`:
                                e.selected = p && typeof p != `function` && typeof p != `symbol`;
                                break;
                            default:
                                $(e, t, l, p, r, m)
                        }
                    return;
                case `img`:
                case `link`:
                case `area`:
                case `base`:
                case `br`:
                case `col`:
                case `embed`:
                case `hr`:
                case `keygen`:
                case `meta`:
                case `param`:
                case `source`:
                case `track`:
                case `wbr`:
                case `menuitem`:
                    for (var g in n) p = n[g], n.hasOwnProperty(g) && p != null && !r.hasOwnProperty(g) && $(e, t, g, null, r, p);
                    for (u in r)
                        if (p = r[u], m = n[u], r.hasOwnProperty(u) && p !== m && (p != null || m != null)) switch (u) {
                            case `children`:
                            case `dangerouslySetInnerHTML`:
                                if (p != null) throw Error(a(137, t));
                                break;
                            default:
                                $(e, t, u, p, r, m)
                        }
                    return;
                default:
                    if (on(t)) {
                        for (var _ in n) p = n[_], n.hasOwnProperty(_) && p !== void 0 && !r.hasOwnProperty(_) && Nd(e, t, _, void 0, r, p);
                        for (d in r) p = r[d], m = n[d], !r.hasOwnProperty(d) || p === m || p === void 0 && m === void 0 || Nd(e, t, d, p, r, m);
                        return
                    }
            }
            for (var v in n) p = n[v], n.hasOwnProperty(v) && p != null && !r.hasOwnProperty(v) && $(e, t, v, null, r, p);
            for (f in r) p = r[f], m = n[f], !r.hasOwnProperty(f) || p === m || p == null && m == null || $(e, t, f, p, r, m)
        }

        function Id(e) {
            switch (e) {
                case `css`:
                case `script`:
                case `font`:
                case `img`:
                case `image`:
                case `input`:
                case `link`:
                    return !0;
                default:
                    return !1
            }
        }

        function Ld() {
            if (typeof performance.getEntriesByType == `function`) {
                for (var e = 0, t = 0, n = performance.getEntriesByType(`resource`), r = 0; r < n.length; r++) {
                    var i = n[r],
                        a = i.transferSize,
                        o = i.initiatorType,
                        s = i.duration;
                    if (a && s && Id(o)) {
                        for (o = 0, s = i.responseEnd, r += 1; r < n.length; r++) {
                            var c = n[r],
                                l = c.startTime;
                            if (l > s) break;
                            var u = c.transferSize,
                                d = c.initiatorType;
                            u && Id(d) && (c = c.responseEnd, o += u * (c < s ? 1 : (s - l) / (c - l)))
                        }
                        if (--r, t += 8 * (a + o) / (i.duration / 1e3), e++, 10 < e) break
                    }
                }
                if (0 < e) return t / e / 1e6
            }
            return navigator.connection && (e = navigator.connection.downlink, typeof e == `number`) ? e : 5
        }
        var Rd = null,
            zd = null;

        function Bd(e) {
            return e.nodeType === 9 ? e : e.ownerDocument
        }

        function Vd(e) {
            switch (e) {
                case `http://www.w3.org/2000/svg`:
                    return 1;
                case `http://www.w3.org/1998/Math/MathML`:
                    return 2;
                default:
                    return 0
            }
        }

        function Hd(e, t) {
            if (e === 0) switch (t) {
                case `svg`:
                    return 1;
                case `math`:
                    return 2;
                default:
                    return 0
            }
            return e === 1 && t === `foreignObject` ? 0 : e
        }

        function Ud(e, t) {
            return e === `textarea` || e === `noscript` || typeof t.children == `string` || typeof t.children == `number` || typeof t.children == `bigint` || typeof t.dangerouslySetInnerHTML == `object` && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
        }
        var Wd = null;

        function Gd() {
            var e = window.event;
            return e && e.type === `popstate` ? e === Wd ? !1 : (Wd = e, !0) : (Wd = null, !1)
        }
        var Kd = typeof setTimeout == `function` ? setTimeout : void 0,
            qd = typeof clearTimeout == `function` ? clearTimeout : void 0,
            Jd = typeof Promise == `function` ? Promise : void 0,
            Yd = typeof queueMicrotask == `function` ? queueMicrotask : Jd === void 0 ? Kd : function(e) {
                return Jd.resolve(null).then(e).catch(Xd)
            };

        function Xd(e) {
            setTimeout(function() {
                throw e
            })
        }

        function Zd(e) {
            return e === `head`
        }

        function Qd(e, t) {
            var n = t,
                r = 0;
            do {
                var i = n.nextSibling;
                if (e.removeChild(n), i && i.nodeType === 8)
                    if (n = i.data, n === `/$` || n === `/&`) {
                        if (r === 0) {
                            e.removeChild(i), Np(t);
                            return
                        }
                        r--
                    } else if (n === `$` || n === `$?` || n === `$~` || n === `$!` || n === `&`) r++;
                else if (n === `html`) pf(e.ownerDocument.documentElement);
                else if (n === `head`) {
                    n = e.ownerDocument.head, pf(n);
                    for (var a = n.firstChild; a;) {
                        var o = a.nextSibling,
                            s = a.nodeName;
                        a[wt] || s === `SCRIPT` || s === `STYLE` || s === `LINK` && a.rel.toLowerCase() === `stylesheet` || n.removeChild(a), a = o
                    }
                } else n === `body` && pf(e.ownerDocument.body);
                n = i
            } while (n);
            Np(t)
        }

        function $d(e, t) {
            var n = e;
            e = 0;
            do {
                var r = n.nextSibling;
                if (n.nodeType === 1 ? t ? (n._stashedDisplay = n.style.display, n.style.display = `none`) : (n.style.display = n._stashedDisplay || ``, n.getAttribute(`style`) === `` && n.removeAttribute(`style`)) : n.nodeType === 3 && (t ? (n._stashedText = n.nodeValue, n.nodeValue = ``) : n.nodeValue = n._stashedText || ``), r && r.nodeType === 8)
                    if (n = r.data, n === `/$`) {
                        if (e === 0) break;
                        e--
                    } else n !== `$` && n !== `$?` && n !== `$~` && n !== `$!` || e++;
                n = r
            } while (n)
        }

        function ef(e) {
            var t = e.firstChild;
            for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
                var n = t;
                switch (t = t.nextSibling, n.nodeName) {
                    case `HTML`:
                    case `HEAD`:
                    case `BODY`:
                        ef(n), Tt(n);
                        continue;
                    case `SCRIPT`:
                    case `STYLE`:
                        continue;
                    case `LINK`:
                        if (n.rel.toLowerCase() === `stylesheet`) continue
                }
                e.removeChild(n)
            }
        }

        function tf(e, t, n, r) {
            for (; e.nodeType === 1;) {
                var i = n;
                if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
                    if (!r && (e.nodeName !== `INPUT` || e.type !== `hidden`)) break
                } else if (!r)
                    if (t === `input` && e.type === `hidden`) {
                        var a = i.name == null ? null : `` + i.name;
                        if (i.type === `hidden` && e.getAttribute(`name`) === a) return e
                    } else return e;
                else if (!e[wt]) switch (t) {
                    case `meta`:
                        if (!e.hasAttribute(`itemprop`)) break;
                        return e;
                    case `link`:
                        if (a = e.getAttribute(`rel`), a === `stylesheet` && e.hasAttribute(`data-precedence`) || a !== i.rel || e.getAttribute(`href`) !== (i.href == null || i.href === `` ? null : i.href) || e.getAttribute(`crossorigin`) !== (i.crossOrigin == null ? null : i.crossOrigin) || e.getAttribute(`title`) !== (i.title == null ? null : i.title)) break;
                        return e;
                    case `style`:
                        if (e.hasAttribute(`data-precedence`)) break;
                        return e;
                    case `script`:
                        if (a = e.getAttribute(`src`), (a !== (i.src == null ? null : i.src) || e.getAttribute(`type`) !== (i.type == null ? null : i.type) || e.getAttribute(`crossorigin`) !== (i.crossOrigin == null ? null : i.crossOrigin)) && a && e.hasAttribute(`async`) && !e.hasAttribute(`itemprop`)) break;
                        return e;
                    default:
                        return e
                }
                if (e = cf(e.nextSibling), e === null) break
            }
            return null
        }

        function nf(e, t, n) {
            if (t === ``) return null;
            for (; e.nodeType !== 3;)
                if ((e.nodeType !== 1 || e.nodeName !== `INPUT` || e.type !== `hidden`) && !n || (e = cf(e.nextSibling), e === null)) return null;
            return e
        }

        function rf(e, t) {
            for (; e.nodeType !== 8;)
                if ((e.nodeType !== 1 || e.nodeName !== `INPUT` || e.type !== `hidden`) && !t || (e = cf(e.nextSibling), e === null)) return null;
            return e
        }

        function af(e) {
            return e.data === `$?` || e.data === `$~`
        }

        function of (e) {
            return e.data === `$!` || e.data === `$?` && e.ownerDocument.readyState !== `loading`
        }

        function sf(e, t) {
            var n = e.ownerDocument;
            if (e.data === `$~`) e._reactRetry = t;
            else if (e.data !== `$?` || n.readyState !== `loading`) t();
            else {
                var r = function() {
                    t(), n.removeEventListener(`DOMContentLoaded`, r)
                };
                n.addEventListener(`DOMContentLoaded`, r), e._reactRetry = r
            }
        }

        function cf(e) {
            for (; e != null; e = e.nextSibling) {
                var t = e.nodeType;
                if (t === 1 || t === 3) break;
                if (t === 8) {
                    if (t = e.data, t === `$` || t === `$!` || t === `$?` || t === `$~` || t === `&` || t === `F!` || t === `F`) break;
                    if (t === `/$` || t === `/&`) return null
                }
            }
            return e
        }
        var lf = null;

        function uf(e) {
            e = e.nextSibling;
            for (var t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === `/$` || n === `/&`) {
                        if (t === 0) return cf(e.nextSibling);
                        t--
                    } else n !== `$` && n !== `$!` && n !== `$?` && n !== `$~` && n !== `&` || t++
                }
                e = e.nextSibling
            }
            return null
        }

        function df(e) {
            e = e.previousSibling;
            for (var t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === `$` || n === `$!` || n === `$?` || n === `$~` || n === `&`) {
                        if (t === 0) return e;
                        t--
                    } else n !== `/$` && n !== `/&` || t++
                }
                e = e.previousSibling
            }
            return null
        }

        function ff(e, t, n) {
            switch (t = Bd(n), e) {
                case `html`:
                    if (e = t.documentElement, !e) throw Error(a(452));
                    return e;
                case `head`:
                    if (e = t.head, !e) throw Error(a(453));
                    return e;
                case `body`:
                    if (e = t.body, !e) throw Error(a(454));
                    return e;
                default:
                    throw Error(a(451))
            }
        }

        function pf(e) {
            for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
            Tt(e)
        }
        var mf = new Map,
            hf = new Set;

        function gf(e) {
            return typeof e.getRootNode == `function` ? e.getRootNode() : e.nodeType === 9 ? e : e.ownerDocument
        }
        var _f = T.d;
        T.d = {
            f: vf,
            r: yf,
            D: Sf,
            C: Cf,
            L: wf,
            m: Tf,
            X: Df,
            S: Ef,
            M: Of
        };

        function vf() {
            var e = _f.f(),
                t = bu();
            return e || t
        }

        function yf(e) {
            var t = Dt(e);
            t !== null && t.tag === 5 && t.type === `form` ? js(t) : _f.r(e)
        }
        var bf = typeof document > `u` ? null : document;

        function xf(e, t, n) {
            var r = bf;
            if (r && typeof t == `string` && t) {
                var i = Jt(t);
                i = `link[rel="` + e + `"][href="` + i + `"]`, typeof n == `string` && (i += `[crossorigin="` + n + `"]`), hf.has(i) || (hf.add(i), e = {
                    rel: e,
                    crossOrigin: n,
                    href: t
                }, r.querySelector(i) === null && (t = r.createElement(`link`), Pd(t, `link`, e), O(t), r.head.appendChild(t)))
            }
        }

        function Sf(e) {
            _f.D(e), xf(`dns-prefetch`, e, null)
        }

        function Cf(e, t) {
            _f.C(e, t), xf(`preconnect`, e, t)
        }

        function wf(e, t, n) {
            _f.L(e, t, n);
            var r = bf;
            if (r && e && t) {
                var i = `link[rel="preload"][as="` + Jt(t) + `"]`;
                t === `image` && n && n.imageSrcSet ? (i += `[imagesrcset="` + Jt(n.imageSrcSet) + `"]`, typeof n.imageSizes == `string` && (i += `[imagesizes="` + Jt(n.imageSizes) + `"]`)) : i += `[href="` + Jt(e) + `"]`;
                var a = i;
                switch (t) {
                    case `style`:
                        a = Af(e);
                        break;
                    case `script`:
                        a = Pf(e)
                }
                mf.has(a) || (e = m({
                    rel: `preload`,
                    href: t === `image` && n && n.imageSrcSet ? void 0 : e,
                    as: t
                }, n), mf.set(a, e), r.querySelector(i) !== null || t === `style` && r.querySelector(jf(a)) || t === `script` && r.querySelector(Ff(a)) || (t = r.createElement(`link`), Pd(t, `link`, e), O(t), r.head.appendChild(t)))
            }
        }

        function Tf(e, t) {
            _f.m(e, t);
            var n = bf;
            if (n && e) {
                var r = t && typeof t.as == `string` ? t.as : `script`,
                    i = `link[rel="modulepreload"][as="` + Jt(r) + `"][href="` + Jt(e) + `"]`,
                    a = i;
                switch (r) {
                    case `audioworklet`:
                    case `paintworklet`:
                    case `serviceworker`:
                    case `sharedworker`:
                    case `worker`:
                    case `script`:
                        a = Pf(e)
                }
                if (!mf.has(a) && (e = m({
                        rel: `modulepreload`,
                        href: e
                    }, t), mf.set(a, e), n.querySelector(i) === null)) {
                    switch (r) {
                        case `audioworklet`:
                        case `paintworklet`:
                        case `serviceworker`:
                        case `sharedworker`:
                        case `worker`:
                        case `script`:
                            if (n.querySelector(Ff(a))) return
                    }
                    r = n.createElement(`link`), Pd(r, `link`, e), O(r), n.head.appendChild(r)
                }
            }
        }

        function Ef(e, t, n) {
            _f.S(e, t, n);
            var r = bf;
            if (r && e) {
                var i = kt(r).hoistableStyles,
                    a = Af(e);
                t || = `default`;
                var o = i.get(a);
                if (!o) {
                    var s = {
                        loading: 0,
                        preload: null
                    };
                    if (o = r.querySelector(jf(a))) s.loading = 5;
                    else {
                        e = m({
                            rel: `stylesheet`,
                            href: e,
                            "data-precedence": t
                        }, n), (n = mf.get(a)) && Rf(e, n);
                        var c = o = r.createElement(`link`);
                        O(c), Pd(c, `link`, e), c._p = new Promise(function(e, t) {
                            c.onload = e, c.onerror = t
                        }), c.addEventListener(`load`, function() {
                            s.loading |= 1
                        }), c.addEventListener(`error`, function() {
                            s.loading |= 2
                        }), s.loading |= 4, Lf(o, t, r)
                    }
                    o = {
                        type: `stylesheet`,
                        instance: o,
                        count: 1,
                        state: s
                    }, i.set(a, o)
                }
            }
        }

        function Df(e, t) {
            _f.X(e, t);
            var n = bf;
            if (n && e) {
                var r = kt(n).hoistableScripts,
                    i = Pf(e),
                    a = r.get(i);
                a || (a = n.querySelector(Ff(i)), a || (e = m({
                    src: e,
                    async: !0
                }, t), (t = mf.get(i)) && zf(e, t), a = n.createElement(`script`), O(a), Pd(a, `link`, e), n.head.appendChild(a)), a = {
                    type: `script`,
                    instance: a,
                    count: 1,
                    state: null
                }, r.set(i, a))
            }
        }

        function Of(e, t) {
            _f.M(e, t);
            var n = bf;
            if (n && e) {
                var r = kt(n).hoistableScripts,
                    i = Pf(e),
                    a = r.get(i);
                a || (a = n.querySelector(Ff(i)), a || (e = m({
                    src: e,
                    async: !0,
                    type: `module`
                }, t), (t = mf.get(i)) && zf(e, t), a = n.createElement(`script`), O(a), Pd(a, `link`, e), n.head.appendChild(a)), a = {
                    type: `script`,
                    instance: a,
                    count: 1,
                    state: null
                }, r.set(i, a))
            }
        }

        function kf(e, t, n, r) {
            var i = (i = ve.current) ? gf(i) : null;
            if (!i) throw Error(a(446));
            switch (e) {
                case `meta`:
                case `title`:
                    return null;
                case `style`:
                    return typeof n.precedence == `string` && typeof n.href == `string` ? (t = Af(n.href), n = kt(i).hoistableStyles, r = n.get(t), r || (r = {
                        type: `style`,
                        instance: null,
                        count: 0,
                        state: null
                    }, n.set(t, r)), r) : {
                        type: `void`,
                        instance: null,
                        count: 0,
                        state: null
                    };
                case `link`:
                    if (n.rel === `stylesheet` && typeof n.href == `string` && typeof n.precedence == `string`) {
                        e = Af(n.href);
                        var o = kt(i).hoistableStyles,
                            s = o.get(e);
                        if (s || (i = i.ownerDocument || i, s = {
                                type: `stylesheet`,
                                instance: null,
                                count: 0,
                                state: {
                                    loading: 0,
                                    preload: null
                                }
                            }, o.set(e, s), (o = i.querySelector(jf(e))) && !o._p && (s.instance = o, s.state.loading = 5), mf.has(e) || (n = {
                                rel: `preload`,
                                as: `style`,
                                href: n.href,
                                crossOrigin: n.crossOrigin,
                                integrity: n.integrity,
                                media: n.media,
                                hrefLang: n.hrefLang,
                                referrerPolicy: n.referrerPolicy
                            }, mf.set(e, n), o || Nf(i, e, n, s.state))), t && r === null) throw Error(a(528, ``));
                        return s
                    }
                    if (t && r !== null) throw Error(a(529, ``));
                    return null;
                case `script`:
                    return t = n.async, n = n.src, typeof n == `string` && t && typeof t != `function` && typeof t != `symbol` ? (t = Pf(n), n = kt(i).hoistableScripts, r = n.get(t), r || (r = {
                        type: `script`,
                        instance: null,
                        count: 0,
                        state: null
                    }, n.set(t, r)), r) : {
                        type: `void`,
                        instance: null,
                        count: 0,
                        state: null
                    };
                default:
                    throw Error(a(444, e))
            }
        }

        function Af(e) {
            return `href="` + Jt(e) + `"`
        }

        function jf(e) {
            return `link[rel="stylesheet"][` + e + `]`
        }

        function Mf(e) {
            return m({}, e, {
                "data-precedence": e.precedence,
                precedence: null
            })
        }

        function Nf(e, t, n, r) {
            e.querySelector(`link[rel="preload"][as="style"][` + t + `]`) ? r.loading = 1 : (t = e.createElement(`link`), r.preload = t, t.addEventListener(`load`, function() {
                return r.loading |= 1
            }), t.addEventListener(`error`, function() {
                return r.loading |= 2
            }), Pd(t, `link`, n), O(t), e.head.appendChild(t))
        }

        function Pf(e) {
            return `[src="` + Jt(e) + `"]`
        }

        function Ff(e) {
            return `script[async]` + e
        }

        function If(e, t, n) {
            if (t.count++, t.instance === null) switch (t.type) {
                case `style`:
                    var r = e.querySelector(`style[data-href~="` + Jt(n.href) + `"]`);
                    if (r) return t.instance = r, O(r), r;
                    var i = m({}, n, {
                        "data-href": n.href,
                        "data-precedence": n.precedence,
                        href: null,
                        precedence: null
                    });
                    return r = (e.ownerDocument || e).createElement(`style`), O(r), Pd(r, `style`, i), Lf(r, n.precedence, e), t.instance = r;
                case `stylesheet`:
                    i = Af(n.href);
                    var o = e.querySelector(jf(i));
                    if (o) return t.state.loading |= 4, t.instance = o, O(o), o;
                    r = Mf(n), (i = mf.get(i)) && Rf(r, i), o = (e.ownerDocument || e).createElement(`link`), O(o);
                    var s = o;
                    return s._p = new Promise(function(e, t) {
                        s.onload = e, s.onerror = t
                    }), Pd(o, `link`, r), t.state.loading |= 4, Lf(o, n.precedence, e), t.instance = o;
                case `script`:
                    return o = Pf(n.src), (i = e.querySelector(Ff(o))) ? (t.instance = i, O(i), i) : (r = n, (i = mf.get(o)) && (r = m({}, n), zf(r, i)), e = e.ownerDocument || e, i = e.createElement(`script`), O(i), Pd(i, `link`, r), e.head.appendChild(i), t.instance = i);
                case `void`:
                    return null;
                default:
                    throw Error(a(443, t.type))
            } else t.type === `stylesheet` && !(t.state.loading & 4) && (r = t.instance, t.state.loading |= 4, Lf(r, n.precedence, e));
            return t.instance
        }

        function Lf(e, t, n) {
            for (var r = n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`), i = r.length ? r[r.length - 1] : null, a = i, o = 0; o < r.length; o++) {
                var s = r[o];
                if (s.dataset.precedence === t) a = s;
                else if (a !== i) break
            }
            a ? a.parentNode.insertBefore(e, a.nextSibling) : (t = n.nodeType === 9 ? n.head : n, t.insertBefore(e, t.firstChild))
        }

        function Rf(e, t) {
            e.crossOrigin ? ? = t.crossOrigin, e.referrerPolicy ? ? = t.referrerPolicy, e.title ? ? = t.title
        }

        function zf(e, t) {
            e.crossOrigin ? ? = t.crossOrigin, e.referrerPolicy ? ? = t.referrerPolicy, e.integrity ? ? = t.integrity
        }
        var Bf = null;

        function Vf(e, t, n) {
            if (Bf === null) {
                var r = new Map,
                    i = Bf = new Map;
                i.set(n, r)
            } else i = Bf, r = i.get(n), r || (r = new Map, i.set(n, r));
            if (r.has(e)) return r;
            for (r.set(e, null), n = n.getElementsByTagName(e), i = 0; i < n.length; i++) {
                var a = n[i];
                if (!(a[wt] || a[_t] || e === `link` && a.getAttribute(`rel`) === `stylesheet`) && a.namespaceURI !== `http://www.w3.org/2000/svg`) {
                    var o = a.getAttribute(t) || ``;
                    o = e + o;
                    var s = r.get(o);
                    s ? s.push(a) : r.set(o, [a])
                }
            }
            return r
        }

        function Hf(e, t, n) {
            e = e.ownerDocument || e, e.head.insertBefore(n, t === `title` ? e.querySelector(`head > title`) : null)
        }

        function Uf(e, t, n) {
            if (n === 1 || t.itemProp != null) return !1;
            switch (e) {
                case `meta`:
                case `title`:
                    return !0;
                case `style`:
                    if (typeof t.precedence != `string` || typeof t.href != `string` || t.href === ``) break;
                    return !0;
                case `link`:
                    if (typeof t.rel != `string` || typeof t.href != `string` || t.href === `` || t.onLoad || t.onError) break;
                    switch (t.rel) {
                        case `stylesheet`:
                            return e = t.disabled, typeof t.precedence == `string` && e == null;
                        default:
                            return !0
                    }
                case `script`:
                    if (t.async && typeof t.async != `function` && typeof t.async != `symbol` && !t.onLoad && !t.onError && t.src && typeof t.src == `string`) return !0
            }
            return !1
        }

        function Wf(e) {
            return !(e.type === `stylesheet` && !(e.state.loading & 3))
        }

        function Gf(e, t, n, r) {
            if (n.type === `stylesheet` && (typeof r.media != `string` || !1 !== matchMedia(r.media).matches) && !(n.state.loading & 4)) {
                if (n.instance === null) {
                    var i = Af(r.href),
                        a = t.querySelector(jf(i));
                    if (a) {
                        t = a._p, typeof t == `object` && t && typeof t.then == `function` && (e.count++, e = Jf.bind(e), t.then(e, e)), n.state.loading |= 4, n.instance = a, O(a);
                        return
                    }
                    a = t.ownerDocument || t, r = Mf(r), (i = mf.get(i)) && Rf(r, i), a = a.createElement(`link`), O(a);
                    var o = a;
                    o._p = new Promise(function(e, t) {
                        o.onload = e, o.onerror = t
                    }), Pd(a, `link`, r), n.instance = a
                }
                e.stylesheets === null && (e.stylesheets = new Map), e.stylesheets.set(n, t), (t = n.state.preload) && !(n.state.loading & 3) && (e.count++, n = Jf.bind(e), t.addEventListener(`load`, n), t.addEventListener(`error`, n))
            }
        }
        var Kf = 0;

        function qf(e, t) {
            return e.stylesheets && e.count === 0 && Xf(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(n) {
                var r = setTimeout(function() {
                    if (e.stylesheets && Xf(e, e.stylesheets), e.unsuspend) {
                        var t = e.unsuspend;
                        e.unsuspend = null, t()
                    }
                }, 6e4 + t);
                0 < e.imgBytes && Kf === 0 && (Kf = 62500 * Ld());
                var i = setTimeout(function() {
                    if (e.waitingForImages = !1, e.count === 0 && (e.stylesheets && Xf(e, e.stylesheets), e.unsuspend)) {
                        var t = e.unsuspend;
                        e.unsuspend = null, t()
                    }
                }, (e.imgBytes > Kf ? 50 : 800) + t);
                return e.unsuspend = n,
                    function() {
                        e.unsuspend = null, clearTimeout(r), clearTimeout(i)
                    }
            } : null
        }

        function Jf() {
            if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
                if (this.stylesheets) Xf(this, this.stylesheets);
                else if (this.unsuspend) {
                    var e = this.unsuspend;
                    this.unsuspend = null, e()
                }
            }
        }
        var Yf = null;

        function Xf(e, t) {
            e.stylesheets = null, e.unsuspend !== null && (e.count++, Yf = new Map, t.forEach(Zf, e), Yf = null, Jf.call(e))
        }

        function Zf(e, t) {
            if (!(t.state.loading & 4)) {
                var n = Yf.get(e);
                if (n) var r = n.get(null);
                else {
                    n = new Map, Yf.set(e, n);
                    for (var i = e.querySelectorAll(`link[data-precedence],style[data-precedence]`), a = 0; a < i.length; a++) {
                        var o = i[a];
                        (o.nodeName === `LINK` || o.getAttribute(`media`) !== `not all`) && (n.set(o.dataset.precedence, o), r = o)
                    }
                    r && n.set(null, r)
                }
                i = t.instance, o = i.getAttribute(`data-precedence`), a = n.get(o) || r, a === r && n.set(null, i), n.set(o, i), this.count++, r = Jf.bind(this), i.addEventListener(`load`, r), i.addEventListener(`error`, r), a ? a.parentNode.insertBefore(i, a.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(i, e.firstChild)), t.state.loading |= 4
            }
        }
        var Qf = {
            $$typeof: te,
            Provider: null,
            Consumer: null,
            _currentValue: fe,
            _currentValue2: fe,
            _threadCount: 0
        };

        function $f(e, t, n, r, i, a, o, s, c) {
            this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = ot(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = ot(0), this.hiddenUpdates = ot(null), this.identifierPrefix = r, this.onUncaughtError = i, this.onCaughtError = a, this.onRecoverableError = o, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c, this.incompleteTransitions = new Map
        }

        function ep(e, t, n, r, i, a, o, s, c, l, u, d) {
            return e = new $f(e, t, n, o, c, l, u, d, s), t = 1, !0 === a && (t |= 24), a = vi(3, null, null, t), e.current = a, a.stateNode = e, t = ha(), t.refCount++, e.pooledCache = t, t.refCount++, a.memoizedState = {
                element: r,
                isDehydrated: n,
                cache: t
            }, Ja(a), e
        }

        function tp(e) {
            return e ? (e = gi, e) : gi
        }

        function np(e, t, n, r, i, a) {
            i = tp(i), r.context === null ? r.context = i : r.pendingContext = i, r = Xa(t), r.payload = {
                element: n
            }, a = a === void 0 ? null : a, a !== null && (r.callback = a), n = Za(e, r, t), n !== null && (hu(n, e, t), Qa(n, e, t))
        }

        function rp(e, t) {
            if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
                var n = e.retryLane;
                e.retryLane = n !== 0 && n < t ? n : t
            }
        }

        function ip(e, t) {
            rp(e, t), (e = e.alternate) && rp(e, t)
        }

        function ap(e) {
            if (e.tag === 13 || e.tag === 31) {
                var t = pi(e, 67108864);
                t !== null && hu(t, e, 67108864), ip(e, 67108864)
            }
        }

        function op(e) {
            if (e.tag === 13 || e.tag === 31) {
                var t = pu();
                t = ft(t);
                var n = pi(e, t);
                n !== null && hu(n, e, t), ip(e, t)
            }
        }
        var sp = !0;

        function cp(e, t, n, r) {
            var i = w.T;
            w.T = null;
            var a = T.p;
            try {
                T.p = 2, up(e, t, n, r)
            } finally {
                T.p = a, w.T = i
            }
        }

        function lp(e, t, n, r) {
            var i = w.T;
            w.T = null;
            var a = T.p;
            try {
                T.p = 8, up(e, t, n, r)
            } finally {
                T.p = a, w.T = i
            }
        }

        function up(e, t, n, r) {
            if (sp) {
                var i = dp(r);
                if (i === null) wd(e, t, r, fp, n), Cp(e, r);
                else if (Tp(i, e, t, n, r)) r.stopPropagation();
                else if (Cp(e, r), t & 4 && -1 < Sp.indexOf(e)) {
                    for (; i !== null;) {
                        var a = Dt(i);
                        if (a !== null) switch (a.tag) {
                            case 3:
                                if (a = a.stateNode, a.current.memoizedState.isDehydrated) {
                                    var o = tt(a.pendingLanes);
                                    if (o !== 0) {
                                        var s = a;
                                        for (s.pendingLanes |= 2, s.entangledLanes |= 2; o;) {
                                            var c = 1 << 31 - Je(o);
                                            s.entanglements[1] |= c, o &= ~c
                                        }
                                        rd(a), !(W & 6) && (nu = Ie() + 500, id(0, !1))
                                    }
                                }
                                break;
                            case 31:
                            case 13:
                                s = pi(a, 2), s !== null && hu(s, a, 2), bu(), ip(a, 2)
                        }
                        if (a = dp(r), a === null && wd(e, t, r, fp, n), a === i) break;
                        i = a
                    }
                    i !== null && r.stopPropagation()
                } else wd(e, t, r, null, n)
            }
        }

        function dp(e) {
            return e = fn(e), pp(e)
        }
        var fp = null;

        function pp(e) {
            if (fp = null, e = Et(e), e !== null) {
                var t = c(e);
                if (t === null) e = null;
                else {
                    var n = t.tag;
                    if (n === 13) {
                        if (e = l(t), e !== null) return e;
                        e = null
                    } else if (n === 31) {
                        if (e = u(t), e !== null) return e;
                        e = null
                    } else if (n === 3) {
                        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
                        e = null
                    } else t !== e && (e = null)
                }
            }
            return fp = e, null
        }

        function mp(e) {
            switch (e) {
                case `beforetoggle`:
                case `cancel`:
                case `click`:
                case `close`:
                case `contextmenu`:
                case `copy`:
                case `cut`:
                case `auxclick`:
                case `dblclick`:
                case `dragend`:
                case `dragstart`:
                case `drop`:
                case `focusin`:
                case `focusout`:
                case `input`:
                case `invalid`:
                case `keydown`:
                case `keypress`:
                case `keyup`:
                case `mousedown`:
                case `mouseup`:
                case `paste`:
                case `pause`:
                case `play`:
                case `pointercancel`:
                case `pointerdown`:
                case `pointerup`:
                case `ratechange`:
                case `reset`:
                case `resize`:
                case `seeked`:
                case `submit`:
                case `toggle`:
                case `touchcancel`:
                case `touchend`:
                case `touchstart`:
                case `volumechange`:
                case `change`:
                case `selectionchange`:
                case `textInput`:
                case `compositionstart`:
                case `compositionend`:
                case `compositionupdate`:
                case `beforeblur`:
                case `afterblur`:
                case `beforeinput`:
                case `blur`:
                case `fullscreenchange`:
                case `focus`:
                case `hashchange`:
                case `popstate`:
                case `select`:
                case `selectstart`:
                    return 2;
                case `drag`:
                case `dragenter`:
                case `dragexit`:
                case `dragleave`:
                case `dragover`:
                case `mousemove`:
                case `mouseout`:
                case `mouseover`:
                case `pointermove`:
                case `pointerout`:
                case `pointerover`:
                case `scroll`:
                case `touchmove`:
                case `wheel`:
                case `mouseenter`:
                case `mouseleave`:
                case `pointerenter`:
                case `pointerleave`:
                    return 8;
                case `message`:
                    switch (Le()) {
                        case Re:
                            return 2;
                        case ze:
                            return 8;
                        case Be:
                        case Ve:
                            return 32;
                        case He:
                            return 268435456;
                        default:
                            return 32
                    }
                default:
                    return 32
            }
        }
        var hp = !1,
            gp = null,
            _p = null,
            vp = null,
            yp = new Map,
            bp = new Map,
            xp = [],
            Sp = `mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);

        function Cp(e, t) {
            switch (e) {
                case `focusin`:
                case `focusout`:
                    gp = null;
                    break;
                case `dragenter`:
                case `dragleave`:
                    _p = null;
                    break;
                case `mouseover`:
                case `mouseout`:
                    vp = null;
                    break;
                case `pointerover`:
                case `pointerout`:
                    yp.delete(t.pointerId);
                    break;
                case `gotpointercapture`:
                case `lostpointercapture`:
                    bp.delete(t.pointerId)
            }
        }

        function wp(e, t, n, r, i, a) {
            return e === null || e.nativeEvent !== a ? (e = {
                blockedOn: t,
                domEventName: n,
                eventSystemFlags: r,
                nativeEvent: a,
                targetContainers: [i]
            }, t !== null && (t = Dt(t), t !== null && ap(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e)
        }

        function Tp(e, t, n, r, i) {
            switch (t) {
                case `focusin`:
                    return gp = wp(gp, e, t, n, r, i), !0;
                case `dragenter`:
                    return _p = wp(_p, e, t, n, r, i), !0;
                case `mouseover`:
                    return vp = wp(vp, e, t, n, r, i), !0;
                case `pointerover`:
                    var a = i.pointerId;
                    return yp.set(a, wp(yp.get(a) || null, e, t, n, r, i)), !0;
                case `gotpointercapture`:
                    return a = i.pointerId, bp.set(a, wp(bp.get(a) || null, e, t, n, r, i)), !0
            }
            return !1
        }

        function Ep(e) {
            var t = Et(e.target);
            if (t !== null) {
                var n = c(t);
                if (n !== null) {
                    if (t = n.tag, t === 13) {
                        if (t = l(n), t !== null) {
                            e.blockedOn = t, ht(e.priority, function() {
                                op(n)
                            });
                            return
                        }
                    } else if (t === 31) {
                        if (t = u(n), t !== null) {
                            e.blockedOn = t, ht(e.priority, function() {
                                op(n)
                            });
                            return
                        }
                    } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                        e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                        return
                    }
                }
            }
            e.blockedOn = null
        }

        function Dp(e) {
            if (e.blockedOn !== null) return !1;
            for (var t = e.targetContainers; 0 < t.length;) {
                var n = dp(e.nativeEvent);
                if (n === null) {
                    n = e.nativeEvent;
                    var r = new n.constructor(n.type, n);
                    dn = r, n.target.dispatchEvent(r), dn = null
                } else return t = Dt(n), t !== null && ap(t), e.blockedOn = n, !1;
                t.shift()
            }
            return !0
        }

        function Op(e, t, n) {
            Dp(e) && n.delete(t)
        }

        function kp() {
            hp = !1, gp !== null && Dp(gp) && (gp = null), _p !== null && Dp(_p) && (_p = null), vp !== null && Dp(vp) && (vp = null), yp.forEach(Op), bp.forEach(Op)
        }

        function Ap(e, n) {
            e.blockedOn === n && (e.blockedOn = null, hp || (hp = !0, t.unstable_scheduleCallback(t.unstable_NormalPriority, kp)))
        }
        var jp = null;

        function Mp(e) {
            jp !== e && (jp = e, t.unstable_scheduleCallback(t.unstable_NormalPriority, function() {
                jp === e && (jp = null);
                for (var t = 0; t < e.length; t += 3) {
                    var n = e[t],
                        r = e[t + 1],
                        i = e[t + 2];
                    if (typeof r != `function`) {
                        if (pp(r || n) === null) continue;
                        break
                    }
                    var a = Dt(n);
                    a !== null && (e.splice(t, 3), t -= 3, ks(a, {
                        pending: !0,
                        data: i,
                        method: n.method,
                        action: r
                    }, r, i))
                }
            }))
        }

        function Np(e) {
            function t(t) {
                return Ap(t, e)
            }
            gp !== null && Ap(gp, e), _p !== null && Ap(_p, e), vp !== null && Ap(vp, e), yp.forEach(t), bp.forEach(t);
            for (var n = 0; n < xp.length; n++) {
                var r = xp[n];
                r.blockedOn === e && (r.blockedOn = null)
            }
            for (; 0 < xp.length && (n = xp[0], n.blockedOn === null);) Ep(n), n.blockedOn === null && xp.shift();
            if (n = (e.ownerDocument || e).$$reactFormReplay, n != null)
                for (r = 0; r < n.length; r += 3) {
                    var i = n[r],
                        a = n[r + 1],
                        o = i[vt] || null;
                    if (typeof a == `function`) o || Mp(n);
                    else if (o) {
                        var s = null;
                        if (a && a.hasAttribute(`formAction`)) {
                            if (i = a, o = a[vt] || null) s = o.formAction;
                            else if (pp(i) !== null) continue
                        } else s = o.action;
                        typeof s == `function` ? n[r + 1] = s : (n.splice(r, 3), r -= 3), Mp(n)
                    }
                }
        }

        function Pp() {
            function e(e) {
                e.canIntercept && e.info === `react-transition` && e.intercept({
                    handler: function() {
                        return new Promise(function(e) {
                            return i = e
                        })
                    },
                    focusReset: `manual`,
                    scroll: `manual`
                })
            }

            function t() {
                i !== null && (i(), i = null), r || setTimeout(n, 20)
            }

            function n() {
                if (!r && !navigation.transition) {
                    var e = navigation.currentEntry;
                    e && e.url != null && navigation.navigate(e.url, {
                        state: e.getState(),
                        info: `react-transition`,
                        history: `replace`
                    })
                }
            }
            if (typeof navigation == `object`) {
                var r = !1,
                    i = null;
                return navigation.addEventListener(`navigate`, e), navigation.addEventListener(`navigatesuccess`, t), navigation.addEventListener(`navigateerror`, t), setTimeout(n, 100),
                    function() {
                        r = !0, navigation.removeEventListener(`navigate`, e), navigation.removeEventListener(`navigatesuccess`, t), navigation.removeEventListener(`navigateerror`, t), i !== null && (i(), i = null)
                    }
            }
        }

        function Fp(e) {
            this._internalRoot = e
        }
        Ip.prototype.render = Fp.prototype.render = function(e) {
            var t = this._internalRoot;
            if (t === null) throw Error(a(409));
            var n = t.current;
            np(n, pu(), e, t, null, null)
        }, Ip.prototype.unmount = Fp.prototype.unmount = function() {
            var e = this._internalRoot;
            if (e !== null) {
                this._internalRoot = null;
                var t = e.containerInfo;
                np(e.current, 2, null, e, null, null), bu(), t[yt] = null
            }
        };

        function Ip(e) {
            this._internalRoot = e
        }
        Ip.prototype.unstable_scheduleHydration = function(e) {
            if (e) {
                var t = mt();
                e = {
                    blockedOn: null,
                    target: e,
                    priority: t
                };
                for (var n = 0; n < xp.length && t !== 0 && t < xp[n].priority; n++);
                xp.splice(n, 0, e), n === 0 && Ep(e)
            }
        };
        var Lp = r.version;
        if (Lp !== `19.2.4`) throw Error(a(527, Lp, `19.2.4`));
        T.findDOMNode = function(e) {
            var t = e._reactInternals;
            if (t === void 0) throw typeof e.render == `function` ? Error(a(188)) : (e = Object.keys(e).join(`,`), Error(a(268, e)));
            return e = f(t), e = e === null ? null : p(e), e = e === null ? null : e.stateNode, e
        };
        var Rp = {
            bundleType: 0,
            version: `19.2.4`,
            rendererPackageName: `react-dom`,
            currentDispatcherRef: w,
            reconcilerVersion: `19.2.4`
        };
        if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u`) {
            var zp = __REACT_DEVTOOLS_GLOBAL_HOOK__;
            if (!zp.isDisabled && zp.supportsFiber) try {
                Ge = zp.inject(Rp), Ke = zp
            } catch {}
        }
        e.createRoot = function(e, t) {
            if (!s(e)) throw Error(a(299));
            var n = !1,
                r = ``,
                i = Qs,
                o = $s,
                c = ec;
            return t != null && (!0 === t.unstable_strictMode && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onUncaughtError !== void 0 && (i = t.onUncaughtError), t.onCaughtError !== void 0 && (o = t.onCaughtError), t.onRecoverableError !== void 0 && (c = t.onRecoverableError)), t = ep(e, 1, !1, null, null, n, r, null, i, o, c, Pp), e[yt] = t.current, Sd(e), new Fp(t)
        }
    })),
    v = t(((e, t) => {
        function n() {
            if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`)) try {
                __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
            } catch {}
        }
        n(), t.exports = _()
    })),
    y = e(n(), 1),
    b = v(),
    x = `grail_cookie_consent`,
    ee = new Set([`Atlantic/Canary`, `Atlantic/Madeira`, `Atlantic/Azores`, `Atlantic/Reykjavik`, `Atlantic/Faroe`]);

function te() {
    try {
        let e = Intl.DateTimeFormat().resolvedOptions().timeZone || ``;
        return e.startsWith(`Europe/`) || ee.has(e)
    } catch {
        return !1
    }
}

function ne() {
    try {
        let e = localStorage.getItem(x);
        return e === `granted` || e === `denied` ? e : null
    } catch {
        return null
    }
}

function re(e) {
    try {
        localStorage.setItem(x, e)
    } catch {}
}

function ie() {
    return te() ? ne() === `granted` : !0
}

function ae() {
    return te() && ne() === null
}
var S = {
        bar: `_bar_1lt29_4`,
        cookieIn: `_cookieIn_1lt29_1`,
        copy: `_copy_1lt29_33`,
        link: `_link_1lt29_39`,
        actions: `_actions_1lt29_42`,
        accept: `_accept_1lt29_48`,
        decline: `_decline_1lt29_49`
    },
    C = r();

function oe() {
    let [e, t] = (0, y.useState)(() => ae());
    if (!e) return null;
    let n = e => {
        re(e), t(!1), e === `granted` && m()
    };
    return (0, C.jsxs)(`div`, {
        className: S.bar,
        role: `dialog`,
        "aria-label": `Cookies`,
        children: [(0, C.jsxs)(`p`, {
            className: S.copy,
            children: [`We use one analytics cookie to see which parts of this page people read. No ads, no tracking across other sites.`, ` `, (0, C.jsx)(`a`, {
                className: S.link,
                href: `/privacy`,
                children: `Privacy`
            })]
        }), (0, C.jsxs)(`div`, {
            className: S.actions,
            children: [(0, C.jsx)(`button`, {
                type: `button`,
                className: S.decline,
                onClick: () => n(`denied`),
                children: `Decline`
            }), (0, C.jsx)(`button`, {
                type: `button`,
                className: S.accept,
                onClick: () => n(`granted`),
                children: `Accept`
            })]
        })]
    })
}
var se = (0, y.lazy)(() => u(() =>
        import (`./LandingPage-CTc69vQU.js`).then(e => ({
            default: e.LandingPage
        })), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))),
    ce = (0, y.lazy)(() => u(() =>
        import (`./AdminPage-jFGRsJNv.js`).then(e => ({
            default: e.AdminPage
        })), __vite__mapDeps([11, 1, 2, 5, 6, 7, 12]))),
    le = (0, y.lazy)(() => u(() =>
        import (`./QuestPreviewPage-DsyUOMYq.js`).then(e => ({
            default: e.QuestPreviewPage
        })), __vite__mapDeps([13, 1, 2, 4, 5, 14, 9, 7, 15]))),
    ue = (0, y.lazy)(() => u(() =>
        import (`./VinePage-DRdU3128.js`).then(e => ({
            default: e.VinePage
        })), __vite__mapDeps([16, 1, 5, 17, 18]))),
    de = (0, y.lazy)(() => u(() =>
        import (`./VineGardenPage-DThsOHDb.js`).then(e => ({
            default: e.VineGardenPage
        })), __vite__mapDeps([19, 5, 1, 20, 21, 17, 22]))),
    w = (0, y.lazy)(() => u(() =>
        import (`./TotemLabPage-BVmcCZ5j.js`).then(e => ({
            default: e.TotemLabPage
        })), __vite__mapDeps([23, 1, 5, 24, 25, 26, 27, 21, 28, 29]))),
    T = (0, y.lazy)(() => u(() =>
        import (`./TotemMotionLabPage-fR4PRscq.js`).then(e => ({
            default: e.TotemMotionLabPage
        })), __vite__mapDeps([30, 1, 5, 26, 27, 21, 31, 24, 25, 28, 29]))),
    fe = (0, y.lazy)(() => u(() =>
        import (`./LegalPage-CJ5YXgPP.js`).then(e => ({
            default: e.PrivacyPage
        })), __vite__mapDeps([32, 1, 14, 9, 5, 33]))),
    pe = (0, y.lazy)(() => u(() =>
        import (`./LegalPage-CJ5YXgPP.js`).then(e => ({
            default: e.TermsPage
        })), __vite__mapDeps([32, 1, 14, 9, 5, 33]))),
    me = (0, y.lazy)(() => u(() =>
        import (`./LightLabPage-DXIfYTrs.js`).then(e => ({
            default: e.LightLabPage
        })), __vite__mapDeps([34, 1, 5, 24, 25, 35]))),
    he = (0, y.lazy)(() => u(() =>
        import (`./WarpPage-CSnFt4vc.js`).then(e => ({
            default: e.WarpPage
        })), __vite__mapDeps([36, 1, 5, 37, 38]))),
    E = (0, y.lazy)(() => u(() =>
        import (`./SpiralPage-DMepWIBc.js`).then(e => ({
            default: e.SpiralPage
        })), __vite__mapDeps([39, 1, 5, 40, 41]))),
    D = (0, y.lazy)(() => u(() =>
        import (`./LoaderLabPage-gJopzEng.js`).then(e => ({
            default: e.LoaderLabPage
        })), __vite__mapDeps([42, 1, 43, 9, 5, 24, 26, 27, 21, 20, 17, 40, 8, 37, 44, 45]))),
    ge = (0, y.lazy)(() => u(() =>
        import (`./App-DWONLjzX.js`), __vite__mapDeps([46, 1, 2, 3, 4, 5, 6, 7, 40, 47])));
ie() && m();
var _e = (0, C.jsx)(`div`, {
    style: {
        minHeight: `100vh`,
        background: `#0a0a0a`
    }
});
(0, b.createRoot)(document.getElementById(`root`)).render((0, C.jsx)(y.StrictMode, {
    children: (0, C.jsxs)(p, {
        children: [(0, C.jsx)(y.Suspense, {
            fallback: _e,
            children: (0, C.jsxs)(d, {
                children: [(0, C.jsx)(f, {
                    path: `/`,
                    element: (0, C.jsx)(l, {})
                }), (0, C.jsx)(f, {
                    path: `/v1`,
                    element: (0, C.jsx)(se, {})
                }), (0, C.jsx)(f, {
                    path: `/privacy`,
                    element: (0, C.jsx)(fe, {})
                }), (0, C.jsx)(f, {
                    path: `/terms`,
                    element: (0, C.jsx)(pe, {})
                }), (0, C.jsx)(f, {
                    path: `/q/:slug`,
                    element: (0, C.jsx)(le, {})
                }), (0, C.jsx)(f, {
                    path: `/demo`,
                    element: (0, C.jsx)(ge, {})
                }), (0, C.jsx)(f, {
                    path: `/vine`,
                    element: (0, C.jsx)(ue, {})
                }), (0, C.jsx)(f, {
                    path: `/vine-garden`,
                    element: (0, C.jsx)(de, {})
                }), (0, C.jsx)(f, {
                    path: `/totem-lab`,
                    element: (0, C.jsx)(w, {})
                }), (0, C.jsx)(f, {
                    path: `/totem-motion`,
                    element: (0, C.jsx)(T, {})
                }), (0, C.jsx)(f, {
                    path: `/totems`,
                    element: (0, C.jsx)(c, {})
                }), (0, C.jsx)(f, {
                    path: `/stats`,
                    element: (0, C.jsx)(s, {})
                }), (0, C.jsx)(f, {
                    path: `/guilds`,
                    element: (0, C.jsx)(i, {})
                }), (0, C.jsx)(f, {
                    path: `/light-lab`,
                    element: (0, C.jsx)(me, {})
                }), (0, C.jsx)(f, {
                    path: `/warp`,
                    element: (0, C.jsx)(he, {})
                }), (0, C.jsx)(f, {
                    path: `/spiral`,
                    element: (0, C.jsx)(E, {})
                }), (0, C.jsx)(f, {
                    path: `/spiral-gl`,
                    element: (0, C.jsx)(a, {})
                }), (0, C.jsx)(f, {
                    path: `/loader-lab`,
                    element: (0, C.jsx)(D, {})
                }), (0, C.jsx)(f, {
                    path: `/home`,
                    element: (0, C.jsx)(l, {})
                }), (0, C.jsx)(f, {
                    path: `/hometest`,
                    element: (0, C.jsx)(l, {})
                }), (0, C.jsx)(f, {
                    path: `/admin`,
                    element: (0, C.jsx)(ce, {})
                })]
            })
        }), (0, C.jsx)(oe, {})]
    })
}));