function e(e) {
    let t = e >>> 0;
    return function() {
        t |= 0, t = t + 1831565813 | 0;
        let e = Math.imul(t ^ t >>> 15, 1 | t);
        return e = e + Math.imul(e ^ e >>> 7, 61 | e) ^ e, ((e ^ e >>> 14) >>> 0) / 4294967296
    }
}

function t(e) {
    let t = Math.max(0, Math.min(1, e));
    return t * t * (3 - 2 * t)
}
var n = `rgb(107, 77, 26)`,
    r = `rgb(199, 158, 66)`,
    i = `rgb(247, 224, 140)`,
    a = `rgba(255, 240, 184, 0.55)`;

function o(e, t) {
    let a = e.createLinearGradient(0, 0, 0, t);
    return a.addColorStop(0, i), a.addColorStop(.55, r), a.addColorStop(1, n), a
}

function s(e, t, n, r, i) {
    let a = t.length,
        o = [],
        s = [];
    for (let e = 0; e < a; e++) {
        let c = t[Math.max(0, e - 1)],
            l = t[Math.min(a - 1, e + 1)],
            u = l.x - c.x,
            d = l.y - c.y,
            f = Math.max(.001, Math.hypot(u, d)),
            p = -d / f,
            m = u / f,
            h = t[e].w / 2 * n,
            g = t[e].x + r,
            _ = t[e].y + i;
        o.push([g + p * h, _ + m * h]), s.push([g - p * h, _ - m * h])
    }
    e.beginPath(), e.moveTo(o[0][0], o[0][1]);
    for (let t = 1; t < a; t++) e.lineTo(o[t][0], o[t][1]);
    for (let t = a - 1; t >= 0; t--) e.lineTo(s[t][0], s[t][1]);
    e.closePath()
}

function c(e, t, n, r = !1) {
    t.length < 2 || (s(e, t, 1, 0, 0), e.fillStyle = n, e.fill(), r && (s(e, t, .32, -.6, -.9), e.fillStyle = a, e.fill()))
}

function l(e, t, n, r = !1) {
    let i = t.length;
    if (i < 2) return;
    let o = Array(i),
        s = Array(i),
        c = Array(i),
        l = Array(i),
        u = Array(i),
        d = Array(i),
        f = Array(i),
        p = Array(i);
    for (let e = 0; e < i; e++) {
        let n = t[Math.max(0, e - 1)],
            a = t[Math.min(i - 1, e + 1)],
            m = a.x - n.x,
            h = a.y - n.y,
            g = Math.max(.001, Math.hypot(m, h)),
            _ = -h / g,
            v = m / g,
            y = t[e].w / 2;
        if (o[e] = t[e].x + _ * y, s[e] = t[e].y + v * y, c[e] = t[e].x - _ * y, l[e] = t[e].y - v * y, r) {
            let n = t[e].w / 2 * .32,
                r = -.6,
                i = -.9;
            u[e] = t[e].x + r + _ * n, d[e] = t[e].y + i + v * n, f[e] = t[e].x + r - _ * n, p[e] = t[e].y + i - v * n
        }
    }
    e.fillStyle = n;
    for (let n = 0; n < i - 1; n++) {
        let r = (t[n].a + t[n + 1].a) / 2;
        r <= .01 || (e.globalAlpha = r, e.beginPath(), e.moveTo(o[n], s[n]), e.lineTo(o[n + 1], s[n + 1]), e.lineTo(c[n + 1], l[n + 1]), e.lineTo(c[n], l[n]), e.closePath(), e.fill())
    }
    if (r) {
        e.fillStyle = a;
        for (let n = 0; n < i - 1; n++) {
            let r = (t[n].a + t[n + 1].a) / 2;
            r <= .01 || (e.globalAlpha = r, e.beginPath(), e.moveTo(u[n], d[n]), e.lineTo(u[n + 1], d[n + 1]), e.lineTo(f[n + 1], p[n + 1]), e.lineTo(f[n], p[n]), e.closePath(), e.fill())
        }
    }
    e.globalAlpha = 1
}

function u(e) {
    let t = [],
        n = Math.max(2, Math.floor(e.lobes));
    t.push({
        t: `m`,
        x: .04,
        y: 0
    });
    for (let r = 0; r < n; r++) {
        let i = e.ampTop * (1 - .22 * r);
        t.push({
            t: `q`,
            cx: (r + .45) / n * .92,
            cy: -i,
            x: (r + .95) / n * .92,
            y: -i * .3
        })
    }
    t.push({
        t: `q`,
        cx: .99,
        cy: -e.ampTop * .2,
        x: 1,
        y: -.02
    });
    let r = Math.max(1, n - 1);
    for (let n = r - 1; n >= 0; n--) {
        let i = e.ampBot * (1 - .22 * n);
        t.push({
            t: `q`,
            cx: (n + .55) / r * .9,
            cy: i,
            x: (n + .08) / r * .9,
            y: i * .35
        })
    }
    return t.push({
        t: `q`,
        cx: 0,
        cy: e.ampBot * .3,
        x: .04,
        y: 0
    }), t
}

function d(e, t, n, i) {
    let a = t.size * n;
    if (a <= .01) return;
    let o = t.heavy ? .05 : .3,
        s = Math.cos(t.angle),
        c = Math.sin(t.angle),
        l = Math.cos(t.bend),
        d = Math.sin(t.bend),
        f = (e, n) => {
            let r = e * t.stretch,
                i = r * l - n * d,
                u = r * d + n * l;
            return i += o, i *= a, u *= a, [i * s - u * c + t.ax, i * c + u * s + t.ay]
        };
    if (!t.heavy) {
        let n = (e, n) => {
                let r = e * a,
                    i = n * a;
                return [r * s - i * c + t.ax, r * c + i * s + t.ay]
            },
            i = n(0, 0),
            o = n(.15, .08),
            l = n(.3, 0);
        e.beginPath(), e.moveTo(i[0], i[1]), e.quadraticCurveTo(o[0], o[1], l[0], l[1]), e.strokeStyle = r, e.lineWidth = 1.6, e.stroke()
    }
    let p = u(t);
    e.beginPath();
    for (let t of p)
        if (t.t === `m`) {
            let n = f(t.x, t.y);
            e.moveTo(n[0], n[1])
        } else {
            let n = f(t.cx, t.cy),
                r = f(t.x, t.y);
            e.quadraticCurveTo(n[0], n[1], r[0], r[1])
        }
    e.closePath(), e.fillStyle = i, e.fill()
}
export {
    e as a, o as i, c as n, t as o, l as r, d as t
};