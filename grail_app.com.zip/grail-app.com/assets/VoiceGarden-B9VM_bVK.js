import {
    a as e
} from "./chunk-BEqpzyXh.js";
import {
    n as t,
    t as n
} from "./jsx-runtime-B4RpOl0S.js";
import {
    t as r
} from "./viewport-DYDJlLll.js";
import {
    a as i,
    i as a,
    n as o,
    t as s
} from "./vineGarden-CW1PICZE.js";
var c = e(t(), 1);

function l(e) {
    let t = i(e.seed),
        n = (e, n) => e + (n - e) * t(),
        r = e => t() < e,
        {
            cx: a,
            cy: o,
            holeRadius: s
        } = e,
        c = e.maxX - e.minX,
        l = e.maxY - e.minY,
        u = Math.min(c, l) * .51,
        d = [],
        f = [],
        p = (e, t) => {
            let n = (t - e) % (2 * Math.PI);
            return n > Math.PI && (n -= 2 * Math.PI), n < -Math.PI && (n += 2 * Math.PI), n
        };

    function m(t, i, c, l, h, g, _, v, y) {
        let b = t,
            x = i,
            S = c,
            C = 0,
            w = [{
                x: b,
                y: x,
                w: h,
                dist: 0
            }],
            T = [.7, 1, 1.45, 2.1, 3].map(e => e * s),
            E = 0,
            D = v / T[Math.floor(n(0, 4.99))],
            O = n(.9, 2.4) * (1 / Math.abs(D)),
            k = y ? l : l * n(.13, .2),
            A = r(.72) ? v : -v,
            j = _ === 0 ? 40 : 0,
            M = n(55, 100),
            N = r(.5) ? 1 : -1,
            P = 0,
            F = n(20, 42),
            I = r(.5) ? 1 : -1,
            L = 0,
            R = 1,
            z = y ? 2.2 : 3,
            B = y,
            V = 0;
        for (; C < l;) {
            let t = l - C;
            if (!B && t < k && (B = !0, _ <= 1 && f.push({
                    ax: b,
                    ay: x,
                    angle: S + A * n(.2, .45),
                    size: 24 + h * 3.8 + n(0, 8),
                    revealDist: g + C,
                    ampTop: n(.32, .48),
                    ampBot: n(.18, .3),
                    lobes: n(2.8, 3.99),
                    stretch: n(1, 1.3),
                    bend: A * n(.15, .35),
                    heavy: !0
                })), B) {
                if (S += A * .2, V += .2, z *= .972, z < .6 || V > 2.1 * Math.PI) break
            } else {
                if (O -= z, O <= 0) {
                    let e = r(.85) ? v : -v,
                        t = T[Math.floor(n(0, 4.99))];
                    D = e / t, O = n(1.2, 2.8) * t
                }
                E += (D - E) * .3, S += E * z;
                let t = b - a,
                    i = x - o,
                    c = Math.hypot(t, i),
                    l = 0,
                    d = 0;
                c < s + 22 && (l += t / Math.max(1, c) * 1.5, d += i / Math.max(1, c) * 1.5), c > u && (l -= t / Math.max(1, c) * ((c - u) / 40), d -= i / Math.max(1, c) * ((c - u) / 40)), b < e.minX + 24 && (l += (e.minX + 24 - b) / 24), b > e.maxX - 24 && (l -= (b - (e.maxX - 24)) / 24), x < e.minY + 24 && (d += (e.minY + 24 - x) / 24), x > e.maxY - 24 && (d -= (x - (e.maxY - 24)) / 24), (l !== 0 || d !== 0) && (S += p(S, Math.atan2(d, l)) * .12)
            }
            b += Math.cos(S) * z, x += Math.sin(S) * z, C += z;
            let i = C / l,
                c = h * (1 - (_ <= 1 ? .45 : .7) * i ** .85) * R;
            if (B && (c *= Math.max(.65, 1 - V / (2.1 * Math.PI) * .35)), c = Math.max(_ <= 1 ? 1.3 : .6, c), w.push({
                    x: b,
                    y: x,
                    w: c,
                    dist: C
                }), y) continue;
            if (j += z, !B && _ < 3 && j > M && r(.8) && t > 80) {
                let e = r(.35);
                m(b, x, S + N * n(.4, .8), t * n(.3, .5), e ? c * .3 : c * .7, g + C, e ? 3 : _ + 1, r(.75) ? v : -v, !1), N = -N, j = 0, M = n(65, 120), R *= .94
            }
            L += z;
            let d = Math.hypot(b - a, x - o);
            !B && L > 60 && d < s * 3.4 && r(.55) && (m(b, x, S + N * n(.6, 1.1), n(35, 65), c * .45, g + C, 2, v, !0), L = 0), P += z, !B && P > F && r(.92) && (f.push({
                ax: b,
                ay: x,
                angle: S + I * n(.5, 1),
                size: 15 + c * 2.8 + n(0, 10),
                revealDist: g + C,
                ampTop: n(.26, .44),
                ampBot: n(.12, .26),
                lobes: n(2.6, 3.99),
                stretch: n(.8, 1.12),
                bend: n(-.22, .22),
                heavy: !1
            }), I = -I, P = 0, F = n(28, 58))
        }
        w.length > 2 && d.push({
            points: w,
            rootDist: g,
            length: w[w.length - 1].dist,
            depth: _
        })
    }
    let h = Math.min(c, l),
        g = e.sectorAngle + n(-.3, .3);
    return m(a + Math.cos(g) * s * .45, o + Math.sin(g) * s * .45, g + e.swirl * n(1.1, 1.45), h * n(.6, .9) * e.sizeScale, n(3.2, 4.3) * (.55 + .45 * e.sizeScale), 0, 0, e.swirl, !1), {
        branches: d,
        leaves: f,
        maxDist: d.reduce((e, t) => Math.max(e, t.rootDist + t.length), 1)
    }
}

function u(e, t) {
    let n = [];
    for (let r = 0; r < e.length; r++) {
        let i = e[r];
        if (i.dist <= t) n.push(i);
        else {
            if (r > 0) {
                let a = e[r - 1],
                    o = (t - a.dist) / Math.max(.001, i.dist - a.dist);
                n.push({
                    x: a.x + (i.x - a.x) * o,
                    y: a.y + (i.y - a.y) * o,
                    w: a.w + (i.w - a.w) * o,
                    dist: t
                })
            }
            break
        }
    }
    return n
}

function d(e, t, n, r) {
    if (n <= .001) return;
    let i = n * t.maxDist;
    for (let n of t.branches) {
        let t = i - n.rootDist;
        if (t <= 0) continue;
        let a = u(n.points, t);
        if (!(a.length < 2) && (o(e, a, r, n.depth <= 1), t >= n.length)) {
            let t = a[a.length - 1],
                n = Math.max(.8, t.w * .62);
            e.beginPath(), e.arc(t.x, t.y, n, 0, 2 * Math.PI), e.closePath(), e.fillStyle = r, e.fill()
        }
    }
    for (let n of t.leaves) {
        let t = (i - n.revealDist) / 50;
        if (t <= 0) continue;
        let a = Math.min(1, t);
        s(e, n, a * a * (3 - 2 * a), r)
    }
}

function f(e, t) {
    if (e < t.growDur) return 1 - (1 - e / t.growDur) ** 2;
    if (e < t.growDur + t.holdDur) return 1;
    let n = (e - t.growDur - t.holdDur) / t.retractDur;
    return n >= 1 ? 0 : (1 - n) ** 1.6
}

function p(e) {
    return e.growDur + e.holdDur + e.retractDur
}

function m(e) {
    return {
        growDur: .6 + .5 * e,
        holdDur: .35 + 1.05 * e ** .8,
        retractDur: .5 + .8 * e
    }
}

function h(e = Math.random) {
    let t = [],
        n = .25,
        r = 2 + Math.floor(e() * 3);
    for (let i = 0; i < r; i++) {
        let r = 2 + Math.floor(e() * 3);
        for (let i = 0; i < r; i++) {
            let r = 1 + Math.floor(e() * 3);
            for (let i = 0; i < r; i++) {
                let r = i === 0 ? .6 + e() * .4 : .32 + e() * .4;
                t.push({
                    at: n,
                    loud: r
                }), n += .13 + e() * .09
            }
            n += .17 + e() * .2
        }
        n += .55 + e() * .55
    }
    return t
}
var g = 2.399963,
    _ = n(),
    v = 160;

function y({
    holeFracX: e = .5,
    holeFracY: t = .5,
    className: n
}) {
    let i = (0, c.useRef)(null);
    return (0, c.useEffect)(() => {
        let n = i.current,
            o = n.getContext(`2d`),
            s = 0,
            c = !0,
            u = 0,
            _ = 0,
            y = [],
            b = 0,
            x = h(),
            S = performance.now() / 1e3,
            C = 0,
            w = () => {
                let e = Math.min(2, window.devicePixelRatio || 1),
                    t = n.clientWidth,
                    r = n.clientHeight;
                n.width = Math.floor(t * e), n.height = Math.floor(r * e);
                let i = Math.min(t, r) / v || 1;
                u = t / i, _ = r / i, o.setTransform(e * i, 0, 0, e * i, 0, 0)
            };
        w();
        let T = r(w),
            E = 0,
            D = !1,
            O = (n, r) => {
                if (y.length >= 22) return;
                b++;
                let i = l({
                    seed: (12648430 ^ Math.imul(b, 2654435761)) >>> 0,
                    cx: u * e,
                    cy: _ * t,
                    minX: 6,
                    minY: 6,
                    maxX: u - 6,
                    maxY: _ - 6,
                    holeRadius: Math.min(u, _) * .14,
                    sectorAngle: b * g,
                    swirl: 1,
                    sizeScale: .45 + .55 * n
                });
                y.push({
                    key: b,
                    pattern: i,
                    birth: r,
                    ...m(n)
                })
            },
            k = () => {
                if (!c) return;
                let e = performance.now() / 1e3,
                    t = e - S;
                for (; C < x.length && t >= x[C].at;) O(x[C].loud, e), C++;
                let r = x.length ? x[x.length - 1].at : 0;
                C >= x.length && t > r + 2.2 && (x = h(), S = e, C = 0);
                for (let t = y.length - 1; t >= 0; t--) e - y[t].birth > p(y[t]) + .1 && y.splice(t, 1);
                if (!(E++ & 7)) {
                    let e = n.getBoundingClientRect();
                    D = e.bottom > -40 && e.top < window.innerHeight + 40
                }
                if (D) {
                    o.clearRect(0, 0, u, _);
                    let t = a(o, _);
                    for (let n of y) {
                        let r = f(e - n.birth, n);
                        r > .001 && d(o, n.pattern, r, t)
                    }
                }
                s = requestAnimationFrame(k)
            };
        return s = requestAnimationFrame(k), () => {
            c = !1, cancelAnimationFrame(s), T()
        }
    }, [e, t]), (0, _.jsx)(`canvas`, {
        ref: i,
        className: n,
        "aria-hidden": !0
    })
}
export {
    y as t
};