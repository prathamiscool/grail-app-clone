var e = `modulepreload`,
    t = function(e) {
        return `/` + e
    },
    n = {},
    r = function(r, i, a) {
        let o = Promise.resolve();
        if (i && i.length > 0) {
            let r = document.getElementsByTagName(`link`),
                s = document.querySelector(`meta[property=csp-nonce]`),
                c = s ? .nonce || s ? .getAttribute(`nonce`);

            function l(e) {
                return Promise.all(e.map(e => Promise.resolve(e).then(e => ({
                    status: `fulfilled`,
                    value: e
                }), e => ({
                    status: `rejected`,
                    reason: e
                }))))
            }
            o = l(i.map(i => {
                if (i = t(i, a), i in n) return;
                n[i] = !0;
                let o = i.endsWith(`.css`),
                    s = o ? `[rel="stylesheet"]` : ``;
                if (a)
                    for (let e = r.length - 1; e >= 0; e--) {
                        let t = r[e];
                        if (t.href === i && (!o || t.rel === `stylesheet`)) return
                    } else if (document.querySelector(`link[href="${i}"]${s}`)) return;
                let l = document.createElement(`link`);
                if (l.rel = o ? `stylesheet` : e, o || (l.as = `script`), l.crossOrigin = ``, l.href = i, c && l.setAttribute(`nonce`, c), document.head.appendChild(l), o) return new Promise((e, t) => {
                    l.addEventListener(`load`, e), l.addEventListener(`error`, () => t(Error(`Unable to preload CSS for ${i}`)))
                })
            }))
        }

        function s(e) {
            let t = new Event(`vite:preloadError`, {
                cancelable: !0
            });
            if (t.payload = e, window.dispatchEvent(t), !t.defaultPrevented) throw e
        }
        return o.then(e => {
            for (let t of e || []) t.status === `rejected` && s(t.reason);
            return r().catch(s)
        })
    };
export {
    r as t
};