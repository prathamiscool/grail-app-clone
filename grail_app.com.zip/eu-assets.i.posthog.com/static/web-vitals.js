! function() {
    "function" != typeof [].at && Object.defineProperty(Array.prototype, "at", {
        value(t) {
            const n = this.length;
            let i = Math.trunc(t) || 0;
            return 0 > i && (i += n), 0 > i || i >= n ? void 0 : this[i]
        },
        writable: !0,
        enumerable: !1,
        configurable: !0
    });
    const t = "u" > typeof window ? window : void 0,
        n = "u" > typeof globalThis ? globalThis : t;
    null != n && n.XMLHttpRequest && new n.XMLHttpRequest;
    const i = "undefined" != typeof globalThis ? globalThis : t;
    i && "undefined" == typeof self && (i.self = i), i && "undefined" == typeof File && (i.File = function() {});
    const e = null != t ? t : {};

    function o(t) {
        return o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        }, o(t)
    }

    function r(t, n, i) {
        return (n = function(t) {
            var n = function(t) {
                if ("object" != o(t) || !t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var i = n.call(t, "string");
                    if ("object" != o(i)) return i;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return String(t)
            }(t);
            return "symbol" == o(n) ? n : n + ""
        }(n)) in t ? Object.defineProperty(t, n, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[n] = i, t
    }

    function a(t, n) {
        var i = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var e = Object.getOwnPropertySymbols(t);
            n && (e = e.filter(function(n) {
                return Object.getOwnPropertyDescriptor(t, n).enumerable
            })), i.push.apply(i, e)
        }
        return i
    }

    function s(t) {
        for (var n = 1; arguments.length > n; n++) {
            var i = null != arguments[n] ? arguments[n] : {};
            n % 2 ? a(Object(i), !0).forEach(function(n) {
                r(t, n, i[n])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : a(Object(i)).forEach(function(n) {
                Object.defineProperty(t, n, Object.getOwnPropertyDescriptor(i, n))
            })
        }
        return t
    }
    let c = -1;
    const l = () => c,
        u = t => {
            addEventListener("pageshow", n => {
                n.persisted && (c = n.timeStamp, t(n))
            }, !0)
        },
        f = (t, n, i, e) => {
            let o, r;
            return a => {
                var s;
                n.value >= 0 && (a || e) && (r = n.value - (null !== (s = o) && void 0 !== s ? s : 0), (r || void 0 === o) && (o = n.value, n.delta = r, n.rating = ((t, n) => t > n[1] ? "poor" : t > n[0] ? "needs-improvement" : "good")(n.value, i), t(n)))
            }
        },
        v = t => {
            requestAnimationFrame(() => requestAnimationFrame(() => t()))
        },
        d = () => {
            const t = performance.getEntriesByType("navigation")[0];
            if (t && t.responseStart > 0 && t.responseStart < performance.now()) return t
        },
        h = () => {
            var t, n;
            return null !== (t = null === (n = d()) || void 0 === n ? void 0 : n.activationStart) && void 0 !== t ? t : 0
        };
    let b = -1;
    const g = new Set,
        m = () => "hidden" !== document.visibilityState || document.prerendering ? 1 / 0 : 0,
        p = t => {
            if ("hidden" === document.visibilityState) {
                if ("visibilitychange" === t.type)
                    for (const t of g) t();
                isFinite(b) || (b = "visibilitychange" === t.type ? t.timeStamp : 0, removeEventListener("prerenderingchange", p, !0))
            }
        },
        y = (t = !1) => {
            if (t && (b = 1 / 0), 0 > b) {
                var n;
                const t = h(),
                    i = document.prerendering || null === (n = globalThis.performance.getEntriesByType("visibility-state").find(n => "hidden" === n.name && n.startTime >= t)) || void 0 === n ? void 0 : n.startTime;
                b = null != i ? i : m(), addEventListener("visibilitychange", p, !0), addEventListener("prerenderingchange", p, !0), u(() => {
                    setTimeout(() => {
                        b = m()
                    })
                })
            }
            return {
                get firstHiddenTime() {
                    return b
                },
                onHidden(t) {
                    g.add(t)
                }
            }
        },
        w = (t, n = -1, i, e = 0, o, r, a) => {
            const s = d(),
                c = (null == s ? void 0 : s.navigationId) || 0;
            let u = "navigate";
            return i ? u = i : 0 > l() ? s && (document.prerendering || h() > 0 ? u = "prerender" : document.wasDiscarded ? u = "restore" : s.type && (u = s.type.replace(/_/g, "-"))) : u = "back-forward-cache", {
                name: t,
                value: n,
                rating: "good",
                delta: 0,
                entries: [],
                id: `v6-${Date.now()}-${Math.floor(8999999999999*Math.random())+1e12}`,
                navigationType: u,
                navigationId: e || c,
                navigationInteractionId: o,
                navigationURL: r || (null == s ? void 0 : s.name),
                navigationStartTime: a || 0
            }
        },
        T = new WeakMap;

    function L(t, n) {
        let i = T.get(n);
        return i || (i = new WeakMap, T.set(n, i)), i.get(t) || i.set(t, new n), i.get(t)
    }
    var M = class {
        constructor() {
            this.t = void 0, this.i = 0, this.o = []
        }
        h(t) {
            var n;
            if (t.hadRecentInput) return;
            const i = this.o[0],
                e = this.o.at(-1);
            this.i && i && e && 1e3 > t.startTime - e.startTime && 5e3 > t.startTime - i.startTime ? (this.i += t.value, this.o.push(t)) : (this.i = t.value, this.o = [t]), null === (n = this.t) || void 0 === n || n.call(this, t)
        }
    };
    const P = (t, n, i = {}) => {
            try {
                const e = t.filter(t => PerformanceObserver.supportedEntryTypes.includes(t));
                if (e.length > 0) {
                    const t = new PerformanceObserver(t => {
                        queueMicrotask(() => {
                            const i = t.getEntries();
                            e.length > 1 && i.sort((t, n) => t.startTime + t.duration - (n.startTime + n.duration)), n(i)
                        })
                    });
                    for (const n of e) t.observe(s({
                        type: n,
                        buffered: !0
                    }, i));
                    return t
                }
            } catch (t) {}
        },
        j = t => {
            var n, i;
            return (null === (n = globalThis.PerformanceObserver) || void 0 === n || null === (n = n.supportedEntryTypes) || void 0 === n ? void 0 : n.includes("soft-navigation")) && "function" == typeof(null === (i = globalThis.PerformanceSoftNavigation) || void 0 === i || null === (i = i.prototype) || void 0 === i ? void 0 : i.getLargestInteractionContentfulPaint) && t && t.reportSoftNavs
        },
        O = (t, n) => {
            if (t.set(n.navigationId, n), t.size > 2) {
                const n = t.keys().next().value;
                void 0 !== n && t.delete(n)
            }
        },
        k = t => {
            let n = !1;
            return () => {
                n || (t(), n = !0)
            }
        };
    var C = class {
        constructor() {
            this.l = void 0
        }
    };
    const S = t => {
            document.prerendering ? addEventListener("prerenderingchange", t, !0) : t()
        },
        E = [1800, 3e3],
        I = (t, n = {}) => {
            const i = j(n);
            S(() => {
                const e = L(n, C),
                    o = y();
                let r, a = w("FCP");
                const s = P(["paint"], t => {
                    for (const n of t) "first-contentful-paint" === n.name && (s.disconnect(), o.firstHiddenTime > n.startTime && (a.value = Math.max(n.startTime - h(), 0), a.entries.push(n), a.navigationId = n.navigationId || a.navigationId, r(!0)))
                });
                s && (r = f(t, a, E, n.reportAllChanges), u(i => {
                    a = w("FCP", -1, "back-forward-cache", a.navigationId, a.navigationInteractionId, a.navigationURL, l()), r = f(t, a, E, n.reportAllChanges), v(() => {
                        a.value = performance.now() - i.timeStamp, r(!0)
                    })
                })), i && P(["soft-navigation"], i => {
                    i.forEach(i => {
                        e.l && i.navigationId && O(e.l, i);
                        const o = Math.max((i.presentationTime || i.paintTime || 0) - i.startTime, 0);
                        a = w("FCP", o, "soft-navigation", i.navigationId, i.interactionId, i.name, i.startTime), r = f(t, a, E, n.reportAllChanges), r(!0)
                    })
                }, n)
            })
        },
        F = [.1, .25];
    let q = 0,
        A = 1 / 0,
        N = 0;
    const H = t => {
        for (const n of t) n.interactionId && (A = Math.min(A, n.interactionId), N = Math.max(N, n.interactionId), q = N ? (N - A) / 7 + 1 : 0)
    };
    let W;
    const _ = () => {
        var t;
        return W ? q : null !== (t = performance.interactionCount) && void 0 !== t ? t : 0
    };
    var D = class {
        constructor() {
            this.u = 0, this.v = [], this.m = new Map, this.p = void 0, this.T = void 0
        }
        _() {
            return _() - this.u
        }
        M() {
            this.u = _(), this.v.length = 0, this.m.clear()
        }
        L(t) {
            const n = this._(),
                i = Math.min(this.v.length - 1, Math.floor(n / 50));
            return !n || -1 !== i || "soft-navigation" !== t && "back-forward-cache" !== t ? this.v[i] : {
                P: 8,
                id: -1,
                entries: []
            }
        }
        h(t) {
            var n;
            if (null === (n = this.p) || void 0 === n || n.call(this, t), !t.interactionId) return;
            const i = this.v.at(-1);
            let e = this.m.get(t.interactionId);
            if (e || 10 > this.v.length || t.duration > i.P) {
                var o;
                if (e ? t.duration > e.P ? (e.entries = [t], e.P = t.duration) : t.duration === e.P && t.startTime === e.entries[0].startTime && e.entries.push(t) : (e = {
                        id: t.interactionId,
                        entries: [t],
                        P: t.duration
                    }, this.m.set(e.id, e), this.v.push(e)), this.v.sort((t, n) => n.P - t.P), this.v.length > 10) {
                    const t = this.v.splice(10);
                    for (const n of t) this.m.delete(n.id)
                }
                null === (o = this.T) || void 0 === o || o.call(this, e)
            }
        }
    };
    const R = t => {
            const n = "requestIdleCallback" in globalThis ? 1e3 : 0,
                i = globalThis.requestIdleCallback || setTimeout,
                e = globalThis.cancelIdleCallback || clearTimeout;
            if ("hidden" === document.visibilityState) t();
            else {
                const o = k(t);
                let r = -1;
                const a = () => {
                    e(r), o()
                };
                addEventListener("visibilitychange", a, {
                    once: !0,
                    capture: !0
                }), r = i(() => {
                    removeEventListener("visibilitychange", a, {
                        capture: !0
                    }), o()
                }, {
                    timeout: n
                })
            }
        },
        U = [200, 500];
    var x = class {
        constructor() {
            this.p = void 0, this.l = void 0
        }
        h(t) {
            var n;
            null === (n = this.p) || void 0 === n || n.call(this, t)
        }
    };
    const z = [2500, 4e3],
        B = {
            onLCP(t, n = {}) {
                let i = !1;
                const e = j(n);
                S(() => {
                    let o, r = y(),
                        a = w("LCP");
                    const s = L(n, x),
                        c = (e, s, c, l, u) => {
                            a = w("LCP", -1, e, s, c, l, u), o = f(t, a, z, n.reportAllChanges), i = !1, "soft-navigation" === e && (r = y(!0))
                        },
                        d = t => {
                            var n;
                            s.l && t.navigationId && O(s.l, t), i || o(!0), c("soft-navigation", t.navigationId, t.interactionId, t.name, t.startTime);
                            const e = null === (n = t.getLargestInteractionContentfulPaint) || void 0 === n ? void 0 : n.call(t);
                            e && b([e])
                        },
                        b = t => {
                            n.reportAllChanges || e || (t = t.slice(-1));
                            for (const n of t) {
                                if (!n) continue;
                                if ("soft-navigation" === n.entryType) {
                                    d(n);
                                    continue
                                }
                                let t = 0,
                                    e = [],
                                    c = n.startTime;
                                if ("largest-contentful-paint" === n.entryType) t = Math.max(n.startTime - h(), 0), s.h(n), e = [n];
                                else if ("interaction-contentful-paint" === n.entryType) {
                                    var i;
                                    const o = n;
                                    if (!a.navigationId) continue;
                                    if ("interactionId" in o && o.interactionId != a.navigationInteractionId) continue;
                                    c = (null === (i = o.largestContentfulPaint) || void 0 === i ? void 0 : i.renderTime) || 0, t = Math.max(c - n.startTime, 0), o.largestContentfulPaint && (s.h(o.largestContentfulPaint), e = [o.largestContentfulPaint])
                                }
                                r.firstHiddenTime > c && (a.value = t, a.entries = e, o())
                            }
                        },
                        g = ["largest-contentful-paint"];
                    e && g.push("interaction-contentful-paint", "soft-navigation");
                    const m = P(g, b);
                    if (m) {
                        o = f(t, a, z, n.reportAllChanges);
                        const r = ["keydown", "click", "visibilitychange"],
                            s = t => {
                                if (t.isTrusted && !i) {
                                    const t = a.id;
                                    R(() => {
                                        if (!i) {
                                            if (!e) {
                                                m.disconnect();
                                                for (const t of r) removeEventListener(t, s, {
                                                    capture: !0
                                                })
                                            }
                                            t === a.id && (i = !0, o(!0))
                                        }
                                    })
                                }
                            };
                        for (const t of r) addEventListener(t, s, {
                            capture: !0
                        });
                        u(e => {
                            c("back-forward-cache", a.navigationId, a.navigationInteractionId, a.navigationURL, l()), o = f(t, a, z, n.reportAllChanges), v(() => {
                                a.value = performance.now() - e.timeStamp, i = !0, o(!0)
                            })
                        })
                    }
                })
            },
            onCLS(t, n = {}) {
                const i = y();
                I(k(() => {
                    let e, o = w("CLS", 0);
                    const r = L(n, M),
                        a = (i, a, s, c, l) => {
                            o = w("CLS", 0, i, a, s, c, l), r.i = 0, e = f(t, o, F, n.reportAllChanges)
                        },
                        s = (t = !1) => {
                            r.i > o.value && (o.value = r.i, o.entries = r.o), e(t)
                        },
                        c = t => {
                            s(!0), a("soft-navigation", t.navigationId, t.interactionId, t.name, t.startTime)
                        },
                        d = t => {
                            for (const n of t) "soft-navigation" !== n.entryType ? r.h(n) : c(n);
                            s()
                        },
                        h = ["layout-shift"];
                    j(n) && h.push("soft-navigation");
                    const b = P(h, d);
                    b && (e = f(t, o, F, n.reportAllChanges), i.onHidden(() => {
                        d(b.takeRecords()), e(!0)
                    }), u(() => {
                        a("back-forward-cache", o.navigationId, o.navigationInteractionId, o.navigationURL, l()), v(e)
                    }), setTimeout(e))
                }))
            },
            onFCP: I,
            onINP(t, n = {}) {
                if (!globalThis.PerformanceEventTiming || !("interactionId" in PerformanceEventTiming.prototype)) return;
                const i = y();
                S(() => {
                    var e;
                    "interactionCount" in performance || W || (W = P(["event"], H, {
                        durationThreshold: 0
                    }));
                    let o, r = w("INP");
                    const a = L(n, D),
                        c = (i, e, s, c, l) => {
                            a.M(), r = w("INP", -1, i, e, s, c, l), o = f(t, r, U, n.reportAllChanges)
                        },
                        v = () => {
                            const t = a.L(r.navigationType);
                            t && t.P !== r.value && (r.value = t.P, r.entries = t.entries, o())
                        },
                        d = t => {
                            v(), o(!0), c("soft-navigation", t.navigationId, t.interactionId, t.name, t.startTime)
                        },
                        h = (t, n = !1) => {
                            R(() => {
                                for (const n of t) "soft-navigation" !== n.entryType ? a.h(n) : d(n);
                                v(), n && o(!0)
                            })
                        },
                        b = ["event", "first-input"];
                    j(n) && b.push("soft-navigation");
                    const g = P(b, h, s(s({}, n), {}, {
                        durationThreshold: null !== (e = n.durationThreshold) && void 0 !== e ? e : 40
                    }));
                    o = f(t, r, U, n.reportAllChanges), g && (i.onHidden(() => {
                        h(g.takeRecords(), !0)
                    }), u(() => {
                        c("back-forward-cache", r.navigationId, r.navigationInteractionId, r.navigationURL, l())
                    }))
                })
            }
        };
    e.__PosthogExtensions__ = e.__PosthogExtensions__ || {}, e.__PosthogExtensions__.postHogWebVitalsCallbacksByFlavor = e.__PosthogExtensions__.postHogWebVitalsCallbacksByFlavor || {}, e.__PosthogExtensions__.postHogWebVitalsCallbacksByFlavor["web-vitals"] = B, e.__PosthogExtensions__.postHogWebVitalsCallbacks = B, e.postHogWebVitalsCallbacks = B, e.__PosthogExtensions__.loadWebVitalsCallbacks = () => B
}();
//# sourceMappingURL=web-vitals.js.map