! function(e) {
    var t, n, r, o, i, s, a, l, u, c, d, f, p, h, v;
    Object.defineProperties(e, {
        __esModule: {
            value: !0
        },
        [Symbol.toStringTag]: {
            value: "Module"
        }
    });
    var m = {},
        y = [],
        g = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
        b = Array.isArray;

    function w(e, t) {
        for (var n in t) e[n] = t[n];
        return e
    }

    function x(e) {
        e && e.parentNode && e.parentNode.removeChild(e)
    }

    function k(e, n, r) {
        var o, i, s, a = {};
        for (s in n) "key" == s ? o = n[s] : "ref" == s ? i = n[s] : a[s] = n[s];
        if (arguments.length > 2 && (a.children = arguments.length > 3 ? t.call(arguments, 2) : r), "function" == typeof e && null != e.defaultProps)
            for (s in e.defaultProps) void 0 === a[s] && (a[s] = e.defaultProps[s]);
        return S(e, a, o, i, null)
    }

    function S(e, t, o, i, s) {
        var a = {
            type: e,
            props: t,
            key: o,
            ref: i,
            __k: null,
            __: null,
            __b: 0,
            __e: null,
            __c: null,
            constructor: void 0,
            __v: null == s ? ++r : s,
            __i: -1,
            __u: 0
        };
        return null == s && null != n.vnode && n.vnode(a), a
    }

    function T(e) {
        return e.children
    }

    function _(e, t) {
        this.props = e, this.context = t
    }

    function $(e, t) {
        if (null == t) return e.__ ? $(e.__, e.__i + 1) : null;
        for (var n; e.__k.length > t; t++)
            if (null != (n = e.__k[t]) && null != n.__e) return n.__e;
        return "function" == typeof e.type ? $(e) : null
    }

    function q(e) {
        if (e.__P && e.__d) {
            var t = e.__v,
                r = t.__e,
                o = [],
                i = [],
                s = w({}, t);
            s.__v = t.__v + 1, n.vnode && n.vnode(s), z(e.__P, s, t, e.__n, e.__P.namespaceURI, 32 & t.__u ? [r] : null, o, null == r ? $(t) : r, !!(32 & t.__u), i), s.__v = t.__v, s.__.__k[s.__i] = s, R(o, s, i), t.__e = t.__ = null, s.__e != r && P(s)
        }
    }

    function P(e) {
        if (null != (e = e.__) && null != e.__c) return e.__e = e.__c.base = null, e.__k.some(function(t) {
            if (null != t && null != t.__e) return e.__e = e.__c.base = t.__e
        }), P(e)
    }

    function I(e) {
        (!e.__d && (e.__d = !0) && o.push(e) && !E.__r++ || i != n.debounceRendering) && ((i = n.debounceRendering) || s)(E)
    }

    function E() {
        try {
            for (var e, t = 1; o.length;) o.length > t && o.sort(a), e = o.shift(), t = o.length, q(e)
        } finally {
            o.length = E.__r = 0
        }
    }

    function C(e, t, n, r, o, i, s, a, l, u, c) {
        var d, f, p, h, v, g, b, w = r && r.__k || y,
            x = t.length;
        for (l = M(n, t, w, l, x), d = 0; x > d; d++) null != (p = n.__k[d]) && (f = -1 != p.__i && w[p.__i] || m, p.__i = d, g = z(e, p, f, o, i, s, a, l, u, c), h = p.__e, p.ref && f.ref != p.ref && (f.ref && H(f.ref, null, p), c.push(p.ref, p.__c || h, p)), null == v && null != h && (v = h), (b = !!(4 & p.__u)) || f.__k === p.__k ? (l = A(p, l, e, b), b && f.__e && (f.__e = null)) : "function" == typeof p.type && void 0 !== g ? l = g : h && (l = h.nextSibling), p.__u &= -7);
        return n.__e = v, l
    }

    function M(e, t, n, r, o) {
        var i, s, a, l, u, c = n.length,
            d = c,
            f = 0;
        for (e.__k = new Array(o), i = 0; o > i; i++) null != (s = t[i]) && "boolean" != typeof s && "function" != typeof s ? ("string" == typeof s || "number" == typeof s || "bigint" == typeof s || s.constructor == String ? s = e.__k[i] = S(null, s, null, null, null) : b(s) ? s = e.__k[i] = S(T, {
            children: s
        }, null, null, null) : void 0 === s.constructor && s.__b > 0 ? s = e.__k[i] = S(s.type, s.props, s.key, s.ref ? s.ref : null, s.__v) : e.__k[i] = s, l = i + f, s.__ = e, s.__b = e.__b + 1, a = null, -1 != (u = s.__i = D(s, n, l, d)) && (d--, (a = n[u]) && (a.__u |= 2)), null == a || null == a.__v ? (-1 == u && (o > c ? f-- : c > o && f++), "function" != typeof s.type && (s.__u |= 4)) : u != l && (u == l - 1 ? f-- : u == l + 1 ? f++ : (u > l ? f-- : f++, s.__u |= 4))) : e.__k[i] = null;
        if (d)
            for (i = 0; c > i; i++) null != (a = n[i]) && !(2 & a.__u) && (a.__e == r && (r = $(a)), U(a, a));
        return r
    }

    function A(e, t, n, r) {
        var o, i;
        if ("function" == typeof e.type) {
            for (o = e.__k, i = 0; o && o.length > i; i++) o[i] && (o[i].__ = e, t = A(o[i], t, n, r));
            return t
        }
        e.__e != t && (r && (t && e.type && !t.parentNode && (t = $(e)), n.insertBefore(e.__e, t || null)), t = e.__e);
        do {
            t = t && t.nextSibling
        } while (null != t && 8 == t.nodeType);
        return t
    }

    function D(e, t, n, r) {
        var o, i, s, a = e.key,
            l = e.type,
            u = t[n],
            c = null != u && !(2 & u.__u);
        if (null === u && null == a || c && a == u.key && l == u.type) return n;
        if (r > (c ? 1 : 0))
            for (o = n - 1, i = n + 1; o >= 0 || t.length > i;)
                if (null != (u = t[s = 0 > o ? i++ : o--]) && !(2 & u.__u) && a == u.key && l == u.type) return s;
        return -1
    }

    function N(e, t, n) {
        "-" == t[0] ? e.setProperty(t, null == n ? "" : n) : e[t] = null == n ? "" : "number" != typeof n || g.test(t) ? n : n + "px"
    }

    function j(e, t, n, r, o) {
        var i, s;
        e: if ("style" == t)
            if ("string" == typeof n) e.style.cssText = n;
            else {
                if ("string" == typeof r && (e.style.cssText = r = ""), r)
                    for (t in r) n && t in n || N(e.style, t, "");
                if (n)
                    for (t in n) r && n[t] == r[t] || N(e.style, t, n[t])
            }
        else if ("o" == t[0] && "n" == t[1]) i = t != (t = t.replace(d, "$1")), s = t.toLowerCase(), t = s in e || "onFocusOut" == t || "onFocusIn" == t ? s.slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + i] = n, n ? r ? n[c] = r[c] : (n[c] = f, e.addEventListener(t, i ? h : p, i)) : e.removeEventListener(t, i ? h : p, i);
        else {
            if ("http://www.w3.org/2000/svg" == o) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
            else if ("width" != t && "height" != t && "href" != t && "list" != t && "form" != t && "tabIndex" != t && "download" != t && "rowSpan" != t && "colSpan" != t && "role" != t && "popover" != t && t in e) try {
                e[t] = null == n ? "" : n;
                break e
            } catch (e) {}
            "function" == typeof n || (null == n || !1 === n && "-" != t[4] ? e.removeAttribute(t) : e.setAttribute(t, "popover" == t && 1 == n ? "" : n))
        }
    }

    function O(e) {
        return function(t) {
            if (this.l) {
                var r = this.l[t.type + e];
                if (null == t[u]) t[u] = f++;
                else if (r[c] > t[u]) return;
                return r(n.event ? n.event(t) : t)
            }
        }
    }

    function z(e, t, r, o, i, s, a, l, u, c) {
        var d, f, p, h, v, m, g, k, S, q, $, P, I, E, M, A, D = t.type;
        if (void 0 !== t.constructor) return null;
        128 & r.__u && (u = !!(32 & r.__u), s = [l = t.__e = r.__e]), (d = n.__b) && d(t);
        e: if ("function" == typeof D) {
            f = a.length;
            try {
                if (S = t.props, q = D.prototype && D.prototype.render, $ = (d = D.contextType) && o[d.__c], P = d ? $ ? $.props.value : d.__ : o, r.__c ? k = (p = t.__c = r.__c).__ = p.__E : (q ? t.__c = p = new D(S, P) : (t.__c = p = new _(S, P), p.constructor = D, p.render = Q), $ && $.sub(p), p.state || (p.state = {}), p.__n = o, h = p.__d = !0, p.__h = [], p._sb = []), q && null == p.__s && (p.__s = p.state), q && null != D.getDerivedStateFromProps && (p.__s == p.state && (p.__s = w({}, p.__s)), w(p.__s, D.getDerivedStateFromProps(S, p.__s))), v = p.props, m = p.state, p.__v = t, h) q && null == D.getDerivedStateFromProps && null != p.componentWillMount && p.componentWillMount(), q && null != p.componentDidMount && p.__h.push(p.componentDidMount);
                else {
                    if (q && null == D.getDerivedStateFromProps && S !== v && null != p.componentWillReceiveProps && p.componentWillReceiveProps(S, P), t.__v == r.__v || !p.__e && null != p.shouldComponentUpdate && !1 === p.shouldComponentUpdate(S, p.__s, P)) {
                        t.__v != r.__v && (p.props = S, p.state = p.__s, p.__d = !1), t.__e = r.__e, t.__k = r.__k, t.__k.some(function(e) {
                            e && (e.__ = t)
                        }), y.push.apply(p.__h, p._sb), p._sb = [], p.__h.length && a.push(p);
                        break e
                    }
                    null != p.componentWillUpdate && p.componentWillUpdate(S, p.__s, P), q && null != p.componentDidUpdate && p.__h.push(function() {
                        p.componentDidUpdate(v, m, g)
                    })
                }
                if (p.context = P, p.props = S, p.__P = e, p.__e = !1, I = n.__r, E = 0, q) p.state = p.__s, p.__d = !1, I && I(t), d = p.render(p.props, p.state, p.context), y.push.apply(p.__h, p._sb), p._sb = [];
                else
                    do {
                        p.__d = !1, I && I(t), d = p.render(p.props, p.state, p.context), p.state = p.__s
                    } while (p.__d && 25 > ++E);
                p.state = p.__s, null != p.getChildContext && (o = w(w({}, o), p.getChildContext())), q && !h && null != p.getSnapshotBeforeUpdate && (g = p.getSnapshotBeforeUpdate(v, m)), M = null != d && d.type === T && null == d.key ? F(d.props.children) : d, l = C(e, b(M) ? M : [M], t, r, o, i, s, a, l, u, c), p.base = t.__e, t.__u &= -161, p.__h.length && a.push(p), k && (p.__E = p.__ = null)
            } catch (e) {
                if (a.length = f, t.__v = null, u || null != s)
                    if (e.then) {
                        for (t.__u |= u ? 160 : 128; l && 8 == l.nodeType && l.nextSibling;) l = l.nextSibling;
                        null != s && (s[s.indexOf(l)] = null), t.__e = l
                    } else {
                        if (null != s)
                            for (A = s.length; A--;) x(s[A]);
                        L(t)
                    }
                else t.__e = r.__e, !t.__k && r.__k && (t.__k = r.__k), e.then || L(t);
                n.__e(e, t, r)
            }
        } else null == s && t.__v == r.__v ? (t.__k = r.__k, t.__e = r.__e) : l = t.__e = B(r.__e, t, r, o, i, s, a, u, c);
        return (d = n.diffed) && d(t), 128 & t.__u ? void 0 : l
    }

    function L(e) {
        e && (e.__c && (e.__c.__e = !0), e.__k && e.__k.some(L))
    }

    function R(e, t, r) {
        for (var o = 0; r.length > o; o++) H(r[o], r[++o], r[++o]);
        n.__c && n.__c(t, e), e.some(function(t) {
            try {
                e = t.__h, t.__h = [], e.some(function(e) {
                    e.call(t)
                })
            } catch (e) {
                n.__e(e, t.__v)
            }
        })
    }

    function F(e) {
        return "object" != typeof e || null == e || e.__b > 0 ? e : b(e) ? e.map(F) : void 0 !== e.constructor ? null : w({}, e)
    }

    function B(e, r, o, i, s, a, l, u, c) {
        var d, f, p, h, v, y, g, w = o.props || m,
            k = r.props,
            S = r.type;
        if ("svg" == S ? s = "http://www.w3.org/2000/svg" : "math" == S ? s = "http://www.w3.org/1998/Math/MathML" : s || (s = "http://www.w3.org/1999/xhtml"), null != a)
            for (d = 0; a.length > d; d++)
                if ((v = a[d]) && "setAttribute" in v == !!S && (S ? v.localName == S : 3 == v.nodeType)) {
                    e = v, a[d] = null;
                    break
                }
        if (null == e) {
            if (null == S) return document.createTextNode(k);
            e = document.createElementNS(s, S, k.is && k), u && (n.__m && n.__m(r, a), u = !1), a = null
        }
        if (null == S) w === k || u && e.data == k || (e.data = k);
        else {
            if (a = "textarea" == S && null != k.defaultValue ? null : a && t.call(e.childNodes), !u && null != a)
                for (w = {}, d = 0; e.attributes.length > d; d++) w[(v = e.attributes[d]).name] = v.value;
            for (d in w) v = w[d], "dangerouslySetInnerHTML" == d ? p = v : "children" == d || d in k || "value" == d && "defaultValue" in k || "checked" == d && "defaultChecked" in k || j(e, d, null, v, s);
            for (d in k) v = k[d], "children" == d ? h = v : "dangerouslySetInnerHTML" == d ? f = v : "value" == d ? y = v : "checked" == d ? g = v : u && "function" != typeof v || w[d] === v || j(e, d, v, w[d], s);
            if (f) u || p && (f.__html == p.__html || f.__html == e.innerHTML) || (e.innerHTML = f.__html), r.__k = [];
            else if (p && (e.innerHTML = ""), C("template" == r.type ? e.content : e, b(h) ? h : [h], r, o, i, "foreignObject" == S ? "http://www.w3.org/1999/xhtml" : s, a, l, a ? a[0] : o.__k && $(o, 0), u, c), null != a)
                for (d = a.length; d--;) x(a[d]);
            u && "textarea" != S || (d = "value", "progress" == S && null == y ? e.removeAttribute("value") : null != y && (y !== e[d] || "progress" == S && !y || "option" == S && y != w[d]) && j(e, d, y, w[d], s), d = "checked", null != g && g != e[d] && j(e, d, g, w[d], s))
        }
        return e
    }

    function H(e, t, r) {
        try {
            if ("function" == typeof e) {
                var o = "function" == typeof e.__u;
                o && e.__u(), o && null == t || (e.__u = e(t))
            } else e.current = t
        } catch (e) {
            n.__e(e, r)
        }
    }

    function U(e, t, r) {
        var o, i;
        if (n.unmount && n.unmount(e), (o = e.ref) && (o.current && o.current != e.__e || H(o, null, t)), null != (o = e.__c)) {
            if (o.componentWillUnmount) try {
                o.componentWillUnmount()
            } catch (e) {
                n.__e(e, t)
            }
            o.base = o.__P = o.__n = null
        }
        if (o = e.__k)
            for (i = 0; o.length > i; i++) o[i] && U(o[i], t, r || "function" != typeof e.type);
        r || x(e.__e), e.__c = e.__ = e.__e = void 0
    }

    function Q(e, t, n) {
        return this.constructor(e, n)
    }

    function V(e, r, o) {
        var i, s, a, l;
        r == document && (r = document.documentElement), n.__ && n.__(e, r), s = (i = "function" == typeof o) ? null : o && o.__k || r.__k, a = [], l = [], z(r, e = (!i && o || r).__k = k(T, null, [e]), s || m, m, r.namespaceURI, !i && o ? [o] : s ? null : r.firstChild ? t.call(r.childNodes) : null, a, !i && o ? o : s ? s.__e : r.firstChild, i, l), R(a, e, l), e.props.children = null
    }
    t = y.slice, n = {
        __e(e, t, n, r) {
            for (var o, i, s; t = t.__;)
                if ((o = t.__c) && !o.__) try {
                    if ((i = o.constructor) && null != i.getDerivedStateFromError && (o.setState(i.getDerivedStateFromError(e)), s = o.__d), null != o.componentDidCatch && (o.componentDidCatch(e, r || {}), s = o.__d), s) return o.__E = o
                } catch (t) {
                    e = t
                }
            throw e
        }
    }, r = 0, _.prototype.setState = function(e, t) {
        var n = null != this.__s && this.__s != this.state ? this.__s : this.__s = w({}, this.state);
        "function" == typeof e && (e = e(w({}, n), this.props)), e && w(n, e), null != e && this.__v && (t && this._sb.push(t), I(this))
    }, _.prototype.forceUpdate = function(e) {
        this.__v && (this.__e = !0, e && this.__h.push(e), I(this))
    }, _.prototype.render = T, o = [], s = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, a = function(e, t) {
        return e.__v.__b - t.__v.__b
    }, E.__r = 0, l = Math.random().toString(8), u = "__d" + l, c = "__a" + l, d = /(PointerCapture)$|Capture$/i, f = 0, p = O(!1), h = O(!0), v = 0;
    var W = 0;

    function G(e, t, r, o, i, s) {
        t || (t = {});
        var a, l, u = t;
        if ("ref" in u)
            for (l in u = {}, t) "ref" == l ? a = t[l] : u[l] = t[l];
        var c = {
            type: e,
            props: u,
            key: r,
            ref: a,
            __k: null,
            __: null,
            __b: 0,
            __e: null,
            __c: null,
            constructor: void 0,
            __v: --W,
            __i: -1,
            __u: 0,
            __source: i,
            __self: s
        };
        if ("function" == typeof e && (a = e.defaultProps))
            for (l in a) void 0 === u[l] && (u[l] = a[l]);
        return n.vnode && n.vnode(c), c
    }
    const Z = "$surveys",
        Y = "featureFlagsCommon";

    function K({
        client: e,
        config: t
    }) {
        var n;
        if (!e || !t.uiHost) return;
        const r = null === (n = e.session) || void 0 === n ? void 0 : n.sessionId;
        return r ? `${t.uiHost}/project/${e.projectToken}/replay/${r}` : void 0
    }
    var J = function(e) {
        return e.GZipJS = "gzip-js", e.Base64 = "base64", e
    }({});
    const X = "min_length",
        ee = "max_length",
        te = Object.prototype,
        ne = te.hasOwnProperty,
        re = te.toString,
        oe = Array.isArray || function(e) {
            return "[object Array]" === re.call(e)
        },
        ie = e => "function" == typeof e,
        se = e => void 0 === e,
        ae = e => "[object String]" == re.call(e),
        le = e => null === e,
        ue = e => se(e) || le(e),
        ce = e => "[object Number]" == re.call(e) && e == e;

    function de(e, t, n, r, o, i, s) {
        try {
            var a = e[i](s),
                l = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(l) : Promise.resolve(l).then(r, o)
    }

    function fe(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = e.apply(t, n);

                function s(e) {
                    de(i, r, o, s, a, "next", e)
                }

                function a(e) {
                    de(i, r, o, s, a, "throw", e)
                }
                s(void 0)
            })
        }
    }
    const pe = "Mobile",
        he = "Tablet",
        ve = "Android Tablet",
        me = "iPad",
        ye = "Apple Watch",
        ge = "Nintendo",
        be = "PlayStation",
        we = "Xbox",
        xe = "Nokia",
        ke = "Ouya",
        Se = "Generic " + pe.toLowerCase(),
        Te = "Generic " + he.toLowerCase(),
        _e = new RegExp(we, "i"),
        qe = new RegExp("PlayStation \\w+", "i"),
        Pe = new RegExp("Nintendo \\w+", "i"),
        Ie = new RegExp("BlackBerry|PlayBook|BB10", "i");
    new RegExp(ge, "i"), new RegExp(be, "i"), new RegExp("Windows", "i");

    function $e(e) {
        return $e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        }, $e(e)
    }

    function Ee(e, t, n) {
        return (t = function(e) {
            var t = function(e) {
                if ("object" != $e(e) || !e) return e;
                var t = e[Symbol.toPrimitive];
                if (void 0 !== t) {
                    var n = t.call(e, "string");
                    if ("object" != $e(n)) return n;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return String(e)
            }(e);
            return "symbol" == $e(t) ? t : t + ""
        }(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function Ce(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var r = Object.getOwnPropertySymbols(e);
            t && (r = r.filter(function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            })), n.push.apply(n, r)
        }
        return n
    }

    function Me(e) {
        for (var t = 1; arguments.length > t; t++) {
            var n = null != arguments[t] ? arguments[t] : {};
            t % 2 ? Ce(Object(n), !0).forEach(function(t) {
                Ee(e, t, n[t])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ce(Object(n)).forEach(function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
            })
        }
        return e
    }
    let Ae;
    const De = e => {
            throw function(e, t) {
                const n = new Error(t);
                try {
                    Object.defineProperty(n, "name", {
                        value: "NativeGzipValidationError",
                        writable: !0,
                        enumerable: !0,
                        configurable: !0
                    })
                } catch (e) {}
                return n
            }(0, `Native gzip produced invalid output: ${e}`)
        },
        Ne = function() {
            var e = fe(function*(e, t) {
                18 > e.size && De("too-short");
                const n = new Uint8Array(yield e.slice(0, 10).arrayBuffer());
                var r;
                (2 > (r = n).length || 31 !== r[0] || 139 !== r[1] || 8 !== n[2]) && De("invalid-header");
                const o = new DataView(yield e.slice(e.size - 8).arrayBuffer());
                o.getUint32(0, !0) !== (e => {
                    const t = (() => {
                        if (Ae) return Ae;
                        Ae = [];
                        for (let e = 0; 256 > e; e++) {
                            let t = e;
                            for (let e = 0; 8 > e; e++) t = 1 & t ? 3988292384 ^ t >>> 1 : t >>> 1;
                            Ae[e] = t >>> 0
                        }
                        return Ae
                    })();
                    let n = 4294967295;
                    for (let r = 0; e.length > r; r++) n = t[255 & (n ^ e[r])] ^ n >>> 8;
                    return (4294967295 ^ n) >>> 0
                })(t) && De("invalid-crc");
                const i = t.length >>> 0;
                o.getUint32(4, !0) !== i && De("invalid-size")
            });
            return function(t, n) {
                return e.apply(this, arguments)
            }
        }();

    function je() {
        return je = fe(function*(e, t = !0, n) {
            try {
                const t = (new TextEncoder).encode(e),
                    n = new globalThis.CompressionStream("gzip"),
                    o = n.writable.getWriter(),
                    i = o.write(t).then(() => o.close()).catch((r = fe(function*(e) {
                        try {
                            yield o.abort(e)
                        } catch (e) {}
                        throw e
                    }), function(e) {
                        return r.apply(this, arguments)
                    })),
                    s = new Response(n.readable).blob(),
                    [a] = yield Promise.all([s, i]);
                return yield Ne(a, t), a
            } catch (e) {
                if (null == n ? void 0 : n.rethrow) throw e;
                return t && console.error("Failed to gzip compress data", e), null
            }
            var r
        }), je.apply(this, arguments)
    }

    function Oe(e, t) {
        if (!e) return;
        const n = e.find(e => e.type === t);
        return null == n ? void 0 : n.value
    }
    var ze = class e {
            constructor(e) {
                if (this.bytes = e, 16 !== e.length) throw new TypeError("not 128-bit length")
            }
            static fromFieldsV7(t, n, r, o) {
                if (!Number.isInteger(t) || !Number.isInteger(n) || !Number.isInteger(r) || !Number.isInteger(o) || 0 > t || 0 > n || 0 > r || 0 > o || t > 0xffffffffffff || n > 4095 || r > 1073741823 || o > 4294967295) throw new RangeError("invalid field value");
                const i = new Uint8Array(16);
                return i[0] = t / Math.pow(2, 40), i[1] = t / Math.pow(2, 32), i[2] = t / Math.pow(2, 24), i[3] = t / Math.pow(2, 16), i[4] = t / 256, i[5] = t, i[6] = 112 | n >>> 8, i[7] = n, i[8] = 128 | r >>> 24, i[9] = r >>> 16, i[10] = r >>> 8, i[11] = r, i[12] = o >>> 24, i[13] = o >>> 16, i[14] = o >>> 8, i[15] = o, new e(i)
            }
            toString() {
                let e = "";
                for (let t = 0; this.bytes.length > t; t++) e = e + (this.bytes[t] >>> 4).toString(16) + (15 & this.bytes[t]).toString(16), 3 !== t && 5 !== t && 7 !== t && 9 !== t || (e += "-");
                if (36 !== e.length) throw new Error("Invalid UUIDv7 was generated");
                return e
            }
            clone() {
                return new e(this.bytes.slice(0))
            }
            equals(e) {
                return 0 === this.compareTo(e)
            }
            compareTo(e) {
                for (let t = 0; 16 > t; t++) {
                    const n = this.bytes[t] - e.bytes[t];
                    if (0 !== n) return Math.sign(n)
                }
                return 0
            }
        },
        Le = class {
            generate() {
                const e = this.generateOrAbort();
                if (!se(e)) return e; {
                    this.Tt = 0;
                    const e = this.generateOrAbort();
                    if (se(e)) throw new Error("Could not generate UUID after timestamp reset");
                    return e
                }
            }
            generateOrAbort() {
                const e = (() => {
                    const e = Date.now();
                    return ce(e) && isFinite(e) ? Math.min(Math.max(Math.floor(e), 0), 0xffffffffffff) : 0
                })();
                if (e > this.Tt) this.Tt = e, this.It();
                else {
                    if (this.Tt >= e + 1e4) return;
                    this.Mt++, this.Mt > 4398046511103 && (this.Tt++, this.It())
                }
                return ze.fromFieldsV7(this.Tt, Math.trunc(this.Mt / Math.pow(2, 30)), this.Mt & Math.pow(2, 30) - 1, this.Rt.nextUint32())
            }
            It() {
                this.Mt = 1024 * this.Rt.nextUint32() + (1023 & this.Rt.nextUint32())
            }
            constructor() {
                this.Tt = 0, this.Mt = 0, this.Rt = new Be
            }
        };
    const Re = e => {
        if ("u" > typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG) throw new Error("no cryptographically strong RNG available");
        for (let t = 0; e.length > t; t++) e[t] = 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random());
        return e
    };
    let Fe;
    var Be = class {
        nextUint32() {
            var e;
            return this.At.length > this.Et || ((null !== (e = Fe) && void 0 !== e ? e : Fe = "u" > typeof window && !se(window.crypto) && crypto.getRandomValues ? e => {
                try {
                    return crypto.getRandomValues(e)
                } catch (t) {
                    return Re(e)
                }
            } : Re)(this.At), this.Et = 0), this.At[this.Et++]
        }
        constructor() {
            this.At = new Uint32Array(8), this.Et = 1 / 0
        }
    };
    let He;
    const Ue = () => Qe().toString(),
        Qe = () => (He || (He = new Le)).generate();
    var Ve, We, Ge, Ze, Ye = 0,
        Ke = [],
        Je = n,
        Xe = Je.__b,
        et = Je.__r,
        tt = Je.diffed,
        nt = Je.__c,
        rt = Je.unmount,
        ot = Je.__;

    function it(e, t) {
        Je.__h && Je.__h(We, e, Ye || t), Ye = 0;
        var n = We.__H || (We.__H = {
            __: [],
            __h: []
        });
        return e >= n.__.length && n.__.push({}), n.__[e]
    }

    function st(e) {
        return Ye = 1,
            function(e, t) {
                var n = it(Ve++, 2);
                if (n.t = e, !n.__c && (n.__ = [yt(void 0, t), function(e) {
                        var t = n.__N ? n.__N[0] : n.__[0],
                            r = n.t(t, e);
                        t !== r && (n.__N = [r, n.__[1]], n.__c.setState({}))
                    }], n.__c = We, !We.__f)) {
                    var r = function(e, t, r) {
                        if (!n.__c.__H) return !0;
                        var i = !1,
                            s = n.__c.props !== e;
                        if (n.__c.__H.__.some(function(e) {
                                if (e.__N) {
                                    i = !0;
                                    var t = e.__[0];
                                    e.__ = e.__N, e.__N = void 0, t !== e.__[0] && (s = !0)
                                }
                            }), o) {
                            var a = o.call(this, e, t, r);
                            return i ? a || s : a
                        }
                        return !i || s
                    };
                    We.__f = !0;
                    var o = We.shouldComponentUpdate,
                        i = We.componentWillUpdate;
                    We.componentWillUpdate = function(e, t, n) {
                        if (this.__e) {
                            var s = o;
                            o = void 0, r(e, t, n), o = s
                        }
                        i && i.call(this, e, t, n)
                    }, We.shouldComponentUpdate = r
                }
                return n.__N || n.__
            }(yt, e)
    }

    function at(e, t) {
        var n = it(Ve++, 3);
        !Je.__s && mt(n.__H, t) && (n.__ = e, n.u = t, We.__H.__h.push(n))
    }

    function lt(e) {
        return Ye = 5, ut(function() {
            return {
                current: e
            }
        }, [])
    }

    function ut(e, t) {
        var n = it(Ve++, 7);
        return mt(n.__H, t) && (n.__ = e(), n.__H = t, n.__h = e), n.__
    }

    function ct(e) {
        var t = We.context[e.__c],
            n = it(Ve++, 9);
        return n.c = e, t ? (null == n.__ && (n.__ = !0, t.sub(We)), t.props.value) : e.__
    }

    function dt() {
        for (var e; e = Ke.shift();) {
            var t = e.__H;
            if (e.__P && t) try {
                t.__h.some(ht), t.__h.some(vt), t.__h = []
            } catch (n) {
                t.__h = [], Je.__e(n, e.__v)
            }
        }
    }
    Je.__b = function(e) {
        We = null, Xe && Xe(e)
    }, Je.__ = function(e, t) {
        e && t.__k && t.__k.__m && (e.__m = t.__k.__m), ot && ot(e, t)
    }, Je.__r = function(e) {
        et && et(e), Ve = 0;
        var t = (We = e.__c).__H;
        t && (Ge === We ? (t.__h = [], We.__h = [], t.__.some(function(e) {
            e.__N && (e.__ = e.__N), e.u = e.__N = void 0
        })) : (t.__h.length && dt(), Ve = 0)), Ge = We
    }, Je.diffed = function(e) {
        tt && tt(e);
        var t = e.__c;
        t && t.__H && (t.__H.__h.length && (1 !== Ke.push(t) && Ze === Je.requestAnimationFrame || ((Ze = Je.requestAnimationFrame) || pt)(dt)), t.__H.__.some(function(e) {
            e.u && (e.__H = e.u, e.u = void 0)
        })), Ge = We = null
    }, Je.__c = function(e, t) {
        t.some(function(e) {
            try {
                e.__h.some(ht), e.__h = e.__h.filter(function(e) {
                    return !e.__ || vt(e)
                })
            } catch (n) {
                t.some(function(e) {
                    e.__h && (e.__h = [])
                }), t = [], Je.__e(n, e.__v)
            }
        }), nt && nt(e, t)
    }, Je.unmount = function(e) {
        rt && rt(e);
        var t, n = e.__c;
        n && n.__H && (n.__H.__.some(function(e) {
            try {
                ht(e)
            } catch (e) {
                t = e
            }
        }), n.__H = void 0, t && Je.__e(t, n.__v))
    };
    var ft = "function" == typeof requestAnimationFrame;

    function pt(e) {
        var t, n = function() {
                clearTimeout(r), ft && cancelAnimationFrame(t), setTimeout(e)
            },
            r = setTimeout(n, 35);
        ft && (t = requestAnimationFrame(n))
    }

    function ht(e) {
        var t = We,
            n = e.__c;
        "function" == typeof n && (e.__c = void 0, n()), We = t
    }

    function vt(e) {
        var t = We;
        e.__c = e.__(), We = t
    }

    function mt(e, t) {
        return !e || e.length !== t.length || t.some(function(t, n) {
            return t !== e[n]
        })
    }

    function yt(e, t) {
        return "function" == typeof t ? t(e) : t
    }
    const gt = "tab",
        bt = "left",
        wt = "center",
        xt = "right",
        kt = "next_to_trigger",
        St = "popover",
        Tt = "widget",
        _t = "external_survey",
        qt = "open",
        Pt = "multiple_choice",
        It = "single_choice",
        $t = "rating",
        Et = "end",
        Ct = "always",
        Mt = "survey shown",
        At = "survey dismissed",
        Dt = "survey sent",
        Nt = "$survey_id",
        jt = "$survey_name",
        Ot = "$survey_iteration",
        zt = "$survey_iteration_start_date",
        Lt = "$survey_language",
        Rt = "0.10.5",
        Ft = {
            DEBUG: !1,
            LIB_VERSION: Rt,
            LIB_NAME: "browser-common",
            JS_SDK_VERSION: Rt
        },
        Bt = (e, {
            debugEnabled: t
        } = {}) => {
            const n = {
                N(n, ...r) {
                    let o;
                    try {
                        o = typeof window > "u" ? void 0 : window
                    } catch (e) {
                        return
                    }
                    o && (Ft.DEBUG || o.POSTHOG_DEBUG || t) && !se(o.console) && o.console && ("__rrweb_original__" in o.console[n] ? o.console[n].__rrweb_original__ : o.console[n])(e, ...r)
                },
                debug(...e) {
                    n.N("debug", ...e)
                },
                info(...e) {
                    n.N("log", ...e)
                },
                warn(...e) {
                    n.N("warn", ...e)
                },
                error(...e) {
                    n.N("error", ...e)
                },
                critical(...t) {
                    console.error(e, ...t)
                },
                uninitializedWarning(e) {
                    n.error(`You must initialize PostHog before calling ${e}`)
                },
                createLogger: (t, n) => Bt(`${e} ${t}`, n)
            };
            return n
        },
        Ht = Bt("[PostHog.js]"),
        Ut = Ht.createLogger;

    function Qt(e, t, n, r) {
        const {
            capture: o = !1,
            passive: i = !0
        } = null != r ? r : {};
        null == e || e.addEventListener(t, n, {
            capture: o,
            passive: i
        })
    }

    function Vt(e) {
        return `$survey_response_${e}`
    }

    function Wt(e, t) {
        if (!t) return null;
        const n = e[Vt(t)];
        return oe(n) ? [...n] : n
    }

    function Gt({
        event: e,
        survey: t,
        responses: n = {},
        submissionId: r,
        completed: o,
        surveyLanguage: i,
        questionSnapshots: s
    }) {
        return Me(Me(Me(Me({}, !se(r) && {
            $survey_submission_id: r
        }), "sent" === e ? !se(o) && {
            $survey_completed: o
        } : {
            $survey_partially_completed: Zt(n)
        }), i && {
            $survey_language: i
        }), function(e = {}, t, n) {
            const r = {};
            return t.questions.forEach(t => {
                if (se(t.originalQuestionIndex)) return;
                const n = 0 === (o = t.originalQuestionIndex) ? "$survey_response" : `$survey_response_${o}`;
                var o;
                const i = Wt(e, t.id);
                se(i) || (r[n] = i)
            }), Me(Me({
                $survey_questions: t.questions.map(t => {
                    var r, o;
                    return {
                        id: t.id,
                        question: null !== (r = null == n ? void 0 : n[null !== (o = t.id) && void 0 !== o ? o : ""]) && void 0 !== r ? r : t.question,
                        response: Wt(e, t.id)
                    }
                })
            }, e), r)
        }(n, t, s))
    }

    function Zt(e = {}) {
        return Object.values(e).some(e => !ue(e))
    }

    function Yt(e, t) {
        let n = `$survey_${t}/${e.id}`;
        return e.current_iteration && e.current_iteration > 0 && (n = `$survey_${t}/${e.id}/${e.current_iteration}`), n
    }

    function Kt(e) {
        return "string" == typeof e && e.trim() ? e.trim() : null
    }

    function Jt(e) {
        return e.toLowerCase()
    }

    function Xt(e, t, n) {
        if (!e || !t) return null;
        const r = Jt(t),
            o = Object.keys(e).find(e => Jt(e) === r);
        if (o) return null == n || n.debug(`Found exact translation match: ${o}`), o;
        if (r.includes("-")) {
            const o = r.split("-")[0],
                i = Object.keys(e).find(e => Jt(e) === o);
            if (i) return null == n || n.debug(`Found base language translation match: ${i} (from ${t})`), i
        }
        return null
    }
    const en = ["thankYouMessageHeader", "thankYouMessageDescription", "thankYouMessageCloseButtonText", "introScreenHeader", "introScreenDescription", "introScreenButtonText", "submitButtonText", "backButtonText"];

    function tn(e, t, n) {
        var r;
        const o = Xt(e.translations, t, n),
            i = Me({}, e);
        let s = !1;
        if (o) {
            var a;
            const t = null === (a = e.translations) || void 0 === a ? void 0 : a[o];
            if (t)
                if (null == n || n.info(`Applying survey-level translation for language: ${o}`), se(t.name) || (i.name = t.name, s = !0), i.appearance) {
                    const e = Me({}, i.appearance);
                    for (const n of en) {
                        const r = t[n];
                        se(r) || (e[n] = r, s = !0)
                    }
                    i.appearance = e
                } else(function(e) {
                    return en.some(t => !se(e[t]))
                })(t) && (s = !0)
        }
        const l = e.questions.map(e => function(e, t, n) {
                var r;
                const o = Xt(e.translations, t, n);
                if (!o) return {
                    question: e,
                    matchedKey: null,
                    hasChanges: !1
                };
                const i = null === (r = e.translations) || void 0 === r ? void 0 : r[o];
                if (!i) return {
                    question: e,
                    matchedKey: null,
                    hasChanges: !1
                };
                const s = Me({}, e);
                let a = !1;
                return se(i.question) || (s.question = i.question, a = !0), se(i.description) || (s.description = i.description, a = !0), se(i.buttonText) || (s.buttonText = i.buttonText, a = !0), "link" in s && !se(i.link) && (s.link = i.link, a = !0), "lowerBoundLabel" in s && !se(i.lowerBoundLabel) && (s.lowerBoundLabel = i.lowerBoundLabel, a = !0), "upperBoundLabel" in s && !se(i.upperBoundLabel) && (s.upperBoundLabel = i.upperBoundLabel, a = !0), "choices" in s && function(e) {
                    return oe(e.choices)
                }(i) && (s.choices = i.choices, a = !0), {
                    question: a ? s : e,
                    matchedKey: a ? o : null,
                    hasChanges: a
                }
            }(e, t, n)),
            u = l.map(e => e.question),
            c = l.some(e => e.hasChanges);
        let d = null;
        return o || (d = (null === (r = l.find(e => e.matchedKey)) || void 0 === r ? void 0 : r.matchedKey) || null), c && (i.questions = u, s = !0, null == n || n.info(`Applied question-level translations for language: ${t}`)), {
            survey: i,
            matchedKey: s ? o || d : null
        }
    }

    function nn(e) {
        var t;
        return !!(null === (t = e.conditions) || void 0 === t || null === (t = t.events) || void 0 === t || null === (t = t.values) || void 0 === t ? void 0 : t.length)
    }
    const rn = (e, t) => {
            if (!(e => {
                    try {
                        new RegExp(e)
                    } catch (e) {
                        return !1
                    }
                    return !0
                })(t)) return !1;
            try {
                return new RegExp(t).test(e)
            } catch (e) {
                return !1
            }
        },
        on = e => e.toLowerCase(),
        sn = {
            exact: (e, t) => t.some(t => e.some(e => t === e)),
            is_not: (e, t) => t.every(t => e.every(e => t !== e)),
            regex: (e, t) => t.some(t => e.some(e => rn(t, e))),
            not_regex: (e, t) => t.every(t => e.every(e => !rn(t, e))),
            icontains: (e, t) => t.map(on).some(t => e.map(on).some(e => t.includes(e))),
            not_icontains: (e, t) => t.map(on).every(t => e.map(on).every(e => !t.includes(e))),
            gt: (e, t) => t.some(t => {
                const n = parseFloat(t);
                return !isNaN(n) && e.some(e => n > parseFloat(e))
            }),
            lt: (e, t) => t.some(t => {
                const n = parseFloat(t);
                return !isNaN(n) && e.some(e => n < parseFloat(e))
            })
        },
        an = e => {
            const t = [...e];
            for (let e = t.length - 1; e > 0; e--) {
                const n = Math.floor(Math.random() * (e + 1));
                [t[e], t[n]] = [t[n], t[e]]
            }
            return t
        },
        ln = Ut("[Surveys]"),
        un = (e, t) => `${e}${function(e){return e.current_iteration&&e.current_iteration>0?`${e.id}_${e.current_iteration}`:e.id}(t)}`,
        cn = e => un("seenSurvey_", e),
        dn = [St, Tt, "api"];

    function fn(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = Array(t); t > n; n++) r[n] = e[n];
        return r
    }

    function pn(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (null != n) {
                var r, o, i, s, a = [],
                    l = !0,
                    u = !1;
                try {
                    if (i = (n = n.call(e)).next, 0 === t);
                    else
                        for (; !(l = (r = i.call(n)).done) && (a.push(r.value), a.length !== t); l = !0);
                } catch (e) {
                    u = !0, o = e
                } finally {
                    try {
                        if (!l && null != n.return && (s = n.return(), Object(s) !== s)) return
                    } finally {
                        if (u) throw o
                    }
                }
                return a
            }
        }(e, t) || function(e, t) {
            if (e) {
                if ("string" == typeof e) return fn(e, t);
                var n = {}.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? fn(e, t) : void 0
            }
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    const hn = Object.entries,
        vn = Object.setPrototypeOf,
        mn = Object.isFrozen,
        yn = Object.getPrototypeOf,
        gn = Object.getOwnPropertyDescriptor;
    let bn = Object.freeze,
        wn = Object.seal,
        xn = Object.create,
        kn = "undefined" != typeof Reflect && Reflect,
        Sn = kn.apply,
        Tn = kn.construct;
    bn || (bn = function(e) {
        return e
    }), wn || (wn = function(e) {
        return e
    }), Sn || (Sn = function(e, t) {
        for (var n = arguments.length, r = new Array(n > 2 ? n - 2 : 0), o = 2; n > o; o++) r[o - 2] = arguments[o];
        return e.apply(t, r)
    }), Tn || (Tn = function(e) {
        for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; t > r; r++) n[r - 1] = arguments[r];
        return new e(...n)
    });
    const _n = Vn([].forEach),
        qn = Vn([].lastIndexOf),
        Pn = Vn([].pop),
        In = Vn([].push),
        $n = Vn([].splice),
        En = Array.isArray,
        Cn = Vn("".toLowerCase),
        Mn = Vn("".toString),
        An = Vn("".match),
        Dn = Vn("".replace),
        Nn = Vn("".indexOf),
        jn = Vn("".trim),
        On = Vn((0).toString),
        zn = Vn(Boolean.prototype.toString),
        Ln = "undefined" == typeof BigInt ? null : Vn(BigInt.prototype.toString),
        Rn = "undefined" == typeof Symbol ? null : Vn(Symbol.prototype.toString),
        Fn = Vn({}.hasOwnProperty),
        Bn = Vn({}.toString),
        Hn = Vn(/t/.test),
        Un = (Qn = TypeError, function() {
            for (var e = arguments.length, t = new Array(e), n = 0; e > n; n++) t[n] = arguments[n];
            return Tn(Qn, t)
        });
    var Qn;

    function Vn(e) {
        return function(t) {
            t instanceof RegExp && (t.lastIndex = 0);
            for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1; n > o; o++) r[o - 1] = arguments[o];
            return Sn(e, t, r)
        }
    }

    function Wn(e, t) {
        let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Cn;
        if (vn && vn(e, null), !En(t)) return e;
        let r = t.length;
        for (; r--;) {
            let o = t[r];
            if ("string" == typeof o) {
                const e = n(o);
                e !== o && (mn(t) || (t[r] = e), o = e)
            }
            e[o] = !0
        }
        return e
    }

    function Gn(e) {
        for (let t = 0; e.length > t; t++) Fn(e, t) || (e[t] = null);
        return e
    }

    function Zn(e) {
        const t = xn(null);
        for (const r of hn(e)) {
            var n = pn(r, 2);
            const o = n[0],
                i = n[1];
            Fn(e, o) && (t[o] = En(i) ? Gn(i) : i && "object" == typeof i && i.constructor === Object ? Zn(i) : i)
        }
        return t
    }

    function Yn(e, t) {
        for (; null !== e;) {
            const n = gn(e, t);
            if (n) {
                if (n.get) return Vn(n.get);
                if ("function" == typeof n.value) return Vn(n.value)
            }
            e = yn(e)
        }
        return function() {
            return null
        }
    }
    const Kn = bn(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]),
        Jn = bn(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]),
        Xn = bn(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]),
        er = bn(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]),
        tr = bn(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]),
        nr = bn(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]),
        rr = bn(["#text"]),
        or = bn(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "command", "commandfor", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns"]),
        ir = bn(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dominant-baseline", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "mask-type", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-orientation", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]),
        sr = bn(["accent", "accentunder", "align", "bevelled", "close", "columnalign", "columnlines", "columnspacing", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lquote", "lspace", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]),
        ar = bn(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]),
        lr = wn(/{{[\w\W]*|^[\w\W]*}}/g),
        ur = wn(/<%[\w\W]*|^[\w\W]*%>/g),
        cr = wn(/\${[\w\W]*/g),
        dr = wn(/^data-[\-\w.\u00B7-\uFFFF]+$/),
        fr = wn(/^aria-[\-\w]+$/),
        pr = wn(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),
        hr = wn(/^(?:\w+script|data):/i),
        vr = wn(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),
        mr = wn(/^html$/i),
        yr = wn(/^[a-z][.\w]*(-[.\w]+)+$/i),
        gr = wn(/<[/\w!]/g),
        br = wn(/<[/\w]/g),
        wr = wn(/<\/no(script|embed|frames)/i),
        xr = wn(/\/>/i),
        kr = function() {
            return "undefined" == typeof window ? null : window
        },
        Sr = function(e, t, n, r) {
            return Fn(e, t) && En(e[t]) ? Wn(r.base ? Zn(r.base) : {}, e[t], r.transform) : n
        };
    var Tr = function e() {
        let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : kr();
        const n = t => e(t);
        if (n.version = "3.4.13", n.removed = [], !t || !t.document || 9 !== t.document.nodeType || !t.Element) return n.isSupported = !1, n;
        let r = t.document;
        const o = r,
            i = o.currentScript,
            s = t.HTMLTemplateElement,
            a = t.Node,
            l = t.NodeFilter,
            u = t.DOMParser,
            c = t.trustedTypes,
            d = t.Element.prototype,
            f = Yn(d, "cloneNode"),
            p = Yn(d, "remove"),
            h = Yn(d, "nextSibling"),
            v = Yn(d, "childNodes"),
            m = Yn(d, "parentNode"),
            y = Yn(d, "shadowRoot"),
            g = Yn(d, "attributes"),
            b = a && a.prototype ? Yn(a.prototype, "nodeType") : null,
            w = a && a.prototype ? Yn(a.prototype, "nodeName") : null,
            x = a && a.prototype ? Yn(a.prototype, "ownerDocument") : null;
        if ("function" == typeof s) {
            const e = r.createElement("template");
            e.content && e.content.ownerDocument && (r = e.content.ownerDocument)
        }
        let k, S, T = "",
            _ = !1,
            q = 0;
        const P = function() {
                if (q > 0) throw Un('A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.')
            },
            I = function(e) {
                P(), q++;
                try {
                    return k.createHTML(e)
                } finally {
                    q--
                }
            },
            E = r.implementation,
            C = r.createNodeIterator,
            M = r.createDocumentFragment,
            A = r.getElementsByTagName,
            D = o.importNode;
        let N = {
            afterSanitizeAttributes: [],
            afterSanitizeElements: [],
            afterSanitizeShadowDOM: [],
            beforeSanitizeAttributes: [],
            beforeSanitizeElements: [],
            beforeSanitizeShadowDOM: [],
            uponSanitizeAttribute: [],
            uponSanitizeElement: [],
            uponSanitizeShadowNode: []
        };
        n.isSupported = "function" == typeof hn && "function" == typeof m && E && void 0 !== E.createHTMLDocument;
        const j = lr,
            O = ur,
            z = cr,
            L = dr,
            R = fr,
            F = hr,
            B = vr,
            H = yr;
        let U = pr,
            Q = null;
        const V = Wn({}, [...Kn, ...Jn, ...Xn, ...tr, ...rr]);
        let W = null;
        const G = Wn({}, [...or, ...ir, ...sr, ...ar]);
        let Z = Object.seal(xn(null, {
                tagNameCheck: {
                    writable: !0,
                    configurable: !1,
                    enumerable: !0,
                    value: null
                },
                attributeNameCheck: {
                    writable: !0,
                    configurable: !1,
                    enumerable: !0,
                    value: null
                },
                allowCustomizedBuiltInElements: {
                    writable: !0,
                    configurable: !1,
                    enumerable: !0,
                    value: !1
                }
            })),
            Y = null,
            K = null;
        const J = Object.seal(xn(null, {
            tagCheck: {
                writable: !0,
                configurable: !1,
                enumerable: !0,
                value: null
            },
            attributeCheck: {
                writable: !0,
                configurable: !1,
                enumerable: !0,
                value: null
            }
        }));
        let X = !0,
            ee = !0,
            te = !1,
            ne = !0,
            re = !1,
            oe = !0,
            ie = !1,
            se = !1,
            ae = null,
            le = null,
            ue = !1,
            ce = !1,
            de = !1,
            fe = !1,
            pe = !0,
            he = !1;
        const ve = "user-content-";
        let me = !0,
            ye = !1,
            ge = {},
            be = null;
        const we = Wn({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "selectedcontent", "style", "svg", "template", "thead", "title", "video", "xmp"]);
        let xe = null;
        const ke = Wn({}, ["audio", "video", "img", "source", "image", "track"]);
        let Se = null;
        const Te = Wn({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]),
            _e = "http://www.w3.org/1998/Math/MathML",
            qe = "http://www.w3.org/2000/svg",
            Pe = "http://www.w3.org/1999/xhtml";
        let Ie = Pe,
            $e = !1,
            Ee = null;
        const Ce = Wn({}, [_e, qe, Pe], Mn),
            Me = bn(["mi", "mo", "mn", "ms", "mtext"]);
        let Ae = Wn({}, Me);
        const De = bn(["annotation-xml"]);
        let Ne = Wn({}, De);
        const je = Wn({}, ["title", "style", "font", "a", "script"]);
        let Oe = null;
        const ze = ["application/xhtml+xml", "text/html"];
        let Le = null,
            Re = null;
        const Fe = r.createElement("form"),
            Be = function(e) {
                return e instanceof RegExp || e instanceof Function
            },
            He = function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                if (Re && Re === e) return;
                e && "object" == typeof e || (e = {}), e = Zn(e), Oe = -1 === ze.indexOf(e.PARSER_MEDIA_TYPE) ? "text/html" : e.PARSER_MEDIA_TYPE, Le = "application/xhtml+xml" === Oe ? Mn : Cn, Q = Sr(e, "ALLOWED_TAGS", V, {
                    transform: Le
                }), W = Sr(e, "ALLOWED_ATTR", G, {
                    transform: Le
                }), Ee = Sr(e, "ALLOWED_NAMESPACES", Ce, {
                    transform: Mn
                }), Se = Sr(e, "ADD_URI_SAFE_ATTR", Te, {
                    transform: Le,
                    base: Te
                }), xe = Sr(e, "ADD_DATA_URI_TAGS", ke, {
                    transform: Le,
                    base: ke
                }), be = Sr(e, "FORBID_CONTENTS", we, {
                    transform: Le
                }), Y = Sr(e, "FORBID_TAGS", Zn({}), {
                    transform: Le
                }), K = Sr(e, "FORBID_ATTR", Zn({}), {
                    transform: Le
                }), ge = !!Fn(e, "USE_PROFILES") && (e.USE_PROFILES && "object" == typeof e.USE_PROFILES ? Zn(e.USE_PROFILES) : e.USE_PROFILES), X = !1 !== e.ALLOW_ARIA_ATTR, ee = !1 !== e.ALLOW_DATA_ATTR, te = e.ALLOW_UNKNOWN_PROTOCOLS || !1, ne = !1 !== e.ALLOW_SELF_CLOSE_IN_ATTR, re = e.SAFE_FOR_TEMPLATES || !1, oe = !1 !== e.SAFE_FOR_XML, ie = e.WHOLE_DOCUMENT || !1, ce = e.RETURN_DOM || !1, de = e.RETURN_DOM_FRAGMENT || !1, fe = e.RETURN_TRUSTED_TYPE || !1, ue = e.FORCE_BODY || !1, pe = !1 !== e.SANITIZE_DOM, he = e.SANITIZE_NAMED_PROPS || !1, me = !1 !== e.KEEP_CONTENT, ye = e.IN_PLACE || !1, U = function(e) {
                    try {
                        return Hn(e, ""), !0
                    } catch (e) {
                        return !1
                    }
                }(e.ALLOWED_URI_REGEXP) ? e.ALLOWED_URI_REGEXP : pr, Ie = "string" == typeof e.NAMESPACE ? e.NAMESPACE : Pe, Ae = Fn(e, "MATHML_TEXT_INTEGRATION_POINTS") && e.MATHML_TEXT_INTEGRATION_POINTS && "object" == typeof e.MATHML_TEXT_INTEGRATION_POINTS ? Zn(e.MATHML_TEXT_INTEGRATION_POINTS) : Wn({}, Me), Ne = Fn(e, "HTML_INTEGRATION_POINTS") && e.HTML_INTEGRATION_POINTS && "object" == typeof e.HTML_INTEGRATION_POINTS ? Zn(e.HTML_INTEGRATION_POINTS) : Wn({}, De);
                const t = Fn(e, "CUSTOM_ELEMENT_HANDLING") && e.CUSTOM_ELEMENT_HANDLING && "object" == typeof e.CUSTOM_ELEMENT_HANDLING ? Zn(e.CUSTOM_ELEMENT_HANDLING) : xn(null);
                if (Z = xn(null), Fn(t, "tagNameCheck") && Be(t.tagNameCheck) && (Z.tagNameCheck = t.tagNameCheck), Fn(t, "attributeNameCheck") && Be(t.attributeNameCheck) && (Z.attributeNameCheck = t.attributeNameCheck), Fn(t, "allowCustomizedBuiltInElements") && "boolean" == typeof t.allowCustomizedBuiltInElements && (Z.allowCustomizedBuiltInElements = t.allowCustomizedBuiltInElements), wn(Z), re && (ee = !1), de && (ce = !0), ge && (Q = Wn({}, rr), W = xn(null), !0 === ge.html && (Wn(Q, Kn), Wn(W, or)), !0 === ge.svg && (Wn(Q, Jn), Wn(W, ir), Wn(W, ar)), !0 === ge.svgFilters && (Wn(Q, Xn), Wn(W, ir), Wn(W, ar)), !0 === ge.mathMl && (Wn(Q, tr), Wn(W, sr), Wn(W, ar))), J.tagCheck = null, J.attributeCheck = null, Fn(e, "ADD_TAGS") && ("function" == typeof e.ADD_TAGS ? J.tagCheck = e.ADD_TAGS : En(e.ADD_TAGS) && (Q === V && (Q = Zn(Q)), Wn(Q, e.ADD_TAGS, Le))), Fn(e, "ADD_ATTR") && ("function" == typeof e.ADD_ATTR ? J.attributeCheck = e.ADD_ATTR : En(e.ADD_ATTR) && (W === G && (W = Zn(W)), Wn(W, e.ADD_ATTR, Le))), Fn(e, "ADD_URI_SAFE_ATTR") && En(e.ADD_URI_SAFE_ATTR) && Wn(Se, e.ADD_URI_SAFE_ATTR, Le), Fn(e, "FORBID_CONTENTS") && En(e.FORBID_CONTENTS) && (be === we && (be = Zn(be)), Wn(be, e.FORBID_CONTENTS, Le)), Fn(e, "ADD_FORBID_CONTENTS") && En(e.ADD_FORBID_CONTENTS) && (be === we && (be = Zn(be)), Wn(be, e.ADD_FORBID_CONTENTS, Le)), me && (Q["#text"] = !0), ie && Wn(Q, ["html", "head", "body"]), Q.table && (Wn(Q, ["tbody"]), delete Y.tbody), e.TRUSTED_TYPES_POLICY) {
                    if ("function" != typeof e.TRUSTED_TYPES_POLICY.createHTML) throw Un('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
                    if ("function" != typeof e.TRUSTED_TYPES_POLICY.createScriptURL) throw Un('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
                    const t = k;
                    k = e.TRUSTED_TYPES_POLICY;
                    try {
                        T = I("")
                    } catch (e) {
                        throw k = t, e
                    }
                } else null === e.TRUSTED_TYPES_POLICY ? (k = void 0, T = "") : (void 0 === k && (_ || (S = function(e, t) {
                    if ("object" != typeof e || "function" != typeof e.createPolicy) return null;
                    let n = null;
                    const r = "data-tt-policy-suffix";
                    t && t.hasAttribute(r) && (n = t.getAttribute(r));
                    const o = "dompurify" + (n ? "#" + n : "");
                    try {
                        return e.createPolicy(o, {
                            createHTML: e => e,
                            createScriptURL: e => e
                        })
                    } catch (e) {
                        return console.warn("TrustedTypes policy " + o + " could not be created."), null
                    }
                }(c, i), _ = !0), k = S), k && "string" == typeof T && (T = I("")));
                bn && bn(e), Re = e
            },
            Ue = Wn({}, [...Jn, ...Xn, ...er]),
            Qe = Wn({}, [...tr, ...nr]),
            Ve = function(e) {
                In(n.removed, {
                    element: e
                });
                try {
                    m(e).removeChild(e)
                } catch (t) {
                    if (p(e), !m(e)) throw Un("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place")
                }
            },
            We = function(e) {
                Ye(e);
                const t = v(e);
                if (t) {
                    const e = [];
                    _n(t, t => {
                        In(e, t)
                    }), _n(e, e => {
                        try {
                            p(e)
                        } catch (e) {}
                    })
                }
                const n = g(e);
                if (n)
                    for (let t = n.length - 1; t >= 0; --t) {
                        const r = n[t],
                            o = r && r.name;
                        if ("string" == typeof o) try {
                            e.removeAttribute(o)
                        } catch (e) {}
                    }
            },
            Ge = function(e, t) {
                try {
                    In(n.removed, {
                        attribute: t.getAttributeNode(e),
                        from: t
                    })
                } catch (e) {
                    In(n.removed, {
                        attribute: null,
                        from: t
                    })
                }
                if (t.removeAttribute(e), "is" === e)
                    if (ce || de) try {
                        Ve(t)
                    } catch (e) {} else try {
                        t.setAttribute(e, "")
                    } catch (e) {}
            },
            Ze = function(e) {
                const t = g(e);
                if (t)
                    for (let n = t.length - 1; n >= 0; --n) {
                        const r = t[n],
                            o = r && r.name;
                        if ("string" == typeof o && !W[Le(o)]) try {
                            e.removeAttribute(o)
                        } catch (e) {}
                    }
            },
            Ye = function(e) {
                const t = [e];
                for (; t.length > 0;) {
                    const e = t.pop();
                    1 === (b ? b(e) : e.nodeType) && Ze(e);
                    const n = v(e);
                    if (n)
                        for (let e = n.length - 1; e >= 0; --e) t.push(n[e])
                }
            },
            Ke = function(e) {
                let t = null,
                    n = null;
                if (ue) e = "<remove></remove>" + e;
                else {
                    const t = An(e, /^[\r\n\t ]+/);
                    n = t && t[0]
                }
                "application/xhtml+xml" === Oe && Ie === Pe && (e = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + e + "</body></html>");
                const o = k ? I(e) : e;
                if (Ie === Pe) try {
                    t = (new u).parseFromString(o, Oe)
                } catch (e) {}
                if (!t || !t.documentElement) {
                    t = E.createDocument(Ie, "template", null);
                    try {
                        t.documentElement.innerHTML = $e ? T : o
                    } catch (e) {}
                }
                const i = t.body || t.documentElement;
                return e && n && i.insertBefore(r.createTextNode(n), i.childNodes[0] || null), Ie === Pe ? A.call(t, ie ? "html" : "body")[0] : ie ? t.documentElement : i
            },
            Je = function(e) {
                const t = x ? x(e) : e.ownerDocument;
                return C.call(t || e, e, l.SHOW_ELEMENT | l.SHOW_COMMENT | l.SHOW_TEXT | l.SHOW_PROCESSING_INSTRUCTION | l.SHOW_CDATA_SECTION, null)
            },
            Xe = function(e) {
                return e = Dn(e, j, " "), e = Dn(e, O, " "), Dn(e, z, " ")
            },
            et = function(e) {
                var t;
                e.normalize();
                const n = x ? x(e) : e.ownerDocument,
                    r = C.call(n || e, e, l.SHOW_TEXT | l.SHOW_COMMENT | l.SHOW_CDATA_SECTION | l.SHOW_PROCESSING_INSTRUCTION, null);
                let o = r.nextNode();
                for (; o;) o.data = Xe(o.data), o = r.nextNode();
                const i = null === (t = e.querySelectorAll) || void 0 === t ? void 0 : t.call(e, "template");
                i && _n(i, e => {
                    nt(e.content) && et(e.content)
                })
            },
            tt = function(e) {
                const t = w ? w(e) : null;
                return "string" == typeof t && "form" === Le(t) && ("string" != typeof e.nodeName || "string" != typeof e.textContent || "function" != typeof e.removeChild || e.attributes !== g(e) || "function" != typeof e.removeAttribute || "function" != typeof e.setAttribute || "string" != typeof e.namespaceURI || "function" != typeof e.insertBefore || "function" != typeof e.hasChildNodes || e.nodeType !== b(e) || e.childNodes !== v(e))
            },
            nt = function(e) {
                if (!b || "object" != typeof e || null === e) return !1;
                try {
                    return 11 === b(e)
                } catch (e) {
                    return !1
                }
            },
            rt = function(e) {
                if (!b || "object" != typeof e || null === e) return !1;
                try {
                    return "number" == typeof b(e)
                } catch (e) {
                    return !1
                }
            };

        function ot(e, t, r) {
            0 !== e.length && _n(e, e => {
                e.call(n, t, r, Re)
            })
        }
        const it = function(e, t, n, r) {
                return 0 === e.length ? t : t === n || t === r ? Zn(t) : t
            },
            st = function(e, t) {
                if (ot(N.beforeSanitizeElements, e, null), e !== t && null === m(e)) return ye && Ye(e), !0;
                if (tt(e)) return Ve(e), !0;
                const r = Le(w ? w(e) : e.nodeName);
                if (Q = it(N.uponSanitizeElement, Q, V, ae), ot(N.uponSanitizeElement, e, {
                        tagName: r,
                        allowedTags: Q
                    }), e !== t && null === m(e)) return ye && Ye(e), !0;
                if (function(e, t) {
                        return !!(oe && e.hasChildNodes() && !rt(e.firstElementChild) && Hn(gr, e.textContent) && Hn(gr, e.innerHTML)) || !(!oe || e.namespaceURI !== Pe || "style" !== t || !rt(e.firstElementChild)) || 7 === e.nodeType || !(!oe || 8 !== e.nodeType || !Hn(br, e.data))
                    }(e, r)) return Ve(e), !0;
                if (Y[r] || !(J.tagCheck instanceof Function && J.tagCheck(r)) && !Q[r]) {
                    const n = function(e, t, n) {
                        if (!Y[t] && ut(t)) {
                            if (Z.tagNameCheck instanceof RegExp && Hn(Z.tagNameCheck, t)) return !1;
                            if (Z.tagNameCheck instanceof Function && Z.tagNameCheck(t)) return !1
                        }
                        if (me && !be[t]) {
                            const t = m(e),
                                r = v(e);
                            if (r && t)
                                for (let o = r.length - 1; o >= 0; --o) {
                                    const i = e === n ? f(r[o], !0) : r[o];
                                    t.insertBefore(i, h(e))
                                }
                        }
                        return Ve(e), !0
                    }(e, r, t);
                    return !1 === n && ot(N.afterSanitizeElements, e, null), n
                }
                if (1 === (b ? b(e) : e.nodeType) && ! function(e) {
                        let t = m(e);
                        t && t.tagName || (t = {
                            namespaceURI: Ie,
                            tagName: "template"
                        });
                        const n = Cn(e.tagName),
                            r = Cn(t.tagName);
                        return !!Ee[e.namespaceURI] && (e.namespaceURI === qe ? function(e, t, n) {
                            return t.namespaceURI === Pe ? "svg" === e : t.namespaceURI === _e ? "svg" === e && ("annotation-xml" === n || Ae[n]) : Boolean(Ue[e])
                        }(n, t, r) : e.namespaceURI === _e ? function(e, t, n) {
                            return t.namespaceURI === Pe ? "math" === e : t.namespaceURI === qe ? "math" === e && Ne[n] : Boolean(Qe[e])
                        }(n, t, r) : e.namespaceURI === Pe ? function(e, t, n) {
                            return !(t.namespaceURI === qe && !Ne[n]) && !(t.namespaceURI === _e && !Ae[n]) && !Qe[e] && (je[e] || !Ue[e])
                        }(n, t, r) : !("application/xhtml+xml" !== Oe || !Ee[e.namespaceURI]))
                    }(e)) return Ve(e), !0;
                if (("noscript" === r || "noembed" === r || "noframes" === r) && Hn(wr, e.innerHTML)) return Ve(e), !0;
                if (re && 3 === e.nodeType) {
                    const t = Xe(e.textContent);
                    e.textContent !== t && (In(n.removed, {
                        element: e.cloneNode()
                    }), e.textContent = t)
                }
                return ot(N.afterSanitizeElements, e, null), !1
            },
            at = function(e, t, n) {
                if (K[t]) return !1;
                if (oe && "patchsrc" === t) return !1;
                if (oe && "for" === t && "label" !== e && "output" !== e) return !1;
                if (pe && ("id" === t || "name" === t) && (n in r || n in Fe)) return !1;
                const o = W[t] || J.attributeCheck instanceof Function && J.attributeCheck(t, e);
                if (ee && Hn(L, t));
                else if (X && Hn(R, t));
                else if (o) {
                    if (Se[t]);
                    else if (Hn(U, Dn(n, B, "")));
                    else if ("src" !== t && "xlink:href" !== t && "href" !== t || "script" === e || 0 !== Nn(n, "data:") || !xe[e])
                        if (te && !Hn(F, Dn(n, B, "")));
                        else if (n) return !1
                } else if (!(ut(e) && (Z.tagNameCheck instanceof RegExp && Hn(Z.tagNameCheck, e) || Z.tagNameCheck instanceof Function && Z.tagNameCheck(e)) && (Z.attributeNameCheck instanceof RegExp && Hn(Z.attributeNameCheck, t) || Z.attributeNameCheck instanceof Function && Z.attributeNameCheck(t, e)) || "is" === t && Z.allowCustomizedBuiltInElements && (Z.tagNameCheck instanceof RegExp && Hn(Z.tagNameCheck, n) || Z.tagNameCheck instanceof Function && Z.tagNameCheck(n)))) return !1;
                return !0
            },
            lt = Wn({}, ["annotation-xml", "color-profile", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "missing-glyph"]),
            ut = function(e) {
                return !lt[Cn(e)] && Hn(H, e)
            },
            ct = function(e, t, n, r) {
                if (k && "object" == typeof c && "function" == typeof c.getAttributeType && !n) switch (c.getAttributeType(e, t)) {
                    case "TrustedHTML":
                        return I(r);
                    case "TrustedScriptURL":
                        return function(e) {
                            P(), q++;
                            try {
                                return k.createScriptURL(e)
                            } finally {
                                q--
                            }
                        }(r)
                }
                return r
            },
            dt = function(e, t, r, o) {
                try {
                    r ? e.setAttributeNS(r, t, o) : e.setAttribute(t, o), tt(e) ? Ve(e) : Pn(n.removed)
                } catch (n) {
                    Ge(t, e)
                }
            },
            ft = function(e) {
                ot(N.beforeSanitizeAttributes, e, null);
                const t = e.attributes;
                if (!t || tt(e)) return;
                W = it(N.uponSanitizeAttribute, W, G, le);
                const n = {
                    attrName: "",
                    attrValue: "",
                    keepAttr: !0,
                    allowedAttributes: W,
                    forceKeepAttr: void 0
                };
                let r = t.length;
                const o = Le(e.nodeName);
                for (; r--;) {
                    const i = t[r],
                        s = i.name,
                        a = i.namespaceURI,
                        l = i.value,
                        u = Le(s),
                        c = l;
                    let d = "value" === s ? c : jn(c);
                    n.attrName = u, n.attrValue = d, n.keepAttr = !0, n.forceKeepAttr = void 0, ot(N.uponSanitizeAttribute, e, n), d = n.attrValue, !he || "id" !== u && "name" !== u || 0 === Nn(d, ve) || (Ge(s, e), d = ve + d), oe && Hn(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, d) || "attributename" === u && An(d, "href") ? Ge(s, e) : n.forceKeepAttr || (!n.keepAttr || !ne && Hn(xr, d) ? Ge(s, e) : (re && (d = Xe(d)), at(o, u, d) ? (d = ct(o, u, a, d), d !== c && dt(e, s, a, d)) : Ge(s, e)))
                }
                ot(N.afterSanitizeAttributes, e, null)
            },
            pt = function(e) {
                let t = null;
                const n = Je(e);
                for (ot(N.beforeSanitizeShadowDOM, e, null); t = n.nextNode();)
                    if (ot(N.uponSanitizeShadowNode, t, null), st(t, e), ft(t), nt(t.content) && pt(t.content), 1 === (b ? b(t) : t.nodeType)) {
                        const e = y(t);
                        nt(e) && (ht(e), pt(e))
                    }
                ot(N.afterSanitizeShadowDOM, e, null)
            },
            ht = function(e) {
                const t = [{
                    node: e,
                    shadow: null
                }];
                for (; t.length > 0;) {
                    const e = t.pop();
                    if (e.shadow) {
                        pt(e.shadow);
                        continue
                    }
                    const n = e.node,
                        r = 1 === (b ? b(n) : n.nodeType),
                        o = v(n);
                    if (o)
                        for (let e = o.length - 1; e >= 0; --e) t.push({
                            node: o[e],
                            shadow: null
                        });
                    if (r) {
                        const e = w ? w(n) : null;
                        if ("string" == typeof e && "template" === Le(e)) {
                            const e = n.content;
                            nt(e) && t.push({
                                node: e,
                                shadow: null
                            })
                        }
                    }
                    if (r) {
                        const e = y(n);
                        nt(e) && t.push({
                            node: null,
                            shadow: e
                        }, {
                            node: e,
                            shadow: null
                        })
                    }
                }
            };
        return n.sanitize = function(e) {
            let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                r = null,
                i = null,
                s = null,
                a = null;
            if ($e = !e, $e && (e = "\x3c!--\x3e"), "string" != typeof e && !rt(e) && "string" != typeof(e = function(e) {
                    switch (typeof e) {
                        case "string":
                            return e;
                        case "number":
                            return On(e);
                        case "boolean":
                            return zn(e);
                        case "bigint":
                            return Ln ? Ln(e) : "0";
                        case "symbol":
                            return Rn ? Rn(e) : "Symbol()";
                        case "undefined":
                        default:
                            return Bn(e);
                        case "function":
                        case "object":
                            {
                                if (null === e) return Bn(e);
                                const t = e,
                                    n = Yn(t, "toString");
                                if ("function" == typeof n) {
                                    const e = n(t);
                                    return "string" == typeof e ? e : Bn(e)
                                }
                                return Bn(e)
                            }
                    }
                }(e))) throw Un("dirty is not a string, aborting");
            if (!n.isSupported) return e;
            se ? (Q = ae, W = le) : He(t), (N.uponSanitizeElement.length > 0 || N.uponSanitizeAttribute.length > 0) && (Q = Zn(Q)), N.uponSanitizeAttribute.length > 0 && (W = Zn(W)), n.removed = [];
            const l = ye && "string" != typeof e && rt(e);
            if (l) {
                ! function(e) {
                    if (!oe) return;
                    const t = [e];
                    for (; t.length > 0;) {
                        const e = t.pop(),
                            n = b ? b(e) : e.nodeType;
                        if (7 === n || 8 === n && Hn(br, e.data)) {
                            try {
                                p(e)
                            } catch (e) {}
                            continue
                        }
                        if (1 === n) {
                            const t = e,
                                n = Le(w ? w(e) : e.nodeName);
                            try {
                                t.hasAttribute && t.hasAttribute("patchsrc") && t.removeAttribute("patchsrc"), t.hasAttribute && t.hasAttribute("for") && "label" !== n && "output" !== n && t.removeAttribute("for")
                            } catch (e) {}
                        }
                        const r = v(e);
                        if (r)
                            for (let e = r.length - 1; e >= 0; --e) t.push(r[e])
                    }
                }(e);
                const t = w ? w(e) : e.nodeName;
                if ("string" == typeof t) {
                    const n = Le(t);
                    if (!Q[n] || Y[n]) throw We(e), Un("root node is forbidden and cannot be sanitized in-place")
                }
                if (tt(e)) throw We(e), Un("root node is clobbered and cannot be sanitized in-place");
                try {
                    ht(e)
                } catch (t) {
                    throw We(e), t
                }
            } else if (rt(e)) r = Ke("\x3c!----\x3e"), i = r.ownerDocument.importNode(e, !0), 1 === i.nodeType && "BODY" === i.nodeName || "HTML" === i.nodeName ? r = i : r.appendChild(i), ht(i);
            else {
                if (!ce && !re && !ie && -1 === e.indexOf("<")) return k && fe ? I(e) : e;
                if (r = Ke(e), !r) return ce ? null : fe ? T : ""
            }
            r && ue && Ve(r.firstChild);
            const u = l ? e : r;
            try {
                const e = Je(u);
                for (; s = e.nextNode();) st(s, u), ft(s), nt(s.content) && pt(s.content)
            } catch (t) {
                throw l && (We(e), _n(n.removed, e => {
                    e.element && Ye(e.element)
                })), t
            }
            if (l) return _n(n.removed, e => {
                e.element && Ye(e.element)
            }), re && et(e), e;
            if (ce) {
                if (re && et(r), de)
                    for (a = M.call(r.ownerDocument); r.firstChild;) a.appendChild(r.firstChild);
                else a = r;
                return (W.shadowroot || W.shadowrootmode) && (a = D.call(o, a, !0)), a
            }
            let c = ie ? r.outerHTML : r.innerHTML;
            return ie && Q["!doctype"] && r.ownerDocument && r.ownerDocument.doctype && r.ownerDocument.doctype.name && Hn(mr, r.ownerDocument.doctype.name) && (c = "<!DOCTYPE " + r.ownerDocument.doctype.name + ">\n" + c), re && (c = Xe(c)), k && fe ? I(c) : c
        }, n.setConfig = function() {
            He(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}), se = !0, ae = Q, le = W
        }, n.clearConfig = function() {
            Re = null, se = !1, ae = null, le = null, k = S, T = ""
        }, n.isValidAttribute = function(e, t, n) {
            Re || He({});
            const r = Le(e),
                o = Le(t);
            return at(r, o, n)
        }, n.addHook = function(e, t) {
            "function" == typeof t && Fn(N, e) && In(N[e], t)
        }, n.removeHook = function(e, t) {
            if (Fn(N, e)) {
                if (void 0 !== t) {
                    const n = qn(N[e], t);
                    return -1 === n ? void 0 : $n(N[e], n, 1)[0]
                }
                return Pn(N[e])
            }
        }, n.removeHooks = function(e) {
            Fn(N, e) && (N[e] = [])
        }, n.removeAllHooks = function() {
            N = {
                afterSanitizeAttributes: [],
                afterSanitizeElements: [],
                afterSanitizeShadowDOM: [],
                beforeSanitizeAttributes: [],
                beforeSanitizeElements: [],
                beforeSanitizeShadowDOM: [],
                uponSanitizeAttribute: [],
                uponSanitizeElement: [],
                uponSanitizeShadowNode: []
            }
        }, n
    }();
    const _r = ["a", "abbr", "acronym", "area", "article", "aside", "b", "bdi", "bdo", "blockquote", "br", "caption", "center", "cite", "code", "col", "colgroup", "data", "dd", "del", "details", "dfn", "div", "dl", "dt", "em", "figcaption", "figure", "footer", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "hr", "i", "img", "ins", "kbd", "li", "map", "mark", "nav", "ol", "p", "pre", "q", "rp", "rt", "rtc", "ruby", "s", "samp", "small", "span", "strike", "strong", "sub", "summary", "sup", "table", "tbody", "td", "th", "thead", "time", "tr", "tt", "u", "ul", "var", "wbr"],
        qr = ["style", "lang", "title", "width", "height"],
        Pr = ["abbr", "align", "axis", "bgcolor", "char", "charoff", "colspan", "headers", "height", "nowrap", "rowspan", "scope", "valign", "width"],
        Ir = {
            a: ["href", "hreflang", "target", "rel"],
            bdo: ["dir"],
            blockquote: ["cite"],
            col: ["align", "char", "charoff", "span"],
            colgroup: ["align", "char", "charoff", "span"],
            del: ["cite", "datetime"],
            hr: ["align", "size", "width"],
            img: ["align", "alt", "height", "src", "width"],
            ins: ["cite", "datetime"],
            ol: ["start", "type"],
            q: ["cite"],
            table: ["align", "bgcolor", "border", "cellpadding", "cellspacing", "frame", "rules", "summary", "width"],
            tbody: ["align", "char", "charoff", "valign"],
            td: Pr,
            tfoot: ["align", "char", "charoff", "valign"],
            th: Pr,
            thead: ["align", "char", "charoff", "valign"],
            tr: ["align", "bgcolor", "char", "charoff", "valign"]
        };
    let $r;

    function Er(e) {
        var t;
        const n = (null !== (t = $r) && void 0 !== t ? t : $r = Tr()).sanitize(e, {
                ALLOWED_TAGS: _r,
                ALLOWED_ATTR: [],
                ALLOW_ARIA_ATTR: !1,
                ALLOW_DATA_ATTR: !1,
                ALLOWED_NAMESPACES: ["http://www.w3.org/1999/xhtml"],
                ADD_ATTR: (e, t) => -1 !== qr.indexOf(e) || {}.hasOwnProperty.call(Ir, t) && -1 !== (Ir[t] || []).indexOf(e),
                RETURN_DOM_FRAGMENT: !0
            }),
            r = n.querySelectorAll("a");
        for (let e = 0; r.length > e; e++) r.item(e).relList.add("noopener");
        const o = document.createElement("div");
        return o.appendChild(n), o.innerHTML
    }
    const Cr = Ut("[Stylesheet Loader]"),
        Mr = "#020617",
        Ar = {
            fontFamily: "inherit",
            backgroundColor: "#eeeded",
            submitButtonColor: "black",
            submitButtonTextColor: "white",
            ratingButtonColor: "white",
            ratingButtonActiveColor: "black",
            borderColor: "#c9c6c6",
            whiteLabel: !1,
            displayThankYouMessage: !0,
            thankYouMessageHeader: "Thank you for your feedback!",
            position: xt,
            widgetType: gt,
            widgetLabel: "Feedback",
            widgetColor: "black",
            zIndex: String(2147483645),
            disabledButtonOpacity: "0.6",
            maxWidth: "300px",
            textSubtleColor: "#939393",
            boxPadding: "20px 24px",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
            borderRadius: "10px",
            shuffleQuestions: !1,
            outlineColor: "rgba(59, 130, 246, 0.8)",
            inputBackground: "white",
            inputTextColor: Mr,
            scrollbarThumbColor: "var(--ph-survey-border-color)",
            scrollbarTrackColor: "var(--ph-survey-background-color)"
        },
        Dr = [wt, bt, xt];

    function Nr(e) {
        if (e.startsWith("#")) {
            let t = e.replace(/^#/, "");
            return /^[0-9A-Fa-f]{3}$/.test(t) && (t = t[0] + t[0] + t[1] + t[1] + t[2] + t[2]), /^[0-9A-Fa-f]{6}$/.test(t) ? `rgb(${parseInt(t.slice(0,2),16)},${parseInt(t.slice(2,4),16)},${parseInt(t.slice(4,6),16)})` : "rgb(255, 255, 255)"
        }
        return "rgb(255, 255, 255)"
    }

    function jr(e = Ar.backgroundColor) {
        let t;
        "#" === e[0] && (t = Nr(e)), e.startsWith("rgb") && (t = e);
        const n = {
            aliceblue: "#f0f8ff",
            antiquewhite: "#faebd7",
            aqua: "#00ffff",
            aquamarine: "#7fffd4",
            azure: "#f0ffff",
            beige: "#f5f5dc",
            bisque: "#ffe4c4",
            black: "#000000",
            blanchedalmond: "#ffebcd",
            blue: "#0000ff",
            blueviolet: "#8a2be2",
            brown: "#a52a2a",
            burlywood: "#deb887",
            cadetblue: "#5f9ea0",
            chartreuse: "#7fff00",
            chocolate: "#d2691e",
            coral: "#ff7f50",
            cornflowerblue: "#6495ed",
            cornsilk: "#fff8dc",
            crimson: "#dc143c",
            cyan: "#00ffff",
            darkblue: "#00008b",
            darkcyan: "#008b8b",
            darkgoldenrod: "#b8860b",
            darkgray: "#a9a9a9",
            darkgreen: "#006400",
            darkkhaki: "#bdb76b",
            darkmagenta: "#8b008b",
            darkolivegreen: "#556b2f",
            darkorange: "#ff8c00",
            darkorchid: "#9932cc",
            darkred: "#8b0000",
            darksalmon: "#e9967a",
            darkseagreen: "#8fbc8f",
            darkslateblue: "#483d8b",
            darkslategray: "#2f4f4f",
            darkturquoise: "#00ced1",
            darkviolet: "#9400d3",
            deeppink: "#ff1493",
            deepskyblue: "#00bfff",
            dimgray: "#696969",
            dodgerblue: "#1e90ff",
            firebrick: "#b22222",
            floralwhite: "#fffaf0",
            forestgreen: "#228b22",
            fuchsia: "#ff00ff",
            gainsboro: "#dcdcdc",
            ghostwhite: "#f8f8ff",
            gold: "#ffd700",
            goldenrod: "#daa520",
            gray: "#808080",
            green: "#008000",
            greenyellow: "#adff2f",
            honeydew: "#f0fff0",
            hotpink: "#ff69b4",
            "indianred ": "#cd5c5c",
            indigo: "#4b0082",
            ivory: "#fffff0",
            khaki: "#f0e68c",
            lavender: "#e6e6fa",
            lavenderblush: "#fff0f5",
            lawngreen: "#7cfc00",
            lemonchiffon: "#fffacd",
            lightblue: "#add8e6",
            lightcoral: "#f08080",
            lightcyan: "#e0ffff",
            lightgoldenrodyellow: "#fafad2",
            lightgrey: "#d3d3d3",
            lightgreen: "#90ee90",
            lightpink: "#ffb6c1",
            lightsalmon: "#ffa07a",
            lightseagreen: "#20b2aa",
            lightskyblue: "#87cefa",
            lightslategray: "#778899",
            lightsteelblue: "#b0c4de",
            lightyellow: "#ffffe0",
            lime: "#00ff00",
            limegreen: "#32cd32",
            linen: "#faf0e6",
            magenta: "#ff00ff",
            maroon: "#800000",
            mediumaquamarine: "#66cdaa",
            mediumblue: "#0000cd",
            mediumorchid: "#ba55d3",
            mediumpurple: "#9370d8",
            mediumseagreen: "#3cb371",
            mediumslateblue: "#7b68ee",
            mediumspringgreen: "#00fa9a",
            mediumturquoise: "#48d1cc",
            mediumvioletred: "#c71585",
            midnightblue: "#191970",
            mintcream: "#f5fffa",
            mistyrose: "#ffe4e1",
            moccasin: "#ffe4b5",
            navajowhite: "#ffdead",
            navy: "#000080",
            oldlace: "#fdf5e6",
            olive: "#808000",
            olivedrab: "#6b8e23",
            orange: "#ffa500",
            orangered: "#ff4500",
            orchid: "#da70d6",
            palegoldenrod: "#eee8aa",
            palegreen: "#98fb98",
            paleturquoise: "#afeeee",
            palevioletred: "#d87093",
            papayawhip: "#ffefd5",
            peachpuff: "#ffdab9",
            peru: "#cd853f",
            pink: "#ffc0cb",
            plum: "#dda0dd",
            powderblue: "#b0e0e6",
            purple: "#800080",
            red: "#ff0000",
            rosybrown: "#bc8f8f",
            royalblue: "#4169e1",
            saddlebrown: "#8b4513",
            salmon: "#fa8072",
            sandybrown: "#f4a460",
            seagreen: "#2e8b57",
            seashell: "#fff5ee",
            sienna: "#a0522d",
            silver: "#c0c0c0",
            skyblue: "#87ceeb",
            slateblue: "#6a5acd",
            slategray: "#708090",
            snow: "#fffafa",
            springgreen: "#00ff7f",
            steelblue: "#4682b4",
            tan: "#d2b48c",
            teal: "#008080",
            thistle: "#d8bfd8",
            tomato: "#ff6347",
            turquoise: "#40e0d0",
            violet: "#ee82ee",
            wheat: "#f5deb3",
            white: "#ffffff",
            whitesmoke: "#f5f5f5",
            yellow: "#ffff00",
            yellowgreen: "#9acd32"
        }[e.toLowerCase()];
        if (n && (t = Nr(n)), !t) return Mr;
        const r = t.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+(?:\.\d+)?))?\)$/);
        if (r) {
            const e = parseInt(r[1]),
                t = parseInt(r[2]),
                n = parseInt(r[3]);
            return Math.sqrt(e * e * .299 + t * t * .587 + n * n * .114) > 127.5 ? Mr : "white"
        }
        return Mr
    }
    const Or = (e, t, n) => {
            const r = ro(e),
                o = document.querySelector(`.${r}`);
            if (o && o.shadowRoot) return {
                shadow: o.shadowRoot,
                isNewlyCreated: !1
            };
            const i = document.createElement("div");
            ((e, t, n) => {
                const r = Me(Me({}, Ar), n),
                    o = e.style,
                    i = !Dr.includes(r.position) || t === Tt && (null == n ? void 0 : n.widgetType) === gt;
                o.setProperty("--ph-survey-font-family", function(e) {
                    if ("inherit" === e) return "inherit";
                    const t = 'BlinkMacSystemFont, "Inter", "Segoe UI", "Roboto", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"';
                    return e ? `${e}, ${t}` : `-apple-system, ${t}`
                }(r.fontFamily)), o.setProperty("--ph-survey-box-padding", r.boxPadding), o.setProperty("--ph-survey-max-width", r.maxWidth), o.setProperty("--ph-survey-z-index", r.zIndex), o.setProperty("--ph-survey-border-color", r.borderColor), i ? (o.setProperty("--ph-survey-border-radius", r.borderRadius), o.setProperty("--ph-survey-border-bottom", "1.5px solid var(--ph-survey-border-color)")) : (o.setProperty("--ph-survey-border-bottom", "none"), o.setProperty("--ph-survey-border-radius", `${r.borderRadius} ${r.borderRadius} 0 0`)), o.setProperty("--ph-survey-background-color", r.backgroundColor), o.setProperty("--ph-survey-box-shadow", r.boxShadow), o.setProperty("--ph-survey-disabled-button-opacity", r.disabledButtonOpacity), o.setProperty("--ph-survey-submit-button-color", r.submitButtonColor), o.setProperty("--ph-survey-submit-button-text-color", (null == n ? void 0 : n.submitButtonTextColor) || jr(r.submitButtonColor)), o.setProperty("--ph-survey-rating-bg-color", r.ratingButtonColor), o.setProperty("--ph-survey-rating-active-bg-color", r.ratingButtonActiveColor), o.setProperty("--ph-survey-rating-active-text-color", jr(r.ratingButtonActiveColor)), o.setProperty("--ph-survey-text-primary-color", (null == n ? void 0 : n.textColor) || jr(r.backgroundColor)), o.setProperty("--ph-survey-text-subtle-color", r.textSubtleColor), o.setProperty("--ph-widget-color", r.widgetColor), o.setProperty("--ph-widget-text-color", jr(r.widgetColor)), o.setProperty("--ph-widget-z-index", r.zIndex);
                const s = (null == n ? void 0 : n.inputBackground) || (null == n ? void 0 : n.inputBackgroundColor);
                let a = s || r.inputBackground;
                s || "white" !== r.backgroundColor || (a = "#f8f8f8"), o.setProperty("--ph-survey-input-background", a);
                const l = (null == n ? void 0 : n.inputTextColor) || jr(a);
                o.setProperty("--ph-survey-input-text-color", l), o.setProperty("--ph-survey-rating-text-color", l), o.setProperty("--ph-survey-scrollbar-thumb-color", r.scrollbarThumbColor), o.setProperty("--ph-survey-scrollbar-track-color", r.scrollbarTrackColor), o.setProperty("--ph-survey-outline-color", r.outlineColor)
            })(i, e.type, e.appearance), i.className = r;
            const s = i.attachShadow({
                    mode: "open"
                }),
                a = function(e) {
                    const t = ((e, t, n) => {
                        let r = e.createElement("style");
                        r.innerText = t;
                        const o = (e => {
                            var t;
                            return ie(e) ? e : null == e || null === (t = e.config) || void 0 === t ? void 0 : t.prepare_external_dependency_stylesheet
                        })(n);
                        return o && (r = o(r)), r || (Cr.error("prepare_external_dependency_stylesheet returned null"), null)
                    })(document, ':host{--ph-survey-font-family:-apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", "Roboto", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";--ph-survey-box-padding:20px 24px;--ph-survey-max-width:300px;--ph-survey-z-index:calc(2147480000 + 3645);--ph-survey-border-color:#dcdcdc;--ph-survey-border-bottom:1.5px solid var(--ph-survey-border-color);--ph-survey-border-radius:10px;--ph-survey-background-color:#eeeded;--ph-survey-box-shadow:0 4px 12px #00000026;--ph-survey-submit-button-color:black;--ph-survey-submit-button-text-color:white;--ph-survey-rating-bg-color:white;--ph-survey-rating-text-color:#020617;--ph-survey-rating-active-bg-color:black;--ph-survey-rating-active-text-color:white;--ph-survey-text-primary-color:#020617;--ph-survey-text-subtle-color:#939393;--ph-widget-color:#e0a045;--ph-widget-text-color:white;--ph-survey-scrollbar-thumb-color:var(--ph-survey-border-color);--ph-survey-scrollbar-track-color:var(--ph-survey-background-color);--ph-survey-outline-color:#3b82f6cc;--ph-survey-input-background:white;--ph-survey-input-text-color:#020617;--ph-survey-disabled-button-opacity:.6}.ph-survey{min-width:300px;width:var(--ph-survey-max-width);max-width:85%;z-index:var(--ph-survey-z-index);height:fit-content;margin:0;position:fixed;bottom:0}.ph-survey h3,.ph-survey p{margin:0}.ph-survey *{box-sizing:border-box;font-family:var(--ph-survey-font-family);color:var(--ph-survey-text-primary-color)}.ph-survey textarea,.ph-survey input[type=text],.ph-survey .multiple-choice-options label{color:var(--ph-survey-input-text-color);background:var(--ph-survey-input-background);border:1.5px solid var(--ph-survey-border-color);border-radius:4px;padding:10px;transition:border-color .2s ease-out,box-shadow .2s ease-out,transform .15s ease-out}.ph-survey textarea,.ph-survey input[type=text]{transition:border-color .2s ease-out,box-shadow .2s ease-out,transform .15s ease-out}.ph-survey input{margin:0}.ph-survey textarea:focus,.ph-survey textarea:focus-visible,.ph-survey input[type=text]:focus,.ph-survey input[type=text]:focus-visible,.ph-survey .form-submit:focus,.ph-survey .form-submit:focus-visible,.ph-survey input[type=checkbox]:focus,.ph-survey input[type=radio]:focus,.ph-survey input[type=checkbox]:focus-visible,.ph-survey input[type=radio]:focus-visible{outline:1.5px solid var(--ph-survey-outline-color);border-color:var(--ph-survey-rating-active-bg-color);outline-offset:2px}.ph-survey textarea:focus:not(:focus-visible),.ph-survey input[type=text]:focus:not(:focus-visible),.ph-survey button:focus:not(:focus-visible),.ph-survey input[type=checkbox]:focus:not(:focus-visible),.ph-survey input[type=radio]:focus:not(:focus-visible){outline:none}.ph-survey textarea:hover:not(:focus),.ph-survey input[type=text]:hover:not(:focus){border-color:var(--ph-survey-rating-active-bg-color)}@media (max-width:768px){.ph-survey textarea,.ph-survey input[type=text]{font-size:1rem}}.ph-survey .multiple-choice-options label,.ph-survey .rating-options-number,.ph-survey .form-cancel,.ph-survey input[type=checkbox],.ph-survey input[type=radio]{border:1.5px solid var(--ph-survey-border-color)}.ph-survey label,.ph-survey input[type=checkbox],.ph-survey input[type=radio],.ph-survey .ratings-emoji,.ph-survey .ratings-number,.ph-survey .footer-branding,.ph-survey .form-cancel,.ph-survey .form-submit{transition:all .2s ease-out}@media (prefers-reduced-motion:no-preference){.ph-survey button:active,.ph-survey input[type=checkbox]:active,.ph-survey input[type=radio]:active,.ph-survey label:active{transition-duration:.1s}}.ph-survey-widget-tab{background:var(--ph-widget-color);color:var(--ph-widget-text-color);text-align:center;cursor:pointer;z-index:var(--ph-survey-z-index);border:none;border-radius:3px 3px 0 0;padding:10px 12px;transition:padding .2s ease-out;position:fixed}.ph-survey-widget-tab:hover:not(.widget-tab-top){padding-bottom:16px}.ph-survey-widget-tab.widget-tab-top{border-radius:0 0 3px 3px}.ph-survey-widget-tab.widget-tab-top:hover{padding-top:16px}@keyframes ph-survey-fade-in{0%{opacity:0}to{opacity:1}}.survey-box{flex-direction:column;gap:16px;display:flex}.bottom-section{flex-direction:column;gap:8px;display:flex}.thank-you-message-header~.bottom-section,.intro-screen-header~.bottom-section{padding-top:16px}.question-container,.thank-you-message,.intro-screen{flex-direction:column;gap:8px;display:flex}.survey-question{font-size:14px;font-weight:500}.survey-question-description{opacity:.8;padding-top:4px;font-size:13px}.survey-question-description,.thank-you-message-body,.intro-screen-body{word-wrap:break-word;overflow-wrap:break-word}:is(.survey-question-description,.thank-you-message-body,.intro-screen-body) img,:is(.survey-question-description,.thank-you-message-body,.intro-screen-body) video,:is(.survey-question-description,.thank-you-message-body,.intro-screen-body) iframe,:is(.survey-question-description,.thank-you-message-body,.intro-screen-body) embed,:is(.survey-question-description,.thank-you-message-body,.intro-screen-body) object,:is(.survey-question-description,.thank-you-message-body,.intro-screen-body) svg{max-width:100%;height:auto}.question-textarea-wrapper{flex-direction:column;display:flex}.survey-form{animation:.3s ease-out forwards ph-survey-fade-in}.survey-form,.thank-you-message,.intro-screen{text-align:left;width:100%;z-index:var(--ph-survey-z-index);border:1.5px solid var(--ph-survey-border-color);border-bottom:var(--ph-survey-border-bottom);background:var(--ph-survey-background-color);border-radius:var(--ph-survey-border-radius);box-shadow:var(--ph-survey-box-shadow);padding:var(--ph-survey-box-padding);margin:0;position:relative}.survey-form textarea,.survey-form input[type=text]{min-width:100%}.survey-form textarea:focus,.survey-form textarea:focus-visible{box-shadow:0 4px 12px #00000014}.survey-form textarea:focus:not(:focus-visible){box-shadow:none}.survey-box .question-header--empty~.multiple-choice-options,.survey-box .question-header--empty~textarea{margin-top:0}.multiple-choice-options{border:none;flex-direction:column;gap:8px;margin:0;padding:1px 0;font-size:14px;display:flex}.multiple-choice-options label,.multiple-choice-options .response-choice{color:inherit;align-items:center;gap:8px;display:flex}.multiple-choice-options label{cursor:pointer;font-size:13px}.multiple-choice-options label:hover:not(:has(input:checked)){border-color:var(--ph-survey-text-subtle-color);box-shadow:0 2px 8px #00000014}.multiple-choice-options label:has(input:checked){border-color:var(--ph-survey-rating-active-bg-color);box-shadow:0 1px 4px #0000000d}.multiple-choice-options label.choice-option-open{flex-wrap:wrap}.multiple-choice-options label span{color:inherit}.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]{-webkit-appearance:none;-moz-appearance:none;appearance:none;background:var(--ph-survey-input-background);cursor:pointer;z-index:1;border-radius:3px;flex-shrink:0;width:1rem;height:1rem;transition:all .2s cubic-bezier(.4,0,.2,1),transform .15s ease-out;position:relative}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):focus{transform:scale(1.05)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):hover{border-color:var(--ph-survey-rating-active-bg-color);transform:scale(1.05)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):active{transform:scale(.95)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):checked{background:var(--ph-survey-rating-active-bg-color);border-color:var(--ph-survey-rating-active-bg-color);transform:scale(1)}:is(.multiple-choice-options input[type=checkbox],.multiple-choice-options input[type=radio]):checked:hover{transform:scale(1.05)}.multiple-choice-options input[type=checkbox]:checked:after{border:solid var(--ph-survey-rating-active-text-color);border-width:0 2px 2px 0;width:4px;height:8px;animation:.2s ease-out .1s forwards ph-survey-checkmark-reveal;left:4px;transform:rotate(45deg)scale(0)}.multiple-choice-options input[type=radio]:checked:after{background:var(--ph-survey-rating-active-text-color);border-radius:50%;width:6px;height:6px;animation:.15s ease-out 50ms forwards ph-survey-radio-reveal;top:5px;left:5px;transform:scale(0)}.multiple-choice-options input[type=checkbox]:checked:after,.multiple-choice-options input[type=radio]:checked:after{content:"";box-sizing:content-box;position:absolute}.multiple-choice-options input[type=radio]{border-radius:50%}.multiple-choice-options input[type=radio]:checked{border:none}:is(.multiple-choice-options input[type=checkbox]:checked,.multiple-choice-options input[type=radio]:checked)~*{font-weight:700}.multiple-choice-options .choice-option-open input[type=text]::placeholder{color:var(--ph-survey-text-subtle-color);font-weight:400}.rating-options-emoji{justify-content:space-between;display:flex}.rating-options-emoji-2{justify-content:space-around}.ratings-emoji{opacity:.5;background-color:#0000;border:none;padding:0;font-size:16px}.ratings-emoji:hover{cursor:pointer;opacity:1;transform:scale(1.15)}.ratings-emoji.rating-active{opacity:1}.ratings-emoji svg{fill:var(--ph-survey-text-primary-color);transition:fill .2s ease-out}.rating-options-number{border-radius:6px;grid-auto-columns:1fr;grid-auto-flow:column;display:grid;overflow:hidden}.rating-options-number .ratings-number{border-right:1px solid var(--ph-survey-border-color);text-align:center;cursor:pointer;color:var(--ph-survey-rating-text-color);border-top:none;border-bottom:none;border-left:none;font-weight:700}.rating-options-number .ratings-number:last-of-type{border-right:0}.rating-options-number .ratings-number.rating-active{background:var(--ph-survey-rating-active-bg-color);color:var(--ph-survey-rating-active-text-color)}.ratings-number{background-color:var(--ph-survey-rating-bg-color);border:none;padding:8px 0}.ratings-number .rating-active{background-color:var(--ph-survey-rating-active-bg-color)}.ratings-number{cursor:pointer}@media (hover:hover) and (pointer:fine){.ratings-number:hover:not(.rating-active){background-color:color-mix(in srgb, var(--ph-survey-rating-active-bg-color) 14%, var(--ph-survey-rating-bg-color))}}.rating-text{opacity:.7;flex-direction:row;justify-content:space-between;font-size:11px;display:flex}.form-buttons{flex-direction:row;gap:8px;width:100%;display:flex}.form-buttons-with-back>.form-submit{flex:auto;min-width:0}.form-submit{text-align:center;cursor:pointer;user-select:none;background:var(--ph-survey-submit-button-color);color:var(--ph-survey-submit-button-text-color);border:none;border-radius:6px;min-width:100%;padding:12px;font-weight:700;box-shadow:0 2px #0000000b}.form-submit:not([disabled]):hover{transform:scale(1.02);box-shadow:0 4px 8px #0000001a}.form-submit:not([disabled]):active{transform:scale(.98);box-shadow:0 1px 2px #0000000d}.form-submit[disabled]{opacity:var(--ph-survey-disabled-button-opacity);cursor:not-allowed}.form-back{text-align:center;cursor:pointer;user-select:none;color:var(--ph-survey-text-primary-color);border:1.5px solid var(--ph-survey-border-color);background:0 0;border-radius:6px;flex:none;padding:12px 16px;font-weight:600}.form-back:hover{transform:scale(1.02)}.form-back:active{transform:scale(.98)}.validation-hint{opacity:.7;margin-top:4px;font-size:12px}.form-cancel{cursor:pointer;background:#fff;border-radius:100%;padding:12px;line-height:0;position:absolute;top:0;right:0;transform:translate(50%,-50%)}.form-cancel:hover{opacity:.7;transform:translate(50%,-50%)scale(1.1)}.footer-branding{opacity:.6;justify-content:center;align-items:center;gap:4px;font-size:11px;font-weight:500;text-decoration:none;display:flex}.footer-branding:hover{opacity:1}.footer-branding a{text-decoration:none}.thank-you-message{text-align:center}.thank-you-message-header{margin:10px 0 0}.thank-you-message-body{opacity:.8;font-size:14px}.intro-screen{text-align:center;animation:.3s ease-out forwards ph-survey-fade-in}.intro-screen-header{margin:10px 0 0}.intro-screen-body{opacity:.8;font-size:14px}.limit-height{scrollbar-width:thin;scrollbar-color:var(--ph-survey-scrollbar-thumb-color) var(--ph-survey-scrollbar-track-color);max-height:256px;overflow:hidden auto}.limit-height::-webkit-scrollbar{width:8px}.limit-height::-webkit-scrollbar-track{background:var(--ph-survey-scrollbar-track-color);border-radius:4px}.limit-height::-webkit-scrollbar-thumb{background-color:var(--ph-survey-scrollbar-thumb-color);border:2px solid var(--ph-survey-scrollbar-track-color);border-radius:4px}.limit-height::-webkit-scrollbar-thumb:hover{background-color:var(--ph-survey-text-subtle-color)}.sr-only{clip:rect(0, 0, 0, 0);white-space:nowrap;border:0;width:1px;height:1px;margin:-1px;padding:0;position:absolute;overflow:hidden}@media (prefers-reduced-motion:reduce){.ph-survey *{scroll-behavior:auto!important;transition-duration:.01ms!important;animation-duration:.01ms!important;animation-iteration-count:1!important}}@keyframes ph-survey-checkmark-reveal{0%{opacity:0;transform:rotate(45deg)scale(0)}50%{opacity:1;transform:rotate(45deg)scale(1.2)}to{opacity:1;transform:rotate(45deg)scale(1)}}@keyframes ph-survey-radio-reveal{0%{opacity:0;transform:scale(0)}50%{opacity:1;transform:scale(1.3)}to{opacity:1;transform:scale(1)}}', null == e ? void 0 : e.config.prepareStylesheet);
                    return null == t || t.setAttribute("data-ph-survey-style", "true"), t
                }(t);
            if (a) {
                const e = s.querySelector("style");
                e && s.removeChild(e), s.appendChild(a)
            }
            return (n || document.body).appendChild(i), {
                shadow: s,
                isNewlyCreated: !0
            }
        },
        zr = e => {
            try {
                const t = cn(e);
                localStorage.getItem(t) || localStorage.setItem(t, "true")
            } catch (e) {
                ln.error("Failed to persist survey seen state", e)
            }
        },
        Lr = ({
            responses: e,
            survey: t,
            surveySubmissionId: n,
            posthog: r,
            isSurveyCompleted: o,
            properties: i,
            surveyLanguage: s,
            questionSnapshots: a
        }) => {
            var l, u, c;
            r ? (null === (l = r.client) || void 0 === l ? void 0 : l.canCapture) && (zr(t), o && no(t), null === (u = r.client) || void 0 === u || u.capture(Dt, Me(Me(Me({
                [jt]: t.name,
                [Nt]: t.id,
                [Ot]: t.current_iteration,
                [zt]: t.current_iteration_start_date,
                sessionRecordingUrl: K(r)
            }, Gt(Me(Me({
                event: "sent",
                survey: t,
                responses: e,
                submissionId: n,
                completed: o
            }, !se(s) && {
                surveyLanguage: s
            }), !se(a) && {
                questionSnapshots: a
            }))), i), {}, {
                $set: {
                    [Yt(t, "responded")]: !0
                }
            })), o && (window.dispatchEvent(new CustomEvent("PHSurveySent", {
                detail: {
                    surveyId: t.id
                }
            })), null === (c = r.client) || void 0 === c || null === (c = c.getExtension("featureFlagsCommon")) || void 0 === c || c.reloadFeatureFlags())) : ln.error("[survey sent] event not captured, PostHog instance not found.")
        },
        Rr = (e, t, n, r) => Me({
            [jt]: t.name,
            [Nt]: t.id,
            [Ot]: t.current_iteration,
            [zt]: t.current_iteration_start_date,
            sessionRecordingUrl: K(r)
        }, Gt(Me(Me(Me(Me({
            event: e,
            survey: t
        }, !se(null == n ? void 0 : n.responses) && {
            responses: n.responses
        }), !se(null == n ? void 0 : n.surveySubmissionId) && {
            submissionId: n.surveySubmissionId
        }), !se(null == n ? void 0 : n.surveyLanguage) && {
            surveyLanguage: n.surveyLanguage
        }), !se(null == n ? void 0 : n.questionSnapshots) && {
            questionSnapshots: n.questionSnapshots
        }))),
        Fr = (e, t, n, r) => {
            var o;
            if (!t) return void ln.error("[survey dismissed] event not captured, PostHog instance not found.");
            if (n) return;
            const i = eo(e),
                s = i ? i.surveyLanguage : r,
                a = Me(Me(Me({}, Rr("dismissed", e, i, t)), s && {
                    [Lt]: s
                }), {}, {
                    $set: {
                        [Yt(e, "dismissed")]: !0
                    }
                });
            no(e), zr(e), null === (o = t.client) || void 0 === o || o.capture(At, a), window.dispatchEvent(new CustomEvent("PHSurveyClosed", {
                detail: {
                    surveyId: e.id
                }
            }))
        },
        Br = (e, t) => {
            var n, r;
            if (!t) return void ln.error("[survey abandoned] event not captured, PostHog instance not found.");
            if (!(null === (n = t.client) || void 0 === n ? void 0 : n.canCapture)) return;
            const o = (e => un("abandonedSurvey_", e))(e);
            try {
                if ("true" === localStorage.getItem(o)) return
            } catch (e) {
                return
            }
            const i = eo(e);
            if (i) {
                try {
                    localStorage.setItem(o, "true")
                } catch (e) {}
                null === (r = t.client) || void 0 === r || r.capture("survey abandoned", Rr("abandoned", e, i, t), {
                    delivery: "unload"
                })
            }
        },
        Hr = e => {
            const t = e.map(e => e.id);
            return t.every(e => !!e) ? t : void 0
        },
        Ur = (e, t) => {
            var n, r, o;
            return (e => e.questions.some(e => {
                var t;
                return !!(null === (t = e.branching) || void 0 === t ? void 0 : t.type)
            }))(e) ? e.questions : t ? null !== (n = ((e, t) => {
                if (!t || t.length !== e.questions.length) return null;
                const n = new Map(e.questions.map(e => [e.id, e])),
                    r = [];
                for (const e of t) {
                    const t = n.get(e);
                    if (!t) return null;
                    r.push(t)
                }
                return r
            })(e, t.questionOrder)) && void 0 !== n ? n : e.questions : e.appearance && e.appearance.shuffleQuestions && !e.enable_partial_responses ? (r = e.questions, o = an(e.questions), r.length === o.length && r.every((e, t) => e === o[t]) ? o.reverse() : o) : e.questions
        },
        Qr = e => function(e) {
            var t;
            return nn(e) && !!(null === (t = e.conditions) || void 0 === t || null === (t = t.events) || void 0 === t ? void 0 : t.repeatedActivation) || "always" === e.schedule
        }(e) || to(e),
        Vr = function(e) {
            function t(e) {
                var n, r;
                return this.getChildContext || (n = new Set, (r = {})[t.__c] = this, this.getChildContext = function() {
                    return r
                }, this.componentWillUnmount = function() {
                    n = null
                }, this.shouldComponentUpdate = function(e) {
                    this.props.value != e.value && n.forEach(function(e) {
                        e.__e = !0, I(e)
                    })
                }, this.sub = function(e) {
                    n.add(e);
                    var t = e.componentWillUnmount;
                    e.componentWillUnmount = function() {
                        n && n.delete(e), t && t.call(e)
                    }
                }), e.children
            }
            return t.__c = "__cC" + v++, t.__ = e, t.Provider = t.__l = (t.Consumer = function(e, t) {
                return e.children(t)
            }).contextType = t, t
        }({
            isPreviewMode: !1,
            previewPageIndex: 0,
            onPopupSurveyDismissed() {},
            isPopup: !0,
            onPreviewSubmit() {},
            onPreviewBack() {},
            surveySubmissionId: "",
            properties: void 0,
            surveyLanguage: null
        }),
        Wr = () => ct(Vr),
        Gr = ({
            component: e,
            children: n,
            renderAsHtml: r,
            style: o
        }) => function(e, n, r) {
            var o, i, s, a, l = w({}, e.props);
            for (s in e.type && e.type.defaultProps && (a = e.type.defaultProps), n) "key" == s ? o = n[s] : "ref" == s ? i = n[s] : l[s] = void 0 === n[s] && null != a ? a[s] : n[s];
            return arguments.length > 2 && (l.children = arguments.length > 3 ? t.call(arguments, 2) : r), S(e.type, l, o || e.key, i || e.ref, null)
        }(e, r ? {
            dangerouslySetInnerHTML: {
                __html: Er(n)
            },
            style: o
        } : {
            children: n,
            style: o
        });

    function Zr(e, t) {
        var n, r, o;
        if (!(null === (n = e.conditions) || void 0 === n ? void 0 : n.url)) return !0;
        const i = null !== (r = function(e) {
            var t;
            const n = typeof window > "u" ? void 0 : window,
                r = null == n || null === (t = n.location) || void 0 === t ? void 0 : t.href;
            return se(r) ? void 0 : function(e, t) {
                var n;
                const r = null == e || null === (n = e.config) || void 0 === n ? void 0 : n.get_current_url;
                if (!ie(r)) return t;
                try {
                    const e = r(t);
                    return ae(e) && e ? e : t
                } catch (e) {
                    return Ht.error("Error in get_current_url, falling back to window.location.href", e), t
                }
            }(e, r)
        }(t)) && void 0 !== r ? r : "u" > typeof window ? window.location.href : void 0;
        if (!i) return !1;
        const s = [e.conditions.url],
            a = function(e) {
                return null != e ? e : "icontains"
            }(null === (o = e.conditions) || void 0 === o ? void 0 : o.urlMatchType);
        return sn[a](s, [i])
    }

    function Yr(e) {
        var t, n;
        return function(e, t) {
            var n, r, o;
            if (!e || 0 === e.length) return !0;
            const i = "u" > typeof window ? window : void 0,
                s = "u" > typeof globalThis ? globalThis : i,
                a = null == s ? void 0 : s.navigator,
                l = null == a ? void 0 : a.userAgent;
            if (!l) return !1;
            const u = function(e, t) {
                var n;
                const r = function(e) {
                    return Pe.test(e) ? ge : qe.test(e) ? be : _e.test(e) ? we : new RegExp(ke, "i").test(e) ? ke : new RegExp("(Windows Phone|WPDesktop)", "i").test(e) ? "Windows Phone" : /iPad/.test(e) ? me : /iPod/.test(e) ? "iPod Touch" : /iPhone/.test(e) ? "iPhone" : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(e) ? ye : Ie.test(e) ? "BlackBerry" : /(kobo)\s(ereader|touch)/i.test(e) ? "Kobo" : new RegExp(xe, "i").test(e) ? xe : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(e) || /(kf[a-z]+)( bui|\)).+silk\//i.test(e) ? "Kindle Fire" : /(Android|ZTE)/i.test(e) ? new RegExp(pe).test(e) && !/(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(e) || /pixel[\daxl ]{1,6}/i.test(e) && !/pixel c/i.test(e) || /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(e) || /lmy47v/i.test(e) && !/QTAQZ3/i.test(e) ? "Android" : ve : new RegExp("(pda|Mobile)", "i").test(e) ? Se : new RegExp(he, "i").test(e) && !new RegExp("Tablet pc", "i").test(e) ? Te : ""
                }(e);
                return r === me || r === ve || "Kobo" === r || "Kindle Fire" === r || r === Te ? he : r === ge || r === we || r === be || r === ke ? "Console" : r === ye ? "Wearable" : r ? pe : "Android" === (null == t ? void 0 : t.userAgentDataPlatform) && (null !== (n = null == t ? void 0 : t.maxTouchPoints) && void 0 !== n ? n : 0) > 0 ? 600 > Math.min(null !== (o = null == t ? void 0 : t.screenWidth) && void 0 !== o ? o : 0, null !== (i = null == t ? void 0 : t.screenHeight) && void 0 !== i ? i : 0) / (null !== (s = null == t ? void 0 : t.devicePixelRatio) && void 0 !== s ? s : 1) ? pe : he : "Desktop";
                var o, i, s
            }(l, {
                userAgentDataPlatform: null == a || null === (n = a.userAgentData) || void 0 === n ? void 0 : n.platform,
                maxTouchPoints: null == a ? void 0 : a.maxTouchPoints,
                screenWidth: null == i || null === (r = i.screen) || void 0 === r ? void 0 : r.width,
                screenHeight: null == i || null === (o = i.screen) || void 0 === o ? void 0 : o.height,
                devicePixelRatio: null == i ? void 0 : i.devicePixelRatio
            });
            return sn[null != t ? t : "icontains"](e, [u])
        }(null === (t = e.conditions) || void 0 === t ? void 0 : t.deviceTypes, null === (n = e.conditions) || void 0 === n ? void 0 : n.deviceTypesMatchType)
    }
    const Kr = e => un("inProgressSurvey_", e),
        Jr = {},
        Xr = (e, t) => {
            const n = Kr(e);
            try {
                localStorage.setItem(n, JSON.stringify(t)), delete Jr[n]
            } catch (e) {
                ln.error("Error setting in-progress survey state in localStorage", e), Jr[n] = t
            }
        },
        eo = e => {
            const t = Kr(e),
                n = Jr[t];
            if (n) return n;
            try {
                const e = localStorage.getItem(t);
                if (e) return JSON.parse(e)
            } catch (e) {
                ln.error("Error getting in-progress survey state from localStorage", e)
            }
            return null
        },
        to = e => {
            const t = eo(e);
            return !ue(null == t ? void 0 : t.surveySubmissionId)
        },
        no = e => {
            const t = Kr(e);
            delete Jr[t];
            try {
                localStorage.removeItem(t)
            } catch (e) {
                ln.error("Error clearing in-progress survey state from localStorage", e)
            }
        };

    function ro(e, t = !1) {
        const n = `PostHogSurvey-${e.id}`;
        return t ? `.${n}` : n
    }

    function oo(e, t = xt, n) {
        if (e === _t) return {};
        switch (t) {
            case "top_left":
                return {
                    top: "0",
                    left: "0",
                    transform: "translate(30px, 30px)"
                };
            case "top_right":
                return {
                    top: "0",
                    right: "0",
                    transform: "translate(-30px, 30px)"
                };
            case "top_center":
                return {
                    top: "0",
                    left: "50%",
                    transform: "translate(-50%, 30px)"
                };
            case "middle_left":
                return {
                    top: "50%",
                    left: "0",
                    transform: "translate(30px, -50%)"
                };
            case "middle_right":
                return {
                    top: "50%",
                    right: "0",
                    transform: "translate(-30px, -50%)"
                };
            case "middle_center":
                return {
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)"
                };
            case bt:
                return {
                    left: "30px"
                };
            case wt:
                return {
                    left: "50%",
                    transform: "translateX(-50%)"
                };
            default:
                return {
                    right: e === Tt && n === gt ? "60px" : "30px"
                }
        }
    }
    const io = G("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: G("path", {
                d: "M626-533q22.5 0 38.25-15.75T680-587q0-22.5-15.75-38.25T626-641q-22.5 0-38.25 15.75T572-587q0 22.5 15.75 38.25T626-533Zm-292 0q22.5 0 38.25-15.75T388-587q0-22.5-15.75-38.25T334-641q-22.5 0-38.25 15.75T280-587q0 22.5 15.75 38.25T334-533Zm146 272q66 0 121.5-35.5T682-393h-52q-23 40-63 61.5T480.5-310q-46.5 0-87-21T331-393h-53q26 61 81 96.5T480-261Zm0 181q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        so = G("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: G("path", {
                d: "M626-533q22.5 0 38.25-15.75T680-587q0-22.5-15.75-38.25T626-641q-22.5 0-38.25 15.75T572-587q0 22.5 15.75 38.25T626-533Zm-292 0q22.5 0 38.25-15.75T388-587q0-22.5-15.75-38.25T334-641q-22.5 0-38.25 15.75T280-587q0 22.5 15.75 38.25T334-533Zm20 194h253v-49H354v49ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        ao = G("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: G("path", {
                d: "M626-533q22.5 0 38.25-15.75T680-587q0-22.5-15.75-38.25T626-641q-22.5 0-38.25 15.75T572-587q0 22.5 15.75 38.25T626-533Zm-292 0q22.5 0 38.25-15.75T388-587q0-22.5-15.75-38.25T334-641q-22.5 0-38.25 15.75T280-587q0 22.5 15.75 38.25T334-533Zm146.174 116Q413-417 358.5-379.5T278-280h53q22-42 62.173-65t87.5-23Q528-368 567.5-344.5T630-280h52q-25-63-79.826-100-54.826-37-122-37ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        lo = G("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: G("path", {
                d: "M480-417q-67 0-121.5 37.5T278-280h404q-25-63-80-100t-122-37Zm-183-72 50-45 45 45 31-36-45-45 45-45-31-36-45 45-50-45-31 36 45 45-45 45 31 36Zm272 0 44-45 51 45 31-36-45-45 45-45-31-36-51 45-44-45-31 36 44 45-44 45 31 36ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142 0 241-99t99-241q0-142-99-241t-241-99q-142 0-241 99t-99 241q0 142 99 241t241 99Z"
            })
        }),
        uo = G("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 -960 960 960",
            width: "48",
            children: G("path", {
                d: "M479.504-261Q537-261 585.5-287q48.5-26 78.5-72.4 6-11.6-.75-22.6-6.75-11-20.25-11H316.918Q303-393 296.5-382t-.5 22.6q30 46.4 78.5 72.4 48.5 26 105.004 26ZM347-578l27 27q7.636 8 17.818 8Q402-543 410-551q8-8 8-18t-8-18l-42-42q-8.8-9-20.9-9-12.1 0-21.1 9l-42 42q-8 7.636-8 17.818Q276-559 284-551q8 8 18 8t18-8l27-27Zm267 0 27 27q7.714 8 18 8t18-8q8-7.636 8-17.818Q685-579 677-587l-42-42q-8.8-9-20.9-9-12.1 0-21.1 9l-42 42q-8 7.714-8 18t8 18q7.636 8 17.818 8Q579-543 587-551l27-27ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 340q142.375 0 241.188-98.812Q820-337.625 820-480t-98.812-241.188Q622.375-820 480-820t-241.188 98.812Q140-622.375 140-480t98.812 241.188Q337.625-140 480-140Z"
            })
        }),
        co = G("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 0 24 24",
            width: "48",
            children: G("path", {
                d: "M2 20h2c.55 0 1-.45 1-1v-9c0-.55-.45-1-1-1H2v11zm19.83-7.12c.11-.25.17-.52.17-.8V11c0-1.1-.9-2-2-2h-5.5l.92-4.65c.05-.22.02-.46-.08-.66-.23-.45-.52-.86-.88-1.22L14 2 7.59 8.41C7.21 8.79 7 9.3 7 9.83v7.84C7 18.95 8.05 20 9.34 20h8.11c.7 0 1.36-.37 1.72-.97l2.66-6.15z"
            })
        }),
        fo = G("svg", {
            className: "emoji-svg",
            xmlns: "http://www.w3.org/2000/svg",
            height: "48",
            viewBox: "0 0 24 24",
            width: "48",
            children: G("path", {
                d: "M22 4h-2c-.55 0-1 .45-1 1v9c0 .55.45 1 1 1h2V4zM2.17 11.12c-.11.25-.17.52-.17.8V13c0 1.1.9 2 2 2h5.5l-.92 4.65c-.05.22-.02.46.08.66.23.45.52.86.88 1.22L10 22l6.41-6.41c.38-.38.59-.89.59-1.42V6.34C17 5.05 15.95 4 14.66 4H6.55c-.7 0-1.36.37-1.72.97l-2.66 6.15z"
            })
        }),
        po = ({
            fill: e = "currentColor"
        } = {}) => G("svg", {
            width: "12",
            height: "12",
            viewBox: "0 0 12 12",
            fill: e,
            xmlns: "http://www.w3.org/2000/svg",
            "aria-labelledby": "close-survey-title-adam",
            children: [G("title", {
                id: "close-survey-title",
                className: "adam-testing",
                children: "Close survey"
            }), G("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M0.164752 0.164752C0.384422 -0.0549175 0.740578 -0.0549175 0.960248 0.164752L6 5.20451L11.0398 0.164752C11.2594 -0.0549175 11.6156 -0.0549175 11.8352 0.164752C12.0549 0.384422 12.0549 0.740578 11.8352 0.960248L6.79549 6L11.8352 11.0398C12.0549 11.2594 12.0549 11.6156 11.8352 11.8352C11.6156 12.0549 11.2594 12.0549 11.0398 11.8352L6 6.79549L0.960248 11.8352C0.740578 12.0549 0.384422 12.0549 0.164752 11.8352C-0.0549175 11.6156 -0.0549175 11.2594 0.164752 11.0398L5.20451 6L0.164752 0.960248C-0.0549175 0.740578 -0.0549175 0.384422 0.164752 0.164752Z",
                fill: e
            })]
        }),
        ho = G("svg", {
            width: "80",
            height: "14",
            viewBox: "0 0 160 28",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [G("g", {
                "clip-path": "url(#ph-survey-logo-clip)",
                children: [G("path", {
                    fill: "currentColor",
                    d: "m50 23.34-.35-.05A4.5 4.5 0 0 1 47 21.97L35.56 10.1c-.3-.33-.86-.1-.86.35V27.5c0 .27.22.5.5.5h13.78c1.48 0 2.67-1.2 2.67-2.67v-.1a1.9 1.9 0 0 0-1.67-1.89zm-10.81.2a1.8 1.8 0 1 1 0-3.58 1.8 1.8 0 0 1 0 3.58"
                }), G("path", {
                    fill: "#0054ff",
                    d: "M.87 19.13a.5.5 0 0 0-.87.34v5.94a2.6 2.6 0 0 0 2.59 2.58H7.8a.5.5 0 0 0 .37-.84zM.86 8.4c-.3-.32-.86-.1-.86.36v6.73q0 .2.13.34l8.81 9.68 1.8 2.06v-8.82zM4.59.82A2.67 2.67 0 0 0 0 2.68v1.93q0 .4.27.69l10.47 10.95v-9.1z"
                }), G("path", {
                    fill: "#ff5506",
                    d: "M11.36 28h7.08a.5.5 0 0 0 .36-.85l-8.05-8.4v8.8l.23.28q.16.17.38.17m-.61-11.76 8.84 9.25 2.1 2.33q.1.11.27.14V18.7L10.75 7.15zm0-13.7v1.41a2 2 0 0 0 .55 1.28L21.96 16.2V7.65L15.32.8a2.67 2.67 0 0 0-4.57 1.71z"
                }), G("path", {
                    fill: "#ffb70f",
                    d: "M22.06 28h7.76a.5.5 0 0 0 .36-.86l-8.22-8.45v9.27l.09.02zM31 25.49l1.13 1.14c.32.31.85.09.85-.35v-7.3l-.49-.51L21.96 7.64v8.55zM22.52 5.73l9.62 9.89c.3.32.86.1.86-.35V7.46L26.56.82a2.67 2.67 0 0 0-4.59 1.84v1.7c0 .51.2 1 .57 1.37z"
                })]
            }), G("path", {
                fill: "currentColor",
                d: "M64.9 22.88c-.67 0-1.23-.56-1.23-1.24V5.24c0-.69.56-1.24 1.24-1.24h6.55c3.89 0 6.39 2.32 6.39 5.9 0 3.6-2.5 5.91-6.4 5.91h-3.53v5.83c0 .68-.56 1.24-1.24 1.24zm3.02-11.94c0 .68.55 1.23 1.23 1.23h1.88c1.6 0 2.58-.86 2.58-2.26s-.97-2.27-2.58-2.27h-1.88c-.68 0-1.23.55-1.23 1.23zM84.71 23.1c-4.18 0-7.14-2.97-7.14-7.02s2.96-7.01 7.14-7.01c4.14 0 7.14 2.97 7.14 7.01 0 4.05-3 7.01-7.14 7.01m-3.22-7.02c0 2.16 1.3 3.64 3.22 3.64 1.9 0 3.2-1.48 3.2-3.64s-1.3-3.64-3.2-3.64c-1.93 0-3.22 1.48-3.22 3.64m16.34 7.03a6.2 6.2 0 0 1-5.54-3.01c-.34-.57-.01-1.26.6-1.5l.77-.3c.7-.27 1.45.15 1.92.73a2.8 2.8 0 0 0 2.25 1.08c1.05 0 1.75-.51 1.75-1.27 0-2.13-7.17-.7-7.17-5.85 0-2.13 1.85-3.91 4.83-3.91 2.27 0 4.2.9 5.17 2.31.36.53.05 1.2-.54 1.44l-.85.35c-.68.29-1.45-.14-2-.63a2.5 2.5 0 0 0-1.64-.64c-.89 0-1.5.38-1.5.97 0 2.16 7.27.38 7.27 5.88 0 2.35-2.15 4.34-5.32 4.34m14.64-1.31c.04.57-.3 1.1-.86 1.2q-.6.1-1.27.11c-2.92 0-5.15-1.56-5.15-4.85v-5.66h-.91c-.69 0-1.24-.56-1.24-1.24v-.82c0-.68.55-1.23 1.24-1.23h.91v-2.7c0-.69.55-1.24 1.23-1.24h1.48c.68 0 1.24.55 1.24 1.23v2.7h2.04c.68 0 1.23.56 1.23 1.24v.82c0 .68-.55 1.24-1.23 1.24h-2.04v5.15c0 1.2.64 1.91 1.6 1.91.75 0 1.6.5 1.66 1.25zM125.5 5.23c0-.68.55-1.23 1.23-1.23h1.8c.68 0 1.23.55 1.23 1.23v16.41c0 .68-.55 1.24-1.23 1.24h-1.8c-.68 0-1.23-.56-1.23-1.24v-5.43c0-.68-.56-1.23-1.24-1.23h-5c-.67 0-1.23.55-1.23 1.23v5.43c0 .68-.55 1.24-1.23 1.24h-1.77c-.69 0-1.24-.56-1.24-1.24V5.24c0-.69.55-1.24 1.24-1.24h1.77c.68 0 1.23.55 1.23 1.23v4.87c0 .68.56 1.23 1.24 1.23h5c.67 0 1.23-.55 1.23-1.23zm12.87 17.87c-4.19 0-7.14-2.97-7.14-7.02s2.95-7.01 7.14-7.01c4.13 0 7.14 2.97 7.14 7.01 0 4.05-3 7.01-7.14 7.01m-3.22-7.02c0 2.16 1.29 3.64 3.22 3.64 1.9 0 3.2-1.48 3.2-3.64s-1.3-3.64-3.2-3.64c-1.93 0-3.22 1.48-3.22 3.64m17.17 6.37c-3.84 0-6.2-2.58-6.2-6.68s2.36-6.69 6.12-6.69c1.58 0 2.82.54 3.54 1.37 0-.64.52-1.15 1.16-1.15h1.5c.68 0 1.24.55 1.24 1.23V21.9c0 3.64-2.77 6.09-6.93 6.09-2.64 0-4.9-1.2-5.85-3.09-.31-.62.16-1.29.85-1.4l1.14-.17c.67-.11 1.29.4 1.78.85.5.46 1.26.7 2.08.7 1.85 0 3.06-1.04 3.06-2.55v-1.3c-.7.9-2.01 1.4-3.49 1.4m-2.36-6.68c0 2.02 1.18 3.31 3 3.31 1.86 0 3.04-1.29 3.04-3.31s-1.18-3.32-3.03-3.32c-1.83 0-3.01 1.3-3.01 3.32"
            }), G("defs", {
                children: G("clipPath", {
                    id: "ph-survey-logo-clip",
                    children: G("path", {
                        fill: "#fff",
                        d: "M0 0h51.67v28H0z"
                    })
                })
            })]
        });

    function vo({
        urlParams: e
    }) {
        const t = e ? Object.entries(e).map(([e, t]) => `${encodeURIComponent(e)}=${encodeURIComponent(t)}`).join("&") : "";
        return G("a", {
            href: "https://posthog.com/surveys" + (t ? `?${t}` : ""),
            target: "_blank",
            rel: "noopener",
            className: "footer-branding",
            children: ["Survey by ", ho]
        })
    }

    function mo({
        text: e,
        submitDisabled: t,
        appearance: n,
        onSubmit: r,
        link: o,
        onPreviewSubmit: i,
        skipSubmitButton: s,
        canGoBack: a,
        onBack: l
    }) {
        const {
            isPreviewMode: u
        } = ct(Vr), c = !!a && !!l, d = !s && G("button", {
            className: "form-submit",
            disabled: t,
            "aria-label": "Submit survey",
            type: "button",
            onClick() {
                var e;
                o && (null === (e = window) || void 0 === e || e.open(o)), u ? null == i || i() : r()
            },
            children: e
        });
        return G("div", {
            className: "bottom-section",
            children: [c ? G("div", {
                className: "form-buttons form-buttons-with-back",
                children: [G("button", {
                    className: "form-back",
                    type: "button",
                    "aria-label": "Go to previous question",
                    onClick: l,
                    children: n.backButtonText || "Back"
                }), d]
            }) : d, !n.whiteLabel && G(vo, {
                urlParams: {
                    utm_source: "survey-footer"
                }
            })]
        })
    }

    function yo({
        question: e,
        forceDisableHtml: t,
        htmlFor: n
    }) {
        return G("div", {
            class: e.question || e.description ? "question-header" : "question-header question-header--empty",
            children: [G(e.type === qt ? "label" : "h3", {
                className: "survey-question",
                htmlFor: n,
                children: e.question
            }), e.description && Gr({
                component: k("p", {
                    className: "survey-question-description"
                }),
                children: e.description,
                renderAsHtml: !t && "text" !== e.descriptionContentType
            })]
        })
    }

    function go({
        onClick: e
    }) {
        const {
            isPreviewMode: t
        } = ct(Vr);
        return G("button", {
            className: "form-cancel",
            onClick: e,
            disabled: t,
            "aria-label": "Close survey",
            type: "button",
            children: po({
                fill: "black"
            })
        })
    }

    function bo({
        header: e,
        description: t,
        contentType: n,
        forceDisableHtml: r,
        appearance: o,
        onClose: i
    }) {
        const {
            isPopup: s
        } = ct(Vr);
        return at(() => {
            const e = e => {
                "Enter" !== e.key && "Escape" !== e.key || (e.preventDefault(), i())
            };
            return Qt(window, "keydown", e), () => {
                window.removeEventListener("keydown", e)
            }
        }, [i]), G("div", {
            className: "thank-you-message",
            role: "status",
            tabIndex: 0,
            "aria-atomic": "true",
            children: [s && !0 !== o.hideCancelButton && G(go, {
                onClick: () => i()
            }), G("h3", {
                className: "thank-you-message-header",
                children: e
            }), t && Gr({
                component: k("p", {
                    className: "thank-you-message-body"
                }),
                children: t,
                renderAsHtml: !r && "text" !== n
            }), s && G(mo, {
                text: o.thankYouMessageCloseButtonText || "Close",
                submitDisabled: !1,
                appearance: o,
                onSubmit: () => i()
            })]
        })
    }

    function wo({
        header: e,
        description: t,
        contentType: n,
        forceDisableHtml: r,
        appearance: o,
        onStart: i
    }) {
        const {
            isPopup: s,
            onPreviewSubmit: a,
            onPopupSurveyDismissed: l
        } = ct(Vr);
        return G("div", {
            className: "intro-screen",
            role: "status",
            tabIndex: 0,
            "aria-atomic": "true",
            children: [s && !0 !== o.hideCancelButton && G(go, {
                onClick: () => l()
            }), e && G("h3", {
                className: "intro-screen-header",
                children: e
            }), t && Gr({
                component: k("p", {
                    className: "intro-screen-body"
                }),
                children: t,
                renderAsHtml: !r && "text" !== n
            }), G(mo, {
                text: o.introScreenButtonText || "Get started",
                submitDisabled: !1,
                appearance: o,
                onSubmit: i,
                onPreviewSubmit: () => a(null)
            })]
        })
    }
    const xo = e => oe(e) && e.every(e => ae(e));

    function ko({
        question: e,
        forceDisableHtml: t,
        appearance: n,
        onSubmit: r,
        onPreviewSubmit: o,
        displayQuestionIndex: i,
        initialValue: s,
        canGoBack: a,
        onBack: l
    }) {
        const {
            isPreviewMode: u
        } = Wr(), c = lt(null), [d, f] = st(() => ae(s) ? s : ""), p = null == n ? void 0 : n.disableAutofocus;
        at(() => {
            p || setTimeout(() => {
                var e;
                u || null === (e = c.current) || void 0 === e || e.focus()
            }, 100)
        }, [u, p]);
        const h = `surveyQuestion${i}`,
            v = ut(() => function(e, t, n) {
                const r = e.trim();
                if (!n && "" === r) return "This field is required";
                if ("" === r) return !1;
                if (t && t.length > 0)
                    for (const e of t) switch (e.type) {
                        case X:
                            var o;
                            if (void 0 !== e.value && e.value > r.length) return null !== (o = e.errorMessage) && void 0 !== o ? o : `Please enter at least ${e.value} characters`;
                            break;
                        case ee:
                            var i;
                            if (void 0 !== e.value && r.length > e.value) return null !== (i = e.errorMessage) && void 0 !== i ? i : `Please enter no more than ${e.value} characters`
                    }
                return !1
            }(d, e.validation, e.optional), [d, e.validation, e.optional]),
            m = Oe(e.validation, X),
            y = Oe(e.validation, ee),
            g = ut(() => function(e, t) {
                const n = 1 === e ? void 0 : e;
                return n && t ? `Enter ${n}-${t} characters` : n ? `Enter at least ${n} ${1===n?"character":"characters"}` : t ? `Maximum ${t} ${1===t?"character":"characters"}` : void 0
            }(m, y), [m, y]),
            b = () => {
                v || r(d.trim())
            },
            w = () => {
                v || o(d.trim())
            };
        return G(T, {
            children: [G("div", {
                className: "question-container",
                children: [G(yo, {
                    question: e,
                    forceDisableHtml: t,
                    htmlFor: h
                }), G("textarea", {
                    ref: c,
                    id: h,
                    rows: 4,
                    placeholder: null == n ? void 0 : n.placeholder,
                    minLength: m,
                    maxLength: y,
                    onInput(e) {
                        f(e.currentTarget.value), e.stopPropagation()
                    },
                    onKeyDown(e) {
                        e.stopPropagation(), "Enter" !== e.key || !e.metaKey && !e.ctrlKey || v || (e.preventDefault(), u ? w() : b())
                    },
                    value: d
                }), g && G("div", {
                    className: "validation-hint",
                    children: g
                })]
            }), G(mo, {
                text: e.buttonText || "Submit",
                submitDisabled: !!v,
                appearance: n,
                onSubmit: b,
                onPreviewSubmit: w,
                canGoBack: a,
                onBack: l
            })]
        })
    }

    function So({
        question: e,
        forceDisableHtml: t,
        appearance: n,
        onSubmit: r,
        onPreviewSubmit: o,
        canGoBack: i,
        onBack: s
    }) {
        return G(T, {
            children: [G("div", {
                className: "question-container",
                children: G(yo, {
                    question: e,
                    forceDisableHtml: t
                })
            }), G(mo, {
                text: e.buttonText || "Submit",
                submitDisabled: !1,
                link: e.link,
                appearance: n,
                onSubmit: () => r("link clicked"),
                onPreviewSubmit: () => o("link clicked"),
                canGoBack: i,
                onBack: s
            })]
        })
    }

    function To({
        question: e,
        forceDisableHtml: t,
        displayQuestionIndex: n,
        appearance: r,
        onSubmit: o,
        onPreviewSubmit: i,
        initialValue: s,
        canGoBack: a,
        onBack: l
    }) {
        var u;
        const c = e.scale,
            d = 10 === e.scale ? 0 : 1,
            [f, p] = st(() => ce(s) ? s : oe(s) && s.length > 0 && ce(parseInt(s[0])) ? parseInt(s[0]) : ae(s) && ce(parseInt(s)) ? parseInt(s) : null),
            h = "emoji" === e.display && 2 === e.scale,
            {
                isPreviewMode: v
            } = Wr(),
            m = e => v ? i(e) : o(e);
        return G(T, {
            children: [G("div", {
                className: "question-container",
                children: [G(yo, {
                    question: e,
                    forceDisableHtml: t
                }), G("div", {
                    className: "rating-section",
                    children: [G("div", {
                        className: "rating-options",
                        children: ["emoji" === e.display && G("div", {
                            className: "rating-options-emoji" + (h ? " rating-options-emoji-2" : ""),
                            children: null === (u = Eo[e.scale]) || void 0 === u ? void 0 : u.map((t, r) => G("button", {
                                "aria-label": `Rate ${r+1}`,
                                className: `ratings-emoji question-${n}-rating-${r} ${r+1===f?"rating-active":""}`,
                                value: r + 1,
                                type: "button",
                                onClick() {
                                    const t = r + 1;
                                    p(t), e.skipSubmitButton && m(t)
                                },
                                children: t
                            }, r))
                        }), "number" === e.display && G("div", {
                            className: "rating-options-number",
                            style: {
                                gridTemplateColumns: `repeat(${c-d+1}, minmax(0, 1fr))`
                            },
                            children: Co(e.scale).map((t, o) => G(_o, {
                                displayQuestionIndex: n,
                                active: f === t,
                                appearance: r,
                                num: t,
                                setActiveNumber(t) {
                                    p(t), e.skipSubmitButton && m(t)
                                }
                            }, o))
                        })]
                    }), !h && G("div", {
                        className: "rating-text",
                        children: [G("div", {
                            children: e.lowerBoundLabel
                        }), G("div", {
                            children: e.upperBoundLabel
                        })]
                    })]
                })]
            }), G(mo, {
                text: e.buttonText || (null == r ? void 0 : r.submitButtonText) || "Submit",
                submitDisabled: le(f) && !e.optional,
                appearance: r,
                onSubmit: () => o(f),
                onPreviewSubmit: () => i(f),
                skipSubmitButton: e.skipSubmitButton,
                canGoBack: a,
                onBack: l
            })]
        })
    }

    function _o({
        num: e,
        active: t,
        displayQuestionIndex: n,
        setActiveNumber: r
    }) {
        return G("button", {
            "aria-label": `Rate ${e}`,
            className: `ratings-number question-${n}-rating-${e} ${t?"rating-active":""}`,
            type: "button",
            onClick() {
                r(e)
            },
            children: e
        })
    }

    function qo({
        question: e,
        forceDisableHtml: t,
        displayQuestionIndex: n,
        appearance: r,
        onSubmit: o,
        onPreviewSubmit: i,
        initialValue: s,
        canGoBack: a,
        onBack: l
    }) {
        const u = lt(null),
            c = ut(() => (e => {
                var t;
                if (!e.shuffleOptions) return e.choices;
                const n = [...e.choices],
                    r = e.hasOpenChoice && null !== (t = n.pop()) && void 0 !== t ? t : null,
                    o = (i = n, (s = an(n)).length > 1 && i.every((e, t) => e === s[t]) ? s.reverse() : s);
                var i, s;
                return le(r) || o.push(r), o
            })(e), [e]),
            [d, f] = st(() => ((e, t) => ae(e) || xo(e) ? e : t === It ? null : [])(s, e.type)),
            [p, h] = st(() => ((e, t) => {
                if (ae(e) && !t.includes(e)) return {
                    isSelected: !0,
                    inputValue: e
                };
                if (xo(e)) {
                    const n = e.find(e => !t.includes(e));
                    if (n) return {
                        isSelected: !0,
                        inputValue: n
                    }
                }
                return {
                    isSelected: !1,
                    inputValue: ""
                }
            })(s, c)),
            {
                isPreviewMode: v
            } = Wr(),
            m = e.type === It,
            y = e.type === Pt,
            g = e.skipSubmitButton && m && !e.hasOpenChoice,
            b = (e, t) => {
                if (t) {
                    const e = !p.isSelected;
                    return h(t => Me(Me({}, t), {}, {
                        isSelected: e,
                        inputValue: e ? t.inputValue : ""
                    })), m && f(""), void(e && setTimeout(() => {
                        var e;
                        return null === (e = u.current) || void 0 === e ? void 0 : e.focus()
                    }, 75))
                }
                if (m) return f(e), h(e => Me(Me({}, e), {}, {
                    isSelected: !1,
                    inputValue: ""
                })), void(g && (o(e), v && i(e)));
                y && oe(d) && (d.includes(e) ? f(d.filter(t => t !== e)) : f([...d, e]))
            },
            w = e => {
                e.stopPropagation();
                const t = e.currentTarget.value;
                h(e => Me(Me({}, e), {}, {
                    inputValue: t
                })), m && f(t)
            },
            x = e => {
                e.stopPropagation(), "Enter" !== e.key || k() || (e.preventDefault(), S()), "Escape" === e.key && (e.preventDefault(), h(e => Me(Me({}, e), {}, {
                    isSelected: !1,
                    inputValue: ""
                })), m && f(null))
            },
            k = () => !(e.optional || !le(d) && (!oe(d) || p.isSelected || 0 !== d.length) && (!p.isSelected || "" !== p.inputValue.trim())),
            S = () => {
                p.isSelected && y ? oe(d) && (v ? i([...d, p.inputValue]) : o([...d, p.inputValue])) : v ? i(d) : o(d)
            };
        return G(T, {
            children: [G("div", {
                className: "question-container",
                children: [G(yo, {
                    question: e,
                    forceDisableHtml: t
                }), G("fieldset", {
                    className: "multiple-choice-options limit-height",
                    children: [G("legend", {
                        className: "sr-only",
                        children: y ? " Select all that apply" : " Select one"
                    }), c.map((t, r) => {
                        const o = !!e.hasOpenChoice && r === e.choices.length - 1,
                            i = `surveyQuestion${n}Choice${r}`,
                            s = `${i}Open`,
                            a = o ? p.isSelected : m ? d === t : oe(d) && d.includes(t);
                        return G("label", {
                            className: o ? "choice-option-open" : "",
                            children: [G("div", {
                                className: "response-choice",
                                children: [G("input", {
                                    type: m ? "radio" : "checkbox",
                                    name: i,
                                    checked: a,
                                    onChange: () => b(t, o),
                                    id: i,
                                    "aria-controls": s
                                }), G("span", {
                                    children: o ? `${t}:` : t
                                })]
                            }), o && G("input", {
                                type: "text",
                                ref: u,
                                id: s,
                                name: `question${n}Open`,
                                value: p.inputValue,
                                onKeyDown: x,
                                onInput: w,
                                onClick(e) {
                                    p.isSelected || b(t, !0), e.stopPropagation()
                                },
                                "aria-label": `${t} - please specify`
                            })]
                        }, r)
                    })]
                })]
            }), G(mo, {
                text: e.buttonText || "Submit",
                submitDisabled: k(),
                appearance: r,
                onSubmit: S,
                onPreviewSubmit: S,
                skipSubmitButton: g,
                canGoBack: a,
                onBack: l
            })]
        })
    }
    const Po = [1, 2, 3, 4, 5],
        Io = [1, 2, 3, 4, 5, 6, 7],
        $o = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        Eo = {
            2: [co, fo],
            3: [ao, so, io],
            5: [lo, ao, so, io, uo]
        };

    function Co(e) {
        switch (e) {
            case 5:
            default:
                return Po;
            case 7:
                return Io;
            case 10:
                return $o
        }
    }
    const Mo = Ut("[Surveys]");

    function Ao(e, t, n) {
        var r;
        const o = e.questions[t],
            i = t + 1;
        if (!(null === (r = o.branching) || void 0 === r ? void 0 : r.type)) return t === e.questions.length - 1 ? Et : i;
        if (o.branching.type === Et) return Et;
        if ("specific_question" === o.branching.type) {
            if (Number.isInteger(o.branching.index)) return o.branching.index
        } else if ("response_based" === o.branching.type) {
            if (o.type === It) {
                var s;
                let e = o.choices.indexOf(`${n}`);
                if (-1 === e && o.hasOpenChoice && (e = o.choices.length - 1), null === (s = o.branching) || void 0 === s || null === (s = s.responseValues) || void 0 === s ? void 0 : s.hasOwnProperty(e)) {
                    const t = o.branching.responseValues[e];
                    if (Number.isInteger(t)) return t;
                    if (t === Et) return Et
                }
            } else if (o.type === $t) {
                var a;
                if (o.optional && ue(n)) return i === e.questions.length ? Et : i;
                if ("number" != typeof n || !Number.isInteger(n)) throw new Error("The response type must be an integer");
                const t = function(e, t) {
                    if (2 === t) {
                        if (1 > e || e > 2) throw new Error("The response must be in range 1-2");
                        return 1 === e ? "positive" : "negative"
                    }
                    if (3 === t) {
                        if (1 > e || e > 3) throw new Error("The response must be in range 1-3");
                        return 1 === e ? "negative" : 2 === e ? "neutral" : "positive"
                    }
                    if (5 === t) {
                        if (1 > e || e > 5) throw new Error("The response must be in range 1-5");
                        return e > 2 ? 3 === e ? "neutral" : "positive" : "negative"
                    }
                    if (7 === t) {
                        if (1 > e || e > 7) throw new Error("The response must be in range 1-7");
                        return e > 3 ? 4 === e ? "neutral" : "positive" : "negative"
                    }
                    if (10 === t) {
                        if (0 > e || e > 10) throw new Error("The response must be in range 0-10");
                        return e > 6 ? e > 8 ? "promoters" : "passives" : "detractors"
                    }
                    throw new Error("The scale must be one of: 2, 3, 5, 7, 10")
                }(n, o.scale);
                if (null === (a = o.branching) || void 0 === a || null === (a = a.responseValues) || void 0 === a ? void 0 : a.hasOwnProperty(t)) {
                    const e = o.branching.responseValues[t];
                    if (Number.isInteger(e)) return e;
                    if (e === Et) return Et
                }
            }
            return i
        }
        return Mo.warn("Falling back to next question index due to unexpected branching type"), i
    }
    const Do = Ut("[SurveyTranslations]");

    function No(e, t) {
        const n = function(e) {
            var t;
            return function({
                overrideLanguage: e,
                storedPersonProperties: t,
                locale: n
            }, r) {
                const o = Kt(e);
                if (o) return null == r || r.info(`Using override display language: ${o}`), o;
                const i = function(e) {
                    return e && "object" == typeof e && "language" in e ? Kt(e.language) : null
                }(t);
                if (i) return null == r || r.info(`Using person property language: ${i}`), i;
                const s = Kt(n);
                return s ? (null == r || r.info(`Using detected locale: ${s}`), s) : (null == r || r.info("No user language detected"), null)
            }({
                overrideLanguage: e.config.overrideLanguage,
                storedPersonProperties: null === (t = e.client) || void 0 === t ? void 0 : t.kv.get("$stored_person_properties"),
                locale: "u" > typeof navigator ? navigator.language || navigator.userLanguage : void 0
            }, Do)
        }(t);
        if (!n) return Do.info("No user language detected"), {
            survey: e,
            language: null
        };
        const r = tn(e, n, Do);
        return {
            survey: r.survey,
            language: r.matchedKey
        }
    }
    const jo = "ph:show_survey_widget",
        Oo = "PHWidgetSurveyClickListener";

    function zo(e, t) {
        try {
            const n = e.getBoundingClientRect(),
                r = window.innerHeight,
                o = window.innerWidth;
            let i = n.left + n.width / 2 - t / 2;
            i + t > o - 20 && (i = o - t - 20), 20 > i && (i = 20);
            const s = r - n.bottom,
                a = 250 > s && n.top > s;
            return {
                position: "fixed",
                top: a ? "auto" : `${n.bottom+12}px`,
                left: `${i}px`,
                right: "auto",
                bottom: a ? r - n.top + 12 + "px" : "auto",
                zIndex: Ar.zIndex
            }
        } catch (e) {
            return ln.warn("Failed to calculate trigger position:", e), null
        }
    }
    var Lo = class {
        constructor(e) {
            var t, n;
            this.wi = new Map, this.ki = new Map, this.Si = new Map, this.xi = new Map, this.Ci = new Set, this.Ti = !1, this.Ii = null, this.Mi = !1, this.Ri = null, this.Ai = null, this.Ei = null, this.Oi = !1, this.handlePageUnload = () => {
                var e;
                const t = null === (e = this.$i.client) || void 0 === e ? void 0 : e.kv.get(Z);
                if (t)
                    for (const e of t) to(e) && Br(e, this.$i)
            }, this.handlePopoverSurvey = (e, t, {
                resumeDelayFromActivation: n = !1
            } = {}) => {
                var r, o, i, s, a, l, u;
                if (!(null === (r = this.$i.client) || void 0 === r ? void 0 : r.canCapture)) return;
                const {
                    survey: c,
                    language: d
                } = this.Li(e);
                this.Ii = d, this.Ei = null, this.Di = t;
                const f = this.Pi(c, t);
                this.Fi(f.id);
                const {
                    properties: p,
                    initialResponses: h
                } = null != t ? t : {}, v = !(!h || 0 >= Object.keys(h).length) && this.Ni(f, h, p, d);
                if (v && !(null === (o = f.appearance) || void 0 === o ? void 0 : o.displayThankYouMessage)) return;
                this.qi(f);
                let m = {};
                if ((null === (i = f.appearance) || void 0 === i ? void 0 : i.position) === kt && (null === (s = f.appearance) || void 0 === s ? void 0 : s.widgetSelector)) {
                    var y;
                    const e = document.querySelector(f.appearance.widgetSelector);
                    e && (m = zo(e, parseInt((null === (y = f.appearance) || void 0 === y ? void 0 : y.maxWidth) || Ar.maxWidth)) || {})
                }
                const g = (null === (a = f.appearance) || void 0 === a ? void 0 : a.surveyPopupDelaySeconds) || 0,
                    {
                        shadow: b
                    } = Or(f, this.$i);
                this.xi.set(b, b.host);
                const w = {
                    posthog: this.$i,
                    survey: f,
                    removeSurveyFromFocus: this.ji,
                    properties: p,
                    style: m,
                    isSurveyCompleted: v,
                    skipShownEvent: null == t ? void 0 : t.skipShownEvent,
                    surveyLanguage: d
                };
                if (this.Ei = w, 0 >= g) return this.Mi = !0, V(G(Ho, Me({}, w)), b);
                const x = () => {
                        this.Mi = !0;
                        const {
                            survey: n,
                            language: r
                        } = this.Li(e);
                        this.Ii = r;
                        const o = this.Pi(n, t),
                            i = Me(Me({}, w), {}, {
                                survey: o,
                                surveyLanguage: r
                            });
                        this.Ei = i, V(G(Ho, Me(Me({}, i), {}, {
                            survey: Me(Me({}, o), {}, {
                                appearance: Me(Me({}, o.appearance), {}, {
                                    surveyPopupDelaySeconds: 0
                                })
                            })
                        })), b)
                    },
                    k = () => {
                        var e;
                        if (!(null === (e = this.$i.client) || void 0 === e ? void 0 : e.canCapture) || !this.Bi(f)) return ln.info(`Survey ${f.id} no longer eligible when its display delay elapsed; not displaying`), this.ji(f);
                        x()
                    },
                    S = n ? null === (l = this.$i.surveys) || void 0 === l || null === (l = l._surveyEventReceiver) || void 0 === l || null === (u = l.getActivationTimestamp) || void 0 === u ? void 0 : u.call(l, f.id) : void 0,
                    T = ce(S) ? Math.max(0, Date.now() - S) : 0,
                    _ = Math.max(0, 1e3 * g - T);
                if (0 >= _) return k();
                const q = window.setTimeout(() => {
                    this.wi.delete(f.id), k()
                }, _);
                this.wi.set(f.id, q)
            }, this.zi = e => {
                var t;
                const {
                    survey: n,
                    language: r
                } = this.Li(e), {
                    shadow: o,
                    isNewlyCreated: i
                } = Or(n, this.$i);
                this.xi.set(o, o.host), (null === (t = e.appearance) || void 0 === t ? void 0 : t.widgetType) === gt && this.Si.set(e.id, e), i && V(G(Qo, {
                    posthog: this.$i,
                    survey: n,
                    surveyLanguage: r
                }, e.id), o)
            }, this.Hi = e => {
                const t = this.ki.get(e);
                t && (t.element.removeEventListener("click", t.listener), t.element.removeAttribute(Oo), this.ki.delete(e), ln.info(`Removed click listener for survey ${e}`))
            }, this.Ui = e => {
                this.Wi(e) || (this.Gi(e), this.Hi(e.id))
            }, this.Vi = e => {
                this.Wi(e) || (this.Gi(e), this.Si.delete(e.id))
            }, this.Wi = e => {
                try {
                    var t;
                    const n = document.querySelector(ro(e, !0));
                    return !!(null == n || null === (t = n.shadowRoot) || void 0 === t ? void 0 : t.querySelector(".ph-survey"))
                } catch (e) {
                    return !1
                }
            }, this.Qi = (e, t) => {
                const n = document.querySelector(t),
                    r = this.ki.get(e.id);
                if (n) {
                    if (this.zi(e), r) {
                        if (n === r.element) return;
                        ln.info(`Selector element changed for survey ${e.id}. Re-attaching listener.`), this.Hi(e.id)
                    }
                    if (!n.hasAttribute(Oo)) {
                        const t = t => {
                            var n, r;
                            t.stopPropagation();
                            const o = (null === (n = e.appearance) || void 0 === n ? void 0 : n.position) === kt ? zo(t.currentTarget, parseInt((null === (r = e.appearance) || void 0 === r ? void 0 : r.maxWidth) || Ar.maxWidth)) : {};
                            window.dispatchEvent(new CustomEvent(jo, {
                                detail: {
                                    surveyId: e.id,
                                    position: o
                                }
                            }))
                        };
                        Qt(n, "click", t), n.setAttribute(Oo, "true"), this.ki.set(e.id, {
                            element: n,
                            listener: t,
                            survey: e
                        }), ln.info(`Attached click listener for feedback button survey ${e.id}`)
                    }
                } else r && this.Ui(e)
            }, this.renderPopover = e => {
                var t;
                if (!(null === (t = this.$i.client) || void 0 === t ? void 0 : t.canCapture)) return;
                const {
                    survey: n,
                    language: r
                } = this.Li(e), {
                    shadow: o
                } = Or(n, this.$i);
                this.xi.set(o, o.host), V(G(Ho, {
                    posthog: this.$i,
                    survey: n,
                    removeSurveyFromFocus: this.ji,
                    surveyLanguage: r
                }), o)
            }, this.renderSurvey = (e, t, n) => {
                var r;
                if (!(null === (r = this.$i.client) || void 0 === r ? void 0 : r.canCapture)) return;
                const {
                    survey: o,
                    language: i
                } = this.Li(e);
                let s = !1;
                this.$i.config.prefillFromUrl && (s = this.Zi(o, i, n)), V(G(Ho, {
                    posthog: this.$i,
                    survey: o,
                    removeSurveyFromFocus: this.ji,
                    isPopup: !1,
                    properties: n,
                    isSurveyCompleted: s,
                    surveyLanguage: i
                }), t)
            }, this.getActiveMatchingSurveys = (e, t = !1) => {
                var n;
                null === (n = this.$i.surveys) || void 0 === n || n.getSurveys(t => {
                    e(t.filter(e => this.Bi(e)))
                }, t)
            }, this.callSurveysAndEvaluateDisplayLogic = (e = !1) => {
                this.getActiveMatchingSurveys(e => {
                    var t;
                    const n = null === (t = this.$i.client) || void 0 === t ? void 0 : t.canCapture,
                        r = e.filter(e => n && (e.type === St || e.type === Tt)),
                        o = new Set(r.map(e => e.id));
                    for (const e of Array.from(this.wi.keys())) o.has(e) || this.cancelSurvey(e);
                    const i = this.Ji(r),
                        s = new Set,
                        a = new Set;
                    i.forEach(e => {
                        if (e.type === Tt) {
                            var t, n, r, o;
                            if ((null === (t = e.appearance) || void 0 === t ? void 0 : t.widgetType) === gt) return a.add(e.id), void this.zi(e);
                            "selector" === (null === (n = e.appearance) || void 0 === n ? void 0 : n.widgetType) && (null === (r = e.appearance) || void 0 === r ? void 0 : r.widgetSelector) && (s.add(e.id), this.Qi(e, null === (o = e.appearance) || void 0 === o ? void 0 : o.widgetSelector))
                        }
                        le(this.Yi) && e.type === St && this.handlePopoverSurvey(e, void 0, {
                            resumeDelayFromActivation: !0
                        })
                    }), this.ki.forEach(({
                        survey: e
                    }) => {
                        s.has(e.id) || this.Ui(e)
                    }), this.Si.forEach((e, t) => {
                        a.has(t) || this.Vi(e)
                    })
                }, e)
            }, this.qi = e => {
                le(this.Yi) || ln.error(`Survey ${this.Yi} already in focus. Cannot add survey ${e.id}.`), this.Yi = e.id
            }, this.ji = e => {
                this.Yi !== e.id && ln.error(`Survey ${e.id} is not in focus. Cannot remove survey ${e.id}.`), this.Fi(e.id), this.Yi = null, this.Ii = null, this.Mi = !1, this.Ei = null, this.Di = void 0, this.Gi(e)
            }, this.$i = e, this.Yi = null, this.Ri = () => this.Ki(), Qt(window, "languagechange", this.Ri), this.Ai = null !== (t = null === (n = e.client) || void 0 === n || null === (n = n.getExtension("featureFlagsCommon")) || void 0 === n ? void 0 : n.onFeatureFlags(() => this.Ki())) && void 0 !== t ? t : null
        }
        Ki() {
            var e;
            if (le(this.Yi)) return;
            const t = null === (e = this.$i.client) || void 0 === e ? void 0 : e.kv.get(Z),
                n = null == t ? void 0 : t.find(e => e.id === this.Yi);
            if (!n) return;
            const {
                survey: r,
                language: o
            } = this.Li(n);
            if (o === this.Ii) return;
            if (this.Ii = o, !this.Mi) return;
            const i = this.Pi(r, this.Di),
                {
                    shadow: s
                } = Or(i, this.$i);
            V(G(Ho, Me(Me({}, this.Ei), {}, {
                posthog: this.$i,
                survey: i,
                removeSurveyFromFocus: this.ji,
                surveyLanguage: o
            })), s)
        }
        Pi(e, t) {
            return (null == t ? void 0 : t.position) || (null == t ? void 0 : t.selector) ? Me(Me({}, e), {}, {
                appearance: Me(Me(Me({}, e.appearance), t.position && {
                    position: t.position
                }), t.selector && {
                    widgetSelector: t.selector
                })
            }) : e
        }
        Fi(e) {
            const t = this.wi.get(e);
            t && (clearTimeout(t), this.wi.delete(e))
        }
        cancelSurvey(e) {
            this.wi.has(e) && (ln.info(`Cancelled pending survey ${e}`), this.Fi(e), this.Yi === e && (this.Yi = null, this.Ii = null, this.Mi = !1, this.Ei = null, this.Di = void 0))
        }
        startAutomaticDisplay() {
            if (this.Ti || this.Xi || !1 === this.$i.config.automaticDisplay) return;
            this.Xi = () => {};
            const e = function(e) {
                let t;
                e.callSurveysAndEvaluateDisplayLogic(!0);
                const n = () => {
                        se(t) && (t = setInterval(() => {
                            e.callSurveysAndEvaluateDisplayLogic(!1)
                        }, 1e3))
                    },
                    r = () => {
                        se(t) || (clearInterval(t), t = void 0)
                    };
                n();
                const o = () => {
                    document.hidden ? r() : (e.callSurveysAndEvaluateDisplayLogic(!1), n())
                };
                return Qt(document, "visibilitychange", o), () => {
                    r(), document.removeEventListener("visibilitychange", o)
                }
            }(this);
            this.Ti ? e() : this.Xi = e
        }
        clearInMemoryInProgressSurveyState() {
            (() => {
                for (const e of Object.keys(Jr)) delete Jr[e]
            })()
        }
        dispose() {
            var e;
            this.Ti = !0, null === (e = this.Xi) || void 0 === e || e.call(this), this.Xi = void 0, this.Ri && (window.removeEventListener("languagechange", this.Ri), this.Ri = null), this.Ai && (this.Ai(), this.Ai = null), this.wi.forEach((e, t) => this.Fi(t)), this.ki.forEach((e, t) => this.Hi(t)), this.xi.forEach((e, t) => {
                V(null, t), null == e || e.remove()
            }), this.xi.clear(), this.Si.clear(), this.Yi = null
        }
        Ji(e) {
            return e.sort((e, t) => {
                var n, r;
                const o = to(e),
                    i = to(t);
                if (o && !i) return -1;
                if (!o && i) return 1;
                const s = e.schedule === Ct,
                    a = t.schedule === Ct;
                return s && !a ? 1 : !s && a ? -1 : ((null === (n = e.appearance) || void 0 === n ? void 0 : n.surveyPopupDelaySeconds) || 0) - ((null === (r = t.appearance) || void 0 === r ? void 0 : r.surveyPopupDelaySeconds) || 0)
            })
        }
        Li(e) {
            return No(e, this.$i)
        }
        Zi(e, t, n) {
            if (this.Ci.has(e.id)) return !1;
            const {
                params: r
            } = function() {
                const e = {};
                let t = !1;
                const n = window.location.search.replace(/^\?/, "");
                if (!n) return {
                    params: e,
                    autoSubmit: t
                };
                const r = n.split("&");
                for (const n of r) {
                    const r = n.indexOf("=");
                    if (0 >= r) continue;
                    let o, i;
                    try {
                        o = decodeURIComponent(n.slice(0, r)), i = decodeURIComponent(n.slice(r + 1))
                    } catch (e) {
                        continue
                    }
                    if ("auto_submit" === o && "true" === i) {
                        t = !0;
                        continue
                    }
                    const s = o.match(/^q(\d+)$/);
                    if (s) {
                        const t = parseInt(s[1], 10);
                        e[t] || (e[t] = []), e[t].push(i)
                    }
                }
                return {
                    params: e,
                    autoSubmit: t
                }
            }();
            if (0 === Object.keys(r).length) return !1;
            ln.info("[Survey Prefill] Detected URL prefill parameters");
            const o = this.er(e, r, t);
            return !!o && (this.nr(e, o, n, t), this.Ci.add(e.id), o.isSurveyCompleted)
        }
        nr(e, t, n, r) {
            const {
                responses: o,
                submissionId: i,
                isSurveyCompleted: s,
                skippedResponses: a
            } = t;
            (Object.keys(a).length > 0 && e.enable_partial_responses || s) && Lr({
                responses: s ? o : a,
                survey: e,
                surveySubmissionId: i,
                posthog: this.$i,
                isSurveyCompleted: s,
                properties: n,
                surveyLanguage: r
            })
        }
        Ni(e, t, n, r) {
            const o = {};
            for (const [e, n] of Object.entries(t)) o[parseInt(e)] = oe(n) ? n.map(String) : [String(n)];
            ln.info("[Survey] Processing initial responses");
            const i = this.er(e, o, r);
            return !!i && (this.nr(e, i, n, r), i.isSurveyCompleted)
        }
        er(e, t, n) {
            try {
                const r = function(e, t) {
                    const n = {};
                    return e.questions.forEach((e, r) => {
                        if (!t[r] || !e.id) return;
                        const o = t[r],
                            i = Vt(e.id);
                        try {
                            switch (e.type) {
                                case It:
                                    {
                                        if (!e.choices || 0 === e.choices.length) return void Ht.warn(`[Survey Prefill] Question ${r} has no choices`);
                                        const t = parseInt(o[0], 10);
                                        if (isNaN(t) || 0 > t || t >= e.choices.length) return void Ht.warn(`[Survey Prefill] Invalid choice index for q${r}: ${o[0]}`);n[i] = e.choices[t];
                                        break
                                    }
                                case Pt:
                                    {
                                        if (!e.choices || 0 === e.choices.length) return void Ht.warn(`[Survey Prefill] Question ${r} has no choices`);
                                        const t = o.map(e => parseInt(e, 10)).filter(t => !isNaN(t) && t >= 0 && e.choices.length > t);
                                        if (0 === t.length) return void Ht.warn(`[Survey Prefill] No valid choices for q${r}`);
                                        const s = [...new Set(t.map(t => e.choices[t]))];t.length > s.length && Ht.warn(`[Survey Prefill] Removed duplicate choices for q${r}`),
                                        n[i] = s;
                                        break
                                    }
                                case $t:
                                    {
                                        const t = parseInt(o[0], 10),
                                            s = e.scale || 10,
                                            a = 10 === s ? 0 : 1;
                                        if (isNaN(t) || a > t || t > s) return void Ht.warn(`[Survey Prefill] Invalid rating for q${r}: ${o[0]} (scale: ${a}-${s})`);n[i] = t;
                                        break
                                    }
                                default:
                                    Ht.info(`[Survey Prefill] Question type ${e.type} does not support prefill`)
                            }
                        } catch (e) {
                            Ht.error(`[Survey Prefill] Error converting q${r}:`, e)
                        }
                    }), n
                }(e, t);
                if (0 === Object.keys(r).length) return ln.warn("[Survey Prefill] No valid responses after conversion"), null;
                const o = Ue(),
                    {
                        startQuestionIndex: i,
                        skippedResponses: s,
                        skippedIndices: a
                    } = function(e, t, n) {
                        let r = 0;
                        const o = {},
                            i = [],
                            s = e.questions.length + 1;
                        let a = 0;
                        for (; e.questions.length > r && s > a && (a++, t.includes(r));) {
                            const t = e.questions[r];
                            if (!t || !("skipSubmitButton" in t) || !t.skipSubmitButton) break;
                            if (t.id) {
                                const e = Vt(t.id);
                                se(n[e]) || (o[e] = n[e])
                            }
                            i.push(r);
                            const s = Ao(e, r, t.id ? n[Vt(t.id)] : null);
                            if (s === Et) return {
                                startQuestionIndex: e.questions.length,
                                skippedResponses: o,
                                skippedIndices: i
                            };
                            r = s
                        }
                        return {
                            startQuestionIndex: r,
                            skippedResponses: o,
                            skippedIndices: i
                        }
                    }(e, Object.keys(t).map(e => parseInt(e, 10)).filter(t => {
                        const n = e.questions[t];
                        return (null == n ? void 0 : n.id) && !se(r[Vt(n.id)])
                    }), r),
                    l = i >= e.questions.length;
                return Xr(e, {
                    surveySubmissionId: o,
                    responses: r,
                    lastQuestionIndex: i,
                    questionOrder: Hr(e.questions),
                    visitedIndices: a,
                    surveyLanguage: n
                }), ln.info("[Survey Prefill] Stored prefilled responses in localStorage"), {
                    responses: r,
                    submissionId: o,
                    startQuestionIndex: i,
                    isSurveyCompleted: l,
                    skippedResponses: s
                }
            } catch (e) {
                return ln.error("[Survey Prefill] Error handling prefill:", e), null
            }
        }
        ir(e, t) {
            var n;
            if (!e) return !0;
            const r = null === (n = this.$i.client) || void 0 === n ? void 0 : n.getExtension(Y),
                o = !!(null == r ? void 0 : r.isFeatureEnabled(e, {
                    send_event: !e.startsWith("survey-targeting-")
                }));
            let i = !0;
            t && (i = (null == r ? void 0 : r.getFeatureFlag(e, {
                send_event: !1
            })) === t || "any" === t);
            const s = o && i;
            return s || this.rr(e), s
        }
        rr(e) {
            this.Oi || !1 !== this.$i.config.featureFlagEvaluation || (this.Oi = !0, ln.warn(`Survey feature flag "${e}" evaluated to false because advanced_disable_feature_flags is set. PostHog creates an internal targeting flag for almost every survey, so no survey can display while flags are disabled. To keep surveys working, replace advanced_disable_feature_flags with advanced_only_evaluate_survey_feature_flags, which evaluates survey flags only.`))
        }
        sr(e) {
            return !e.conditions || Zr(e, this.$i) && Yr(e) && function(e) {
                var t, n;
                return !(null === (t = e.conditions) || void 0 === t ? void 0 : t.selector) || !!(null === (n = document) || void 0 === n ? void 0 : n.querySelector(e.conditions.selector))
            }(e)
        }
        ar(e) {
            var t;
            return Qr(e) ? {
                satisfied: !0
            } : e.internal_targeting_flag_key && function(e) {
                var t;
                return "recurring" === e.schedule || (null !== (t = e.current_iteration) && void 0 !== t ? t : 0) > 0
            }(e) && !(null === (t = this.$i.client) || void 0 === t || null === (t = t.getExtension("featureFlagsCommon")) || void 0 === t ? void 0 : t.hasLoadedFlags) ? (this.rr(e.internal_targeting_flag_key), {
                satisfied: !1,
                reason: "Feature flags have not loaded yet; deferring internal targeting flag check"
            }) : {
                satisfied: this.ir(e.internal_targeting_flag_key)
            }
        }
        checkSurveyEligibility(e) {
            var t, n;
            const r = {
                eligible: !0,
                reason: void 0
            };
            if (! function(e) {
                    return !(!e.start_date || e.end_date)
                }(e)) return r.eligible = !1, r.reason = `Survey is not running. It was completed on ${e.end_date}`, r;
            if (!dn.includes(e.type)) return r.eligible = !1, r.reason = `Surveys of type ${e.type} are never eligible to be shown in the app`, r;
            const o = null === (t = e.conditions) || void 0 === t ? void 0 : t.linkedFlagVariant;
            if (!this.ir(e.linked_flag_key, o)) return r.eligible = !1, r.reason = o ? `Survey linked feature flag is not enabled for variant ${o}` : "Survey linked feature flag is not enabled", r;
            if (!this.ir(e.targeting_flag_key)) return r.eligible = !1, r.reason = "Survey targeting feature flag is not enabled", r;
            const i = this.ar(e);
            var s;
            return i.satisfied ? (e => {
                let t = null;
                try {
                    t = localStorage.getItem("lastSeenSurveyDate")
                } catch (e) {
                    ln.error("localStorage error: " + e)
                }
                return function(e, t) {
                    if (!e || !t) return !0;
                    const n = "string" == typeof t ? new Date(t) : t,
                        r = Math.abs((new Date).getTime() - n.getTime());
                    return Math.ceil(r / 864e5) > e
                }(e, t)
            })(null === (n = e.conditions) || void 0 === n ? void 0 : n.seenSurveyWaitPeriodInDays) ? ((e => {
                let t = null;
                try {
                    t = localStorage.getItem(cn(e))
                } catch (e) {
                    ln.error("localStorage error: " + e)
                }
                return !!t && !Qr(e)
            })(e) && (r.eligible = !1, r.reason = "Survey has already been seen and it can't be activated again"), r) : (r.eligible = !1, r.reason = "Survey wait period has not passed", r) : (r.eligible = !1, r.reason = null !== (s = i.reason) && void 0 !== s ? s : "Survey internal targeting flag is not enabled and survey cannot activate repeatedly and survey is not in progress", r)
        }
        checkSurveyCaptureEligibility() {
            var e;
            return (null === (e = this.$i.client) || void 0 === e ? void 0 : e.canCapture) ? {
                eligible: !0
            } : {
                eligible: !1,
                reason: "PostHog is not capturing, so a survey response cannot be recorded"
            }
        }
        checkSurveyDisplayEligibility(e) {
            const t = this.checkSurveyCaptureEligibility();
            return t.eligible ? this.checkSurveyEligibility(e) : t
        }
        checkSurveyRenderability(e) {
            const t = this.checkSurveyDisplayEligibility(e);
            return t.eligible && !this.lr(e) ? {
                eligible: !1,
                reason: "Survey event/action trigger has not been fired yet"
            } : t
        }
        lr(e) {
            var t;
            if (!nn(e) && ! function(e) {
                    var t;
                    return !!(null === (t = e.conditions) || void 0 === t || null === (t = t.actions) || void 0 === t || null === (t = t.values) || void 0 === t ? void 0 : t.length)
                }(e)) return !0;
            const n = null === (t = this.$i.surveys) || void 0 === t || null === (t = t._surveyEventReceiver) || void 0 === t ? void 0 : t.getSurveys();
            return !!(null == n ? void 0 : n.includes(e.id))
        }
        ur(e) {
            var t;
            return !(null === (t = e.feature_flag_keys) || void 0 === t ? void 0 : t.length) || e.feature_flag_keys.every(({
                key: e,
                value: t
            }) => !e || !t || this.ir(t))
        }
        Bi(e) {
            return this.checkSurveyEligibility(e).eligible && this.sr(e) && this.lr(e) && this.ur(e)
        }
        Gi(e) {
            try {
                const t = document.querySelector(ro(e, !0));
                (null == t ? void 0 : t.shadowRoot) && (V(null, t.shadowRoot), this.xi.delete(t.shadowRoot)), null == t || t.remove()
            } catch (t) {
                ln.warn(`Failed to remove survey ${e.id} from DOM:`, t)
            }
        }
        getTestAPI() {
            return {
                addSurveyToFocus: this.qi,
                removeSurveyFromFocus: this.ji,
                surveyInFocus: this.Yi,
                surveyTimeouts: this.wi,
                handleWidget: this.zi,
                handlePopoverSurvey: this.handlePopoverSurvey,
                manageWidgetSelectorListener: this.Qi,
                sortSurveysByAppearanceDelay: this.Ji.bind(this),
                checkFlags: this.ur.bind(this),
                isSurveyFeatureFlagEnabled: this.ir.bind(this),
                onLanguageChange: this.Ki.bind(this),
                currentLanguage: this.Ii,
                surveyIsRendered: this.Mi
            }
        }
    };

    function Ro({
        survey: e,
        removeSurveyFromFocus: t = () => {},
        setSurveyVisible: n,
        isPreviewMode: r = !1,
        posthog: o
    }) {
        at(() => {
            var i;
            if (r || !(null === (i = e.conditions) || void 0 === i ? void 0 : i.url)) return;
            const s = () => {
                var r;
                const i = e.type === Tt,
                    s = Zr(e, o),
                    a = (null === (r = e.appearance) || void 0 === r ? void 0 : r.widgetType) === gt && i;
                if (!s) return ln.info(`Hiding survey ${e.id} because URL does not match`), n(!1), t(e);
                a && (ln.info(`Showing survey ${e.id} because it is a feedback button tab and URL matches`), n(!0))
            };
            Qt(window, "popstate", s), Qt(window, "hashchange", s);
            const a = window.history.pushState,
                l = window.history.replaceState;
            return window.history.pushState = function(...e) {
                a.apply(this, e), s()
            }, window.history.replaceState = function(...e) {
                l.apply(this, e), s()
            }, () => {
                window.removeEventListener("popstate", s), window.removeEventListener("hashchange", s), window.history.pushState = a, window.history.replaceState = l
            }
        }, [r, e, t, n, o])
    }
    const Fo = 200;

    function Bo(e = "right") {
        switch (e) {
            case "top":
                return {
                    top: "0",
                    left: "50%",
                    transform: "translateX(-50%)"
                };
            case "left":
                return {
                    top: "50%",
                    left: "0",
                    transform: "rotate(90deg) translateY(-100%)",
                    transformOrigin: "left top"
                };
            case "bottom":
                return {
                    bottom: "0",
                    left: "50%",
                    transform: "translateX(-50%)"
                };
            default:
                return {
                    top: "50%",
                    right: "0",
                    transform: "rotate(-90deg) translateY(-100%)",
                    transformOrigin: "right top"
                }
        }
    }

    function Ho({
        survey: e,
        forceDisableHtml: t,
        posthog: n,
        style: r = {},
        previewPageIndex: o,
        removeSurveyFromFocus: i = () => {},
        isPopup: s = !0,
        onPreviewSubmit: a = () => {},
        onPreviewBack: l = () => {},
        onPopupSurveyDismissed: u = () => {},
        onCloseConfirmationMessage: c = () => {},
        properties: d,
        isSurveyCompleted: f,
        skipShownEvent: p,
        surveyLanguage: h
    }) {
        var v, m, y, g, b, w, x, k, S, T, _, q;
        const P = lt(null),
            I = Number.isInteger(o),
            {
                isPopupVisible: E,
                isSurveySent: C,
                hidePopupWithAnimation: M
            } = function(e, t, n, r, o, i, s, a, l) {
                const [u, c] = st(r || 0 === n || e.type === _t), [d, f] = st(!1), p = lt(!1), h = () => {
                    const t = () => {
                        i && o(e), c(!1)
                    };
                    if (p.current) return;
                    const n = null == s ? void 0 : s.current;
                    n ? (p.current = !0, n.style.transition = `opacity ${Fo}ms ease-out`, n.style.opacity = "0", setTimeout(() => {
                        p.current = !1, t()
                    }, 250)) : t()
                }, v = t => {
                    t.detail.surveyId === e.id && h()
                };
                return at(() => {
                    if (!t) return void ln.error("usePopupVisibility hook called without a PostHog instance.");
                    if (r) return;
                    let o;
                    const i = t => {
                            var n, r;
                            if (t.detail.surveyId === e.id) {
                                if (!(null === (n = e.appearance) || void 0 === n ? void 0 : n.displayThankYouMessage)) return h();
                                f(!0), (null === (r = e.appearance) || void 0 === r ? void 0 : r.autoDisappear) && (o && clearTimeout(o), o = setTimeout(h, 5e3))
                            }
                        },
                        s = () => {
                            var n;
                            if (Zr(e, t)) {
                                c(!0);
                                try {
                                    localStorage.setItem("lastSeenSurveyDate", (new Date).toISOString())
                                } catch (e) {}
                                window.dispatchEvent(new Event("PHSurveyShown")), a || null === (n = t.client) || void 0 === n || n.capture(Mt, Me(Me({
                                    [jt]: e.name,
                                    [Nt]: e.id,
                                    [Ot]: e.current_iteration,
                                    [zt]: e.current_iteration_start_date
                                }, l && {
                                    [Lt]: l
                                }), {}, {
                                    sessionRecordingUrl: K(t)
                                }))
                            }
                        };
                    Qt(window, "PHSurveyClosed", v), Qt(window, "PHSurveySent", i);
                    const u = n > 0 ? setTimeout(s, n) : void 0;
                    return se(u) && s(), () => {
                        se(u) || clearTimeout(u), se(o) || clearTimeout(o), window.removeEventListener("PHSurveyClosed", v), window.removeEventListener("PHSurveySent", i)
                    }
                }, []), Ro({
                    survey: e,
                    removeSurveyFromFocus: o,
                    setSurveyVisible: c,
                    isPreviewMode: r,
                    posthog: t
                }), {
                    isPopupVisible: u,
                    isSurveySent: d,
                    setIsPopupVisible: c,
                    hidePopupWithAnimation: h
                }
            }(e, n, (null === (v = e.appearance) || void 0 === v ? void 0 : v.surveyPopupDelaySeconds) ? 1e3 * e.appearance.surveyPopupDelaySeconds : 0, I, i, s, P, p, h),
            A = C || o === e.questions.length || !0 === f,
            [D, N] = st(!1),
            j = ut(() => !!eo(e), [e]),
            O = !(!(null === (m = e.appearance) || void 0 === m ? void 0 : m.introScreenHeader) && !(null === (y = e.appearance) || void 0 === y ? void 0 : y.introScreenDescription)),
            z = I ? -1 === o : !!(null === (g = e.appearance) || void 0 === g ? void 0 : g.displayIntroScreen) && O && !D && !j,
            L = ut(() => {
                const t = eo(e),
                    r = (null == t ? void 0 : t.surveySubmissionId) || Ue() || "";
                return {
                    isPreviewMode: I,
                    previewPageIndex: o,
                    onPopupSurveyDismissed() {
                        h ? Fr(e, n, I, h) : Fr(e, n, I), u()
                    },
                    isPopup: s || !1,
                    surveySubmissionId: r,
                    onPreviewSubmit: a,
                    onPreviewBack: l,
                    posthog: n,
                    properties: d,
                    surveyLanguage: h
                }
            }, [I, o, s, n, e, u, a, l, d, h]);
        return E ? G(Vr.Provider, {
            value: L,
            children: G("div", {
                className: "ph-survey",
                style: Me(Me({}, oo(e.type, null === (b = e.appearance) || void 0 === b ? void 0 : b.position, null === (w = e.appearance) || void 0 === w ? void 0 : w.widgetType)), r),
                ref: P,
                children: A ? G(bo, {
                    header: (null === (x = e.appearance) || void 0 === x ? void 0 : x.thankYouMessageHeader) || "Thank you!",
                    description: (null === (k = e.appearance) || void 0 === k ? void 0 : k.thankYouMessageDescription) || "",
                    forceDisableHtml: !!t,
                    contentType: null === (S = e.appearance) || void 0 === S ? void 0 : S.thankYouMessageDescriptionContentType,
                    appearance: e.appearance || Ar,
                    onClose() {
                        M(), c()
                    }
                }) : z ? G(wo, {
                    header: (null === (T = e.appearance) || void 0 === T ? void 0 : T.introScreenHeader) || "",
                    description: (null === (_ = e.appearance) || void 0 === _ ? void 0 : _.introScreenDescription) || "",
                    forceDisableHtml: !!t,
                    contentType: null === (q = e.appearance) || void 0 === q ? void 0 : q.introScreenDescriptionContentType,
                    appearance: e.appearance || Ar,
                    onStart: () => N(!0)
                }) : G(Uo, {
                    survey: e,
                    forceDisableHtml: !!t,
                    posthog: n
                })
            })
        }) : null
    }

    function Uo({
        survey: e,
        forceDisableHtml: t,
        posthog: n
    }) {
        var r, o;
        const i = ut(() => {
                const t = eo(e);
                if (!t) return null;
                const n = ce(t.lastQuestionIndex);
                return !n || n && t.lastQuestionIndex >= 0 && e.questions.length > t.lastQuestionIndex ? t : (no(e), null)
            }, [e]),
            [s, a] = st(() => ((null == i ? void 0 : i.responses) && ln.info("Survey is already in progress, filling in initial responses"), (null == i ? void 0 : i.responses) || {})),
            [l, u] = st(!1),
            {
                previewPageIndex: c,
                onPopupSurveyDismissed: d,
                isPopup: f,
                onPreviewSubmit: p,
                onPreviewBack: h,
                surveySubmissionId: v,
                isPreviewMode: m,
                properties: y,
                surveyLanguage: g
            } = ct(Vr),
            [b, w] = st(() => {
                const t = null == i ? void 0 : i.lastQuestionIndex,
                    n = ce(t) && t >= 0 && e.questions.length > t ? t : 0;
                return ce(c) && c >= 0 ? c : n
            }),
            [x, k] = st(() => {
                var t;
                return (null !== (t = null == i ? void 0 : i.visitedIndices) && void 0 !== t ? t : []).filter(t => t >= 0 && e.questions.length > t)
            }),
            [S, T] = st(() => {
                var t;
                const n = eo(e);
                return null !== (t = null == n ? void 0 : n.questionSnapshots) && void 0 !== t ? t : {}
            }),
            _ = ut(() => Hr(Ur(e, i)), [e.id, i]),
            q = ut(() => {
                if (!_ || new Set(_).size !== _.length) return Ur(e, i);
                const t = new Map(e.questions.map(e => [e.id, e])),
                    n = _.map(e => t.get(e)).filter(e => !!e);
                return n.length === _.length ? n : e.questions
            }, [_, e.questions, e, i]);
        at(() => {
            !m || se(c) || 0 > c || w(c)
        }, [c, m]);
        const P = !!(null === (r = e.appearance) || void 0 === r ? void 0 : r.allowGoBack) && (m ? (null != c ? c : 0) > 0 : x.length > 0),
            I = q.at(b);
        return I ? G("form", {
            className: "survey-form",
            name: "surveyForm",
            children: [f && !0 !== (null === (o = e.appearance) || void 0 === o ? void 0 : o.hideCancelButton) && G(go, {
                onClick() {
                    d()
                }
            }), G("div", {
                className: "survey-box",
                "data-question-index": b,
                children: [l && G("p", {
                    role: "alert",
                    children: "Your response could not be sent. Please try again later."
                }), Vo({
                    question: I,
                    forceDisableHtml: t,
                    displayQuestionIndex: b,
                    appearance: e.appearance || Ar,
                    onSubmit: t => (({
                        res: t,
                        displayQuestionIndex: r,
                        questionId: o
                    }) => {
                        var i;
                        if (!n) return void ln.error("onNextButtonClick called without a PostHog instance.");
                        if (!(null === (i = n.client) || void 0 === i ? void 0 : i.canCapture)) return void u(!0);
                        if (u(!1), !o) return void ln.error("onNextButtonClick called without a questionId.");
                        const {
                            responses: l,
                            questionSnapshots: c
                        } = function({
                            responses: e,
                            questionSnapshots: t = {}
                        }, n, r, o) {
                            return {
                                responses: Me(Me({}, e), {}, {
                                    [Vt(n)]: r
                                }),
                                questionSnapshots: (null == o ? void 0 : o.id) ? Me(Me({}, t), {}, {
                                    [o.id]: o.question
                                }) : t
                            }
                        }({
                            responses: s,
                            questionSnapshots: S
                        }, o, t, q[r]);
                        a(l), T(c);
                        const d = Ao(e, r, t),
                            f = d === Et,
                            p = [...x, r];
                        if (f || (k(p), w(d), Xr(e, {
                                surveySubmissionId: v,
                                responses: l,
                                lastQuestionIndex: d,
                                questionOrder: Hr(q),
                                visitedIndices: p,
                                surveyLanguage: g,
                                questionSnapshots: c
                            })), e.enable_partial_responses || f) {
                            const t = new Set(p.map(e => {
                                    var t;
                                    return null === (t = q[e]) || void 0 === t ? void 0 : t.id
                                }).filter(e => !!e).map(e => Vt(e))),
                                r = Object.fromEntries(Object.entries(l).filter(([e]) => t.has(e)));
                            Lr({
                                responses: r,
                                survey: e,
                                surveySubmissionId: v,
                                isSurveyCompleted: f,
                                posthog: n,
                                properties: y,
                                surveyLanguage: g,
                                questionSnapshots: c
                            })
                        }
                    })({
                        res: t,
                        displayQuestionIndex: b,
                        questionId: I.id
                    }),
                    onPreviewSubmit: p,
                    initialValue: I.id ? s[Vt(I.id)] : void 0,
                    canGoBack: P,
                    onBack() {
                        if (m) return void h();
                        if (0 === x.length) return;
                        const t = x[x.length - 1],
                            n = x.slice(0, -1);
                        k(n), w(t), Xr(e, {
                            surveySubmissionId: v,
                            responses: s,
                            lastQuestionIndex: t,
                            questionOrder: Hr(q),
                            visitedIndices: n,
                            surveyLanguage: g,
                            questionSnapshots: S
                        })
                    }
                })]
            })]
        }) : null
    }

    function Qo({
        survey: e,
        forceDisableHtml: t,
        posthog: n,
        readOnly: r,
        surveyLanguage: o
    }) {
        var i, s, a, l, u, c, d, f;
        const [p, h] = st(!0), [v, m] = st(!1), [y, g] = st({}), b = lt(void 0), w = () => {
            var e;
            (v || !n || r || (null === (e = n.client) || void 0 === e ? void 0 : e.canCapture)) && m(!v)
        };
        if (at(() => {
                var t, o, i;
                if (!n) return void ln.error("FeedbackWidget called without a PostHog instance.");
                if (r) return;
                "tab" === (null === (t = e.appearance) || void 0 === t ? void 0 : t.widgetType) && g((i = null === (o = e.appearance) || void 0 === o ? void 0 : o.position) && i !== xt && i !== kt ? {} : {
                    top: "50%",
                    bottom: "auto"
                });
                const s = t => {
                    var n;
                    const r = t;
                    (null === (n = r.detail) || void 0 === n ? void 0 : n.surveyId) === e.id && (ln.info(`Received show event for feedback button survey ${e.id}`), g(r.detail.position || {}), w())
                };
                return Qt(window, jo, s), () => {
                    se(b.current) || (clearTimeout(b.current), b.current = void 0), window.removeEventListener(jo, s)
                }
            }, [n, r, e.id, null === (i = e.appearance) || void 0 === i ? void 0 : i.widgetType, null === (s = e.appearance) || void 0 === s ? void 0 : s.position, null === (a = e.appearance) || void 0 === a ? void 0 : a.widgetSelector, null === (l = e.appearance) || void 0 === l ? void 0 : l.borderColor]), Ro({
                survey: e,
                setSurveyVisible: h,
                posthog: n
            }), !p) return null;
        const x = () => {
            e.schedule !== Ct && h(!1), se(b.current) || clearTimeout(b.current), b.current = setTimeout(() => {
                b.current = void 0, m(!1)
            }, 200)
        };
        return G(T, {
            children: ["tab" === (null === (u = e.appearance) || void 0 === u ? void 0 : u.widgetType) && G("button", {
                className: "ph-survey-widget-tab " + ("top" === (null === (c = e.appearance) || void 0 === c ? void 0 : c.tabPosition) ? "widget-tab-top" : ""),
                onClick: w,
                disabled: r,
                style: Bo(null === (d = e.appearance) || void 0 === d ? void 0 : d.tabPosition),
                children: (null === (f = e.appearance) || void 0 === f ? void 0 : f.widgetLabel) || ""
            }), v && G(Ho, {
                posthog: n,
                survey: e,
                forceDisableHtml: t,
                style: y,
                onPopupSurveyDismissed: x,
                onCloseConfirmationMessage: x,
                surveyLanguage: o
            })]
        })
    }
    const Vo = ({
        question: e,
        forceDisableHtml: t,
        displayQuestionIndex: n,
        appearance: r,
        onSubmit: o,
        onPreviewSubmit: i,
        initialValue: s,
        canGoBack: a,
        onBack: l
    }) => {
        const u = {
            forceDisableHtml: t,
            appearance: r,
            onPreviewSubmit(e) {
                i(e)
            },
            onSubmit(e) {
                o(e)
            },
            initialValue: s,
            displayQuestionIndex: n,
            canGoBack: a,
            onBack: l
        };
        switch (e.type) {
            case qt:
                return k(ko, Me(Me({}, u), {}, {
                    question: e,
                    key: e.id
                }));
            case "link":
                return k(So, Me(Me({}, u), {}, {
                    question: e,
                    key: e.id
                }));
            case $t:
                return k(To, Me(Me({}, u), {}, {
                    question: e,
                    key: e.id
                }));
            case It:
            case Pt:
                return k(qo, Me(Me({}, u), {}, {
                    question: e,
                    key: e.id
                }));
            default:
                return ln.error(`Unsupported question type: ${e.type}`), null
        }
    };

    function Wo(e) {
        let t = !0;
        return {
            dispose() {
                if (t) {
                    t = !1;
                    const n = e();
                    n && ie(n.then) && n.then(void 0, () => {})
                }
            }
        }
    }
    const Go = "u" > typeof window ? window : void 0,
        Zo = "u" > typeof globalThis ? globalThis : Go;
    null != Zo && Zo.XMLHttpRequest && new Zo.XMLHttpRequest;
    const Yo = "undefined" != typeof globalThis ? globalThis : Go;
    Yo && "undefined" == typeof self && (Yo.self = Yo), Yo && "undefined" == typeof File && (Yo.File = function() {});
    const Ko = null != Go ? Go : {};
    Ft.DEBUG = !1, Ft.LIB_VERSION = "1.445.3", Ft.LIB_NAME = "web";
    var Jo = Ft;
    Ut("[AutoCapture]");
    const Xo = (e, t) => {
            try {
                let n;
                return JSON.stringify(e, (e, t) => {
                    var r;
                    return function(e) {
                        switch ({}.toString.call(e)) {
                            case "[object Error]":
                            case "[object Exception]":
                            case "[object DOMException]":
                            case "[object DOMError]":
                            case "[object WebAssembly.Exception]":
                                return !0;
                            default:
                                return function(e, t) {
                                    try {
                                        return e instanceof t
                                    } catch (e) {
                                        return !1
                                    }
                                }(e, Error)
                        }
                    }(t) ? (null !== (r = n) && void 0 !== r || (n = new WeakMap), n.has(t) || n.set(t, function(e) {
                        const t = Me({}, e);
                        for (const n of ["name", "message", "stack", "cause", "errors"]) try {
                            n in e && (t[n] = e[n])
                        } catch (e) {}
                        return t
                    }(t)), n.get(t)) : "bigint" == typeof t ? t.toString() : t
                }, t)
            } catch (t) {
                return function(e) {
                    var t;
                    const n = [];
                    return null !== (t = JSON.stringify(e, function(e, t) {
                        if ("bigint" == typeof t) return t.toString();
                        if ("function" != typeof t && "symbol" != typeof t) {
                            if (t instanceof Error) return {
                                name: t.name,
                                message: t.message,
                                stack: t.stack
                            };
                            if (t && "object" == typeof t) {
                                for (; n.length > 0 && n[n.length - 1] !== this;) n.pop();
                                if (n.includes(t)) return "[Circular]";
                                n.push(t)
                            }
                            return t
                        }
                    })) && void 0 !== t ? t : "null"
                }(e)
            }
        },
        ei = function(e, t = "&") {
            let n, r;
            const o = [];
            return function(e, t) {
                if (!ue(e))
                    if (oe(e)) e.forEach(t);
                    else if ((e => e instanceof FormData)(e)) e.forEach((e, n) => t(e, n));
                else
                    for (const n in e) ne.call(e, n) && t(e[n], n)
            }(e, function(e, t) {
                se(e) || se(t) || "undefined" === t || (n = encodeURIComponent((e => e instanceof File)(e) ? e.name : e.toString()), r = encodeURIComponent(t), o[o.length] = r + "=" + n)
            }), o.join(t)
        };
    fe(function*(e) {
        const t = yield function(e) {
            return je.apply(this, arguments)
        }(Xo(e.data), Jo.DEBUG, {
            rethrow: !0
        });
        if (!t) return e;
        const n = yield t.arrayBuffer();
        return Me(Me({}, e), {}, {
            cr: {
                contentType: "text/plain",
                body: n,
                estimatedSize: n.byteLength
            }
        })
    });
    var ti = class {
            constructor(e) {
                this._instance = e
            }
            initialize() {}
            get(e) {
                const t = this._instance.persistence;
                if ("string" == typeof e) return null == t ? void 0 : t.get_property(e);
                const n = {};
                for (const r of e) {
                    const e = null == t ? void 0 : t.get_property(r);
                    se(e) || (n[r] = e)
                }
                return n
            }
            set(e, t) {
                var n;
                null === (n = this._instance.persistence) || void 0 === n || n.register("string" == typeof e ? {
                    [e]: t
                } : e)
            }
            remove(e) {
                var t;
                null === (t = this._instance.persistence) || void 0 === t || t.unregister(e)
            }
        },
        ni = class {
            constructor(e) {
                this.instance = e, this.A = Ht, this.kv = new ti(e), this.onSession = e => Wo(this.instance.onSessionId(t => {
                    try {
                        e(t)
                    } catch (e) {
                        this.A.error("Browser extension session listener failed", e)
                    }
                })), this.onEvent = e => Wo(this.instance._addCaptureHook((t, n) => {
                    if (n) try {
                        e({
                            event: t,
                            properties: n.properties
                        })
                    } catch (e) {
                        this.A.error("Browser extension event listener failed", e)
                    }
                })), this.onRemoteConfig = e => {
                    const t = t => {
                            try {
                                e(t)
                            } catch (e) {
                                this.A.error("Browser extension remote config listener failed", e)
                            }
                        },
                        n = this.instance.dr.on("extensionsRemoteConfig", t);
                    return this.instance.vr && t(this.instance.vr), Wo(n)
                }
            }
            get logger() {
                return this.A
            }
            get distinctId() {
                return this.instance.get_distinct_id()
            }
            get anonymousId() {
                var e;
                return null !== (e = this.instance.get_property("$device_id")) && void 0 !== e ? e : this.distinctId
            }
            get deviceId() {
                const e = this.instance.get_property("$device_id");
                return "string" == typeof e ? e : void 0
            }
            get library() {
                return {
                    name: Jo.LIB_NAME,
                    version: Jo.LIB_VERSION
                }
            }
            get initialPersonProperties() {
                var e, t;
                return null !== (e = null === (t = this.instance.persistence) || void 0 === t ? void 0 : t.get_initial_props()) && void 0 !== e ? e : {}
            }
            get groups() {
                return this.instance.getGroups()
            }
            get session() {
                try {
                    var e, t, n, r, o;
                    const i = null === (e = this.instance.sessionManager) || void 0 === e ? void 0 : e.checkAndGetSessionAndWindowId(!0);
                    return {
                        sessionId: null !== (t = null == i ? void 0 : i.sessionId) && void 0 !== t ? t : "",
                        windowId: null !== (n = null == i ? void 0 : i.windowId) && void 0 !== n ? n : "",
                        sessionStartTimestamp: null !== (r = null == i ? void 0 : i.sessionStartTimestamp) && void 0 !== r ? r : 0,
                        lastActivityTimestamp: null !== (o = null == i ? void 0 : i.lastActivityTimestamp) && void 0 !== o ? o : 0
                    }
                } catch (e) {
                    return {
                        sessionId: "",
                        windowId: "",
                        sessionStartTimestamp: 0,
                        lastActivityTimestamp: 0
                    }
                }
            }
            get isOptedOut() {
                return this.instance.has_opted_out_capturing()
            }
            get canCapture() {
                return ie(this.instance.is_capturing) ? this.instance.is_capturing() : !this.isOptedOut
            }
            get projectToken() {
                return this.instance.config.token
            }
            getExtension(e) {
                let t;
                switch (e) {
                    case "featureFlags":
                    case Y:
                        t = this.instance.featureFlags;
                        break;
                    case "logs":
                        t = this.instance.logs;
                        break;
                    case "surveys":
                        t = this.instance.surveys;
                        break;
                    case "autocapture":
                        t = this.instance.autocapture
                }
                return t
            }
            capture(e, t, n) {
                if (!n) return void this.instance.capture(e, t);
                const r = Me({
                    timestamp: n.timestamp,
                    uuid: n.uuid,
                    $set: n.set,
                    $set_once: n.setOnce
                }, "unload" === n.delivery ? {
                    transport: "sendBeacon",
                    send_instantly: !0
                } : {});
                this.instance.capture(e, t, r)
            }
            registerDynamicEventProperties(e) {
                return Wo(this.instance.pr(e))
            }
            sendRequest(e) {
                var t = this;
                return fe(function*(e, n = {}) {
                    var r;
                    const o = null !== (r = n.target) && void 0 !== r ? r : "api",
                        i = n.query ? ((e, t, n = !0) => {
                            var r;
                            const [o, i] = e.split("?"), s = Me({}, t), a = null !== (r = null == i ? void 0 : i.split("&").map(e => {
                                var t;
                                const [r, o] = e.split("="), i = n && null !== (t = s[r]) && void 0 !== t ? t : o;
                                return delete s[r], `${r}=${i}`
                            })) && void 0 !== r ? r : [], l = ei(s);
                            return l && a.push(l), a.length > 0 ? `${o}?${a.join("&")}` : o
                        })(e, n.query) : e,
                        s = t.instance.requestRouter.endpointFor(o, i),
                        a = {
                            method: n.method,
                            url: s,
                            data: n.body,
                            headers: n.headers,
                            timeout: n.timeoutMs,
                            fireCallbackOnDrop: !0,
                            transport: n.transport,
                            compression: n.compression,
                            compressionFallback: "flags" === n.target && "best-available" === n.compression ? J.Base64 : void 0,
                            timestampMode: n.sentAt
                        };
                    return "api" === o && "/i/v1/logs" === e && (a.batchKey = "logs"), "sendBeacon" === n.transport ? (t.instance._send_request(a), {
                        statusCode: 202
                    }) : new Promise(e => {
                        a.callback = e, t.instance._send_request(a)
                    })
                }).apply(this, arguments)
            }
        },
        ri = class {
            constructor(e) {
                this._instance = e
            }
            get() {
                var e, t, n, r;
                const o = null === (e = this._instance) || void 0 === e ? void 0 : e.config;
                return {
                    disableSurveys: !!(null == o ? void 0 : o.disable_surveys),
                    cookielessMode: !!(null == o ? void 0 : o.cookieless_mode),
                    advancedEnableSurveys: !!(null == o ? void 0 : o.advanced_enable_surveys),
                    requestTimeoutMs: null !== (t = null == o ? void 0 : o.surveys_request_timeout_ms) && void 0 !== t ? t : 1e4,
                    prefillFromUrl: !!(null == o || null === (n = o.surveys) || void 0 === n ? void 0 : n.prefillFromUrl),
                    automaticDisplay: !(null == o ? void 0 : o.disable_surveys_automatic_display),
                    featureFlagEvaluation: !(null == o ? void 0 : o.advanced_disable_feature_flags),
                    overrideLanguage: null == o ? void 0 : o.override_display_language,
                    prepareStylesheet: null == o ? void 0 : o.prepare_external_dependency_stylesheet,
                    get_current_url: null == o ? void 0 : o.get_current_url,
                    uiHost: null === (r = this._instance) || void 0 === r || null === (r = r.requestRouter) || void 0 === r ? void 0 : r.endpointFor("ui", "")
                }
            }
            getExtensions() {
                const e = null == Ko ? void 0 : Ko.__PosthogExtensions__;
                if (!e || !this._instance) return;
                const t = this._instance,
                    {
                        generateSurveys: n,
                        loadExternalDependency: r
                    } = e;
                return {
                    generateSurveys: n ? e => n(t, e) : void 0,
                    loadExternalDependency: r ? e => r(t, "surveys", e) : void 0
                }
            }
            onMatchingConditionsChanged(e) {
                var t, n;
                const r = null === (t = this._instance) || void 0 === t ? void 0 : t._addCaptureHook(t => {
                        "$pageview" !== t && t !== Mt && t !== At && t !== Dt || e()
                    }),
                    o = () => e();
                Qt(Go, "PHSurveyShown", o);
                let i = !1;
                const s = null === (n = this._instance) || void 0 === n ? void 0 : n.onFeatureFlags(() => {
                    i && e()
                });
                return i = !0, () => {
                    i = !1, null == r || r(), null == s || s(), null == Go || Go.removeEventListener("PHSurveyShown", o)
                }
            }
        };
    const oi = new WeakMap,
        ii = (e, t) => {
            const n = function(e) {
                var t;
                const n = new ri(e);
                if (!e) return {
                    get config() {
                        return n.get()
                    }
                };
                if (null === (t = e.surveys) || void 0 === t ? void 0 : t.getRenderContext) return e.surveys.getRenderContext();
                let r = oi.get(e);
                return r || (r = {
                    client: new ni(e),
                    get config() {
                        return n.get()
                    },
                    surveys: e.surveys
                }, oi.set(e, r)), r
            }(e);
            return n ? function(e, t) {
                if (typeof document > "u" || typeof window > "u") return;
                const n = new Lo(e);
                return !1 === e.config.automaticDisplay ? (ln.info("Surveys automatic display is disabled. Skipping call surveys and evaluate display logic."), n) : !1 === t ? (ln.info("There are no surveys to load or Surveys is disabled in the project settings."), n) : (n.startAutomaticDisplay(), n)
            }(n, t) : void 0
        };
    Ko.__PosthogExtensions__ = Ko.__PosthogExtensions__ || {}, Ko.__PosthogExtensions__.generateSurveys = ii, Ko.extendPostHogWithSurveys = ii, e.default = ii, e.generateSurveys = ii
}({});
//# sourceMappingURL=surveys.js.map